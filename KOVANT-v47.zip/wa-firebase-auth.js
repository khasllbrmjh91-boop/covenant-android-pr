'use strict';
/**
 * بديل useMultiFileAuthState: يحفظ جلسة Baileys (creds + keys) في Firebase Realtime Database
 * بدل الملفات المحلية التي تُمسح على Render المجاني عند النوم.
 *
 * البنية في قاعدة البيانات:
 *   <basePath>/creds                      ← نص JSON (Buffer مُرمَّز عبر BufferJSON)
 *   <basePath>/keys/<type>/<id>           ← نص JSON لكل مفتاح
 *
 * ملاحظات:
 *  - مفاتيح Firebase لا تقبل  . $ # [ ] /  فنرمّزها بـ %XX (مفاتيح app-state-sync-key base64 قد تحوي "/").
 *  - كل الكتابات تمر عبر طابور متسلسل كي لا يسبق اتصالٌ جديد كتابةَ creds السابقة (مهم بعد مسح الباركود).
 *  - المسار يجب أن يكون محجوباً عن عملاء التطبيق في قواعد Firebase (السيرفر يستخدم Admin SDK فيتجاوز القواعد).
 *
 * @param {import('firebase-admin').database.Database} db
 * @param {string} basePath  مثل 'whatsapp_session'
 * @param {{initAuthCreds:Function, BufferJSON:{replacer:Function,reviver:Function}, proto:any}} lib  من @whiskeysockets/baileys
 */
function encodeKey(value) {
    return String(value).replace(/[%.$#[\]/]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0'));
}

async function useFirebaseAuthState(db, basePath, lib) {
    const root = db.ref(basePath);
    const { initAuthCreds, BufferJSON, proto } = lib;

    let queue = Promise.resolve();
    const enqueue = (fn) => {
        const p = queue.then(fn);
        queue = p.catch(() => {});
        return p;
    };
    const serialize = (v) => JSON.stringify(v, BufferJSON.replacer);
    const deserialize = (s) => (s == null ? null : JSON.parse(s, BufferJSON.reviver));

    await queue; // لا شيء معلّق عند البدء
    const credsSnap = await root.child('creds').once('value');
    const creds = deserialize(credsSnap.val()) || initAuthCreds();

    const keys = {
        get: async (type, ids) => {
            await queue; // نقرأ بعد انتهاء أي كتابة معلّقة
            const data = {};
            await Promise.all(ids.map(async (id) => {
                const snap = await root.child('keys/' + encodeKey(type) + '/' + encodeKey(id)).once('value');
                let value = deserialize(snap.val());
                if (type === 'app-state-sync-key' && value) {
                    value = proto.Message.AppStateSyncKeyData.fromObject(value);
                }
                data[id] = value;
            }));
            return data;
        },
        set: (data) => {
            const updates = {};
            for (const type of Object.keys(data)) {
                for (const id of Object.keys(data[type])) {
                    const value = data[type][id];
                    updates['keys/' + encodeKey(type) + '/' + encodeKey(id)] = value ? serialize(value) : null;
                }
            }
            if (!Object.keys(updates).length) return Promise.resolve();
            return enqueue(() => root.update(updates));
        }
    };

    return {
        state: { creds, keys },
        // حفظ فوري للجلسة في Firebase (يُستدعى عند كل creds.update)
        saveCreds: () => enqueue(() => root.child('creds').set(serialize(creds))),
        // انتظار انتهاء كل الكتابات المعلّقة
        flush: () => queue
    };
}

// هل توجد جلسة مربوطة محفوظة؟ (يُستخدم للاستئناف التلقائي بعد نوم/إعادة تشغيل السيرفر)
async function hasRegisteredSession(db, basePath) {
    const snap = await db.ref(basePath + '/creds').once('value');
    const raw = snap.val();
    if (!raw) return false;
    try { return !!JSON.parse(raw).registered; } catch (_) { return false; }
}

async function clearSession(db, basePath) {
    await db.ref(basePath).remove();
}

module.exports = { useFirebaseAuthState, hasRegisteredSession, clearSession, encodeKey };
