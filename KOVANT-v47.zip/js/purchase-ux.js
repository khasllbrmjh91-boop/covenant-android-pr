/* ============================================================
 * COVANT — PURCHASE UX
 * - مؤشر تحميل (دائرة نقاط تدور) بدون أي مربع حولها
 * - تأثير بصري عند نسخ الكود (بدون أي صوت)
 * - فترة صمت: لا يُشغَّل أي صوت أثناء الشراء أو عرض الكرت
 * ============================================================ */
(function (window, document) {
    'use strict';
    if (window.PurchaseUX) return;

    var DOT_COUNT = 12;
    var loaderEl = null;
    var quietUntil = 0;
    var copyTimers = [];

    /* ---------- فترة الصمت ---------- */
    function quiet(ms) {
        quietUntil = Math.max(quietUntil, Date.now() + (ms || 12000));
    }

    function isQuiet() {
        if (Date.now() < quietUntil) return true;
        var modal = document.getElementById('successModal');
        return !!(modal && modal.classList.contains('active'));
    }

    /* ---------- مؤشر النقاط الدوّارة ---------- */
    function buildLoader() {
        var el = document.createElement('div');
        el.id = 'pxLoader';
        el.setAttribute('role', 'status');
        el.setAttribute('aria-live', 'polite');
        el.setAttribute('aria-label', 'جاري التحقق من إتمام عملية الشراء');

        var ring = document.createElement('div');
        ring.className = 'px-ring';
        for (var i = 0; i < DOT_COUNT; i++) {
            var dot = document.createElement('span');
            dot.className = 'px-dot';
            dot.style.setProperty('--i', i);
            ring.appendChild(dot);
        }
        el.appendChild(ring);
        document.body.appendChild(el);
        return el;
    }

    function showLoader() {
        if (!loaderEl || !loaderEl.isConnected) loaderEl = buildLoader();
        // إعادة تشغيل حركة الدخول في كل مرة
        loaderEl.classList.remove('show');
        void loaderEl.offsetWidth;
        loaderEl.classList.add('show');
    }

    function hideLoader() {
        if (loaderEl) loaderEl.classList.remove('show');
    }

    /* ---------- تأثير النسخ (بصري فقط) ---------- */
    function copiedFeedback() {
        var box = document.querySelector('#successModal .voucher-code-box');
        if (box) {
            box.classList.remove('vx-copied');
            void box.offsetWidth;
            box.classList.add('vx-copied');
        }

        var buttons = document.querySelectorAll('#successModal .voucher-icon-btn.copy, #successModal #voucherCopyBtn');
        buttons.forEach(function (btn) {
            var icon = btn.querySelector('i');
            var label = btn.querySelector('span');
            if (!btn._vxOrig) {
                btn._vxOrig = {
                    icon: icon ? icon.className : '',
                    label: label ? label.textContent : ''
                };
            }
            btn.classList.add('vx-ok');
            if (icon) icon.className = 'fas fa-check';
            if (label) label.textContent = 'تم النسخ';
            clearTimeout(btn._vxTimer);
            btn._vxTimer = setTimeout(function () {
                btn.classList.remove('vx-ok');
                if (icon && btn._vxOrig) icon.className = btn._vxOrig.icon;
                if (label && btn._vxOrig) label.textContent = btn._vxOrig.label;
                btn._vxOrig = null;
            }, 1500);
        });

        if (box) {
            clearTimeout(box._vxTimer);
            box._vxTimer = setTimeout(function () { box.classList.remove('vx-copied'); }, 1500);
        }
    }

    /* إعادة تشغيل حركة CSS على عنصر */
    function replay(el, cls) {
        if (!el) return;
        el.classList.remove(cls);
        void el.offsetWidth;
        el.classList.add(cls);
    }

    window.PurchaseUX = {
        showLoader: showLoader,
        hideLoader: hideLoader,
        copiedFeedback: copiedFeedback,
        replay: replay,
        quiet: quiet,
        isQuiet: isQuiet
    };
}(window, document));
