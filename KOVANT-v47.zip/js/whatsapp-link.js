/* ============================================================
   COVANT — ربط الواتساب (نافذة الأدمن)
   • يضيف بطاقة «ربط الواتساب» إلى صفحة «نظام التطبيق» برمجياً (بدون لمس تصميم الصفحة)
   • نافذة (Modal): رقم الهاتف + توليد باركود + ربط عبر رمز + فحص دوري للحالة
   • يتصل بمسارات السيرفر: /api/whatsapp/{status,qr,pair,logout} (للأدمن فقط — JWT)
   ============================================================ */
(function () {
    'use strict';
    if (window.WhatsAppLink) return;

    const API = 'https://kovant-backend3.onrender.com/api/whatsapp';
    const POLL_MS = 3000;
    let pollTimer = null;
    let busy = false;
    let overlay = null;

    function adminToken() {
        try { return localStorage.getItem('admin_jwt') || ''; } catch (_) { return ''; }
    }

    async function api(path, opts) {
        opts = opts || {};
        const token = adminToken();
        if (!token) throw new Error('سجّل دخول الأدمن من جديد ثم حاول مرة أخرى');
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), opts.timeout || 45000);   // السيرفر المجاني قد يحتاج وقتاً للإقلاع
        try {
            const res = await fetch(API + path, {
                method: opts.method || 'GET',
                headers: Object.assign({ 'Authorization': 'Bearer ' + token }, opts.body ? { 'Content-Type': 'application/json' } : {}),
                body: opts.body ? JSON.stringify(opts.body) : undefined,
                signal: ctrl.signal,
                cache: 'no-store'
            });
            let data = null;
            try { data = await res.json(); } catch (_) {}
            if (!res.ok || !data || data.success === false) {
                const err = new Error((data && data.error) || ('خطأ ' + res.status));
                err.status = res.status; err.data = data;
                throw err;
            }
            return data;
        } catch (e) {
            if (e.name === 'AbortError') throw new Error('انتهت مهلة الاتصال بالسيرفر، حاول مرة أخرى');
            throw e;
        } finally { clearTimeout(timer); }
    }

    /* ── الأنماط (معزولة ببادئة wa-) ── */
    function injectStyle() {
        if (document.getElementById('waLinkStyle')) return;
        const st = document.createElement('style');
        st.id = 'waLinkStyle';
        st.textContent = `
.wa-overlay{position:fixed;inset:0;z-index:9500;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(4,8,18,.72);backdrop-filter:blur(6px);animation:waFade .2s ease}
.wa-modal{width:100%;max-width:400px;max-height:92vh;overflow-y:auto;background:var(--bg-primary,#0b0f1a);border:1px solid rgba(37,211,102,.25);border-radius:20px;padding:20px 18px 18px;box-shadow:0 20px 60px rgba(0,0,0,.5),0 0 40px rgba(37,211,102,.08);direction:rtl;font-family:'Cairo',sans-serif;color:var(--text-primary,#f1f5f9)}
.wa-head{display:flex;align-items:center;gap:10px;margin-bottom:14px}
.wa-head .wa-ico{width:42px;height:42px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:22px;color:#25d366;background:rgba(37,211,102,.1)}
.wa-head h3{margin:0;font-size:16px;font-weight:800;flex:1}
.wa-x{background:none;border:none;color:var(--text-secondary,#94a3b8);font-size:20px;cursor:pointer;padding:4px 8px}
.wa-badge{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;background:rgba(148,163,184,.12);color:var(--text-secondary,#94a3b8);margin-bottom:12px}
.wa-badge.on{background:rgba(16,185,129,.14);color:#34d399}
.wa-badge.wait{background:rgba(251,191,36,.12);color:#fbbf24}
.wa-label{display:block;font-size:12px;font-weight:700;color:var(--text-secondary,#94a3b8);margin-bottom:6px}
.wa-input{width:100%;box-sizing:border-box;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:var(--text-primary,#f1f5f9);font:inherit;font-size:15px;direction:ltr;text-align:left;letter-spacing:1px;outline:none}
.wa-input:focus{border-color:rgba(37,211,102,.5)}
.wa-hint{font-size:11px;color:var(--text-secondary,#94a3b8);margin:6px 0 14px;line-height:1.7}
.wa-row{display:flex;gap:8px}
.wa-btn{flex:1;padding:12px 8px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:var(--text-primary,#f1f5f9);font:inherit;font-weight:800;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;transition:.2s}
.wa-btn.primary{background:linear-gradient(135deg,#128c7e,#25d366);border-color:transparent;color:#fff}
.wa-btn.danger{border-color:rgba(239,68,68,.4);color:#fca5a5;background:rgba(239,68,68,.08)}
.wa-btn:disabled{opacity:.55;cursor:not-allowed}
.wa-out{margin-top:14px;text-align:center;min-height:0}
.wa-qr{display:inline-block;background:#fff;padding:12px;border-radius:16px;box-shadow:0 8px 24px rgba(0,0,0,.3)}
.wa-qr img{display:block;width:230px;height:230px;max-width:100%}
.wa-code{font-family:monospace;font-size:30px;font-weight:900;letter-spacing:5px;direction:ltr;color:#25d366;background:rgba(37,211,102,.08);border:1px dashed rgba(37,211,102,.4);border-radius:14px;padding:14px 10px;user-select:all}
.wa-steps{font-size:11.5px;color:var(--text-secondary,#94a3b8);line-height:1.9;margin-top:10px;text-align:right}
.wa-err{margin-top:12px;font-size:12px;font-weight:700;color:#fca5a5;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:9px 12px;text-align:right}
.wa-toast{position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:9800;display:flex;align-items:center;gap:10px;padding:12px 20px;border-radius:14px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;font:700 14px 'Cairo',sans-serif;box-shadow:0 10px 30px rgba(16,185,129,.4);animation:waFade .25s ease;direction:rtl}
@keyframes waFade{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}
.wa-toast{animation-name:waToast}
@keyframes waToast{from{opacity:0;transform:translate(-50%,-10px)}to{opacity:1;transform:translate(-50%,0)}}`;
        document.head.appendChild(st);
    }

    function el(tag, cls, text) {
        const n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text != null) n.textContent = text;
        return n;
    }

    function toastGreen(msg) {
        const t = el('div', 'wa-toast');
        const i = el('i', 'fa-solid fa-circle-check');
        t.appendChild(i);
        t.appendChild(el('span', '', msg));
        document.body.appendChild(t);
        setTimeout(() => { try { t.remove(); } catch (_) {} }, 4000);
    }

    /* ── النافذة ── */
    function buildModal() {
        injectStyle();
        overlay = el('div', 'wa-overlay');
        overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

        const modal = el('div', 'wa-modal');
        const head = el('div', 'wa-head');
        const ico = el('div', 'wa-ico'); ico.innerHTML = '<i class="fa-brands fa-whatsapp"></i>';
        const x = el('button', 'wa-x', '✕'); x.type = 'button'; x.addEventListener('click', close);
        head.appendChild(ico); head.appendChild(el('h3', '', 'ربط الواتساب')); head.appendChild(x);

        const badge = el('div', 'wa-badge wait', 'جاري فحص الحالة…'); badge.id = 'waBadge';

        const form = el('div'); form.id = 'waForm';
        const lab = el('label', 'wa-label', 'رقم الهاتف (للربط عبر الرمز)');
        const input = el('input', 'wa-input'); input.id = 'waPhone'; input.type = 'tel'; input.inputMode = 'numeric';
        input.placeholder = '967771234567'; input.autocomplete = 'off';
        const hint = el('div', 'wa-hint', 'اكتب الرقم بالصيغة الدولية بدون + أو أصفار (مثال: 967771234567). الباركود لا يحتاج رقماً.');
        const row = el('div', 'wa-row');
        const bQr = el('button', 'wa-btn primary'); bQr.type = 'button'; bQr.id = 'waBtnQr';
        bQr.innerHTML = '<i class="fa-solid fa-qrcode"></i> توليد باركود';
        const bPair = el('button', 'wa-btn'); bPair.type = 'button'; bPair.id = 'waBtnPair';
        bPair.innerHTML = '<i class="fa-solid fa-key"></i> ربط عبر رمز';
        bQr.addEventListener('click', onQr); bPair.addEventListener('click', onPair);
        row.appendChild(bQr); row.appendChild(bPair);
        form.appendChild(lab); form.appendChild(input); form.appendChild(hint); form.appendChild(row);

        const connected = el('div'); connected.id = 'waConnected'; connected.style.display = 'none';
        const info = el('div', 'wa-hint'); info.id = 'waConnInfo';
        const bOut = el('button', 'wa-btn danger'); bOut.type = 'button'; bOut.id = 'waBtnLogout';
        bOut.innerHTML = '<i class="fa-solid fa-link-slash"></i> فك الربط';
        bOut.addEventListener('click', onLogout);
        connected.appendChild(info); connected.appendChild(bOut);

        const out = el('div', 'wa-out'); out.id = 'waOut';

        modal.appendChild(head); modal.appendChild(badge); modal.appendChild(form); modal.appendChild(connected); modal.appendChild(out);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);
    }

    const $ = (id) => document.getElementById(id);

    function showError(msg) {
        const out = $('waOut'); if (!out) return;
        out.textContent = '';
        out.appendChild(el('div', 'wa-err', msg));
    }
    function setBusy(on) {
        busy = on;
        ['waBtnQr', 'waBtnPair', 'waBtnLogout'].forEach(id => { const b = $(id); if (b) b.disabled = on; });
    }

    function renderStatus(st) {
        const badge = $('waBadge'); if (!badge) return;
        const connected = !!(st && st.connected);
        $('waForm').style.display = connected ? 'none' : 'block';
        $('waConnected').style.display = connected ? 'block' : 'none';
        if (connected) {
            badge.className = 'wa-badge on'; badge.textContent = 'متصل';
            $('waConnInfo').textContent = st.me && st.me.number ? 'الرقم المربوط: +' + st.me.number : 'الواتساب مربوط بنجاح.';
        } else if (st && (st.status === 'qr' || st.status === 'connecting' || st.status === 'reconnecting')) {
            badge.className = 'wa-badge wait'; badge.textContent = st.status === 'reconnecting' ? 'إعادة اتصال…' : 'بانتظار الربط…';
        } else {
            badge.className = 'wa-badge'; badge.textContent = 'غير مربوط';
        }
    }

    let wasConnectedOnOpen = false;
    let linkingStarted = false;

    async function checkStatus() {
        try {
            const st = await api('/status', { timeout: 20000 });
            renderStatus(st);
            if (st.connected && linkingStarted && !wasConnectedOnOpen) {
                stopPoll();
                toastGreen('تم ربط الواتساب بنجاح');
                setTimeout(close, 900);
            }
            return st;
        } catch (e) {
            const badge = $('waBadge');
            if (badge) { badge.className = 'wa-badge'; badge.textContent = 'تعذّر فحص الحالة'; }
            return null;
        }
    }
    function startPoll() { stopPoll(); pollTimer = setInterval(checkStatus, POLL_MS); }
    function stopPoll() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }

    async function onQr() {
        if (busy) return;
        setBusy(true); linkingStarted = true;
        const out = $('waOut'); out.textContent = '';
        out.appendChild(el('div', 'wa-hint', 'جاري توليد الباركود…'));
        try {
            const d = await api('/qr');
            out.textContent = '';
            if (d.connected) { await checkStatus(); return; }
            const box = el('div', 'wa-qr'); const img = el('img'); img.alt = 'WhatsApp QR'; img.src = d.qr; box.appendChild(img);
            out.appendChild(box);
            out.appendChild(el('div', 'wa-steps', 'واتساب ← الأجهزة المرتبطة ← ربط جهاز ← امسح الباركود. (ينتهي الباركود بعد نحو دقيقة؛ أعد التوليد إن انتهت صلاحيته)'));
            startPoll();
        } catch (e) { showError(e.message); }
        finally { setBusy(false); }
    }

    async function onPair() {
        if (busy) return;
        const phone = ($('waPhone').value || '').replace(/\D/g, '');
        if (phone.length < 8) { showError('أدخل رقم الهاتف بالصيغة الدولية أولاً'); $('waPhone').focus(); return; }
        setBusy(true); linkingStarted = true;
        const out = $('waOut'); out.textContent = '';
        out.appendChild(el('div', 'wa-hint', 'جاري طلب رمز الربط…'));
        try {
            const d = await api('/pair', { method: 'POST', body: { phoneNumber: phone } });
            out.textContent = '';
            out.appendChild(el('div', 'wa-code', d.code));
            out.appendChild(el('div', 'wa-steps', 'واتساب ← الأجهزة المرتبطة ← ربط جهاز ← «الربط باستخدام رقم الهاتف بدلاً من ذلك» ← أدخل الرمز أعلاه.'));
            startPoll();
        } catch (e) {
            if (e.status === 409) await checkStatus();
            showError(e.message);
        } finally { setBusy(false); }
    }

    async function onLogout() {
        if (busy) return;
        if (!window.confirm('هل أنت متأكد من فك ربط الواتساب؟')) return;
        setBusy(true);
        try {
            await api('/logout', { method: 'POST', body: {} });
            linkingStarted = false; wasConnectedOnOpen = false;
            $('waOut').textContent = '';
            await checkStatus();
        } catch (e) { showError(e.message); }
        finally { setBusy(false); }
    }

    async function open() {
        if (overlay) close();
        buildModal();
        linkingStarted = false; wasConnectedOnOpen = false;
        const st = await checkStatus();
        wasConnectedOnOpen = !!(st && st.connected);
        startPoll();
        if (!adminToken()) showError('سجّل دخول الأدمن من جديد ثم حاول مرة أخرى');
    }
    function close() {
        stopPoll();
        if (overlay) { try { overlay.remove(); } catch (_) {} overlay = null; }
    }

    /* ── بطاقة «ربط الواتساب» داخل صفحة نظام التطبيق ── */
    function injectCard() {
        if ($('waLinkCard')) return true;
        const grid = document.querySelector('#appSystemInterface .grid-container-4');
        if (!grid) return false;
        const card = el('div', 'admin-card wall-green');
        card.id = 'waLinkCard';
        card.innerHTML = '<div class="card-icon"><i class="fa-brands fa-whatsapp"></i></div><span>ربط الواتساب</span>';
        card.addEventListener('click', open);
        grid.appendChild(card);
        return true;
    }
    function initCard() {
        if (injectCard()) return;
        let tries = 0;
        const t = setInterval(() => { if (injectCard() || ++tries > 20) clearInterval(t); }, 500);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initCard);
    else initCard();

    window.WhatsAppLink = { open, close };
})();
