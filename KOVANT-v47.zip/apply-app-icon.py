#!/usr/bin/env python3
"""يطبّق أيقونة كوفانت (الشعار الأصلي) على مشروع أندرويد الموجود.

الاستخدام (من جذر المشروع، بعد وجود مجلد android/):
    python3 apply-app-icon.py
أو مع مسار مختلف لمجلد res:
    python3 apply-app-icon.py path/to/android/app/src/main/res
ثم ابنِ التطبيق من جديد (Clean + Rebuild) وثبّته بعد حذف النسخة القديمة.
"""
import shutil, sys
from pathlib import Path

root = Path(__file__).resolve().parent
src = root / "native-plugins" / "android" / "res"
dest = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "android" / "app" / "src" / "main" / "res"
if not dest.parent.is_dir():
    sys.exit(f"لم أجد {dest.parent} — شغّل npx cap add android أولاً أو مرّر مسار res صحيح")

dest.mkdir(parents=True, exist_ok=True)
# حذف أي أيقونات قديمة (png/webp/xml) حتى لا يحدث تعارض موارد أو تبقى القديمة
for d in dest.glob("mipmap-*"):
    for f in d.glob("ic_launcher*"):
        f.unlink()
for d in src.glob("mipmap-*"):
    (dest / d.name).mkdir(exist_ok=True)
    for f in d.iterdir():
        shutil.copy2(f, dest / d.name / f.name)
print(f"✅ تم تطبيق أيقونة كوفانت على {dest}")
