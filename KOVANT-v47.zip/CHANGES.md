# CHANGES — الإصدار 2

الجزء (أ) يلخّص ما تغيّر عن الإصدار الأول (v1). الجزء (ب) هو التغييرات التراكمية مقابل مشروعك الأصلي. «قبل» = رقم السطر في الملف السابق، «بعد» = رقمه في الملف الحالي.


# الجزء (أ) — تعديلات الإصدار 2


## `android/app/src/main/java/com/kova/cash/SMSForegroundService.java`

**تغيير 1** — قبل: سطر 292 | بعد: سطر 292–296

قبل:
```
            // processOld=true → نافذة 7 أيام وبدون حد عمر الـ5 دقائق؛ false → السلوك القديم (24 ساعة / 5 دقائق)
```
بعد:
```
            // العلاقة بين الإعدادين (مستقلان):
            //  • autoProcess: فُحص أعلى الدالة — إن كان false فلا يصل التنفيذ إلى هنا إطلاقاً.
            //  • processOld=false (الافتراضي): السلوك القديم كما هو — نافذة 24 ساعة + حد عمر 5 دقائق،
            //    أي أن الرسالة الجديدة تُعالَج دائماً ولا يتأثر الاستقبال الحي.
            //  • processOld=true: نافذة 7 أيام وبدون حد الـ5 دقائق (رسائل وصلت أثناء إغلاق التطبيق).
```


## `android/app/src/main/java/com/kova/cash/SMSWorker.java`

**تغيير 1** — قبل: سطر 48 | بعد: سطر 48–50

قبل: *(لا شيء — إضافة)*
بعد:
```
        // العلاقة بين الإعدادين (مستقلان): autoProcess فُحص في doWork() — إن كان false لا نصل هنا.
        // processOld=false (الافتراضي) → 24 ساعة + حد عمر 5 دقائق (السلوك القديم، الرسائل الجديدة تمر دائماً)
        // processOld=true → 7 أيام وبدون حد الـ5 دقائق.
```


## `js/sms-logic.js`

**تغيير 1** — قبل: سطر 17 | بعد: سطر 17

قبل:
```
        settings: { autoProcess: true, processOld: true },
```
بعد:
```
        settings: { autoProcess: true, processOld: false },
```

**تغيير 2** — قبل: سطر 327 | بعد: سطر 327

قبل:
```
        window.SmsSettingsBridge.push({ autoProcess: true, processOld: true, readSim: -1, sendSim: -1 })
```
بعد:
```
        window.SmsSettingsBridge.push({ autoProcess: true, processOld: false, readSim: -1, sendSim: -1 })
```

**تغيير 3** — قبل: سطر 545 | بعد: سطر 545

قبل:
```
    const oldT = document.getElementById('smsProcessOldToggle'); if (oldT) oldT.checked = SmsStore.data.settings?.processOld !== false;
```
بعد:
```
    const oldT = document.getElementById('smsProcessOldToggle'); if (oldT) oldT.checked = SmsStore.data.settings?.processOld === true;
```


## `index.html`

**تغيير 1** — قبل: سطر 486 | بعد: سطر 486

قبل:
```
            <div class="sms-setting-row"><div><div class="sms-row-title">معالجة الرسائل القديمة</div><div class="sms-row-desc">معالجة الرسائل التي وصلت أثناء إغلاق التطبيق</div></div><label class="sms-toggle"><input type="checkbox …
```
بعد:
```
            <div class="sms-setting-row"><div><div class="sms-row-title">معالجة الرسائل القديمة</div><div class="sms-row-desc">معالجة الرسائل التي وصلت أثناء إغلاق التطبيق</div></div><label class="sms-toggle"><input type="checkbox …
```


## `android/app/src/main/java/com/kova/cash/SmsGatewaySettings.java`

**تغيير 1** — قبل: سطر 30 | بعد: سطر 30–43

قبل: *(لا شيء — إضافة)*
بعد:
```
    /*
     * العلاقة بين autoProcess و processOld (مستقلان تماماً):
     *
     *  - autoProcess  = «هل نعالج/نرفع الرسائل أصلاً؟». الافتراضي true.
     *      false → تُستقبل الرسائل وتُحفظ محلياً فقط، ولا يُرفع ولا يُفحص شيء
     *      (لا استقبال حي ولا مسح الصندوق ولا العامل الدوري).
     *  - processOld   = «ما مدى قِدم الرسائل المسموح بمعالجتها عند مسح الصندوق؟». الافتراضي false.
     *      false → السلوك القديم: نافذة 24 ساعة + حد عمر 5 دقائق (رسائل جديدة فقط عملياً).
     *      true  → نافذة 7 أيام وبدون حد الـ5 دقائق (رسائل وصلت أثناء إغلاق التطبيق).
     *
     *  processOld لا يعطّل الرسائل الجديدة أبداً: الرسالة الواصلة الآن تمر في الحالتين.
     *  وهو لا يعمل إلا إذا كان autoProcess = true (autoProcess=false يسبقه ويوقف كل شيء).
     */

```

**تغيير 2** — قبل: سطر 45 | بعد: سطر 59

قبل:
```
        return prefs(context).getBoolean(KEY_PROCESS_OLD, true);
```
بعد:
```
        return prefs(context).getBoolean(KEY_PROCESS_OLD, false);
```


## `native-plugins/android/TuaSmsSettingsPlugin.kt`

**تغيير 1** — قبل: سطر 26 | بعد: سطر 26

قبل:
```
            put("processOld", p.getBoolean(SmsGatewaySettings.KEY_PROCESS_OLD, true))
```
بعد:
```
            put("processOld", p.getBoolean(SmsGatewaySettings.KEY_PROCESS_OLD, false))
```

**تغيير 2** — قبل: سطر 43 | بعد: سطر 43

قبل:
```
            if (call.hasOption("processOld")) editor.putBoolean(SmsGatewaySettings.KEY_PROCESS_OLD, call.getBoolean("processOld", true) ?: true)
```
بعد:
```
            if (call.hasOption("processOld")) editor.putBoolean(SmsGatewaySettings.KEY_PROCESS_OLD, call.getBoolean("processOld", false) ?: false)
```


## `js/sms-settings-bridge.js`

**تغيير 1** — قبل: سطر 9 | بعد: سطر 9

قبل:
```
 * المفاتيح الأصلية: autoProcess(bool) processOld(bool) readSim(int) sendSim(int) deviceId(string)
```
بعد:
```
 * المفاتيح الأصلية: autoProcess(bool, الافتراضي true) processOld(bool, الافتراضي false) readSim(int) sendSim(int) deviceId(string)
```

**تغيير 2** — قبل: سطر 57 | بعد: سطر 57–58

قبل:
```
            processOld: s.processOld !== false,
```
بعد:
```
            // الافتراضي false: لا نعتبره مفعّلاً إلا إذا كان true صراحةً
            processOld: s.processOld === true,
```

**تغيير 3** — قبل: سطر 103 | بعد: سطر 104–106

قبل:
```
                        autoProcess: local.autoProcess, processOld: local.processOld,
```
بعد:
```
                        // processOld لا يُنقل من localStorage: القيمة القديمة هناك كانت true افتراضياً ولم يكن لها أي أثر،
                        // وترحيلها كان سيبدأ رفع 7 أيام من الرسائل فور التحديث. يبقى false حتى يفعّله المستخدم يدوياً.
                        autoProcess: local.autoProcess, processOld: false,
```


## `android/app/src/main/java/com/kova/cash/MainActivity.kt` (ملف جديد)

**تغيير 1** — قبل: سطر 1 | بعد: سطر 1–22

قبل: *(لا شيء — إضافة)*
بعد:
```
package com.kova.cash

import android.os.Bundle
import com.getcapacitor.BridgeActivity
import com.kova.cash.plugins.TuaBiometricPlugin
import com.kova.cash.plugins.TuaSmsSenderPlugin
import com.kova.cash.plugins.TuaWifiManagerPlugin
import com.kova.cash.plugins.TuaSmsInboxPlugin
import com.kova.cash.plugins.TuaSmsSettingsPlugin

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Capacitor يقرأ قائمة الإضافات داخل super.onCreate()، لذلك يجب التسجيل قبله.
        registerPlugin(TuaBiometricPlugin::class.java)
        registerPlugin(TuaSmsSenderPlugin::class.java)
        registerPlugin(TuaWifiManagerPlugin::class.java)
        registerPlugin(TuaSmsInboxPlugin::class.java)
        registerPlugin(TuaSmsSettingsPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}

```


## ملاحظات على التعديلات
- **التعديل 1:** القيمة الافتراضية false في الأصلي (`SmsGatewaySettings.java`, `TuaSmsSettingsPlugin.kt`) وفي الجسر وفي `SmsStore` وفي زر الواجهة (أُزيلت خاصية `checked`). إضافة مهمة لم تُطلب صراحةً: عند أول مزامنة لا أنقل قيمة processOld من localStorage، لأنها كانت true افتراضياً عند كل المستخدمين وكان ترحيلها سيفعّل رفع 7 أيام فور التحديث. autoProcess بقي true.
- **التعديل 2:** `MainActivity.kt` يسجّل 5 مكوّنات قبل `super.onCreate()`: Biometric وSmsSender وWifiManager وSmsInbox وSmsSettings. تأكدت أن `setup-native-plugins.py` يتركه كما هو دون تكرار.
- **التعديل 3:** لا تغيير في المنطق — فقط تعليقات. المنطق كان مستقلاً أصلاً: autoProcess يُفحص أولاً ويوقف كل شيء، وprocessOld يغيّر النافذة فقط. عند processOld=false تبقى نافذة 24 ساعة وحد 5 دقائق. الفرق الوحيد عن v0 الأصلي أن استعلام الصندوق صار يضيف `body LIKE 'CVT:%'` ويرفع LIMIT من 50 إلى 100، وهذا لا يغيّر الرسائل المعالَجة فعلياً لأن الفحص `startsWith("CVT:")` كان موجوداً.


---

# الجزء (ب) — التغييرات التراكمية مقابل مشروعك الأصلي


## `android/app/src/main/java/com/kova/cash/SMSForegroundService.java`

**تغيير 1** — قبل: سطر 92 | بعد: سطر 92–94

قبل: *(لا شيء — إضافة)*
بعد:
```
    // مستمع تغيّر الإعدادات المشتركة — يجب الاحتفاظ بمرجع قوي لأن SharedPreferences تحتفظ بمرجع ضعيف فقط
    private SharedPreferences gatewayPrefs;
    private SharedPreferences.OnSharedPreferenceChangeListener gatewayPrefsListener;
```

**تغيير 2** — قبل: سطر 134 | بعد: سطر 137

قبل: *(لا شيء — إضافة)*
بعد:
```
        registerGatewaySettingsListener();
```

**تغيير 3** — قبل: سطر 223 | بعد: سطر 227–233

قبل: *(لا شيء — إضافة)*
بعد:
```
                    // فلترة شريحة القراءة: -1 = الكل. extra "subscription" يضيفه النظام لـ SMS_RECEIVED
                    int readSim = SmsGatewaySettings.readSim(SMSForegroundService.this);
                    int receivedSub = intent.getIntExtra("subscription", -1);
                    if (readSim >= 0 && receivedSub >= 0 && receivedSub != readSim) {
                        Log.d(TAG, "SMS ignored: received on subscription " + receivedSub + ", readSim=" + readSim);
                        return;
                    }
```

**تغيير 4** — قبل: سطر 250 | بعد: سطر 261

قبل: *(لا شيء — إضافة)*
بعد:
```
            // الاستقبال دائماً (حفظ محلي) — الرفع/المعالجة فقط عند تفعيل autoProcess
```

**تغيير 5** — قبل: سطر 251 | بعد: سطر 263–264

قبل:
```
            syncOfflineSmsQueue();
```
بعد:
```
            if (SmsGatewaySettings.isAutoProcess(this)) syncOfflineSmsQueue();
            else Log.d(TAG, "autoProcess=false: SMS stored locally, not processed");
```

**تغيير 6** — قبل: سطر 273 | بعد: سطر 286

قبل: *(لا شيء — إضافة)*
بعد:
```
        if (!SmsGatewaySettings.isAutoProcess(this)) return;
```

**تغيير 7** — قبل: سطر 278 | بعد: سطر 292–307

قبل:
```
            long since = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
```
بعد:
```
            // العلاقة بين الإعدادين (مستقلان):
            //  • autoProcess: فُحص أعلى الدالة — إن كان false فلا يصل التنفيذ إلى هنا إطلاقاً.
            //  • processOld=false (الافتراضي): السلوك القديم كما هو — نافذة 24 ساعة + حد عمر 5 دقائق،
            //    أي أن الرسالة الجديدة تُعالَج دائماً ولا يتأثر الاستقبال الحي.
            //  • processOld=true: نافذة 7 أيام وبدون حد الـ5 دقائق (رسائل وصلت أثناء إغلاق التطبيق).
            final boolean processOld = SmsGatewaySettings.isProcessOld(this);
            long since = System.currentTimeMillis() - SmsGatewaySettings.inboxWindowMs(this);
            int readSim = SmsGatewaySettings.readSim(this);
            String selection = "date > ? AND body LIKE 'CVT:%'";
            String[] selectionArgs;
            if (readSim >= 0) {
                selection += " AND " + Telephony.Sms.SUBSCRIPTION_ID + " = ?";
                selectionArgs = new String[]{String.valueOf(since), String.valueOf(readSim)};
            } else {
                selectionArgs = new String[]{String.valueOf(since)};
            }
```

**تغيير 8** — قبل: سطر 280 | بعد: سطر 309

قبل:
```
            try (Cursor cursor = getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI, projection, "date > ?", new String[]{String.valueOf(since)}, "date DESC LIMIT 50")) {
```
بعد:
```
            try (Cursor cursor = getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI, projection, selection, selectionArgs, "date DESC LIMIT 100")) {
```

**تغيير 9** — قبل: سطر 285 | بعد: سطر 314

قبل:
```
                    if (body == null || !body.startsWith("CVT:") || System.currentTimeMillis() - receivedAt > MAX_COMMAND_AGE_MS) continue;
```
بعد:
```
                    if (body == null || !body.startsWith("CVT:") || (!processOld && System.currentTimeMillis() - receivedAt > MAX_COMMAND_AGE_MS)) continue;
```

**تغيير 10** — قبل: سطر 394 | بعد: سطر 423

قبل: *(لا شيء — إضافة)*
بعد:
```
        if (!SmsGatewaySettings.isAutoProcess(this)) return;
```

**تغيير 11** — قبل: سطر 505 | بعد: سطر 535

قبل:
```
                    SmsManager manager = SmsManager.getDefault();
```
بعد:
```
                    SmsManager manager = managerForQueueItem(current);
```

**تغيير 12** — قبل: سطر 886 | بعد: سطر 916–942

قبل: *(لا شيء — إضافة)*
بعد:
```
    /** شريحة الإرسال: subscriptionId الصريح في عنصر الطابور أولاً، ثم إعداد sendSim، ثم الافتراضي. */
    private SmsManager managerForQueueItem(DataSnapshot item) {
        long explicit = -1;
        Object raw = item.child("subscriptionId").getValue();
        if (raw != null) { try { explicit = Long.parseLong(text(raw)); } catch (Exception ignored) {} }
        if (explicit >= 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try { return SmsManager.getSmsManagerForSubscriptionId((int) explicit); } catch (Exception ignored) {}
        }
        return SmsGatewaySettings.smsManagerForSend(this);
    }

    private void registerGatewaySettingsListener() {
        gatewayPrefs = SmsGatewaySettings.prefs(this);
        gatewayPrefsListener = (prefs, key) -> {
            if (SmsGatewaySettings.KEY_AUTO_PROCESS.equals(key) && prefs.getBoolean(key, true)) {
                // أُعيد تفعيل المعالجة: أرسل ما اجتمع محلياً وافحص الصندوق فوراً
                if (executor != null && !executor.isShutdown()) {
                    executor.execute(this::syncOfflineSmsQueue);
                    executor.execute(this::processExistingInbox);
                }
            } else if (SmsGatewaySettings.KEY_PROCESS_OLD.equals(key) || SmsGatewaySettings.KEY_READ_SIM.equals(key)) {
                if (executor != null && !executor.isShutdown()) executor.execute(this::processExistingInbox);
            }
        };
        gatewayPrefs.registerOnSharedPreferenceChangeListener(gatewayPrefsListener);
    }

```

**تغيير 13** — قبل: سطر 888 | بعد: سطر 945

قبل:
```
        try { SmsManager.getDefault().sendTextMessage(phone, null, message, null, null); }
```
بعد:
```
        try { SmsGatewaySettings.smsManagerForSend(this).sendTextMessage(phone, null, message, null, null); }
```

**تغيير 14** — قبل: سطر 905 | بعد: سطر 962–964

قبل: *(لا شيء — إضافة)*
بعد:
```
        if (gatewayPrefs != null && gatewayPrefsListener != null) {
            try { gatewayPrefs.unregisterOnSharedPreferenceChangeListener(gatewayPrefsListener); } catch (Exception ignored) {}
        }
```


## `android/app/src/main/java/com/kova/cash/SMSWorker.java`

**تغيير 1** — قبل: سطر 36 | بعد: سطر 36–37

قبل: *(لا شيء — إضافة)*
بعد:
```
        // المعالجة التلقائية متوقفة من الإعدادات: لا نقرأ الصندوق ولا نرفع شيئاً
        if (!SmsGatewaySettings.isAutoProcess(context)) return Result.success();
```

**تغيير 2** — قبل: سطر 46 | بعد: سطر 48–61

قبل:
```
        long since = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
```
بعد:
```
        // العلاقة بين الإعدادين (مستقلان): autoProcess فُحص في doWork() — إن كان false لا نصل هنا.
        // processOld=false (الافتراضي) → 24 ساعة + حد عمر 5 دقائق (السلوك القديم، الرسائل الجديدة تمر دائماً)
        // processOld=true → 7 أيام وبدون حد الـ5 دقائق.
        final boolean processOld = SmsGatewaySettings.isProcessOld(context);
        long since = System.currentTimeMillis() - SmsGatewaySettings.inboxWindowMs(context);
        int readSim = SmsGatewaySettings.readSim(context);
        String selection = "date > ? AND body LIKE 'CVT:%'";
        String[] selectionArgs;
        if (readSim >= 0) {
            selection += " AND " + Telephony.Sms.SUBSCRIPTION_ID + " = ?";
            selectionArgs = new String[]{String.valueOf(since), String.valueOf(readSim)};
        } else {
            selectionArgs = new String[]{String.valueOf(since)};
        }
```

**تغيير 3** — قبل: سطر 49 | بعد: سطر 64

قبل:
```
        try (Cursor cursor = context.getContentResolver().query(uri, projection, "date > ?", new String[]{String.valueOf(since)}, "date DESC LIMIT 50")) {
```
بعد:
```
        try (Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, "date DESC LIMIT 100")) {
```

**تغيير 4** — قبل: سطر 54 | بعد: سطر 69

قبل:
```
                if (body == null || !body.startsWith("CVT:") || System.currentTimeMillis() - date > MAX_COMMAND_AGE_MS) continue;
```
بعد:
```
                if (body == null || !body.startsWith("CVT:") || (!processOld && System.currentTimeMillis() - date > MAX_COMMAND_AGE_MS)) continue;
```


## `js/sms-auto-processor.js`

**تغيير 1** — قبل: سطر 193 | بعد: سطر 193–201

قبل: *(لا شيء — إضافة)*
بعد:
```
    // المعالجة التلقائية: تُقرأ من SharedPreferences (عبر الجسر) مع احتياط localStorage
    function autoOn() {
        if (window.SmsSettingsBridge) return window.SmsSettingsBridge.isAutoProcess();
        try {
            const st = window.SmsStore;
            return !(st && st.data && st.data.settings && st.data.settings.autoProcess === false);
        } catch (e) { return true; }
    }

```

**تغيير 2** — قبل: سطر 194 | بعد: سطر 203

قبل: *(لا شيء — إضافة)*
بعد:
```
        if (!autoOn()) return;
```

**تغيير 3** — قبل: سطر 204 | بعد: سطر 214

قبل:
```
        if (!db() || !navigator.onLine || state.processing) return;
```
بعد:
```
        if (!db() || !navigator.onLine || state.processing || !autoOn()) return;
```

**تغيير 4** — قبل: سطر 224 | بعد: سطر 234–238

قبل: *(لا شيء — إضافة)*
بعد:
```
    // عند إعادة تفعيل المعالجة التلقائية: عالج ما تراكم
    window.addEventListener('sms-settings-changed', function (event) {
        if (event && event.detail && event.detail.autoProcess === true) processQueue();
    });

```


## `js/sms-logic.js`

**تغيير 1** — قبل: سطر 17 | بعد: سطر 17

قبل:
```
        settings: { autoProcess: true, processOld: true },
```
بعد:
```
        settings: { autoProcess: true, processOld: false },
```

**تغيير 2** — قبل: سطر 106 | بعد: سطر 106–108

قبل: *(لا شيء — إضافة)*
بعد:
```

// SmsStore معرَّف بـ const فلا يظهر على window تلقائياً — الملفات الأخرى تقرأ window.SmsStore
window.SmsStore = SmsStore;
```

**تغيير 3** — قبل: سطر 322 | بعد: سطر 325–329

قبل: *(لا شيء — إضافة)*
بعد:
```
    if (window.SmsSettingsBridge) {
        // أعد الإعدادات الأصلية للقيم الافتراضية ثم اقرأها (معرّف الجهاز يبقى ANDROID_ID)
        window.SmsSettingsBridge.push({ autoProcess: true, processOld: false, readSim: -1, sendSim: -1 })
            .then(function () { return window.SmsSettingsBridge.sync(); });
    }
```

**تغيير 4** — قبل: سطر 450 | بعد: سطر 458

قبل: *(لا شيء — إضافة)*
بعد:
```
    if (window.SmsSettingsBridge) window.SmsSettingsBridge.pushSims();
```

**تغيير 5** — قبل: سطر 536 | بعد: سطر 545

قبل:
```
    const oldT = document.getElementById('smsProcessOldToggle'); if (oldT) oldT.checked = SmsStore.data.settings?.processOld !== false;
```
بعد:
```
    const oldT = document.getElementById('smsProcessOldToggle'); if (oldT) oldT.checked = SmsStore.data.settings?.processOld === true;
```

**تغيير 6** — قبل: سطر 616 | بعد: سطر 625–626

قبل:
```
            const subId = simInfo && simInfo.sendSubscriptionId ? simInfo.sendSubscriptionId : null;
```
بعد:
```
            let subId = simInfo && simInfo.sendSubscriptionId ? simInfo.sendSubscriptionId : null;
            if (subId == null && window.SmsSettingsBridge) subId = await window.SmsSettingsBridge.getSendSubscriptionId();
```

**تغيير 7** — قبل: سطر 657 | بعد: سطر 667–668

قبل: *(لا شيء — إضافة)*
بعد:
```
    // كتابة مزدوجة: localStorage (فوق) + SharedPreferences الأصلية
    if (window.SmsSettingsBridge) window.SmsSettingsBridge.push({ [key]: !!value });
```

**تغيير 8** — قبل: سطر 676 | بعد: سطر 688–689

قبل: *(لا شيء — إضافة)*
بعد:
```
    // اقرأ الإعدادات الحقيقية من SharedPreferences عند فتح الصفحة
    if (window.SmsSettingsBridge) window.SmsSettingsBridge.sync();
```


## `js/admin-sms-gateway.js`

**تغيير 1** — قبل: سطر 50 | بعد: سطر 50–52

قبل: *(لا شيء — إضافة)*
بعد:
```
        // الأولوية للمعرّف الأصلي (ANDROID_ID) القادم من SharedPreferences
        const bridge = window.SmsSettingsBridge;
        if (bridge && bridge.cache && bridge.cache.deviceId) return safeString(bridge.cache.deviceId);
```

**تغيير 2** — قبل: سطر 83 | بعد: سطر 86–94

قبل: *(لا شيء — إضافة)*
بعد:
```
    // شريحة الإرسال: subscriptionId الصريح في العنصر أولاً، وإلا إعداد sendSim، وإلا الافتراضي
    async function resolveSubscriptionId(item) {
        if (item && item.subscriptionId != null && item.subscriptionId !== '') return Number(item.subscriptionId);
        if (window.SmsSettingsBridge) {
            try { const id = await window.SmsSettingsBridge.getSendSubscriptionId(); if (id != null) return id; } catch (e) {}
        }
        return undefined;
    }

```

**تغيير 3** — قبل: سطر 84 | بعد: سطر 96

قبل: *(لا شيء — إضافة)*
بعد:
```
        const subscriptionId = await resolveSubscriptionId(item);
```

**تغيير 4** — قبل: سطر 90 | بعد: سطر 103

قبل:
```
                subscriptionId: item.subscriptionId == null ? undefined : Number(item.subscriptionId)
```
بعد:
```
                subscriptionId: subscriptionId
```

**تغيير 5** — قبل: سطر 94 | بعد: سطر 107

قبل:
```
            return window.tuaSendRealSms(to, message, item.subscriptionId);
```
بعد:
```
            return window.tuaSendRealSms(to, message, subscriptionId);
```

**تغيير 6** — قبل: سطر 274 | بعد: سطر 287–290

قبل: *(لا شيء — إضافة)*
بعد:
```
        if (window.SmsSettingsBridge) {
            // انتظر قراءة الإعدادات الأصلية (بحد أقصى 3 ثوانٍ) كي يُستخدم ANDROID_ID كمعرّف للبوابة
            await Promise.race([window.SmsSettingsBridge.ready, new Promise(function (r) { setTimeout(r, 3000); })]);
        }
```


## `index.html`

**تغيير 1** — قبل: سطر 486 | بعد: سطر 486

قبل:
```
            <div class="sms-setting-row"><div><div class="sms-row-title">معالجة الرسائل القديمة</div><div class="sms-row-desc">معالجة الرسائل التي وصلت أثناء إغلاق التطبيق</div></div><label class="sms-toggle"><input type="checkbox …
```
بعد:
```
            <div class="sms-setting-row"><div><div class="sms-row-title">معالجة الرسائل القديمة</div><div class="sms-row-desc">معالجة الرسائل التي وصلت أثناء إغلاق التطبيق</div></div><label class="sms-toggle"><input type="checkbox …
```

**تغيير 2** — قبل: سطر 2600 | بعد: سطر 2600

قبل: *(لا شيء — إضافة)*
بعد:
```
<script src="js/sms-settings-bridge.js"></script>
```


## `setup-native-plugins.py`

**تغيير 1** — قبل: سطر 39–40 | بعد: سطر 39–40

قبل:
```
PLUGIN_FILES = ["TuaBiometricPlugin.kt", "TuaSmsSenderPlugin.kt", "TuaWifiManagerPlugin.kt", "TuaSmsInboxPlugin.kt"]
PLUGIN_CLASSES = ["TuaBiometricPlugin", "TuaSmsSenderPlugin", "TuaWifiManagerPlugin", "TuaSmsInboxPlugin"]
```
بعد:
```
PLUGIN_FILES = ["TuaBiometricPlugin.kt", "TuaSmsSenderPlugin.kt", "TuaWifiManagerPlugin.kt", "TuaSmsInboxPlugin.kt", "TuaSmsSettingsPlugin.kt"]
PLUGIN_CLASSES = ["TuaBiometricPlugin", "TuaSmsSenderPlugin", "TuaWifiManagerPlugin", "TuaSmsInboxPlugin", "TuaSmsSettingsPlugin"]
```


## `capacitor.config.json`

**تغيير 1** — قبل: سطر 33 | بعد: سطر 33–35

قبل: *(لا شيء — إضافة)*
بعد:
```
    "TuaSmsSettings": {
      "enabled": true
    },
```


## ملف جديد: `android/app/src/main/java/com/kova/cash/SmsGatewaySettings.java` (125 سطراً)


## ملف جديد: `native-plugins/android/TuaSmsSettingsPlugin.kt` (55 سطراً)


## ملف جديد: `js/sms-settings-bridge.js` (188 سطراً)


## ملف جديد: `android/app/src/main/java/com/kova/cash/MainActivity.kt` (22 سطراً)


## ملفات لم تتغيّر
- `topup-approval-logic.js` (يقرأ `autoProcess` من `SmsStore` وهي تُزامَن من SharedPreferences) و`package.json` و`AndroidManifest.xml` (غير موجود في ملفك المرفوع ولا تحتاجه الميزة).

## تسجيل الدخول بالكرت: حسب autoLogin الفعلي للراوتر
- الراوتر: `http://10.78.0.1`. الدخول بطلب GET: أولاً `/logout` ثم `/login?username=<كرت>&domain=<1M|2M|3M|4M|8M>`.
- النجاح = احتواء الرد على «تم تسجيل دخولك بنجاح» (ثم تُجلب بيانات الكرت من status كالسابق).
- خيارات السرعة: 1M اقتصادية، 2M عادية، 3M متوسطة، 4M عالية، 8M عالية جداً.
- `TuaWifiManagerPlugin.kt`: حافظة كوكيز لكل مضيف في httpGet/httpPost (يعادل credentials: include) — يلزم إعادة نسخ البلجن وبناء APK.
- `getRouterBase()` يرجع الآن `http://10.78.0.1` (status من نفس عنوان الدخول).

## تسجيل الدخول: معالجة الرفض والحظر (covaDoLogin)
- استخراج الخطأ بـ DOMParser (`<p id="error">` أو أي عنصر بكلاس `error`) وعرض نصه فقط؛ لا يُعرض HTML خام. وإن لم يوجد نص: «فشل الدخول: قد يكون الكرت مستخدماً على جهاز آخر أو أن الماك أدرس غير مسجل».
- كشف الحظر المؤقت (الانتظار/مدة/متبقي/حظر أو مسار wait/block): تنبيه «لقد تم إدخال الكرت خطأ عدة مرات…»، تعطيل زر الدخول والبصمة دقيقة، وإيقاف أي طلب إضافي.
- مهلة 3 ثوانٍ بين كل محاولتين. لا توجد أي إعادة توجيه أو فتح صفحات: الرد يُحلَّل نصياً فقط.

## covaDoLogin: ناقل أمين لرسائل الراوتر (بدون رسائل ثابتة)
- كل نص يُعرض يُقرأ حرفياً من رد الراوتر عبر DOMParser: عنصر `#error` / `.error` / `.alert` أو أعمق عنصر فيه «خطأ»/«عذراً»، وإلا نص الـ body بعد إزالة السكربتات.
- صفحة الحظر (`block.html` في الـ URL/الرد أو «انت محظور»): يُعرض نص العداد الحرفي («بقي على فك الحظر: …») في SweetAlert2، ويُعطَّل زر الدخول والبصمة حسب الوقت المستخرج (أو 60 ثانية).
- حُذفت الرسائل الثابتة (فحص طول الكرت، رسالة الحظر، الرسالة العامة، نافذة «انتهى الكرت» من مسار الدخول).
- مهلة 3 ثوانٍ بين المحاولات؛ لا إعادة توجيه ولا فتح روابط.

## إصلاح: عرض نص الخطأ الكامل (لا «خطأ!» فقط)
- `covaParseRouterMessage`: يقرأ نصوص العناصر الداخلية (p/span/div) للعنصر الحامل للخطأ؛ وإن كان النص عنواناً قصيراً يصعد للعناصر الأم، ثم نص الـ body (بلا سكربتات وأزرار)، وأخيراً أول 150 حرفاً من الرد بلا وسوم.

## covaParseRouterMessage: #error حصراً
- يقرأ نص `<p id="error">` فقط (مع الوسوم الداخلية)، وحُذفت كل الخطط البديلة التي تسحب نص الصفحة.
- عند خلو `#error`: تُعرض «فشل الدخول: تأكد من الكرت أو السرعة» في SweetAlert2 دون أي نص آخر من الصفحة.

## covaParseRouterMessage: قراءة الخطأ من الـ URL ثم من «×»/«خطأ!»
- الراوتر يملأ #error بجافاسكربت خارجي لا ينفّذه التطبيق، لذا: (0) نص #error إن وُجد، (1) باراميترات الخطأ في الـ URL النهائي (error/err/code/reason/msg)، (2) النص الذي يلي «×» أو «خطأ!»، (3) وإلا الرسالة الاحتياطية «فشل الدخول: تأكد من الكرت أو السرعة».
- `covaHttpGet` يُرجع الآن الـ URL النهائي أيضاً (native / CapacitorHttp / fetch).

## covaParseRouterMessage: ترجمة متغير error
- يُستخرج `error="..."` / `error='...'` من الـ HTML الخام بـ Regex، ويُترجم بقاموس `COVA_ERROR_MAP` (15 رسالة؛ مطابقة بالاحتواء دون حساسية لحالة الأحرف، الأطول أولاً). غير الموجود يُعرض بالإنجليزية كما هو.

## إصلاح: بيانات status + حذف النافذة المنبثقة
- `covaShowRouterText`: حُذف SweetAlert2 نهائياً؛ المربع الملوّن في الواجهة هو العرض الوحيد لرسائل الراوتر (وللحظر أيضاً).
- `parseCovaRouterData`: القراءة بـ DOMParser و`getElementById` للحقول timeLeft/timeup/bytesin/bytesout/bytesto/speed-status، مع تعريب d/h/m/s وMiB/GiB/KiB وunlimited→مفتوح (والسرعة 3M تبقى كما هي). فشل أي حقل يُطبع في الكونسول بوسم `[kovant/status]`.

## status: احتياطات إضافية (JS فقط — لا HTML ولا CSS)
- إن لم يوجد العنصر بالـ ID: يُقرأ من خلية الجدول المجاورة لاسم الحقل (الوقت المتبقي، الوقت المستهلك، الرفع، التنزيل، التحميل المتبقي، السرعة الحالية).
- إن لم تُستخرج أي قيمة: يُطبع الرد الخام في الكونسول بوسم `[kovant/status-error]`.

## عرض الرصيد والوقت (JS فقط)
- `covaFormatDataSmart`: أقل من 1024 ميجا → «ميجا بايت» كما هي (مثل 739.4)، وإلا → «جيجا بايت» (مثل 1.3). يُطبَّق على قيمة الرصيد/التحميل المتبقي وسطر «من أصل».
- `cwdFormatDurationSplit`: الوقت المتبقي والمستهلك بالعربية كاملاً دون اختصار ودون حذف الثواني.

## الدخول: إعادة محاولة تلقائية (JS فقط)
- حُذف الاعتماد على اسم الشبكة (SSID / last_cova_ssid) كلياً.
- الدخول أولاً؛ وإن رجع «الكرت مستخدم على جهاز آخر» (simultaneous session limit / مستخدم على جهاز آخر…): طرد قسري `/logout?erase-cookie=on` ثم انتظار 500ms ثم محاولة ثانية واحدة. فشلت الثانية → الرسالة الإرشادية في المربع الأحمر.
- زر الدخول يبقى «جاري الاتصال...» ومعطّلاً طوال المحاولتين، ثم يعود لحالته.
- أول انتظار للتحقق من status صار 300ms بدل 700ms.

## زر «تسجيل الخروج» في صفحة بيانات الكرت (JS فقط)
- `covaEnsureLogoutBtn`: ينشئ الزر برمجياً (أنماط مضمّنة) أسفل بطاقة البيانات، ويُستدعى من `covaShowContent`.
- `covaDoLogout`: `window.confirm('هل أنت متأكد من تسجيل الخروج؟')` ← GET `http://10.78.0.1/logout?erase-cookie=on` ← مسح حالة الجلسة في التطبيق وحقل الكرت ← `covaShowLogin()`. إن تعذّر الوصول للراوتر يبقى المستخدم في صفحة البيانات مع تنبيه.

## ربط الواتساب (Baileys)
**السيرفر (server.js + package.json):**
- مسارات للأدمن فقط (JWT): `GET /api/whatsapp/qr`، `POST /api/whatsapp/pair`، `GET /api/whatsapp/status`، `POST /api/whatsapp/logout`.
- الجلسة في `auth_info_baileys` (أو `WA_AUTH_DIR`)، وتُستأنف تلقائياً عند إعادة تشغيل السيرفر. أُضيف المجلد إلى `.gitignore`.
- معالجة أخطاء: تحميل كسول للمكتبة، إعادة اتصال متدرجة، توقف عن توليد الباركود عند انتهاء المهلة، و`unhandledRejection` لا يُسقط السيرفر.
- الاعتماديات: `@whiskeysockets/baileys` (^6.7.9) و`pino` و`qrcode` و`qrcode-terminal`.
**التطبيق:**
- `js/whatsapp-link.js` (جديد): بطاقة «ربط الواتساب» تُضاف برمجياً إلى «نظام التطبيق» + نافذة (رقم الهاتف، توليد باركود، ربط عبر رمز، فحص حالة كل 3 ثوانٍ، إشعار أخضر وإغلاق عند النجاح، فك الربط).
- `index.html`: سطر `<script>` واحد. `service-worker.js`: إضافة الملف وترقية الكاش إلى v23.
- `server.js` هنا مبني على نسخة الـ ZIP (تتضمن `/api/public/login-banners`).

## إرسال كرت الزبون عبر الواتساب (server.js)
- عند شراء كرت لرقم زبون (`online_purchase_customer`) يُرسل الكرت بالواتساب بدل SMS. تأكيد المشتري (`online_purchase_buyer`) وبقية الرسائل تبقى SMS.
- `waSendText`: تطبيع الرقم (7XXXXXXXX / 07XXXXXXXX → 967…)، فحص وجوده في واتساب، إرسال متسلسل بفاصل 1.5–3.5ث.
- سجل كل محاولة في Firebase تحت `whatsapp_log` (sent/failed).
- الرجوع إلى SMS يحدث فقط إن كان الواتساب غير متصل أو فشل الإرسال (يُلغى بـ `WA_CARDS_SMS_FALLBACK=false`). الإيقاف الكامل: `WA_CARDS_ENABLED=false`.
- مسار اختبار للأدمن: `POST /api/whatsapp/send` بـ `{phone, text}`.
