/* ============================================================
   متصلين الوايفاي (أدمن) — بطاقة لكل مستخدم + دوائر البيانات والوقت
   المصدر: wifi_sessions/{phone} (يكتبها التطبيق كل ~90 ثانية من wifi-module.js)
============================================================ */
(function () {
    'use strict';
    if (window.__WO_LOADED__) return;
    window.__WO_LOADED__ = true;

    var ONLINE_MS = 4 * 60 * 1000, REFRESH_MS = 20000;
    var _rows = [], _filter = 'online', _term = '', _loading = false, _timer = null;

    function $(id) { return document.getElementById(id); }
    function esc(s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; });
    }
    function num(v) { return (typeof v === 'number' && isFinite(v)) ? v : null; }
    function clamp(p) { return Math.max(0, Math.min(100, p)); }
    function tone(p) { return p >= 50 ? '#10b981' : p >= 20 ? '#fbbf24' : '#f87171'; }
    function fmtBytes(b) {
        b = Math.max(0, b || 0);
        if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
        if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB';
        if (b >= 1024) return Math.round(b / 1024) + ' KB';
        return Math.round(b) + ' B';
    }
    function fmtDur(s) {
        s = Math.max(0, Math.round(s || 0));
        var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
        if (d > 0) return d + 'ي ' + h + 'س';
        if (h > 0) return h + 'س ' + m + 'د';
        return m + 'د';
    }
    function ago(t) {
        if (!t) return '—';
        var s = Math.max(0, Math.round((Date.now() - t) / 1000));
        if (s < 60) return 'الآن';
        if (s < 3600) return 'منذ ' + Math.floor(s / 60) + ' د';
        if (s < 86400) return 'منذ ' + Math.floor(s / 3600) + ' س';
        return 'منذ ' + Math.floor(s / 86400) + ' ي';
    }
    function chip(icon, txt) { return '<span><i class="fas fa-' + icon + '"></i> ' + esc(txt) + '</span>'; }

    function ring(p, color, txt, lbl) {
        var C = 138.23, d = (C * clamp(p) / 100).toFixed(1);
        return '<div class="wo-ring"><div class="wo-rg"><svg viewBox="0 0 56 56" width="56" height="56">' +
            '<circle cx="28" cy="28" r="22" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="5"/>' +
            '<circle cx="28" cy="28" r="22" fill="none" stroke="' + color + '" stroke-width="5" stroke-linecap="round" stroke-dasharray="' + d + ' ' + C + '" transform="rotate(-90 28 28)"/>' +
            '</svg><span class="wo-rv">' + esc(txt) + '</span></div><small>' + lbl + '</small></div>';
    }

    function normalize(val) {
        var out = [], now = Date.now();
        Object.keys(val || {}).forEach(function (phone) {
            var s = val[phone];
            if (!s || typeof s !== 'object') return;
            var up = num(s.updatedAt) || 0;
            out.push({
                phone: phone, name: s.userName || phone, account: s.accountNumber || null, card: s.card || null,
                speed: s.speedLabel || null, ip: s.ip || null, ssid: s.ssid || null,
                unlimited: !!s.unlimited, timeLimited: !!s.timeLimited,
                rem: num(s.remainingBytes) || 0, down: num(s.usedDownBytes) || 0, upl: num(s.usedUpBytes) || 0,
                remSec: num(s.remainingSeconds) || 0, conSec: num(s.consumedSeconds) || 0,
                started: num(s.startedAt), updated: up,
                online: s.online !== false && up > 0 && (now - up) < ONLINE_MS
            });
        });
        out.sort(function (a, b) { return (b.online - a.online) || (b.updated - a.updated); });
        return out;
    }

    function card(r) {
        var dataPct = r.unlimited ? 100 : (r.rem + r.down > 0 ? r.rem / (r.rem + r.down) * 100 : 0);
        var timePct = r.timeLimited ? (r.remSec + r.conSec > 0 ? r.remSec / (r.remSec + r.conSec) * 100 : 0) : 100;
        var rings = ring(dataPct, r.unlimited ? '#10b981' : tone(dataPct), r.unlimited ? '∞' : fmtBytes(r.rem), 'البيانات المتبقية') +
            ring(timePct, r.timeLimited ? tone(timePct) : '#10b981', r.timeLimited ? fmtDur(r.remSec) : '∞', 'الوقت المتبقي') +
            ring(r.unlimited || r.rem + r.down <= 0 ? 0 : 100 - dataPct, '#02a3fe', fmtBytes(r.down), 'المستهلك');
        var tag = r.online ? '<span class="wm-tag g"><i class="fas fa-circle"></i> متصل</span>' : '<span class="wm-tag y">غير متصل</span>';
        var meta = [chip('download', 'تحميل ' + fmtBytes(r.down)), chip('upload', 'رفع ' + fmtBytes(r.upl)), chip('clock', 'مستهلك ' + fmtDur(r.conSec))];
        if (r.ip) meta.push(chip('network-wired', r.ip));
        if (r.ssid) meta.push(chip('wifi', r.ssid));
        if (r.started && r.online) meta.push(chip('play', 'بدأ ' + ago(r.started)));
        meta.push(chip('rotate', (r.online ? 'تحديث ' : 'آخر ظهور ') + ago(r.updated)));
        return '<div class="wo-card"><div class="wo-head"><div class="wm-u-av">' + esc(String(r.name).trim().charAt(0)) + '</div>' +
            '<div class="wm-u-body"><div class="wm-u-name">' + esc(r.name) + '</div><div class="wm-u-sub">' + esc(r.phone) + (r.account ? ' · ' + esc(r.account) : '') + '</div></div>' + tag + '</div>' +
            '<div class="wo-cardno"><i class="fas fa-id-card"></i><span dir="ltr">' + esc(r.card || '—') + '</span>' + (r.speed ? '<small>' + esc(r.speed) + '</small>' : '') + '</div>' +
            '<div class="wo-rings">' + rings + '</div><div class="wm-net-meta">' + meta.join('') + '</div></div>';
    }

    function render() {
        var online = _rows.filter(function (r) { return r.online; });
        $('woStatOnline').textContent = online.length;
        $('woStatTotal').textContent = _rows.length;
        $('woStatUsed').textContent = fmtBytes(online.reduce(function (a, r) { return a + r.down + r.upl; }, 0));
        var f = _term.trim().toLowerCase();
        var items = (_filter === 'online' ? online : _rows).filter(function (r) {
            return !f || r.name.toLowerCase().indexOf(f) > -1 || r.phone.toLowerCase().indexOf(f) > -1 || String(r.card || '').indexOf(f) > -1;
        });
        $('woCount').textContent = items.length + ' مستخدم';
        $('woList').innerHTML = items.map(card).join('');
        $('woEmpty').style.display = (items.length === 0 && !_loading) ? 'block' : 'none';
        var seg = document.querySelectorAll('#wifiOnlineInterface [data-wo-filter]');
        for (var i = 0; i < seg.length; i++) seg[i].classList.toggle('on', seg[i].getAttribute('data-wo-filter') === _filter);
    }

    function load(silent) {
        if (_loading) return;
        if (typeof database === 'undefined') { render(); return; }
        _loading = true;
        if (!silent) $('woLoading').style.display = 'block';
        var auth = (typeof waitForFirebaseAuth === 'function') ? waitForFirebaseAuth() : Promise.resolve();
        auth.then(function () { return database.ref('wifi_sessions').limitToLast(300).once('value'); })
            .then(function (snap) { _rows = normalize(snap.val()); })
            .catch(function (e) { console.error('wifi_sessions load error:', e); })
            .then(function () { _loading = false; $('woLoading').style.display = 'none'; render(); });
    }

    function stop() { if (_timer) { clearInterval(_timer); _timer = null; } }
    window.wifiOnlineOpen = function () {
        stop();
        setTimeout(function () { load(false); }, 150);
        _timer = setInterval(function () {
            var el = $('wifiOnlineInterface');
            if (!el || !el.classList.contains('active')) { stop(); return; }
            load(true);
        }, REFRESH_MS);
    };
    window.wifiOnlineRefresh = function () { load(false); };

    document.addEventListener('input', function (e) {
        if (e.target && e.target.id === 'woSearch') { _term = e.target.value; render(); }
    });
    document.addEventListener('click', function (e) {
        var b = e.target && e.target.closest ? e.target.closest('[data-wo-filter]') : null;
        if (b) { _filter = b.getAttribute('data-wo-filter'); render(); }
    });
})();
