#!/usr/bin/env python3
"""
setup-native-plugins.py — كوفانت (Kova Cash)

شغّله بعد `npx cap add android` وقبل `npx cap sync android`.
(تسجيل الإضافات في MainActivity.kt صار يدوياً/جاهزاً في الملف نفسه، ولم يعد من مهام هذا السكربت.)

ما يفعله (آمن لإعادة التشغيل):
  1. ينسخ 9 ملفات من native-plugins/android/ إلى
     android/app/src/main/java/com/kova/cash/plugins/ :
       - 7 ملفات Kotlin للإضافات: TuaBiometric, TuaSmsSender, TuaWifiManager,
         TuaSmsInbox, TuaSmsSettings, TuaNotification, TuaTrafficStats
       - خدمتان: CovaForegroundService, SpeedOverlayService
  2. ينسخ مواد res/ :
       cova_notification.xml  -> android/app/src/main/res/layout/
       cova_speed_badge_bg.xml -> android/app/src/main/res/drawable/
  3. ينسخ google-services.json إلى android/app/ (فقط إن لم يكن موجوداً)
  4. يضيف تبعيات Gradle الناقصة فقط إلى android/app/build.gradle
  5. يسمح بـ HTTP (cleartext) في AndroidManifest.xml إن لم يكن مضبوطاً

كل ملف يعدّله يُحفظ له نسخة <file>.bak أولاً.

الاستخدام:
    cd <جذر المشروع>          # المجلد الذي فيه capacitor.config.json
    python3 setup-native-plugins.py
"""

import re
import shutil
import sys
from pathlib import Path

PACKAGE = "com.kova.cash"

# 7 إضافات Kotlin + خدمتان = 9 ملفات
KOTLIN_PLUGIN_FILES = [
    "TuaBiometricPlugin.kt",
    "TuaSmsSenderPlugin.kt",
    "TuaWifiManagerPlugin.kt",
    "TuaSmsInboxPlugin.kt",
    "TuaSmsSettingsPlugin.kt",
    "TuaNotificationPlugin.kt",
    "TuaTrafficStatsPlugin.kt",
]
SERVICE_FILES = [
    "CovaForegroundService.kt",
    "SpeedOverlayService.kt",
]
PLUGIN_FILES = KOTLIN_PLUGIN_FILES + SERVICE_FILES

# (المصدر داخل native-plugins/android/ ، المجلد داخل android/app/src/main/res/)
RES_FILES = [
    ("res/layout/cova_notification.xml", "layout"),
    ("res/drawable/cova_speed_badge_bg.xml", "drawable"),
]

# (نص يدل على وجودها، السطر الذي يُضاف). تُضاف الناقصة فقط.
GRADLE_DEPS = [
    ("androidx.biometric:biometric",
     '    implementation "androidx.biometric:biometric:1.1.0"'),
    ("androidx.security:security-crypto",
     '    implementation "androidx.security:security-crypto:1.1.0-alpha06"'),
    ("androidx.work:work-runtime-ktx",
     '    implementation "androidx.work:work-runtime-ktx:2.9.0"'),
    ("com.google.firebase:firebase-bom",
     '    implementation platform("com.google.firebase:firebase-bom:33.1.2")'),
    ("com.google.firebase:firebase-database",
     '    implementation "com.google.firebase:firebase-database"'),
    ("com.google.firebase:firebase-auth",
     '    implementation "com.google.firebase:firebase-auth"'),
    ("com.squareup.okhttp3:okhttp",
     '    implementation "com.squareup.okhttp3:okhttp:4.12.0"'),
    ("androidx.fragment:fragment-ktx",
     '    implementation "androidx.fragment:fragment-ktx:1.6.2"'),
]


def fail(msg):
    print(f"❌ {msg}")
    sys.exit(1)


def backup(path: Path):
    bak = path.with_suffix(path.suffix + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)
        print(f"   🗄  backup: {bak}")


def step1_copy_plugins(root: Path):
    src_dir = root / "native-plugins" / "android"
    android_main = root / "android" / "app" / "src" / "main" / "java" / Path(*PACKAGE.split("."))
    dest_dir = android_main / "plugins"

    if not (root / "android").is_dir():
        fail("android/ not found. Run `npx cap add android` first, then re-run this script.")

    dest_dir.mkdir(parents=True, exist_ok=True)
    print(f"📁 plugins package: {dest_dir}")

    copied = 0
    for fname in PLUGIN_FILES:
        src = src_dir / fname
        if not src.is_file():
            print(f"   ⚠️  {fname} not found in native-plugins/android/, skipping")
            continue
        shutil.copy2(src, dest_dir / fname)
        copied += 1
        print(f"   ✅ copied {fname}")
    print(f"   → {copied}/{len(PLUGIN_FILES)} files copied")


def step2_copy_res(root: Path):
    src_dir = root / "native-plugins" / "android"
    res_dir = root / "android" / "app" / "src" / "main" / "res"

    for rel, kind in RES_FILES:
        src = src_dir / rel
        if not src.is_file():
            print(f"   ⚠️  {rel} not found in native-plugins/android/, skipping")
            continue
        dest_dir = res_dir / kind
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest_dir / src.name)
        print(f"   ✅ copied {src.name} -> res/{kind}/")


def step3_copy_google_services(root: Path):
    src = root / "google-services.json"
    dest = root / "android" / "app" / "google-services.json"

    if dest.is_file():
        print(f"✓ {dest} already exists, not overwritten")
        return
    if not src.is_file():
        print(f"⚠️  {src} not found — put google-services.json in android/app/ by hand.")
        return
    shutil.copy2(src, dest)
    print(f"✅ copied google-services.json -> {dest}")


def step4_patch_gradle(root: Path):
    gradle_path = root / "android" / "app" / "build.gradle"
    if not gradle_path.is_file():
        print("⚠️  build.gradle غير موجود — شغّلني بعد cap add")
        return

    text = gradle_path.read_text(encoding="utf-8")
    missing = [line for marker, line in GRADLE_DEPS if marker not in text]

    if not missing:
        print(f"✅ {gradle_path} already has the required dependencies")
        return

    m = re.search(r"dependencies\s*\{", text)
    if not m:
        print(f"⚠️  Couldn't find a `dependencies {{` block in {gradle_path} — add by hand:")
        for line in missing:
            print(f"   {line.strip()}")
        return

    backup(gradle_path)
    insert_at = m.end()
    addition = "\n" + "\n".join(missing)
    text = text[:insert_at] + addition + text[insert_at:]
    gradle_path.write_text(text, encoding="utf-8")
    print(f"✅ added {len(missing)} missing dependency line(s) to {gradle_path}")


def step5_patch_manifest_cleartext(root: Path):
    """السماح بـ HTTP (صفحة الراوتر http://www.c.com/status.html) — أندرويد 9+ يمنعه افتراضياً."""
    mf = root / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
    if not mf.is_file():
        print("⚠️  AndroidManifest.xml غير موجود — شغّلني بعد cap add")
        return
    text = mf.read_text(encoding="utf-8")
    if "usesCleartextTraffic" in text:
        print("✓ usesCleartextTraffic already present")
        return
    backup(mf)
    text = text.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
    mf.write_text(text, encoding="utf-8")
    print('✓ added android:usesCleartextTraffic="true"')


def main():
    root = Path.cwd()
    if not (root / "capacitor.config.json").is_file():
        fail("Run this from the project root (the folder with capacitor.config.json).")

    print("=== Step 1/5: copy plugin + service .kt files ===")
    step1_copy_plugins(root)

    print("\n=== Step 2/5: copy res/ files ===")
    step2_copy_res(root)

    print("\n=== Step 3/5: google-services.json ===")
    step3_copy_google_services(root)

    print("\n=== Step 4/5: Gradle dependencies ===")
    step4_patch_gradle(root)

    print("\n=== Step 5/5: allow cleartext HTTP (router page) ===")
    step5_patch_manifest_cleartext(root)

    print(
        "\n🎉 Done. Next steps:\n"
        "   npx cap sync android\n"
        "   npx cap open android   # rebuild from Android Studio (or ./gradlew assembleDebug)\n\n"
        "Verify after launch that Capacitor.Plugins.TuaBiometric, TuaNotification and\n"
        "CovaTrafficStats are objects (not undefined) in the WebView console."
    )


if __name__ == "__main__":
    main()
