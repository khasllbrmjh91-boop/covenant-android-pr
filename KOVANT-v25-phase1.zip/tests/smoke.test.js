// tests/smoke.test.js — فحوصات أساسية لا تحتاج Firebase ولا شبكة.
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');

describe('package.json', () => {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));

    test('يحتوي على سكربت start يشغّل server.js', () => {
        expect(pkg.scripts.start).toBe('node server.js');
    });

    test('Capacitor core مُعرَّف في dependencies', () => {
        expect(pkg.dependencies['@capacitor/core']).toBeDefined();
    });
});

describe('service-worker.js', () => {
    const src = fs.readFileSync(path.join(ROOT, 'service-worker.js'), 'utf8');
    const block = src.match(/APP_SHELL\s*=\s*\[([\s\S]*?)\];/);

    test('قائمة APP_SHELL موجودة', () => {
        expect(block).not.toBeNull();
    });

    test('كل ملف في APP_SHELL موجود فعلاً على القرص', () => {
        const paths = [...block[1].matchAll(/'([^']+)'/g)].map(m => m[1]);
        const missing = paths.filter(p => p !== '/' && !fs.existsSync(path.join(ROOT, p)));
        expect(missing).toEqual([]);
    });
});
