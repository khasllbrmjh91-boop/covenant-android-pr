// ============================================================
// USER DATA
// ============================================================
let userDataUnsubscribe = null;

function subscribeToUserData(phone) {
    if (userDataUnsubscribe) {
        userDataUnsubscribe();
        userDataUnsubscribe = null;
    }
    if (!navigator.onLine) {
        if (APP.user) updateUserUI(APP.user, phone);
        return;
    }
    const ref = database.ref('users/' + phone);
    userDataUnsubscribe = ref.on('value', (snap) => {
        const data = snap?.val();
        if (!data) return;

        APP.user = data;
        APP.user.phone = phone;
        updateUserUI(data, phone);
        if (typeof checkAgentProfile === 'function') checkAgentProfile(data);
        renderLastTransactions();
        const allTxEl = document.getElementById('allTransactionsInterface');
        if (allTxEl && allTxEl.classList.contains('active')) renderAllTransactions();
    });
}

function updateUserUI(data, phone) {
    if (!data) return;
    const nameEl = document.getElementById('userName');
    if (nameEl) nameEl.textContent = data.fullName || 'مستخدم';

    const accEl = document.getElementById('accountId');
    if (accEl) accEl.textContent = `ID: ${data.accountNumber || data.phone}`;

    const bal = data.balance || 0;
    const formatted = $n(bal).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    const amountEl = document.getElementById('amount');
    if (amountEl) {
        amountEl.textContent = navigator.onLine ? formatted : '******';
        amountEl.dataset.realValue = navigator.onLine ? formatted : '';
        amountEl.classList.toggle('offline-hidden-balance', !navigator.onLine);
    }
    const balanceCard = document.querySelector('.balance-card');
    if (balanceCard) balanceCard.classList.toggle('balance-offline', !navigator.onLine);

    const bcEl = document.getElementById('barcodeInterface');
    if (bcEl && bcEl.style.display === 'block') updateBarcodePage();

    const trEl = document.getElementById('transferInterface');
    if (trEl && trEl.style.display === 'block') {
        const trBal = document.getElementById('transfer-current-balance');
        if (trBal) trBal.innerText = navigator.onLine ? $fmt(bal) : '******';
    }

    const stEl = document.getElementById('statementInterface');
    if (stEl && stEl.style.display === 'block') {
        if (typeof loadStatementData === 'function') loadStatementData();
    }

    if (phone && APP._notifListenerPhone !== phone) {
        APP._notifListenerPhone = phone;
        listenNotifications(phone);
    }
}

window.updateBalanceConnectivity = function (isOnline) {
    const amountEl = document.getElementById('amount');
    const balanceCard = document.querySelector('.balance-card');
    const trBal = document.getElementById('transfer-current-balance');
    if (amountEl) {
        amountEl.classList.toggle('offline-hidden-balance', !isOnline);
        amountEl.textContent = isOnline ? (amountEl.dataset.realValue || '0.00') : '******';
    }
    if (balanceCard) balanceCard.classList.toggle('balance-offline', !isOnline);
    if (trBal) trBal.textContent = isOnline ? $fmt(APP.user?.balance || 0) : '******';
};

// ============================================================
// TRANSACTIONS / العمليات
// ============================================================
function computeTxWithBalance() {
    const history = (APP.user && APP.user.history) || {};
    const arr = Object.values(history);
    arr.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

    let running = 0;
    return arr.map(tx => {
        const amt = $n(tx.amount);
        const isDebit = (tx.type === 'out' || tx.type === 'withdraw');
        const isCredit = (tx.type === 'in' || tx.type === 'deposit' || tx.type === 'transfer_in');
        if (isCredit) running += amt;
        else if (isDebit) running -= amt;
        return Object.assign({}, tx, { balanceAfter: running });
    });
}

function buildTxRowHTML(tx, withDivider, txId) {
    const amt = $n(tx.amount);
    const isNegative = (tx.type === 'out' || tx.type === 'withdraw');
    const sign = isNegative ? '-' : '+';
    const color = isNegative ? '#ef4444' : '#10b981';
    const icon = isNegative ? 'fa-arrow-up' : 'fa-arrow-down';
    const iconBg = isNegative ? 'rgba(239,68,68,0.08)' : 'rgba(16,185,129,0.08)';

    let dateOnly = '--', timeOnly = '';
    if (tx.timestamp) {
        const d = new Date(tx.timestamp);
        dateOnly = d.toLocaleDateString('ar-EG', { year: 'numeric', month: '2-digit', day: '2-digit' });
        timeOnly = d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    }

    return `
        <div class="tx-card" onclick="showTxDetails('${txId}')" style="--tc:${color}">
            <div class="tx-top">
                <div class="tx-ico" style="background:${iconBg}; color:${color};"><i class="fas ${icon}"></i></div>
                <div class="tx-main">
                    <div class="tx-title">${esc(tx.title || 'معاملة')}</div>
                    <div class="tx-amt" style="color:${color};">${sign} ${$fmt(amt)} <small>YER</small></div>
                </div>
                <div class="tx-when">
                    <span class="tx-when-date"><i class="far fa-calendar-alt"></i>${dateOnly}</span>
                    <span class="tx-when-time"><i class="far fa-clock"></i>${timeOnly}</span>
                </div>
            </div>
            <div class="tx-foot">
                <span class="tx-foot-label">الرصيد بعد العملية</span>
                <span class="tx-foot-val">${$fmt(tx.balanceAfter)} <small>YER</small></span>
            </div>
        </div>
    `;
}

// تسجيل كل عملية بمعرّف فريد ليتم استرجاعها عند فتح صفحة التفاصيل بالضغط على البطاقة
function registerTx(tx) {
    APP._txRegistry = APP._txRegistry || {};
    const id = 'tx_' + (tx.timestamp || Date.now()) + '_' + Math.random().toString(36).slice(2, 7);
    APP._txRegistry[id] = tx;
    return id;
}

// عناوين عربية للحقول الإضافية المعروفة التي قد تُرفق مع العملية
const TX_EXTRA_LABELS = {
    reference: 'المرجع',
    walletName: 'المحفظة',
    walletId: 'معرّف المحفظة',
    topupRequestId: 'رقم الطلب',
    matchedSmsId: 'معرّف الرسالة',
    category: 'الفئة',
    method: 'طريقة الدفع',
    senderPhone: 'رقم المرسل',
    receiverPhone: 'رقم المستقبل',
    note: 'ملاحظة',
    cardCode: '🎫 أكواد الكروت'
};
const TX_KNOWN_KEYS = ['type', 'amount', 'title', 'date', 'timestamp', 'balanceAfter', '_key', 'cardCode', 'codes'];

async function copyTransactionCode(button) {
    const code = button && button.getAttribute ? button.getAttribute('data-code') : '';
    if (!code) return;
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(code);
        } else {
            const input = document.createElement('textarea');
            input.value = code;
            input.style.position = 'fixed';
            input.style.opacity = '0';
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            input.remove();
        }
        if (typeof showAlert === 'function') showAlert('✅ تم نسخ الكود');
    } catch (error) {
        if (typeof showAlert === 'function') showAlert('❌ تعذر نسخ الكود', false);
    }
}
window.copyTransactionCode = copyTransactionCode;

function showTxDetails(txId) {
    const tx = (APP._txRegistry || {})[txId];
    if (!tx) return;

    const amt = $n(tx.amount);
    const isNegative = (tx.type === 'out' || tx.type === 'withdraw');
    const sign = isNegative ? '-' : '+';
    const color = isNegative ? '#ef4444' : '#10b981';
    const icon = isNegative ? 'fa-arrow-up' : 'fa-arrow-down';

    let dateOnly = '--', timeOnly = '';
    if (tx.timestamp) {
        const d = new Date(tx.timestamp);
        dateOnly = d.toLocaleDateString('ar-EG', { year: 'numeric', month: '2-digit', day: '2-digit' });
        timeOnly = d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    }

    const rows = [
        ['التاريخ', dateOnly],
        ['الوقت', timeOnly],
        ['الرصيد بعد العملية', `${$fmt(tx.balanceAfter)} YER`]
    ];

    const codes = Array.isArray(tx.codes) ? tx.codes.filter(code => code !== null && code !== undefined && String(code) !== '') : [];
    if (codes.length) {
        const codesHTML = '<div style="display:flex;flex-direction:column;gap:7px;align-items:stretch;min-width:190px;">' +
            codes.map((code, index) => {
                const safeCode = esc(String(code));
                return `<div style="display:flex;align-items:center;gap:6px;direction:ltr;"><code style="flex:1;padding:6px 8px;border-radius:6px;background:rgba(88,184,232,.08);color:var(--text-primary);font-size:12px;word-break:break-all;">${safeCode}</code><button type="button" data-code="${safeCode}" onclick="copyTransactionCode(this)" style="border:0;border-radius:6px;padding:5px 8px;background:#1a6fa8;color:#fff;cursor:pointer;font-size:11px;">نسخ</button></div>`;
            }).join('') + '</div>';
        rows.push(['🎫 أكواد الكروت', codesHTML]);
    } else if (tx.cardCode !== null && tx.cardCode !== undefined && String(tx.cardCode) !== '') {
        rows.push(['🎫 أكواد الكروت', esc(String(tx.cardCode))]);
    }

    Object.keys(tx).forEach(k => {
        if (TX_KNOWN_KEYS.includes(k)) return;
        const val = tx[k];
        if (val === null || val === undefined || val === '') return;
        const label = TX_EXTRA_LABELS[k] || k;
        rows.push([label, esc(String(val))]);
    });

    const rowsHTML = rows.map(([label, val]) => `
        <div style="display:flex; align-items:center; justify-content:space-between; padding:9px 4px; border-bottom:1px solid rgba(255,255,255,0.06);">
            <span style="font-size:12px; color:var(--text-secondary); font-weight:600;">${esc(label)}</span>
            <span style="font-size:13px; color:var(--text-primary); font-weight:700; text-align:left;">${val}</span>
        </div>
    `).join('');

    if (typeof Swal === 'undefined') return;
    Swal.fire({
        title: '',
        html: `
            <div style="text-align:center; margin-bottom:14px;">
                <div style="width:64px; height:64px; border-radius:50%; background:${color}18; display:flex; align-items:center; justify-content:center; color:${color}; font-size:26px; margin:0 auto 10px;">
                    <i class="fas ${icon}"></i>
                </div>
                <div style="font-size:15px; font-weight:800; color:var(--text-primary);">${esc(tx.title || 'معاملة')}</div>
                <div style="font-size:22px; font-weight:900; color:${color}; margin-top:6px;">${sign} ${$fmt(amt)} <span style="font-size:12px; font-weight:700;">YER</span></div>
            </div>
            <div style="text-align:right;">${rowsHTML}</div>
        `,
        showConfirmButton: true,
        confirmButtonText: 'إغلاق',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        customClass: { popup: 'tx-details-modal' }
    });
}

function emptyTxHTML(big) {
    return `
        <div style="padding:${big ? '40px 16px' : '16px'}; text-align:center; color:var(--text-secondary); font-size:13px;">
            <i class="fas fa-inbox" style="font-size:${big ? '28px' : '20px'}; display:block; margin-bottom:${big ? '8px' : '4px'};"></i>
            لا توجد عمليات مسجلة
        </div>
    `;
}

function renderLastTransactions() {
    const container = document.getElementById('lastTxContainer');
    if (!container || !APP.user) return;

    const withBalance = computeTxWithBalance();
    if (withBalance.length === 0) {
        container.innerHTML = emptyTxHTML(false);
        return;
    }

    const tx = withBalance[withBalance.length - 1];
    const id = registerTx(tx);
    container.innerHTML = buildTxRowHTML(tx, false, id);
}

function renderAllTransactions() {
    const container = document.getElementById('allTxContainer');
    if (!container || !APP.user) return;

    const withBalance = computeTxWithBalance();
    if (withBalance.length === 0) {
        container.innerHTML = emptyTxHTML(true);
        return;
    }

    const descending = withBalance.slice().reverse();
    container.innerHTML = descending.map((tx, i) => {
        const id = registerTx(tx);
        return buildTxRowHTML(tx, i < descending.length - 1, id);
    }).join('');
}

// ============================================================
// NOTIFICATIONS — الإشعارات
// ============================================================

function listenNotifications(phone) {
    if (!phone) return;

    database.ref('notifications/' + phone).on('child_added', snap => {
        const n = snap?.val();
        if (!n) return;
        n._key = snap.key;
        if (APP.notifications.some(x => x._key === n._key)) return;
        APP.notifications.unshift(n);
        renderNotifications();
        if (APP.soundEnabled) playMessengerSound();
        showToastMain(n);
        updateNotifBadge();

        if (typeof showLocalNotification === 'function') {
            showLocalNotification(n.title || 'كوفانت', n.message || 'لديك إشعار جديد');
        }
    });

    database.ref('notifications/' + phone).on('child_changed', snap => {
        const n = snap?.val();
        if (!n) return;
        n._key = snap.key;
        const idx = APP.notifications.findIndex(x => x._key === n._key);
        if (idx >= 0) {
            APP.notifications[idx] = n;
            renderNotifications();
            updateNotifBadge();
        }
    });

    database.ref('notifications/' + phone).on('child_removed', snap => {
        const key = snap.key;
        APP.notifications = APP.notifications.filter(x => x._key !== key);
        renderNotifications();
        updateNotifBadge();
    });

    database.ref('notifications/' + phone).once('value', snap => {
        if (snap?.exists()) {
            const all = [];
            snap.forEach(c => {
                const v = c.val();
                v._key = c.key;
                all.push(v);
            });
            all.sort((a, b) => b.timestamp - a.timestamp);
            APP.notifications = all;
            renderNotifications();
            updateNotifBadge();
        }
    });
}

function updateNotifBadge() {
    const badge = document.getElementById('notifBadge');
    if (!badge) return;
    const unread = APP.notifications.filter(n => !n.isRead).length;
    badge.innerText = unread > 0 ? unread : '0';
    badge.style.display = unread > 0 ? 'flex' : 'none';
}

function classifyNotifColor(n) {
    const text = `${n.title || ''} ${n.message || ''}`;
    const isOutgoing = /شراء|خصم|سداد|دفع|تحويل\s*إلى/.test(text) ||
        ['transfer', 'purchase', 'debt', 'out', 'withdraw'].includes(n.type);
    const isIncoming = /إيداع|استلام|تحويل\s*من/.test(text) ||
        ['deposit', 'in', 'transfer_in'].includes(n.type);
    if (isOutgoing) return 'red';
    if (isIncoming) return 'green';
    return 'gold';
}

function renderNotifications() {
    const c = document.getElementById('notifListContainer');
    if (!c) return;
    if (APP.notifications.length === 0) {
        c.innerHTML = `<div class="empty-state"><i class="fas fa-bell-slash"></i>لا توجد إشعارات حاليًا<div class="sub-text">ستظهر الإشعارات الجديدة هنا تلقائيًا</div></div>`;
        return;
    }
    const sorted = [...APP.notifications].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    c.innerHTML = sorted.map((n, idx) => {
        const isRead = n.isRead === true;
        const icon = n.title?.includes('إيداع') ? 'fa-arrow-down' :
            (n.title?.includes('تحويل') ? 'fa-exchange-alt' :
                (n.title?.includes('فاتورة') ? 'fa-file-invoice' : 'fa-bell'));
        const cls = 'amount-' + classifyNotifColor(n);
        let msg = esc(n.message || '');
        msg = msg.replace(/\d+(?:,\d{3})*(?:\.\d+)?(?:\s*(?:ريال|YER))?/gi, m => `<span class="amount-highlight ${cls}">${m}</span>`);
        const key = n._key || n.id || idx;
        return `
            <div class="notif-item ${isRead ? 'read' : ''}" data-id="${key}" onclick="onNotifClick('${key}')">
                <div class="notif-header">
                    <div class="notif-icon"><i class="fas ${icon}"></i></div>
                    <div class="notif-title">
                        <span class="title-text">${esc(n.title || 'إشعار')} ${!isRead ? '<span class="unread-dot"></span>' : ''}</span>
                    </div>
                </div>
                <div class="notif-divider"></div>
                <div class="notif-body">
                    <div class="notif-message">${msg}</div>
                    <div class="notif-time">
                        <i class="far fa-clock"></i> <span>${getTimeAgo(n.timestamp || Date.now())}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    updateNotifBadge();
}

/* ═══════════════════════════════════════════════════════════
   ✅ جديد: تعليم الإشعارات كمقروءة
   ═══════════════════════════════════════════════════════════ */

async function markAllNotificationsAsRead() {
    if (!APP.user?.phone) return;

    const unread = APP.notifications.filter(n => !n.isRead && n._key);
    if (!unread.length) return;

    unread.forEach(n => { n.isRead = true; });
    updateNotifBadge();

    const updates = {};
    unread.forEach(n => {
        updates[`notifications/${APP.user.phone}/${n._key}/isRead`] = true;
    });

    try {
        await database.ref().update(updates);
        console.log(`✅ تم تعليم ${unread.length} إشعار كمقروء`);
    } catch (e) {
        console.error('❌ فشل تعليم الإشعارات كمقروءة:', e);
    }
}

window.onNotifClick = function(key) {
    const n = APP.notifications.find(x => x._key === key || String(x.id) === String(key));
    if (!n) return;

    if (!n.isRead && APP.user?.phone && n._key) {
        n.isRead = true;
        database.ref(`notifications/${APP.user.phone}/${n._key}/isRead`).set(true).catch(() => {});
        updateNotifBadge();
    }

    Swal.fire({
        title: n.title || 'إشعار',
        html: `
            <div style="text-align:right; padding:8px 4px; line-height:1.9;">
                <div style="color:var(--text-primary); font-size:14.5px;">${esc(n.message || '')}</div>
                <div style="margin-top:14px; font-size:11px; color:var(--text-secondary); border-top:1px solid rgba(255,255,255,0.06); padding-top:10px;">
                    <i class="far fa-clock"></i> ${getTimeAgo(n.timestamp || Date.now())}
                </div>
            </div>
        `,
        confirmButtonText: 'حسناً',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8'
    });
};

function showToastMain(notif) {
    const el = document.getElementById('floatingToastMain');
    if (!el) return;
    document.getElementById('toastMessageMain').textContent = notif.message || '';
    document.getElementById('toastTime').textContent = 'الآن';
    if (APP.toastTimeout) clearTimeout(APP.toastTimeout);
    el.classList.add('visible');
    APP.toastTimeout = setTimeout(() => el.classList.remove('visible'), 7000);
}

function dismissToastMain() {
    if (APP.toastTimeout) clearTimeout(APP.toastTimeout);
    document.getElementById('floatingToastMain')?.classList.remove('visible');
}

function playMessengerSound() {
    if (!APP.soundEnabled) return;
    try {
        const ctx = new(window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator(),
            gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = 880;
        gain.gain.value = 0.15;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.stop(ctx.currentTime + 0.35);
        if (ctx.state === 'suspended') ctx.resume();
    } catch (e) {}
}

function toggleSound() {
    APP.soundEnabled = !APP.soundEnabled;
    localStorage.setItem('notif_sound', APP.soundEnabled ? 'true' : 'false');
    updateSoundUI();
    if (typeof showAlert === 'function') {
        showAlert(APP.soundEnabled ? 'تم تفعيل الصوت' : 'تم إيقاف الصوت');
    }
    if (APP.soundEnabled) playMessengerSound();
}

function updateSoundUI() {
    const btn = document.getElementById('soundToggleBtnNotif');
    if (!btn) return;
    if (APP.soundEnabled) {
        btn.innerHTML = '<i class="fas fa-volume-up"></i> الصوت';
        btn.classList.add('active');
    } else {
        btn.innerHTML = '<i class="fas fa-volume-mute"></i> الصوت';
        btn.classList.remove('active');
    }
}

function showSwalAlert(msg, isSuccess = true) {
    Swal.fire({
        title: isSuccess ? 'نجاح' : 'خطأ',
        text: msg,
        icon: isSuccess ? 'success' : 'error',
        confirmButtonText: 'حسناً',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        timer: 3000,
        timerProgressBar: true
    });
}

// ============================================================
// TRANSFER
// ============================================================
async function findUserByAccId(accId) {
    try {
        const res = await fetch('https://kovant-backend3.onrender.com/lookup-account', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ accountNumber: accId })
        });
        const data = await res.json();
        if (res.ok && data.success) {
            return { exists: true, fullName: data.fullName, accountNumber: data.accountNumber };
        }
        return { exists: false };
    } catch (e) { return { exists: false }; }
}

async function executeTransfer(recipientAccId, amount, note) {
    if (!APP.user) throw new Error('خطأ في الجلسة');

    const transid = `TRF-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const token = getAuthToken();

    if (!token) throw new Error('لم يتم العثور على توكن الجلسة، يرجى تسجيل الدخول مجدداً');

    const res = await fetch('https://kovant-backend3.onrender.com/transfer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({
            phone: APP.user.phone,
            transid: transid,
            recipientAccount: recipientAccId,
            amount: amount,
            note: note
        })
    });

    let data;
    try { data = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

    if (!res.ok || !data.success) {
        if (res.status === 401) {
            localStorage.removeItem('auth_token');
            localStorage.removeItem('auth_expiry');
            if (typeof clearSessionRefreshTimer === 'function') clearSessionRefreshTimer();
            throw new Error('انتهت صلاحية الجلسة، الرجاء تسجيل الدخول مجدداً');
        }
        throw new Error(data.error || 'فشل تنفيذ التحويل');
    }

    APP.user.balance = data.newBalance;
    updateUserUI(APP.user, APP.user.phone);
    renderLastTransactions();
    const balanceEl = document.getElementById('transfer-current-balance');
    if (balanceEl) balanceEl.innerText = $fmt(data.newBalance);

    return { recipient: data.recipient };
}

async function showTransferConfirmation() {
    const acc = document.getElementById('recipient-account').value.trim();
    const amtStr = document.getElementById('transfer-amount').value.trim();
    const note = document.getElementById('transfer-note').value.trim();

    if (!acc) return Swal.fire('خطأ', 'أدخل رقم حساب المستلم', 'error');
    if (!amtStr || isNaN(amtStr) || parseFloat(amtStr) <= 0) return Swal.fire('خطأ', 'أدخل مبلغ صحيح', 'error');
    let amount = parseFloat(amtStr);
    if (amount < 100) return Swal.fire('خطأ', 'الحد الأدنى للتحويل هو 100 ريال', 'error');

    if (!navigator.onLine) {
        if (!window.SMSCommand || typeof window.SMSCommand.sendTransferSMS !== 'function') {
            return Swal.fire('تعذر الإرسال', 'خدمة SMS غير متاحة على هذا الجهاز', 'error');
        }
        try {
            await window.SMSCommand.sendTransferSMS(APP.user.phone, acc, amount);
            document.getElementById('recipient-account').value = '';
            document.getElementById('transfer-amount').value = '';
            document.getElementById('transfer-note').value = '';
            return showAlert('✅ تم إرسال طلب التحويل عبر SMS — سيُنفَّذ خلال دقائق', true);
        } catch (error) {
            return Swal.fire('تعذر الإرسال', error.message || 'فشل إرسال طلب التحويل', 'error');
        }
    }

    Swal.fire({ title: 'جاري التحقق...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

    let recipient, latestBalance;
    try {
        const [recipientResult, balanceSnap] = await Promise.all([
            findUserByAccId(acc),
            database.ref('users/' + APP.user.phone).once('value')
        ]);
        recipient = recipientResult;

        const userData = balanceSnap?.val();
        if (userData && typeof userData.balance === 'number') {
            latestBalance = userData.balance;
        } else if (userData && typeof userData.balance === 'string') {
            latestBalance = parseFloat(userData.balance);
        } else {
            latestBalance = APP.user.balance || 0;
        }

        if (latestBalance !== undefined && !isNaN(latestBalance)) {
            APP.user.balance = latestBalance;
            console.log('✅ تم تحديث الرصيد من Firebase:', latestBalance);
        } else {
            console.warn('⚠️ لم نتمكن من جلب الرصيد، نستخدم الرصيد المخزن:', APP.user.balance);
        }
    } catch (e) {
        Swal.close();
        console.error('❌ خطأ في جلب البيانات:', e);
        return Swal.fire('خطأ', 'حدث خطأ أثناء التحقق', 'error');
    }
    Swal.close();

    if (!recipient.exists) return Swal.fire('خطأ', 'رقم الحساب غير موجود', 'error');

    const currentBalance = APP.user.balance || 0;
    console.log('💰 الرصيد الحالي:', currentBalance, 'المبلغ المطلوب:', amount);

    if (currentBalance < amount) {
        return Swal.fire({
            icon: 'error',
            title: 'الرصيد غير كافي',
            html: `الرصيد الحالي: <strong>${$fmt(currentBalance)} YER</strong><br>المبلغ المطلوب: <strong>${$fmt(amount)} YER</strong>`,
            confirmButtonText: 'حسناً',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8'
        });
    }

    const confirmResult = await Swal.fire({
        title: 'تأكيد التحويل',
        html: `
            <div style="text-align:right; background:rgba(255,255,255,0.03); border-radius:16px; padding:16px;">
                <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">📋 رقم حساب المستلم</span>
                    <span style="color:#58b8e8; font-weight:700;">${esc(recipient.accountNumber)}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">👤 اسم المستلم</span>
                    <span style="color:var(--text-primary); font-weight:700;">${esc(recipient.fullName || recipient.name)}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">💰 المبلغ</span>
                    <span style="color:#fbbf24; font-weight:800;">${$fmt(amount)} YER</span>
                </div>
                ${note ? `<div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">📝 ملاحظة</span>
                    <span style="color:var(--text-primary);">${esc(note)}</span>
                </div>` : ''}
                <div style="margin-top:12px; background:#0d1231; border-radius:12px; padding:10px; text-align:center; color:var(--text-secondary); font-size:13px;">
                    🔒 جلسة موثوقة — سيتم التحويل فوراً
                </div>
            </div>
        `,
        confirmButtonText: 'تأكيد التحويل',
        cancelButtonText: 'إلغاء',
        showCancelButton: true,
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });
    if (!confirmResult.isConfirmed) return;

    Swal.fire({ title: 'جاري التحويل...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
        const result = await executeTransfer(acc, amount, note);
        Swal.close();
        if (typeof playSystemSuccessSound === 'function') playSystemSuccessSound();
        await Swal.fire({
            title: 'تم التحويل بنجاح ✅',
            text: `تم تحويل ${$fmt(amount)} YER إلى ${result.recipient.fullName}`,
            icon: 'success',
            confirmButtonText: 'حسناً',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8'
        });
        document.getElementById('transfer-current-balance').innerText = $fmt(APP.user.balance);
        document.getElementById('recipient-account').value = '';
        document.getElementById('transfer-amount').value = '';
        document.getElementById('transfer-note').value = '';
    } catch (e) {
        Swal.close();
        if (e.message.includes('انتهت صلاحية الجلسة')) {
            Swal.fire({
                title: 'انتهت الجلسة',
                text: 'الرجاء تسجيل الدخول مجدداً',
                icon: 'warning',
                confirmButtonText: 'تسجيل الدخول',
                background: '#161b22',
                color: '#e6edf3',
                confirmButtonColor: '#1a6fa8'
            }).then(() => {
                if (typeof logout === 'function') logout();
                navigateTo('loginInterface', true);
            });
        } else {
            Swal.fire('خطأ', e.message, 'error');
        }
    }
}

// ============================================================
// BARCODE PAGE
// ============================================================
function updateBarcodePage() {
    const d = APP.user;
    if (!d) return;
    document.getElementById('bcPageUserName').textContent = d.fullName || 'مستخدم غير معروف';
    document.getElementById('bcPageUserPhone').textContent = `رقم الجوال: ${d.phone || '---'}`;
    document.getElementById('bcPageAccountId').textContent = d.accountNumber || '0000000000';
    document.getElementById('bcPageBalance').textContent = $n(d.balance || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('personalQrImage').src = `https://quickchart.io/qr?text=${encodeURIComponent(d.accountNumber || '')}&size=250&margin=2&ecLevel=H`;
}

function downloadQrCode() {
    const img = document.getElementById('personalQrImage');
    if (!img || !img.src) {
        if (typeof showAlert === 'function') showAlert('لا توجد صورة للتحميل', false);
        return;
    }
    const canvas = document.createElement('canvas');
    canvas.width = 250;
    canvas.height = 250;
    const ctx = canvas.getContext('2d');
    const temp = new Image();
    temp.crossOrigin = 'anonymous';
    temp.onload = function() {
        ctx.drawImage(temp, 0, 0, 250, 250);
        canvas.toBlob(blob => {
            const link = document.createElement('a');
            link.download = `qr_${APP.user?.accountNumber || 'code'}.png`;
            link.href = URL.createObjectURL(blob);
            link.click();
            URL.revokeObjectURL(link.href);
            if (typeof showAlert === 'function') showAlert('تم تحميل الباركود');
        });
    };
    temp.src = img.src;
}

async function shareQrCode() {
    const img = document.getElementById('personalQrImage');
    if (!img || !img.src) {
        if (typeof showAlert === 'function') showAlert('لا توجد صورة للمشاركة', false);
        return;
    }
    try {
        const r = await fetch(img.src);
        const blob = await r.blob();
        const file = new File([blob], `qr_${APP.user?.accountNumber || 'code'}.png`, { type: 'image/png' });
        if (navigator.share) {
            await navigator.share({ title: 'الباركود الخاص بي - كوفانت', files: [file] });
            if (typeof showAlert === 'function') showAlert('تمت المشاركة');
        } else {
            await navigator.clipboard.writeText(img.src);
            if (typeof showAlert === 'function') showAlert('تم نسخ رابط الباركود');
        }
    } catch (e) {
        if (e.name !== 'AbortError') {
            if (typeof showAlert === 'function') showAlert('فشلت المشاركة', false);
        }
    }
}

// ============================================================
// USER INVOICES
// ============================================================
async function loadUserInvoices() {
    const container = document.getElementById('userInvoicesContainer');
    if (!container || !APP.user) return;

    const userSnap = await database.ref('users/' + APP.user.phone).once('value');
    const user = userSnap?.val();
    if (!user) {
        container.innerHTML = '<div class="empty-state">لا توجد بيانات</div>';
        return;
    }

    const invoices = user.invoices || {};
    const invoiceKeys = Object.keys(invoices).sort((a, b) => invoices[a].number - invoices[b].number);

    if (invoiceKeys.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 20px;">
                <i class="fas fa-file-invoice" style="font-size:40px; display:block; margin-bottom:10px; color:var(--text-secondary);"></i>
                <p style="color:var(--text-secondary); font-size:15px;">لا توجد فواتير مسجلة</p>
            </div>
        `;
        return;
    }

    let html = '';

    invoiceKeys.forEach(key => {
        const inv = invoices[key];
        const isPaid = inv.status === 'paid';
        const borderColor = isPaid ? 'var(--green)' : 'var(--red)';
        const statusText = isPaid ? 'مدفوعة' : 'نشطة';
        const statusColor = isPaid ? 'var(--green)' : 'var(--red)';

        let paymentsHtml = '';
        if (inv.payments && Object.keys(inv.payments).length > 0) {
            const paymentEntries = Object.values(inv.payments).sort((a, b) => a.date - b.date);
            let tempRemaining = inv.remainingAmount;
            const remainingHistory = [];
            for (let i = paymentEntries.length - 1; i >= 0; i--) {
                const p = paymentEntries[i];
                const amountBefore = tempRemaining + p.amount;
                remainingHistory[i] = tempRemaining;
                tempRemaining = amountBefore;
            }

            paymentsHtml = paymentEntries.map((p, idx) => {
                const displayDate = p.date ? new Date(p.date).toLocaleString('ar-EG', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }) : 'غير معروف';
                const remainingAfterPayment = remainingHistory[idx] || inv.remainingAmount;

                return `
                    <div style="background:rgba(255,255,255,0.02); border-radius:10px; padding:10px 14px; margin-bottom:6px; border-right:3px solid var(--gold);">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
                            <div>
                                <span style="font-weight:700; font-size:13px; color:var(--green);;">💰 - ${$fmt(p.amount)} YER</span>
                                <span style="font-size:11px; color:var(--text-secondary); margin-right:10px;">
                                    <i class="far fa-calendar-alt"></i> ${displayDate}
                                </span>
                            </div>
                            <div style="font-size:12px; color:var(--text-secondary);">
                                <span style="color:var(--gold); font-weight:700;">المتبقي: ${$fmt(remainingAfterPayment)} YER</span>
                            </div>
                        </div>
                        ${p.note ? `<div style="font-size:11px; color:var(--text-secondary); margin-top:4px;">📝 ${esc(p.note)}</div>` : ''}
                    </div>
                `;
            }).join('');
        } else {
            paymentsHtml = '<div style="font-size:12px; color:var(--text-secondary); padding:8px 0;">لا توجد سدادت بعد</div>';
        }

        html += `
            <div style="background:var(--bg-card); backdrop-filter:blur(8px); border-radius:var(--radius); margin-bottom:16px; border:1px solid rgba(255,255,255,0.06); box-shadow:var(--shadow-glow); overflow:hidden; border-right:4px solid ${borderColor};">
                <div style="padding:14px 16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; border-bottom:1px solid rgba(255,255,255,0.04); background:rgba(255,255,255,0.02);">
                    <div>
                        <span style="font-weight:800; font-size:16px; color:var(--text-primary);">📄 فاتورة رقم ${inv.number}</span>
                        <span style="background:rgba(255,255,255,0.04); padding:2px 12px; border-radius:30px; font-size:12px; margin-right:10px; color:${statusColor}; font-weight:700;">
                            ${statusText}
                        </span>
                    </div>
                    <div style="font-size:12px; color:var(--text-secondary);">
                        <i class="far fa-calendar-alt"></i> ${new Date(inv.createdAt).toLocaleString('ar-EG', { year:'numeric', month:'2-digit', day:'2-digit' })}
                    </div>
                </div>
                <div style="padding:12px 16px; display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; background:rgba(0,0,0,0.1);">
                    <div style="text-align:center;">
                        <div style="font-size:10px; color:var(--text-secondary);">الإجمالي</div>
                        <div style="font-weight:800; font-size:15px; color:var(--text-primary);">${$fmt(inv.totalAmount)} YER</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:10px; color:var(--text-secondary);">المدفوع</div>
                        <div style="font-weight:800; font-size:15px; color:var(--green);;">${$fmt(inv.paidAmount)} YER</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:10px; color:var(--text-secondary);">المتبقي</div>
                        <div style="font-weight:800; font-size:15px; color:${inv.remainingAmount > 0 ? 'var(--red)' : 'var(--green)'};">${$fmt(inv.remainingAmount)} YER</div>
                    </div>
                </div>
                <div style="padding:12px 16px 16px;">
                    <div style="font-weight:700; font-size:13px; color:var(--text-secondary); margin-bottom:8px;">
                        <i class="fas fa-history"></i> عمليات السداد:
                    </div>
                    <div style="padding-right:4px;">
                        ${paymentsHtml}
                    </div>
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// ============================================================
// PACKAGES
// ============================================================
function loadPackagesFromStore() {
    database.ref('kova_store').on('value', snap => {
        APP.storeData = snap?.val() || {};
        renderPackages();
    });
}

function renderPackages() {
    const c = document.getElementById('packagesContainer');
    if (!c) return;
    const store = APP.storeData;
    const ids = Object.keys(store).filter(id => id !== 'gift_cards');
    if (!ids.length) {
        c.innerHTML = '<div class="empty-state"><i class="fas fa-box-open"></i><br>لا توجد باقات متاحة حالياً</div>';
        return;
    }
    let html = '';
    ids.forEach(id => {
        const cat = store[id];
        const name = cat.name || id;
        const price = cat.sellPrice ? $n(cat.sellPrice) : 0;
        const duration = cat.duration || 'غير محدد';
        const balance = cat.balance || 'غير محدد';
        const timeLimit = cat.timeLimit || 'غير محدد';
        const points = cat.rewardPoints || 0;
        const isMost = cat.mostRequested === true;
        const avail = cat.cards ? Object.keys(cat.cards).length : 0;
        if (!avail) return;
        html += `
            <div class="package-card ${isMost ? 'most-requested' : ''}">
                ${isMost ? '<div class="most-requested-badge"><i class="fas fa-fire"></i> الأكثر طلباً <i class="fas fa-chart-line"></i></div>' : ''}
                <div class="package-name">${esc(name)}</div>
                <div class="price">${esc(String(price))} <small>ريال</small></div>
                <div class="package-details">
                    <div class="detail-row"><span class="detail-label"><i class="fas fa-calendar-alt"></i> المدة:</span><span class="detail-value">${esc(duration)}</span></div>
                    <div class="detail-row"><span class="detail-label"><i class="fas fa-database"></i> الرصيد:</span><span class="detail-value">${esc(balance)}</span></div>
                    <div class="detail-row"><span class="detail-label"><i class="fas fa-infinity"></i> الوقت:</span><span class="detail-value">${esc(timeLimit)}</span></div>
                </div>
                <div class="points-reward"><i class="fas fa-gem"></i> +${esc(String(points))} نقطة مكافأة</div>
                <button class="subscribe-btn" onclick="openModal('${id}')"><i class="fas fa-shopping-cart"></i> اشتري الآن</button>
            </div>
        `;
    });
    c.innerHTML = html || '<div class="empty-state"><i class="fas fa-box-open"></i><br>جميع الباقات نفدت</div>';
}

function openModal(id) {
    const cat = APP.storeData[id];
    if (!cat) {
        if (typeof showAlert === 'function') showAlert('الباقة غير موجودة', false);
        return;
    }
    const keys = Object.keys(cat.cards || {});
    if (!keys.length) {
        Swal.fire('نفدت الكروت', 'عذراً، لا توجد كروت متاحة لهذه الباقة حالياً', 'warning');
        return;
    }
    APP.selectedCategoryId = id;
    APP.selectedCategory = cat;
    const price = cat.sellPrice ? $n(cat.sellPrice) : 0;
    document.getElementById('modalPackageName').textContent = cat.name || id;
    document.getElementById('modalPackagePrice').textContent = $fmt(price) + ' ريال';
    document.getElementById('customerId').value = '';
    document.getElementById('cardsCount').textContent = '1';
    document.getElementById('contactError').style.display = 'none';
    const selfToggle = document.getElementById('selfCardToggle');
    if (selfToggle) selfToggle.checked = true;
    updateSelfCardUI();
    document.getElementById('subscribeModal').classList.add('active');
}

function closeModal() {
    document.getElementById('subscribeModal').classList.remove('active');
}

function changeCards(delta) {
    let v = parseInt(document.getElementById('cardsCount').textContent) || 1;
    v = Math.max(1, v + delta);
    document.getElementById('cardsCount').textContent = v;
}

// الكرت لنفسي أو لعميل آخر — إظهار/إخفاء حقل رقم العميل
function toggleSelfCard() {
    updateSelfCardUI();
}

function updateSelfCardUI() {
    const toggle = document.getElementById('selfCardToggle');
    const group = document.getElementById('customerIdGroup');
    const txt = document.getElementById('selfToggleText');
    if (!toggle || !group || !txt) return;
    const isSelf = toggle.checked;
    if (isSelf) {
        group.style.display = 'none';
        txt.textContent = 'لنفسي (سيُستخدم رقمي تلقائياً)';
        document.getElementById('contactError').style.display = 'none';
    } else {
        group.style.display = 'flex';
        txt.textContent = 'لعميل آخر — أدخل رقمه';
    }
}

function normalizePurchasePhone(value) {
    let phone = String(value || '').trim().replace(/[\s()-]/g, '');
    if (phone.startsWith('+967')) phone = phone.slice(4);
    else if (phone.startsWith('00967')) phone = phone.slice(5);
    if (phone.startsWith('0') && phone.length === 10) phone = phone.slice(1);
    return phone;
}

async function confirmSubscription() {
    const isSelf = document.getElementById('selfCardToggle') ? document.getElementById('selfCardToggle').checked : false;
    let customerId;

    if (isSelf) {
        customerId = normalizePurchasePhone(APP.user && APP.user.phone);
        if (!customerId) {
            if (typeof showAlert === 'function') showAlert('تعذر تحديد رقمك تلقائياً، الرجاء إدخاله يدوياً', false);
            document.getElementById('selfCardToggle').checked = false;
            updateSelfCardUI();
            return;
        }
    } else {
        customerId = normalizePurchasePhone(document.getElementById('customerId').value);
        if (!customerId) {
            if (typeof showAlert === 'function') showAlert('الرجاء إدخال رقم العميل', false);
            return;
        }
        if (!/^[0-9]+$/.test(customerId)) {
            if (typeof showAlert === 'function') showAlert('الرجاء إدخال أرقام فقط', false);
            return;
        }
        localStorage.setItem('customerId', customerId);
    }

    const count = parseInt(document.getElementById('cardsCount').textContent) || 1;
    const id = APP.selectedCategoryId;
    const cat = APP.selectedCategory;

    if (!id || !cat) {
        if (typeof showAlert === 'function') showAlert('حدث خطأ، الرجاء المحاولة مرة أخرى', false);
        return;
    }

    if (!navigator.onLine) {
        if (!window.SMSCommand || typeof window.SMSCommand.sendCardPurchaseSMS !== 'function') {
            return Swal.fire('تعذر الإرسال', 'خدمة SMS غير متاحة على هذا الجهاز', 'error');
        }
        try {
            await window.SMSCommand.sendCardPurchaseSMS(APP.user.phone, id, count, customerId);
            closeModal();
            return showAlert('✅ تم إرسال طلب شراء الكروت عبر SMS — سيُنفَّذ خلال دقائق', true);
        } catch (error) {
            return Swal.fire('تعذر الإرسال', error.message || 'فشل إرسال طلب الشراء', 'error');
        }
    }

    Swal.fire({
        title: 'جاري التحقق من الرصيد والكروت...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    try {
        const token = getAuthToken();
        if (!token) throw new Error('الرجاء تسجيل الدخول مجدداً');

        const response = await fetch('https://kovant-backend3.onrender.com/api/purchase-package', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({
                packageId: id,
                count: count,
                customerId: customerId
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            Swal.close();
            if (response.status === 401) {
                localStorage.removeItem('auth_token');
                localStorage.removeItem('auth_expiry');
                if (typeof clearSessionRefreshTimer === 'function') clearSessionRefreshTimer();
                return Swal.fire('خطأ', 'انتهت صلاحية الجلسة، الرجاء تسجيل الدخول مجدداً', 'error');
            }
            return Swal.fire('خطأ', data.error || 'فشلت عملية الشراء', 'error');
        }

        APP.user.balance = data.newBalance;
        updateUserUI(APP.user, APP.user.phone);
        renderLastTransactions();

        Swal.close();
        closeModal();
        openVoucherSuccess(cat, data.codes || [], count, customerId, isSelf);
        if (typeof playSystemSuccessSound === 'function') playSystemSuccessSound();
        if (typeof showAlert === 'function') showAlert('تم الشراء بنجاح وتم إرسال الأكواد عبر البوت');

    } catch (e) {
        Swal.close();
        console.error(e);
        Swal.fire('خطأ', e.message || 'حدث خطأ أثناء عملية الشراء', 'error');
    }
}

function closeSuccessModal() {
    document.getElementById('successModal').classList.remove('active');
    navigateTo('userInterface', true);
}

// ============================================================
// 🎫 بطاقة النجاح (قائمة الكروت بعد الشراء)
// ============================================================
const VCH = {
    cards: [],
    index: 0,
    visible: false,
    allVisible: false,
    pkgName: '',
    duration: '',
    timeLimit: ''
};

function openVoucherSuccess(cat, codes, count, customerId, isSelf) {
    const price = cat.sellPrice ? $fmt($n(cat.sellPrice)) : '0';
    const batchId = 'KWT' + Date.now();
    VCH.cards = (codes || []).map((code, i) => ({
        code: code,
        price: price,
        txn: batchId + '-' + String(i + 1).padStart(3, '0')
    }));
    VCH.index = 0;
    VCH.visible = false;
    VCH.allVisible = false;
    VCH.pkgName = cat.name || '';
    VCH.duration = cat.duration || '';
    VCH.timeLimit = cat.timeLimit || '';
    VCH.customerId = customerId;
    VCH.isSelf = isSelf;

    document.getElementById('successSub').textContent =
        `تم تخصيص ${VCH.cards.length} كرت بنجاح${isSelf ? '' : ' — للعميل ' + esc(customerId)}`;

    document.getElementById('voucherAllCards').classList.add('hidden');
    const copyBtn = document.getElementById('voucherCopyBtn');
    copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i><span>نسخ</span>';
    copyBtn.setAttribute('onclick', 'copyCurrentVoucher()');
    copyBtn.classList.remove('primary-gold-copy');

    document.getElementById('voucherShowAllBtn').innerHTML =
        `<i class="fas fa-table-cells-large"></i> <span>عرض الكل (${VCH.cards.length})</span>`;

    const miniList = document.getElementById('voucherMiniList');
    miniList.innerHTML = '';
    VCH.cards.forEach((c, i) => {
        if (i === 0) return;
        const div = document.createElement('div');
        div.className = 'voucher-mini-card';
        div.dataset.index = i;
        div.onclick = () => jumpToVoucher(i);
        div.innerHTML = `
            <span class="voucher-mini-idx">كرت ${i + 1}</span>
            <span class="voucher-mini-code masked" dir="ltr" data-code="${esc(c.code)}">${maskVoucherCode(c.code)}</span>
            <span class="voucher-mini-price">${esc(c.price)} ريال</span>
        `;
        miniList.appendChild(div);
    });

    renderVoucherAll();
    document.getElementById('successModal').classList.add('active');
    setupVoucherSwipe();
}

function maskVoucherCode(code) {
    return '*'.repeat(String(code || '').length);
}

function renderVoucherAll() {
    renderMainVoucher();
    renderVoucherDots();
    renderVoucherMiniCodes();
    updateVoucherMiniActive();
    updateVoucherEyeIcon();
}

function renderMainVoucher() {
    const card = VCH.cards[VCH.index];
    if (!card) return;

    document.getElementById('voucherPkgName').textContent = VCH.pkgName;
    document.getElementById('voucherPriceNum').textContent = card.price;
    document.getElementById('voucherTxn').textContent = card.txn;
    document.getElementById('voucherCodeLabel').textContent = `كود البطاقة — رمز ${VCH.index + 1}`;
    document.getElementById('voucherTitleCount').textContent = `البطاقة ${VCH.index + 1} من ${VCH.cards.length}`;

    const codeEl = document.getElementById('voucherCode');
    codeEl.textContent = VCH.visible ? card.code : maskVoucherCode(card.code);
    codeEl.classList.toggle('masked', !VCH.visible);

    const metaList = document.getElementById('voucherMetaList');
    metaList.innerHTML = `
        <li><i class="fas fa-bolt"></i><span>مفتوح التحميل</span></li>
        ${VCH.timeLimit ? `<li><i class="fa-regular fa-clock"></i><span>${esc(VCH.timeLimit)}</span></li>` : ''}
        ${VCH.duration ? `<li><i class="fas fa-calendar-day"></i><span>${esc(VCH.duration)}</span></li>` : ''}
    `;
}

function renderVoucherDots() {
    const dots = document.getElementById('voucherDots');
    dots.innerHTML = '';
    VCH.cards.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.className = 'v-dot-indicator' + (i === VCH.index ? ' active' : '');
        dot.type = 'button';
        dot.setAttribute('aria-label', `البطاقة ${i + 1}`);
        dot.onclick = () => jumpToVoucher(i);
        dots.appendChild(dot);
    });
}

function renderVoucherMiniCodes() {
    document.querySelectorAll('#voucherMiniList .voucher-mini-code').forEach(el => {
        const code = el.dataset.code || '';
        el.textContent = VCH.visible ? code : maskVoucherCode(code);
        el.classList.toggle('masked', !VCH.visible);
    });
}

function updateVoucherMiniActive() {
    document.querySelectorAll('#voucherMiniList .voucher-mini-card').forEach(el => {
        el.classList.toggle('active', parseInt(el.dataset.index, 10) === VCH.index);
    });
}

function updateVoucherEyeIcon() {
    const icon = document.getElementById('voucherEyeIcon');
    const btn = document.getElementById('voucherEyeBtn');
    if (!icon || !btn) return;
    if (VCH.visible) {
        icon.className = 'fa-regular fa-eye-slash';
        btn.title = 'إخفاء الكود';
        btn.classList.add('eye-on');
    } else {
        icon.className = 'fa-regular fa-eye';
        btn.title = 'إظهار الكود';
        btn.classList.remove('eye-on');
    }
}

function toggleVoucherVisibility(e) {
    if (e) e.stopPropagation();
    VCH.visible = !VCH.visible;
    renderVoucherAll();
}

function jumpToVoucher(index) {
    if (index === VCH.index || index < 0 || index >= VCH.cards.length) return;
    VCH.index = index;
    renderVoucherAll();
}

function navigateVoucher(direction) {
    const newIndex = VCH.index + direction;
    if (newIndex < 0 || newIndex >= VCH.cards.length) return;
    VCH.index = newIndex;
    renderVoucherAll();
}

function setupVoucherSwipe() {
    const v = document.getElementById('mainVoucher');
    if (!v || v._swipeBound) return;
    v._swipeBound = true;

    let tStartX = 0, tStartY = 0, tMoved = false;
    v.addEventListener('touchstart', e => {
        tStartX = e.changedTouches[0].screenX;
        tStartY = e.changedTouches[0].screenY;
        tMoved = false;
    }, { passive: true });
    v.addEventListener('touchmove', () => { tMoved = true; }, { passive: true });
    v.addEventListener('touchend', e => {
        const dx = e.changedTouches[0].screenX - tStartX;
        const dy = e.changedTouches[0].screenY - tStartY;
        if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) navigateVoucher(1); else navigateVoucher(-1);
        } else if (!tMoved) {
            copyCurrentVoucher();
        }
    }, { passive: true });

    let mStartX = 0, mDown = false, mMoved = false;
    v.addEventListener('mousedown', e => { mStartX = e.clientX; mDown = true; mMoved = false; });
    v.addEventListener('mousemove', () => { if (mDown) mMoved = true; });
    v.addEventListener('mouseup', e => {
        if (!mDown) return;
        mDown = false;
        const dx = e.clientX - mStartX;
        if (Math.abs(dx) > 60) { if (dx > 0) navigateVoucher(1); else navigateVoucher(-1); }
        else if (!mMoved) copyCurrentVoucher();
    });
    v.addEventListener('mouseleave', () => { mDown = false; });
}

function copyCurrentVoucher(e) {
    if (e) e.stopPropagation();
    const card = VCH.cards[VCH.index];
    if (!card) return;
    copyVoucherText(card.code, 'تم نسخ الكود بنجاح!');
}

function copyAllVoucherCodes() {
    const all = VCH.cards.map(c => c.code).join('\n');
    copyVoucherText(all, 'تم نسخ جميع الأكواد!');
}

function copyVoucherText(text, successMessage) {
    const done = () => {
        if (typeof showAlert === 'function') showAlert(successMessage, true);
        if (typeof playSystemSuccessSound === 'function') playSystemSuccessSound();
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopyVoucherText(text, done));
    } else {
        fallbackCopyVoucherText(text, done);
    }
}

function fallbackCopyVoucherText(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    try { if (document.execCommand('copy')) done(); } catch (err) { console.error(err); }
    document.body.removeChild(ta);
}

function toggleVoucherAllCards() {
    const container = document.getElementById('voucherAllCards');
    const copyBtn = document.getElementById('voucherCopyBtn');
    VCH.allVisible = !VCH.allVisible;
    if (VCH.allVisible) {
        container.classList.remove('hidden');
        copyBtn.innerHTML = '<i class="fas fa-layer-group"></i><span>نسخ الكل</span>';
        copyBtn.setAttribute('onclick', 'copyAllVoucherCodes()');
    } else {
        container.classList.add('hidden');
        copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i><span>نسخ</span>';
        copyBtn.setAttribute('onclick', 'copyCurrentVoucher()');
    }
}

function formatVoucherShareText(card, cardIndex) {
    const who = VCH.isSelf ? 'لنفسي' : ('للعميل: ' + VCH.customerId);
    return `كرت ${VCH.pkgName}
فئة ${card.price} ريال
رمز ${cardIndex}: ${card.code}
${who}
رقم العملية: ${card.txn}`;
}

function sendVoucherSMS() {
    const card = VCH.cards[VCH.index];
    if (!card) return;
    const smsText = formatVoucherShareText(card, VCH.index + 1);
    try { window.location.href = `sms:?body=${encodeURIComponent(smsText)}`; }
    catch (err) { copyVoucherText(smsText, 'تم نسخ نص الرسالة!'); }
}

async function shareVoucherImage() {
    const card = VCH.cards[VCH.index];
    if (!card || typeof html2canvas === 'undefined') {
        shareVoucherFallbackText();
        return;
    }
    setVoucherShareLoading(true);
    try { if (document.fonts && document.fonts.ready) await document.fonts.ready; } catch (_) {}

    const container = document.getElementById('voucherShareCanvas');
    container.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.style.cssText = 'padding:20px;background:linear-gradient(160deg,#0b0f1a,#161b22);font-family:Cairo,sans-serif;direction:rtl;';
    wrap.innerHTML = `
        <div style="border-radius:20px;overflow:hidden;background:#161b22;border:1px solid #2a3340;box-shadow:0 15px 35px -15px rgba(0,0,0,.6);">
            <div style="padding:16px 18px;background:linear-gradient(120deg,#0d1231,#1a237e);color:#fff;display:flex;justify-content:space-between;align-items:center;">
                <div>
                    <p style="margin:0;font-size:14px;font-weight:800;">${esc(VCH.pkgName)}</p>
                    <p style="margin:2px 0 0;font-size:9px;opacity:.75;">بطاقة إنترنت مسبقة الدفع</p>
                </div>
                <div style="background:#fbbf24;color:#0d1231;border-radius:999px;padding:5px 12px;font-size:13px;font-weight:900;">${esc(card.price)} ريال</div>
            </div>
            <div style="padding:18px;">
                <div style="display:flex;justify-content:center;background:rgba(255,255,255,.03);border:1.5px dashed rgba(251,191,36,.4);border-radius:14px;padding:16px;margin-bottom:14px;">
                    <span style="font-size:24px;font-weight:900;letter-spacing:5px;color:#fbbf24;direction:ltr;">${esc(card.code)}</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:12px;color:#94a3b8;font-weight:700;margin-bottom:6px;"><span>رقم العملية</span><span style="color:#f1f5f9;">${esc(card.txn)}</span></div>
                <div style="display:flex;justify-content:space-between;font-size:12px;color:#94a3b8;font-weight:700;"><span>${VCH.isSelf ? 'لنفسي' : 'العميل'}</span><span style="color:#f1f5f9;">${VCH.isSelf ? '—' : esc(VCH.customerId)}</span></div>
            </div>
        </div>
    `;
    container.appendChild(wrap);

    let canvas;
    try {
        canvas = await html2canvas(wrap, { scale: 3, backgroundColor: null, useCORS: true, logging: false });
    } catch (err) {
        console.error(err);
        container.innerHTML = '';
        setVoucherShareLoading(false);
        shareVoucherFallbackText();
        return;
    }
    container.innerHTML = '';

    canvas.toBlob(async (blob) => {
        if (!blob) { setVoucherShareLoading(false); shareVoucherFallbackText(); return; }
        const file = new File([blob], `kawant-card-${card.code}.png`, { type: 'image/png' });
        if (navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share) {
            try {
                await navigator.share({ files: [file], title: 'بطاقة كوفانت', text: `بطاقة ${VCH.pkgName} — رمز ${VCH.index + 1}` });
                setVoucherShareLoading(false);
                return;
            } catch (err) {
                if (err && err.name === 'AbortError') { setVoucherShareLoading(false); return; }
            }
        }
        downloadVoucherImage(blob, card.code);
        setVoucherShareLoading(false);
    }, 'image/png', 0.95);
}

function downloadVoucherImage(blob, code) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `kawant-card-${code}.png`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    if (typeof showAlert === 'function') showAlert('تم تنزيل صورة البطاقة!', true);
}

function shareVoucherFallbackText() {
    const card = VCH.cards[VCH.index];
    if (!card) return;
    const text = formatVoucherShareText(card, VCH.index + 1);
    if (navigator.share) {
        navigator.share({ title: 'بطاقة كوفانت', text }).catch(() => copyVoucherText(text, 'تم نسخ نص المشاركة!'));
    } else {
        copyVoucherText(text, 'تم نسخ نص المشاركة!');
    }
}

function setVoucherShareLoading(on) {
    const btn = document.getElementById('voucherShareBtn');
    const icon = document.getElementById('voucherShareIcon');
    const lbl = document.getElementById('voucherShareLabel');
    if (!btn) return;
    if (on) {
        icon.className = 'fas fa-circle-notch fa-spin';
        lbl.textContent = 'جارٍ...';
        btn.disabled = true; btn.style.opacity = '0.6'; btn.style.pointerEvents = 'none';
    } else {
        icon.className = 'fas fa-image';
        lbl.textContent = 'مشاركة';
        btn.disabled = false; btn.style.opacity = '1'; btn.style.pointerEvents = '';
    }
}

function pickContact() {
    const errorDiv = document.getElementById('contactError');
    errorDiv.style.display = 'none';
    if (!navigator.contacts || typeof navigator.contacts.select !== 'function') {
        document.getElementById('errorText').textContent = 'جهازك أو متصفحك لا يدعم اختيار جهات الاتصال. الرجاء الإدخال يدوياً.';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 6000);
        return;
    }
    navigator.contacts.select(['name', 'tel'], { multiple: false }).then(contacts => {
        if (contacts && contacts.length > 0 && contacts[0].tel && contacts[0].tel.length > 0) {
            let raw = contacts[0].tel[0];
            let cleaned = raw.replace(/[\s\-\(\)]/g, '');
            cleaned = cleaned.replace(/^(?:\+966|966|00966|0?966)/, '');
            if (cleaned.startsWith('0')) cleaned = cleaned.substring(1);
            cleaned = cleaned.replace(/[^0-9]/g, '');
            if (cleaned) {
                document.getElementById('customerId').value = cleaned;
                localStorage.setItem('customerId', cleaned);
            } else {
                document.getElementById('errorText').textContent = 'الرقم المستورد غير صالح. الرجاء الإدخال يدوياً.';
                errorDiv.style.display = 'block';
                setTimeout(() => errorDiv.style.display = 'none', 6000);
            }
        }
    }).catch(err => {
        let msg = 'حدث خطأ أثناء محاولة فتح جهات الاتصال. الرجاء الإدخال يدوياً.';
        if (err.name === 'InvalidStateError') msg = 'تعذر فتح جهات الاتصال بسبب قيود المتصفح. الرجاء الإدخال يدوياً.';
        else if (err.name === 'NotAllowedError') msg = 'تم رفض الوصول إلى جهات الاتصال. الرجاء الإدخال يدوياً.';
        document.getElementById('errorText').textContent = msg;
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 6000);
    });
}

// ============================================================
// SUPPORT
// ============================================================
function getChatId(phone) { return (phone || 'unknown') + '_admin'; }

function openSupportPage() {
    if (!APP.user) return Swal.fire('تنبيه', 'الرجاء تسجيل الدخول أولاً', 'warning');
    document.getElementById('chatPage').classList.add('active');
    database.ref('users/' + APP.user.phone).update({ isOnline: true });
    database.ref('admin/isOnline').on('value', (snap) => {
        APP.adminOnline = snap?.val() === true;
        updateUserChatStatus();
        loadMessages(APP.user.phone, 'userChatMessagesArea', false);
    });
}

function updateUserChatStatus() {
    const st = document.getElementById('userChatStatus');
    if (!st) return;
    st.innerHTML = APP.adminOnline ?
        '<span class="online-dot"></span> <span>متصل الآن</span>' :
        '<span class="offline-dot"></span> <span>غير متصل حالياً</span>';
}

function closeChatPage() {
    document.getElementById('chatPage').classList.remove('active');
    if (APP.user) {
        database.ref('chats/' + getChatId(APP.user.phone)).off();
        database.ref('users/' + APP.user.phone).update({ isOnline: false });
        database.ref('chats/' + getChatId(APP.user.phone) + '/typing').remove();
        database.ref('admin/isOnline').off();
    }
    APP.adminOnline = false;
    APP.selectedMessage = null;
}

function loadMessages(phone, containerId, isAdmin) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const safePhone = phone || 'unknown';
    const chatRef = database.ref('chats/' + getChatId(safePhone));
    chatRef.off('value');
    chatRef.on('value', (snap) => {
        let msgs = snap?.val();
        if (msgs && msgs.typing) delete msgs.typing;
        if (!msgs) {
            container.innerHTML =
                `<div class="empty-chat-msg"><i class="fas fa-comment-dots"></i><p>لا توجد رسائل سابقة</p><span>${isAdmin ? 'ابدأ المحادثة مع العميل' : 'ابدأ المحادثة مع فريق الدعم'}</span></div>`;
            return;
        }
        const recipientOnline = isAdmin ? (APP.viewedUserOnline === true) : (APP.adminOnline === true);
        let html = '',
            lastDate = '';
        const sorted = Object.values(msgs).sort((a, b) => a.timestamp - b.timestamp);
        sorted.forEach((m, idx) => {
            const d = formatDateLabel(m.timestamp);
            if (d !== lastDate) { html += `<div class="date-divider">${d}</div>`; lastDate = d; }
            let outgoing = isAdmin ? (m.from === 'admin') : (m.from === safePhone);
            let isRead = m.read === true;
            let isDelivered = m.delivered === true || (outgoing && recipientOnline);
            let statusIcon = isRead ?
                '<i class="fas fa-check-double read-status read"></i>' :
                (isDelivered ?
                    '<i class="fas fa-check-double read-status delivered"></i>' :
                    '<i class="fas fa-check read-status sent"></i>');
            html += `
                <div class="message-row ${outgoing ? 'outgoing' : 'incoming'}" data-msg-text="${esc(m.text)}">
                    <div class="message-bubble">
                        <div>${esc(m.text)}</div>
                        <div class="message-time">
                            <span>${new Date(m.timestamp).toLocaleTimeString()}</span>
                            ${outgoing ? statusIcon : ''}
                        </div>
                    </div>
                </div>
            `;
            const key = Object.keys(msgs).find(k => msgs[k].timestamp === m.timestamp && msgs[k].from === m.from);
            if (!key) return;
            const activeEl = document.getElementById(isAdmin ? 'chatDetailPage' : 'chatPage');
            if (!outgoing && !isRead && activeEl && activeEl.classList.contains('active')) {
                database.ref('chats/' + getChatId(safePhone) + '/' + key).update({ delivered: true, read: true });
            } else if (outgoing && m.delivered !== true && recipientOnline) {
                database.ref('chats/' + getChatId(safePhone) + '/' + key + '/delivered').set(true);
            }
        });
        container.innerHTML = html;
        container.scrollTop = container.scrollHeight;
    });
}

function formatDateLabel(ts) {
    const now = new Date();
    const d = new Date(ts);
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yest = new Date(today);
    yest.setDate(yest.getDate() - 1);
    const msgDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    if (msgDay.getTime() === today.getTime()) return 'اليوم';
    if (msgDay.getTime() === yest.getTime()) return 'أمس';
    const diff = Math.floor((today - msgDay) / (1000 * 60 * 60 * 24));
    if (diff < 7) {
        const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
        return days[d.getDay()];
    }
    return d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' });
}

function sendMessage(role) {
    let phone, inputId, chatId, containerId;
    if (role === 'user') {
        if (!APP.user) return;
        phone = APP.user.phone;
        inputId = 'userChatInput';
        chatId = getChatId(phone);
        containerId = 'userChatMessagesArea';
    } else {
        if (!APP.currentTicketId) return Swal.fire('خطأ', 'لم يتم تحديد المستخدم', 'error');
        phone = APP.currentTicketId;
        inputId = 'chatMsgInput';
        chatId = getChatId(phone);
        containerId = 'chatMessagesBox';
    }
    const inp = document.getElementById(inputId);
    const text = inp.value.trim();
    if (!text) return;
    database.ref('chats/' + chatId + '/typing').remove();
    const ref = database.ref('chats/' + chatId).push();
    const from = role === 'user' ? phone : 'admin';
    ref.set({ from, to: role === 'user' ? 'admin' : phone, text, timestamp: Date.now(), delivered: false, read: false });
    inp.value = '';
    if (role === 'user') database.ref('users/' + phone).update({ isOnline: true });
}

function handleTypingStart(role) {
    let phone;
    if (role === 'user') { if (!APP.user) return; phone = APP.user.phone; } else { if (!APP.currentTicketId) return;
        phone = APP.currentTicketId; }
    const chatId = getChatId(phone);
    const from = role === 'user' ? phone : 'admin';
    database.ref('chats/' + chatId + '/typing').set({ from, isTyping: true, timestamp: Date.now() });
    if (APP.typingTimeout) clearTimeout(APP.typingTimeout);
    APP.typingTimeout = setTimeout(() => { database.ref('chats/' + chatId + '/typing').remove(); }, 3000);
}

// ============================================================
// BANNERS & NEWS TICKER
// ============================================================
function loadUserBanners() {
    const wrap = document.getElementById('bannerWrapper');
    const dotsContainer = document.getElementById('dotsContainer');
    if (!wrap || !dotsContainer) return;

    let bannerIdx = 0;
    let bannerTimer = null;
    let intervalMs = 4500;

    function renderBanners(images) {
        if (bannerTimer) { clearInterval(bannerTimer); bannerTimer = null; }
        const BN_STEP = i => `translateX(calc(-${i} * (100% + 10px)))`;
        wrap.style.transform = BN_STEP(0);

        if (!images || !images.length) {
            wrap.innerHTML = '<div class="banner-slide" style="background:linear-gradient(135deg,#0d1231,#1a237e);"><div class="banner-overlay"></div><div class="banner-text"><h3>🚀 مرحباً بك في كوفانت</h3><p>خدماتك المالية بين يديك</p></div></div>';
            dotsContainer.innerHTML = '';
            return;
        }

        wrap.innerHTML = images.map(img => {
            const url = typeof img === 'string' ? img : (img.url || '');
            const title = (typeof img === 'object' && img.title) ? img.title : '';
            const sub = (typeof img === 'object' && img.sub) ? img.sub : '';
            const textBlock = (title || sub)
                ? `<div class="banner-overlay"></div><div class="banner-text">${title ? `<h3>${esc(title)}</h3>` : ''}${sub ? `<p>${esc(sub)}</p>` : ''}</div>`
                : '<div class="banner-overlay"></div>';
            return `<div class="banner-slide" style="background-image:url('${esc(url)}');">${textBlock}</div>`;
        }).join('');

        dotsContainer.innerHTML = images.map((_, i) => `<span class="dot ${i === 0 ? 'active' : ''}"></span>`).join('');
        bannerIdx = 0;

        if (images.length > 1) {
            bannerTimer = setInterval(() => {
                bannerIdx = (bannerIdx + 1) % images.length;
                wrap.style.transform = BN_STEP(bannerIdx);
                dotsContainer.querySelectorAll('.dot').forEach((d, i) => d.classList.toggle('active', i === bannerIdx));
            }, intervalMs);
        }
    }

    database.ref('settings/bannerInterval').on('value', snap => {
        const val = snap?.val();
        if (val) intervalMs = Number(val) * 1000;
    });

    database.ref('banners').on('value', snap => {
        let images = [];
        if (snap?.exists()) {
            const data = snap.val();
            images = Array.isArray(data) ? data.filter(Boolean) : Object.values(data).filter(Boolean);
        }
        renderBanners(images);
    });
}

const _newsTickerState = { texts: ['مرحباً بك في كوفانت'], speed: 80, index: 0, timer: null };

function loadNewsTicker() {
    database.ref('newsTexts').on('value', snap => {
        let texts = [];
        if (snap?.exists()) {
            const data = snap.val();
            texts = Array.isArray(data) ? data.filter(Boolean) : Object.values(data).filter(Boolean);
        }
        _newsTickerState.texts = texts.length ? texts : ['مرحباً بك في كوفانت'];
        _newsTickerState.index = 0;
        restartNewsTicker();
    });

    database.ref('settings/typingSpeed').on('value', snap => {
        const val = snap?.val();
        _newsTickerState.speed = val ? Number(val) : 80;
    });
}

function restartNewsTicker() {
    if (_newsTickerState.timer) {
        clearTimeout(_newsTickerState.timer);
        _newsTickerState.timer = null;
    }
    typeNextNewsText();
}

function typeNextNewsText() {
    const el = document.getElementById('alertText');
    if (!el) return;
    const texts = _newsTickerState.texts;
    if (!texts.length) return;

    const text = texts[_newsTickerState.index % texts.length];
    let charIdx = 0;
    el.textContent = '';

    function typeChar() {
        if (charIdx <= text.length) {
            el.textContent = text.slice(0, charIdx);
            charIdx++;
            _newsTickerState.timer = setTimeout(typeChar, _newsTickerState.speed);
        } else {
            _newsTickerState.timer = setTimeout(() => {
                _newsTickerState.index++;
                typeNextNewsText();
            }, 2000);
        }
    }
    typeChar();
}

// ============================================================
// PROFILE / SETTINGS
// ============================================================
function loadProfilePage() {
    const toggle = document.getElementById('profileRequirePinToggle');
    if (toggle && APP.user) {
        toggle.checked = APP.user.requirePin === true;
        toggle.onchange = async function (e) {
            const checked = e.target.checked;
            const ok = await updateRequirePin(checked);
            if (!ok) toggle.checked = !checked;
        };
    }
    const pOldPass = document.getElementById('profileOldPass');
    const pNewPass = document.getElementById('profileNewPass');
    const pOldPin = document.getElementById('profileOldPin');
    const pNewPin = document.getElementById('profileNewPin');
    const pNewPhone = document.getElementById('pdNewPhoneNumber');

    if (pOldPass) pOldPass.value = '';
    if (pNewPass) pNewPass.value = '';
    if (pOldPin) pOldPin.value = '';
    if (pNewPin) pNewPin.value = '';
    if (pNewPhone) pNewPhone.value = '';

    updateProfileHeroUI(APP.user);
    loadProfileSessionDuration();

    if (typeof syncBiometricToggle === 'function') syncBiometricToggle();
    if (typeof updateOfflineStatus === 'function') updateOfflineStatus();

    const notifToggle = document.getElementById('pdNotificationsToggle');
    if (notifToggle) notifToggle.checked = APP.notificationsPrefEnabled === true;
}

function updateProfileHeroUI(user) {
    if (!user) return;
    const name = user.fullName || 'مستخدم كوفانت';
    const elName = document.getElementById('pdDetailName');
    const elPhone = document.getElementById('pdDetailPhone');
    const elAcc = document.getElementById('pdAccountNumber');
    const elDob = document.getElementById('pdDateOfBirth');
    const elAddr = document.getElementById('pdAddress');

    if (elName) elName.textContent = name;
    if (elPhone) elPhone.textContent = user.phone || '---';
    if (elAcc) elAcc.textContent = user.accountNumber || '---';
    if (elDob) elDob.textContent = user.birthDate || '---';
    if (elAddr) elAddr.textContent = user.address || '---';

    const avatarEl = document.getElementById('pdAvatar');
    const avatarText = document.getElementById('pdAvatarText');
    if (!avatarEl || !avatarText) return;

    if (user.avatar) {
        avatarText.style.display = 'none';
        let img = avatarEl.querySelector('img');
        if (!img) {
            img = document.createElement('img');
            avatarEl.appendChild(img);
        }
        img.src = user.avatar;
    } else {
        avatarText.style.display = '';
        const img = avatarEl.querySelector('img');
        if (img) img.remove();
        avatarText.textContent = name.charAt(0).toUpperCase();
    }
}

window.handleProfileAvatarUpload = function (event) {
    if (!APP.user?.phone) {
        if (typeof showAlert === 'function') showAlert('يرجى تسجيل الدخول أولاً', false);
        return;
    }
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
        if (typeof showAlert === 'function') showAlert('حجم الصورة كبير جداً (الحد الأقصى 1 ميجابايت)', false);
        return;
    }
    const reader = new FileReader();
    reader.onload = async function (e) {
        const dataURL = e.target.result;
        APP.user.avatar = dataURL;
        updateProfileHeroUI(APP.user);
        try {
            await database.ref('users/' + APP.user.phone).update({ avatar: dataURL });
            if (typeof showAlert === 'function') showAlert('تم تحديث الصورة الشخصية');
        } catch (err) {
            console.error('avatar upload error:', err);
            if (typeof showAlert === 'function') showAlert('تعذر حفظ الصورة', false);
        }
    };
    reader.readAsDataURL(file);
};

window.changeProfilePhone = async function () {
    if (!APP.user?.phone) {
        if (typeof showAlert === 'function') showAlert('يرجى تسجيل الدخول أولاً', false);
        return;
    }
    const newPhone = document.getElementById('pdNewPhoneNumber').value.trim();
    if (!newPhone) {
        if (typeof showAlert === 'function') showAlert('أدخل رقم الجوال الجديد', false);
        return;
    }
    if (!isValidYemeniPhone(newPhone)) {
        if (typeof showAlert === 'function') showAlert('رقم الجوال يجب أن يبدأ بـ 7 ويتكون من 9 أرقام', false);
        return;
    }
    if (newPhone === APP.user.phone) {
        if (typeof showAlert === 'function') showAlert('هذا هو رقمك الحالي', false);
        return;
    }

    try {
        const res = await fetch('https://kovant-backend3.onrender.com/change-phone-number', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ newPhone })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            Swal.fire('خطأ', data.error || 'حدث خطأ أثناء تغيير الرقم', 'error');
            return;
        }

        if (typeof showAlert === 'function') showAlert('تم تغيير رقم الجوال بنجاح، الرجاء تسجيل الدخول من جديد');
        document.getElementById('pdNewPhoneNumber').value = '';

        if (typeof disableBiometric === 'function') {
            try { await disableBiometric(); } catch (e) { /* صامت */ }
        }
        logout();
    } catch (e) {
        console.error('changeProfilePhone error:', e);
        Swal.fire('خطأ', 'حدث خطأ أثناء تغيير الرقم', 'error');
    }
};

function loadProfileSessionDuration() {
    const select = document.getElementById('pdSessionDuration');
    if (!select) return;
    select.value = localStorage.getItem('sessionDuration') || '0';
}
window.saveProfileSessionDuration = function () {
    const select = document.getElementById('pdSessionDuration');
    if (!select) return;
    const val = select.value;
    localStorage.setItem('sessionDuration', val);
    const labels = { '0': 'دائماً', '5': '5 دقائق', '10': '10 دقائق', '15': '15 دقيقة', '30': '30 دقيقة', '60': 'ساعة' };
    if (typeof showAlert === 'function') showAlert('تم حفظ مدة الجلسة: ' + (labels[val] || val));
};

function initProfileCollapsibles() {
    document.querySelectorAll('#profileInterface .pd-collapsible-header').forEach(header => {
        header.addEventListener('click', function () {
            const item = this.closest('.pd-collapsible');
            const isActive = item.classList.contains('active');
            const card = item.closest('.pd-card');
            if (card) {
                card.querySelectorAll('.pd-collapsible.active').forEach(open => {
                    if (open !== item) open.classList.remove('active');
                });
            }
            item.classList.toggle('active', !isActive);
        });
    });

    document.getElementById('pdNotificationsToggle')?.addEventListener('change', function (e) {
        APP.notificationsPrefEnabled = e.target.checked;
        if (typeof showAlert === 'function') {
            showAlert(e.target.checked ? 'تم تفعيل الإشعارات' : 'تم إلغاء تفعيل الإشعارات');
        }
    });
}

window.updateProfilePassword = async function () {
    if (!APP.user?.phone) {
        if (typeof showAlert === 'function') showAlert('يرجى تسجيل الدخول أولاً', false);
        return;
    }
    const oldPass = document.getElementById('profileOldPass').value.trim();
    const newPass = document.getElementById('profileNewPass').value.trim();

    if (!oldPass || !newPass) {
        if (typeof showAlert === 'function') showAlert('يرجى تعبئة الحقلين', false);
        return;
    }
    if (newPass.length < 6) {
        if (typeof showAlert === 'function') showAlert('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل', false);
        return;
    }

    try {
        const res = await fetch('https://kovant-backend3.onrender.com/change-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            if (typeof showAlert === 'function') showAlert(data.error || 'كلمة المرور الحالية غير صحيحة', false);
            return;
        }
        if (typeof showAlert === 'function') showAlert('تم تحديث كلمة المرور بنجاح');
        document.getElementById('profileOldPass').value = '';
        document.getElementById('profileNewPass').value = '';

        if (typeof disableBiometric === 'function') {
            try { await disableBiometric(); } catch (e) { /* صامت */ }
        }
        if (typeof syncFingerprintButton === 'function') syncFingerprintButton();
    } catch (e) {
        console.error('updateProfilePassword error:', e);
        if (typeof showAlert === 'function') showAlert('حدث خطأ أثناء التحديث', false);
    }
};

// ============================================================
// REGISTER
// ============================================================
const user = {
    async registerUser(data) {
        const {
            firstName, fatherName, grandfatherName, familyName,
            birthDay, birthMonth, birthYear, address,
            phone, password, confirmPassword, referralCode
        } = data || {};

        const deviceId = generateDeviceId(),
            deviceName = getDeviceName(),
            fingerprint = getDeviceFingerprint(),
            deviceAnalytics = await getDeviceAnalytics();

        const res = await fetch('https://kovant-backend3.onrender.com/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                firstName, fatherName, grandfatherName, familyName,
                birthDay, birthMonth, birthYear, address,
                phone, password, confirmPassword, referralCode,
                deviceId, deviceName, fingerprint, deviceAnalytics
            })
        });

        let result;
        try { result = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

        if (!res.ok || !result.success) {
            throw new Error(result.error || 'تعذر إنشاء الحساب، حاول مرة أخرى');
        }

        return { success: true, accountNumber: result.accountNumber, fullName: result.fullName };
    }
};

// ============================================================
// ✅ الوكلاء القريبين مني
// ============================================================
let _nearbyMap = null;
let _nearbyMeMarker = null;

function openNearbyAgentsMap() {
    if (!_nearbyMap) {
        const loadingEl = document.getElementById('nearbyMapLoading');
        if (loadingEl) loadingEl.classList.add('show');

        _nearbyMap = L.map('nearbyMapEl').setView([15.3694, 44.1910], 12);

        const satLayer = L.tileLayer(
            'https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
            {
                subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
                maxZoom: 21,
                attribution: '© Google Maps'
            }
        ).addTo(_nearbyMap);

        L.tileLayer(
            'https://{s}.google.com/vt/lyrs=h&x={x}&y={y}&z={z}',
            {
                subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
                maxZoom: 21,
                opacity: 0.9
            }
        ).addTo(_nearbyMap);

        if (loadingEl) {
            satLayer.on('load', () => loadingEl.classList.remove('show'));
            setTimeout(() => loadingEl.classList.remove('show'), 6000);
        }
    } else {
        setTimeout(() => _nearbyMap.invalidateSize(), 150);
    }

    if (APP.user && APP.user.location && APP.user.location.lat) {
        _renderNearbyOnMap(APP.user.location.lat, APP.user.location.lng);
        _setNearbyPermissionState(true);
    }
    setTimeout(() => _nearbyMap.invalidateSize(), 200);
}

function _setNearbyPermissionState(granted) {
    const bar = document.getElementById('nearbyPermissionBar');
    const btn = document.getElementById('enableLocationBtn');
    if (!bar) return;
    if (granted) {
        bar.classList.add('granted');
        const span = bar.querySelector('span');
        if (span) span.textContent = 'تم تحديد موقعك — تُعرض أقرب الوكلاء وتغطية الإنترنت';
        if (btn) { btn.innerHTML = '<i class="fas fa-check"></i> مُفعّل'; btn.disabled = true; }
    }
}

function enableNearbyLocation() {
    if (!navigator.geolocation) {
        return Swal.fire('غير مدعوم', 'المتصفح لا يدعم تحديد الموقع', 'error');
    }
    const btn = document.getElementById('enableLocationBtn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحديد...'; }

    navigator.geolocation.getCurrentPosition(async (pos) => {
        const lat = pos.coords.latitude, lng = pos.coords.longitude;
        _renderNearbyOnMap(lat, lng);
        _setNearbyPermissionState(true);

        if (APP.user && APP.user.phone) {
            try {
                await database.ref('locations/' + APP.user.phone).set({
                    lat, lng,
                    name: APP.user.fullName || APP.user.phone,
                    isAgent: !!APP.user.isAgent,
                    updatedAt: firebase.database.ServerValue.TIMESTAMP
                });
                APP.user.location = { lat, lng };
            } catch (e) { console.error('تعذر حفظ الموقع:', e); }
        }
    }, (err) => {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-crosshairs"></i> تحديد موقعي'; }
        Swal.fire('تعذر تحديد الموقع', 'يرجى السماح للتطبيق بالوصول إلى موقعك من إعدادات المتصفح', 'warning');
    }, { enableHighAccuracy: true, timeout: 12000 });
}

async function _renderNearbyOnMap(lat, lng) {
    if (!_nearbyMap) return;
    _nearbyMap.eachLayer(l => { if (l instanceof L.Marker || l instanceof L.Circle) _nearbyMap.removeLayer(l); });

    const meIcon = L.divIcon({ className: '', html: '<div class="leaflet-marker-me-pin"></div>', iconSize: [22, 22], iconAnchor: [11, 11] });
    _nearbyMeMarker = L.marker([lat, lng], { icon: meIcon }).addTo(_nearbyMap).bindPopup('موقعك الحالي');
    _nearbyMap.setView([lat, lng], 14);

    try {
        const snap = await database.ref('locations').once('value');
        snap.forEach(child => {
            const u = child.val() || {};
            if (u.isAgent && u.lat && u.lng) {
                const icon = L.divIcon({ className: '', html: '<div class="leaflet-marker-agent-pin"><i class="fa-solid fa-store"></i></div>', iconSize: [34, 34], iconAnchor: [17, 34] });
                L.marker([u.lat, u.lng], { icon }).addTo(_nearbyMap).bindPopup(`<b>وكيل: ${u.name || child.key}</b>`);
            }
        });
    } catch (e) { console.error('تعذر جلب الوكلاء القريبين:', e); }

    try {
        const covSnap = await database.ref('coverage').once('value');
        covSnap.forEach(child => {
            const c = child.val() || {};
            if (c.lat && c.lng) {
                L.circle([c.lat, c.lng], { radius: c.radius || 500, color: '#3b82f6', fillColor: '#3b82f6', fillOpacity: 0.15 })
                    .addTo(_nearbyMap).bindPopup(`<b>${c.name || 'منطقة تغطية'}</b>`);
            }
        });
    } catch (e) { /* لا تغطية بعد */ }
}


/* ============================================================
   تفعيل العمل بدون إنترنت عبر مسح QR
============================================================ */
let _qrActivationScanner = null;
let _qrActivationHandled = false;

window.openQRActivation = function () {
    if (typeof Html5Qrcode === 'undefined') {
        showAlert('مكتبة QR غير محملة', false);
        return;
    }
    if (!APP.user || !APP.user.phone) {
        showAlert('يجب تسجيل الدخول أولاً', false);
        return;
    }

    const scannerId = 'qr-activation-reader';
    _qrActivationHandled = false;
    Swal.fire({
        title: '📷 امسح بطاقة QR',
        html: '<div id="' + scannerId + '" style="width:100%;max-width:350px;margin:0 auto;border-radius:12px;overflow:hidden"></div><p style="font-size:12px;color:#8fa5c0;margin-top:12px">وجّه الكاميرا نحو رمز QR في بطاقتك</p>',
        showCancelButton: true,
        showConfirmButton: false,
        cancelButtonText: 'إلغاء',
        background: '#111b2d',
        color: '#e6edf3',
        didOpen: function () {
            try {
                _qrActivationScanner = new Html5Qrcode(scannerId);
                _qrActivationScanner.start(
                    { facingMode: 'environment' },
                    { fps: 10, qrbox: { width: 240, height: 240 } },
                    async function (decodedText) {
                        if (_qrActivationHandled) return;
                        _qrActivationHandled = true;
                        try { await _qrActivationScanner.stop(); } catch (error) {}
                        await window.handleQRScanned(decodedText);
                    },
                    function () {}
                ).catch(function (error) {
                    console.error('Scanner error:', error);
                    Swal.close();
                    showAlert('فشل فتح الكاميرا: ' + (error.message || 'تحقق من صلاحية الكاميرا'), false);
                });
            } catch (error) {
                Swal.close();
                showAlert('فشل تهيئة الكاميرا: ' + error.message, false);
            }
        },
        willClose: function () {
            if (_qrActivationScanner) {
                _qrActivationScanner.stop().catch(function () {});
                _qrActivationScanner = null;
            }
        }
    });
};

window.handleQRScanned = async function (decodedText) {
    try {
        let data;
        try { data = JSON.parse(String(decodedText || '')); }
        catch (error) { throw new Error('QR غير صالح — ليس بصيغة كوفانت'); }

        if (!data || data.v !== 1) throw new Error('إصدار QR غير مدعوم');
        const myPhone = APP.user && String(APP.user.phone || '').trim();
        if (!myPhone) throw new Error('يجب تسجيل الدخول أولاً');
        if (String(data.phone || '').trim() !== myPhone) throw new Error('هذه البطاقة لحساب آخر');
        if (typeof data.secret !== 'string' || data.secret.trim().length < 20 || data.secret.length > 512) throw new Error('المفتاح غير صالح');
        if (!Number.isFinite(Number(data.issuedAt)) || Date.now() - Number(data.issuedAt) > 365 * 24 * 60 * 60 * 1000) throw new Error('انتهت صلاحية بطاقة QR');
        if (!window.SMSCommand || typeof window.SMSCommand.cacheSmsSecret !== 'function') throw new Error('نظام SMS غير محمّل');

        await window.SMSCommand.cacheSmsSecret(myPhone, data.secret.trim());
        const saved = await window.SMSCommand.getCachedSmsSecret(myPhone);
        if (!saved || saved !== data.secret.trim()) throw new Error('فشل التحقق من الحفظ');

        await Swal.fire({ icon: 'success', title: '✅ تم التفعيل!', html: '<p style="font-size:15px">التطبيق يعمل بدون إنترنت الآن</p><p style="font-size:12px;color:#8fa5c0;margin-top:10px">يمكنك الشراء والتحويل دون الحاجة للإنترنت</p>', background: '#111b2d', color: '#e6edf3', confirmButtonColor: '#10b981', confirmButtonText: 'تمام' });
        updateOfflineStatus();
    } catch (error) {
        await Swal.fire({ icon: 'error', title: '❌ فشل التفعيل', text: error.message || 'بيانات QR غير صالحة', background: '#111b2d', color: '#e6edf3', confirmButtonColor: '#ef4444', confirmButtonText: 'حسناً' });
        console.error('QR activation failed:', error);
    }
};

window.isOfflineActivated = async function () {
    try {
        const phone = APP.user && APP.user.phone;
        if (!phone || !window.SMSCommand || typeof window.SMSCommand.getCachedSmsSecret !== 'function') return false;
        const secret = await window.SMSCommand.getCachedSmsSecret(phone);
        return typeof secret === 'string' && secret.length >= 20;
    } catch (error) { return false; }
};

window.updateOfflineStatus = async function () {
    const status = document.getElementById('offlineActivationStatus');
    const button = document.getElementById('offlineActivationButton');
    const active = await window.isOfflineActivated();
    if (status) status.textContent = active ? '✅ مفعّل — يمكنك استخدام SMS بدون إنترنت' : 'غير مفعّل — امسح بطاقة QR من الأدمن';
    if (status) status.style.color = active ? 'var(--green)' : 'var(--orange)';
    if (button) button.innerHTML = active ? '<i class="fas fa-rotate"></i> إعادة مسح بطاقة QR' : '<i class="fas fa-qrcode"></i> تفعيل بدون إنترنت';
    return active;
};

// تحديث الحالة عند فتح الملف الشخصي.


// ============================================================
// بيانات الوكيل: تظهر للمستخدم بعد تعيينه وكيلاً / نقطة بيع / موزعاً
// ============================================================
const AGENT_BUSINESS_TYPES = ['بقالة / سوبرماركت', 'مطعم / كافيه', 'صيدلية', 'محل اتصالات / جوالات', 'مكتبة / قرطاسية', 'محل صرافة / حوالات', 'محل ملابس', 'ورشة / خدمات', 'أخرى'];
let _agentPromptOpen = false;

function checkAgentProfile(data) {
    const tile = document.getElementById('agentProfileTile');
    const isSeller = !!(data && data.userType);
    if (tile) tile.style.display = isSeller ? '' : 'none';
    const done = data && data.agentProfile && data.agentProfile.completed;
    if (isSeller && !done && data.agentProfileRequired && !_agentPromptOpen) {
        setTimeout(() => { if (!_agentPromptOpen) openAgentProfile(); }, 800);
    }
}

window.openAgentProfile = async function () {
    if (_agentPromptOpen || !APP.user || !APP.user.phone) return;
    _agentPromptOpen = true;
    const prof = APP.user.agentProfile || {};
    let pos = (prof.lat && prof.lng) ? { lat: prof.lat, lng: prof.lng } : null;
    let map = null, marker = null;
    const opts = AGENT_BUSINESS_TYPES.map(t => `<option value="${t}"></option>`).join('');
    const res = await Swal.fire({
        title: 'بيانات الوكيل',
        html: `<div style="font-size:12px;color:#8b949e;margin-bottom:14px;">أكمل البيانات التالية لتفعيل حسابك كوكيل</div>
               <div class="ag-field"><label>رقم حساب الكريمي الخاص بك</label>
                   <input id="agKarimi" type="tel" inputmode="numeric" placeholder="أدخل رقم حساب الكريمي" value="${prof.karimiAccount || ''}"></div>
               <div class="ag-field"><label>نوع النشاط التجاري</label>
                   <input id="agBiz" list="agBizList" placeholder="اكتب أو اختر نوع النشاط" value="${prof.businessType || ''}">
                   <datalist id="agBizList">${opts}</datalist></div>
               <div class="ag-field">
                   <button type="button" class="ag-loc-btn" id="agLocBtn" style="margin-top:0;padding:12px;font-size:13px;"><i class="fas fa-location-dot"></i> <span id="agLocTxt">تحديد موقعي في الخريطة</span></button>
                   <div id="agMap" class="ag-map" style="display:none"></div>
                   <div id="agMapHint" style="display:none;font-size:11px;color:#8b949e;margin-top:6px;">اضغط على الخريطة لتحريك الدبوس إلى موقع محلك بدقة</div></div>`,
        showCancelButton: true,
        confirmButtonText: 'حفظ',
        cancelButtonText: 'لاحقاً',
        background: '#161b22', color: '#e6edf3',
        confirmButtonColor: '#1a6fa8', cancelButtonColor: '#2a3340',
        allowOutsideClick: false,
        didOpen: () => {
            const mapEl = document.getElementById('agMap');
            const txt = document.getElementById('agLocTxt');
            const btn = document.getElementById('agLocBtn');
            const markDone = () => { txt.textContent = 'تم تحديد الموقع ✓ (اضغط للتعديل)'; btn.style.background = 'rgba(16,185,129,0.12)'; btn.style.color = '#10b981'; };
            const setPos = (lat, lng, zoom) => {
                pos = { lat, lng };
                if (marker) marker.setLatLng([lat, lng]); else marker = L.marker([lat, lng]).addTo(map);
                if (zoom) map.setView([lat, lng], zoom);
                markDone();
            };
            const showMap = () => {
                mapEl.style.display = 'block';
                document.getElementById('agMapHint').style.display = 'block';
                if (!map) {
                    map = L.map('agMap').setView(pos ? [pos.lat, pos.lng] : [15.35, 44.2], pos ? 17 : 6);
                    L.tileLayer('https://{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', { subdomains: ['mt0', 'mt1', 'mt2', 'mt3'], maxZoom: 20 }).addTo(map);
                    if (pos) { marker = L.marker([pos.lat, pos.lng]).addTo(map); }
                    map.on('click', e => setPos(e.latlng.lat, e.latlng.lng));
                }
                setTimeout(() => map.invalidateSize(), 200);
            };
            if (pos) markDone();
            btn.addEventListener('click', () => {
                showMap();
                if (!navigator.geolocation) return;
                txt.textContent = 'جاري تحديد موقعك...';
                navigator.geolocation.getCurrentPosition(
                    p => setPos(p.coords.latitude, p.coords.longitude, 18),
                    () => { txt.textContent = pos ? 'تم تحديد الموقع ✓ (اضغط للتعديل)' : 'تحديد موقعي في الخريطة'; },
                    { enableHighAccuracy: true, timeout: 12000 });
            });
        },
        preConfirm: () => {
            const karimi = document.getElementById('agKarimi').value.trim();
            const biz = document.getElementById('agBiz').value.trim();
            if (!karimi) return Swal.showValidationMessage('أدخل رقم حساب الكريمي');
            if (!biz) return Swal.showValidationMessage('أدخل نوع النشاط التجاري');
            if (!pos) return Swal.showValidationMessage('اضغط زر تحديد الموقع في الخريطة');
            return { karimiAccount: karimi, businessType: biz, lat: pos.lat, lng: pos.lng };
        }
    });
    _agentPromptOpen = false;
    if (map) { try { map.remove(); } catch (e) {} }
    if (!res.isConfirmed) return;
    const v = res.value, phone = APP.user.phone;
    try {
        await database.ref('users/' + phone).update({
            agentProfile: { ...v, completed: true, updatedAt: firebase.database.ServerValue.TIMESTAMP },
            agentProfileRequired: null
        });
        await database.ref('locations/' + phone).set({
            lat: v.lat, lng: v.lng,
            name: APP.user.fullName || phone,
            isAgent: true, userType: APP.user.userType || 'agent',
            businessType: v.businessType,
            updatedAt: firebase.database.ServerValue.TIMESTAMP
        });
        APP.user.location = { lat: v.lat, lng: v.lng };
        Swal.fire({ title: 'تم حفظ بياناتك', icon: 'success', toast: true, position: 'top', timer: 1800, showConfirmButton: false });
    } catch (e) {
        Swal.fire('خطأ', 'تعذّر حفظ البيانات، حاول مرة أخرى', 'error');
    }
};
