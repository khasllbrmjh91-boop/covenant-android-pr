# KovaNet

تطبيق KovaNet Android/PWA مع خادم Node.js محصّن.

## التشغيل والنشر

```bash
npm install
npm start
```

Render:
- Build command: `npm install`
- Start command: `npm start`
- Node.js: 18 أو أحدث
- ضع متغيرات `.env.example` في Render Environment Variables.
- لا ترفع `.env` أو `node_modules` إلى GitHub.

## تطبيق Android / Capacitor

```bash
npm run cap:sync
npm run cap:open:android
```

ملفات Android وCapacitor وواجهة التطبيق موجودة في الجذر ولا تحتاج إلى حذفها عند تحديث الخادم.

## الخادم

الخادم موجود بالكامل في `server.js` ولا يعتمد على `src/` أو أي ملف JavaScript محلي آخر. يحتوي على حماية التحويل والشراء، Idempotency، rollback، ترحيل رقم الهاتف، CORS صريح، Helmet، logout، وGET/POST webhook مع HMAC.

### استراتيجية استضافة الواجهة وService Worker

`server.js` خادم **API فقط**؛ لا يستخدم `express.static` ولا يقدّم `index.html` أو ملفات CSS/JS أو Service Worker. لذلك يجب نشر الواجهة الأمامية كاملةً على استضافة Static مثل Netlify أو Vercel، ويجب أن يكون الملفان التاليان في جذر **نطاق الواجهة نفسه**:

- `/service-worker.js`
- `/firebase-messaging-sw.js`

إذا كانت الصفحة على `https://frontend.example.com`، فيجب أن ينجح:

```bash
curl -I https://frontend.example.com/service-worker.js
curl -I https://frontend.example.com/firebase-messaging-sw.js
```

لا تضع ملفات Service Worker على نطاق الـ API فقط؛ تسجيل Service Worker يتطلب Same-Origin مع الصفحة. يقوم `js/bootstrap.js` بتسجيل العاملين مرة واحدة وبشكل اختياري، ولا يمنع ظهور شاشة تسجيل الدخول إذا فشل أحدهما.

## الاختبارات والفحص

```bash
npm test
npm run lint
npm audit
```
