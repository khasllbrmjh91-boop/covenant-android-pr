package com.kova.cash.plugins

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.kova.cash.R

/**
 * TuaNotification — إشعار دائم + Overlay لسرعة الإنترنت
 */
@CapacitorPlugin(name = "TuaNotification")
class TuaNotificationPlugin : Plugin() {

    companion object {
        const val CHANNEL_ID = "cova_net_speed"
        const val CHANNEL_NAME = "سرعة الإنترنت"
        const val NOTIF_ID = 90001
    }

    override fun load() {
        createChannel()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW).apply {
                description = "إشعار دائم يعرض سرعة الإنترنت"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(ch)
        }
    }

    private fun hasNotifPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(context, "android.permission.POST_NOTIFICATIONS") ==
                PackageManager.PERMISSION_GRANTED
    }

    // ✅ override لأن الأب Plugin يحتوي عليها
    @PluginMethod
    override fun checkPermissions(call: PluginCall) {
        val r = JSObject()
        r.put("notifications", if (hasNotifPermission()) "granted" else "denied")
        call.resolve(r)
    }

    // ✅ override
    @PluginMethod
    override fun requestPermissions(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotifPermission()) {
            requestPermissionForAlias("notifications", call, "notifPermsCallback")
        } else {
            checkPermissions(call)
        }
    }

    @com.getcapacitor.annotation.PermissionCallback
    private fun notifPermsCallback(call: PluginCall) {
        checkPermissions(call)
    }

    @PluginMethod
    fun showSpeedNotification(call: PluginCall) {
        try {
            val number = call.getString("number") ?: "0"
            val unit = call.getString("unit") ?: "KB/s"
            val fullText = call.getString("fullText") ?: "0 KB/s"
            val downText = call.getString("downText") ?: fullText
            val upText = call.getString("upText") ?: ""
            val usageText = call.getString("usageText") ?: ""

            if (!hasNotifPermission()) {
                call.reject("NOTIF_PERMISSION_DENIED", "الإشعارات غير مسموح بها")
                return
            }

            val line1 = if (upText.isNotBlank()) "$downText   $upText" else downText
            val line2 = usageText

            val remoteViews = RemoteViews(context.packageName, R.layout.cova_notification).apply {
                setTextViewText(R.id.cova_badge_number, number)
                setTextViewText(R.id.cova_badge_unit, unit)
                setTextViewText(R.id.cova_title, "كوفانت")
                setTextViewText(R.id.cova_line1, line1)
                setTextViewText(R.id.cova_line2, line2)
            }

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setOngoing(true)
                .setSilent(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setCustomContentView(remoteViews)
                .setCustomBigContentView(remoteViews)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())

            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    val pi = PendingIntent.getActivity(
                        context, 0, launchIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    builder.setContentIntent(pi)
                }
            } catch (_: Exception) {}

            NotificationManagerCompat.from(context).notify(NOTIF_ID, builder.build())
            call.resolve(JSObject().put("success", true))

        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun hideSpeedNotification(call: PluginCall) {
        try {
            NotificationManagerCompat.from(context).cancel(NOTIF_ID)
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun updateSpeedSettings(call: PluginCall) {
        try {
            val prefs = context.getSharedPreferences("cova_speed_settings", Context.MODE_PRIVATE)
            val editor = prefs.edit()

            call.getString("unit")?.let { editor.putString("unit", it) }
            call.getBoolean("hideOnLock")?.let { editor.putBoolean("hideOnLock", it) }
            call.getBoolean("showUp")?.let { editor.putBoolean("showUp", it) }
            call.getBoolean("showDown")?.let { editor.putBoolean("showDown", it) }
            call.getString("color")?.let { editor.putString("color", it) }
            call.getString("theme")?.let { editor.putString("theme", it) }
            call.getBoolean("overlayEnabled")?.let { editor.putBoolean("overlayEnabled", it) }

            editor.apply()
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    // ═══════════════════════════════════════════════════════════
    // الخدمة الأصلية (Foreground Service) — إشعار السرعة الدائم
    // ═══════════════════════════════════════════════════════════

    @PluginMethod
    fun startForegroundService(call: PluginCall) {
        try {
            if (!hasNotifPermission()) {
                call.reject("NOTIF_PERMISSION_DENIED", "الإشعارات غير مسموح بها")
                return
            }
            val intent = Intent(context, CovaForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun stopForegroundService(call: PluginCall) {
        try {
            val intent = Intent(context, CovaForegroundService::class.java)
            context.stopService(intent)
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    // ═══════════════════════════════════════════════════════════
    // Overlay
    // ═══════════════════════════════════════════════════════════

    @PluginMethod
    fun hasOverlayPermission(call: PluginCall) {
        try {
            val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true
            }
            val r = JSObject()
            r.put("granted", granted)
            call.resolve(r)
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun requestOverlayPermission(call: PluginCall) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + context.packageName)
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun startOverlay(call: PluginCall) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                !Settings.canDrawOverlays(context)) {
                call.reject("PERMISSION_DENIED", "الإذن غير ممنوح")
                return
            }

            val intent = Intent(context, SpeedOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun stopOverlay(call: PluginCall) {
        try {
            val intent = Intent(context, SpeedOverlayService::class.java)
            context.stopService(intent)
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    // ═══════════════════════════════════════════════════════════
    // رسم الأيقونات
    // ═══════════════════════════════════════════════════════════

    /**
     * الدائرة الكبيرة (Large Icon) - رقم فوق ووحدة تحت
     */
    private fun drawSpeedBadge(number: String, unit: String): Bitmap {
        val size = 192
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT)

        val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        }
        numPaint.textSize = when {
            number.length <= 2 -> size * 0.48f
            number.length == 3 -> size * 0.40f
            number.length == 4 -> size * 0.32f
            else -> size * 0.26f
        }
        canvas.drawText(number, size / 2f, size * 0.50f, numPaint)

        val shortUnit = when {
            unit.contains("GB", true) -> "GB/s"
            unit.contains("MB", true) -> "MB/s"
            unit.contains("KB", true) -> "KB/s"
            else -> "B/s"
        }

        val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        }
        unitPaint.textSize = size * 0.22f
        canvas.drawText(shortUnit, size / 2f, size * 0.82f, unitPaint)

        return bitmap
    }

    /**
     * الأيقونة الصغيرة (Small Icon) - الرقم فقط
     */
    private fun drawSmallIconBitmap(number: String): Bitmap {
        val size = 96
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        }
        paint.textSize = when {
            number.length <= 2 -> size * 0.68f
            number.length == 3 -> size * 0.54f
            number.length == 4 -> size * 0.44f
            else -> size * 0.36f
        }

        val y = size / 2f - (paint.descent() + paint.ascent()) / 2f
        canvas.drawText(number, size / 2f, y, paint)

        return bitmap
    }
}