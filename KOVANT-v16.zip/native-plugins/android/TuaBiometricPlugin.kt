package com.kova.cash.plugins

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * TuaBiometric — بصمة + تخزين محلي آمن مع تحديث صامت للتوكن.
 *
 * - bioPrefs: تخزين مشفّر + محمي بالبصمة (للتحقق الأولي من الهوية)
 * - sessionPrefs: تخزين مشفّر بدون بصمة (لتحديث التوكن بعد كل دخول)
 * - updateSecret: تحديث التوكن بصمت (بدون بصمة)
 */
@CapacitorPlugin(name = "TuaBiometric")
class TuaBiometricPlugin : Plugin() {

    companion object {
        private const val KEY_ALIAS = "tua_biometric_refresh_key"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val BIO_PREFS_FILE = "koufant_secure_prefs"
        private const val SESSION_PREFS_FILE = "koufant_session_prefs"
        private const val META_PREFS_FILE = "tua_biometric_meta"

        private const val K_ENABLED = "enabled"
        private const val K_IV = "iv"
        private const val K_CIPHERTEXT = "ciphertext"
        private const val K_PHONE = "phone"
        private const val K_SESSION_RT = "session_rt"
    }

    private fun metaPrefs(): SharedPreferences =
        context.getSharedPreferences(META_PREFS_FILE, android.content.Context.MODE_PRIVATE)

    /** تخزين محمي بالبصمة - للتحقق من هوية المستخدم */
    private fun bioPrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context, BIO_PREFS_FILE, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    /** تخزين مشفّر بدون بصمة - لتحديث التوكن بصمت */
    private fun sessionPrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context, SESSION_PREFS_FILE, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun keyStore(): KeyStore {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE)
        ks.load(null)
        return ks
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val ks = keyStore()
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val specBuilder = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            specBuilder.setUserAuthenticationParameters(
                0,
                KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL
            )
        } else {
            @Suppress("DEPRECATION")
            specBuilder.setUserAuthenticationValidityDurationSeconds(-1)
        }

        keyGen.init(specBuilder.build())
        return keyGen.generateKey()
    }

    private fun deleteKey() {
        try {
            val ks = keyStore()
            if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS)
        } catch (_: Exception) {}
    }

    @PluginMethod
    fun isAvailable(call: PluginCall) {
        val result = JSObject()
        try {
            val bm = BiometricManager.from(context)
            val strongStatus = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            val credentialStatus = bm.canAuthenticate(BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            val combined = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            val combinedStatus = bm.canAuthenticate(combined)
            result.put("isAvailable", combinedStatus == BiometricManager.BIOMETRIC_SUCCESS)
            result.put("strongStatus", strongStatus)
            result.put("credentialStatus", credentialStatus)
            result.put("combinedStatus", combinedStatus)
            result.put("code", combinedStatus)
        } catch (e: Exception) {
            result.put("isAvailable", false)
            result.put("error", e.message)
        }
        call.resolve(result)
    }

    @PluginMethod
    fun hasSecret(call: PluginCall) {
        val result = JSObject()
        val enabled = metaPrefs().getBoolean(K_ENABLED, false)
        result.put("hasSecret", enabled)
        if (enabled) result.put("phone", metaPrefs().getString(K_PHONE, null))
        call.resolve(result)
    }

    // حفظ السر الأولي (يتطلب بصمة) — يخزن في bioPrefs + sessionPrefs
    @PluginMethod
    fun saveSecret(call: PluginCall) {
        val activity = activity as? FragmentActivity
        if (activity == null) { call.reject("Activity not available"); return }

        val phone = call.getString("phone")
        val refreshToken = call.getString("refreshToken")
        if (phone.isNullOrBlank() || refreshToken.isNullOrBlank()) {
            call.reject("phone and refreshToken are required")
            return
        }

        val title = call.getString("title") ?: "تفعيل البصمة"
        val subtitle = call.getString("subtitle") ?: "كوفانت"
        val description = call.getString("description") ?: "ضع إصبعك للتأكيد"

        activity.runOnUiThread {
            try {
                deleteKey()
                val secretKey = getOrCreateSecretKey()
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, secretKey)

                val executor = ContextCompat.getMainExecutor(context)
                val prompt = BiometricPrompt(activity, executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            super.onAuthenticationSucceeded(result)
                            try {
                                val authedCipher = result.cryptoObject?.cipher
                                    ?: throw IllegalStateException("no cipher")
                                val encrypted = authedCipher.doFinal(refreshToken.toByteArray(Charsets.UTF_8))

                                bioPrefs().edit()
                                    .putString(K_IV, Base64.encodeToString(authedCipher.iv, Base64.NO_WRAP))
                                    .putString(K_CIPHERTEXT, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                                    .apply()

                                sessionPrefs().edit()
                                    .putString(K_SESSION_RT, refreshToken)
                                    .apply()

                                metaPrefs().edit()
                                    .putBoolean(K_ENABLED, true)
                                    .putString(K_PHONE, phone)
                                    .apply()

                                call.resolve(JSObject().put("success", true))
                            } catch (e: Exception) {
                                call.reject("Encryption failed: ${e.message}")
                            }
                        }
                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            super.onAuthenticationError(errorCode, errString)
                            call.reject("Authentication error: $errString")
                        }
                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                        }
                    })

                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title).setSubtitle(subtitle).setDescription(description)
                    .setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    ).build()

                prompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
            } catch (e: Exception) {
                call.reject("Failed to start: ${e.message}")
            }
        }
    }

    // استرجاع التوكن (بصمة مطلوبة) — يقرأ من sessionPrefs إن وُجد، وإلا من bioPrefs
    @PluginMethod
    fun verifyAndGetSecret(call: PluginCall) {
        val activity = activity as? FragmentActivity
        if (activity == null) { call.reject("Activity not available"); return }

        if (!metaPrefs().getBoolean(K_ENABLED, false)) {
            call.reject("NOT_ENABLED", "البصمة غير مُفعّلة"); return
        }

        val ivB64 = bioPrefs().getString(K_IV, null)
        val ctB64 = bioPrefs().getString(K_CIPHERTEXT, null)
        val phone = metaPrefs().getString(K_PHONE, null)
        if (ivB64 == null || ctB64 == null || phone == null) {
            call.reject("NOT_ENABLED", "لا توجد بيانات محفوظة"); return
        }

        val title = call.getString("title") ?: "تسجيل الدخول"
        val subtitle = call.getString("subtitle") ?: "كوفانت"
        val description = call.getString("description") ?: "ضع إصبعك للمتابعة"

        activity.runOnUiThread {
            try {
                val secretKey = getOrCreateSecretKey()
                val iv = Base64.decode(ivB64, Base64.NO_WRAP)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))

                val executor = ContextCompat.getMainExecutor(context)
                val prompt = BiometricPrompt(activity, executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            super.onAuthenticationSucceeded(result)
                            try {
                                val authedCipher = result.cryptoObject?.cipher
                                    ?: throw IllegalStateException("no cipher")
                                val ciphertext = Base64.decode(ctB64, Base64.NO_WRAP)
                                val plain = authedCipher.doFinal(ciphertext)
                                val originalToken = String(plain, Charsets.UTF_8)

                                // 🔥 نفضّل التوكن المُحدَّث من sessionPrefs إن وُجد
                                val sessionToken = sessionPrefs().getString(K_SESSION_RT, null)
                                val finalToken = sessionToken ?: originalToken

                                val out = JSObject()
                                out.put("success", true)
                                out.put("phone", phone)
                                out.put("refreshToken", finalToken)
                                call.resolve(out)
                            } catch (e: Exception) {
                                call.reject("Decryption failed: ${e.message}")
                            }
                        }
                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            super.onAuthenticationError(errorCode, errString)
                            call.reject("Authentication error: $errString")
                        }
                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                        }
                    })

                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title).setSubtitle(subtitle).setDescription(description)
                    .setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    ).build()

                prompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
            } catch (e: KeyPermanentlyInvalidatedException) {
                clearSecretInternal()
                call.reject("KEY_INVALIDATED", "تم تغيير بصمات الجهاز — يجب إعادة تفعيل البصمة")
            } catch (e: Exception) {
                call.reject("Failed to start: ${e.message}")
            }
        }
    }

    // 🔥 تحديث التوكن بصمت (بدون بصمة) - يُستدعى بعد كل تسجيل دخول ناجح
    @PluginMethod
    fun updateSecret(call: PluginCall) {
        val newToken = call.getString("refreshToken")
        if (newToken.isNullOrBlank()) {
            call.reject("refreshToken is required"); return
        }
        try {
            sessionPrefs().edit().putString(K_SESSION_RT, newToken).apply()
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Update failed: ${e.message}")
        }
    }

    private fun clearSecretInternal() {
        deleteKey()
        bioPrefs().edit().remove(K_IV).remove(K_CIPHERTEXT).apply()
        sessionPrefs().edit().remove(K_SESSION_RT).apply()
        metaPrefs().edit().clear().apply()
    }

    @PluginMethod
    fun clearSecret(call: PluginCall) {
        try {
            clearSecretInternal()
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }
}