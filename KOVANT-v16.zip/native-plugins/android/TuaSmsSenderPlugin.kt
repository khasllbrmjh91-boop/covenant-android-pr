package com.kova.cash.plugins

import android.Manifest
import android.content.Context
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.PermissionState
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

@CapacitorPlugin(
    name = "TuaSmsSender",
    permissions = [
        Permission(
            strings = [
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_PHONE_STATE
            ],
            alias = "sms"
        )
    ]
)
class TuaSmsSenderPlugin : Plugin() {

    /* ═══════════════════════════════════════════
       📤 إرسال SMS
    ═══════════════════════════════════════════ */
    @PluginMethod
    fun send(call: PluginCall) {
        if (getPermissionState("sms") != PermissionState.GRANTED) {
            requestPermissionForAlias("sms", call, "sendCallback")
            return
        }
        doSend(call)
    }

    @PermissionCallback
    private fun sendCallback(call: PluginCall) {
        if (getPermissionState("sms") == PermissionState.GRANTED) {
            doSend(call)
        } else {
            call.reject("SEND_SMS permission denied")
        }
    }

    private fun doSend(call: PluginCall) {
        val number = call.getString("number")
        val text = call.getString("text")
        val subscriptionId = call.getInt("subscriptionId", -1)

        if (number.isNullOrBlank() || text.isNullOrBlank()) {
            call.reject("number and text are required")
            return
        }

        try {
            val smsManager: SmsManager =
                if (subscriptionId != null && subscriptionId != -1) {
                    SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
                } else {
                    SmsManager.getDefault()
                }

            val parts = smsManager.divideMessage(text)
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(number, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(number, null, text, null, null)
            }

            val ret = JSObject()
            ret.put("sent", true)
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("SEND_FAILED: " + e.message, e)
        }
    }

    /* ═══════════════════════════════════════════
       📱 قراءة الشرائح
    ═══════════════════════════════════════════ */
    @PluginMethod
    fun checkPermissions(call: PluginCall) {
        val result = JSObject()
        val state = getPermissionState("sms").toString()
        result.put("readPhoneState", state)
        result.put("sendSms", state)
        call.resolve(result)
    }

    @PluginMethod
    fun requestPermissions(call: PluginCall) {
        requestPermissionForAlias("sms", call, "simPermsCallback")
    }

    @PermissionCallback
    private fun simPermsCallback(call: PluginCall) {
        checkPermissions(call)
    }

    @PluginMethod
    fun getSimCards(call: PluginCall) {
        if (getPermissionState("sms") != PermissionState.GRANTED) {
            requestPermissionForAlias("sms", call, "simPermsCallback")
            return
        }
        doGetSims(call)
    }

    private fun doGetSims(call: PluginCall) {
        try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE)
                as SubscriptionManager
            val simCards = JSArray()
            val list = subscriptionManager.activeSubscriptionInfoList ?: emptyList()

            list.forEach { info ->
                val sim = JSObject().apply {
                    put("subscriptionId", info.subscriptionId)
                    put("simSlotIndex", info.simSlotIndex)
                    put("displayName", info.displayName?.toString() ?: "شريحة ${info.simSlotIndex + 1}")
                    put("carrierName", info.carrierName?.toString() ?: "غير معروف")
                    put("countryIso", info.countryIso ?: "")
                    put("isEmbedded",
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P)
                            info.isEmbedded else false
                    )
                }
                simCards.put(sim)
            }

            val result = JSObject()
            result.put("simCards", simCards)
            call.resolve(result)
        } catch (e: Exception) {
            call.reject("Failed to get SIMs: ${e.message}")
        }
    }
}
