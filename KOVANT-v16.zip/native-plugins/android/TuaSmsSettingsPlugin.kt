package com.kova.cash.plugins

import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.kova.cash.SmsGatewaySettings

/**
 * TuaSmsSettings — جسر الإعدادات بين الواجهة والخدمة الأصلية.
 * يقرأ/يكتب SharedPreferences "sms_gateway_prefs" (أنواع حقيقية: boolean / int / string).
 *
 *   get()                    -> { initialized, autoProcess, processOld, readSim, sendSim, deviceId }
 *   set({ autoProcess?, processOld?, readSim?, sendSim? })
 */
@CapacitorPlugin(name = "TuaSmsSettings")
class TuaSmsSettingsPlugin : Plugin() {

    private companion object {
        // اسم خيار الشريحة في الواجهة ("1" / "2" / "both") — للواجهة فقط، والخدمة تستخدم readSim/sendSim
        const val KEY_READ_SIM_SLOT = "readSimSlot"
        const val KEY_SEND_SIM_SLOT = "sendSimSlot"
    }

    private fun snapshot(): JSObject {
        val ctx = context
        val p = SmsGatewaySettings.prefs(ctx)
        return JSObject().apply {
            put("initialized", p.getBoolean(SmsGatewaySettings.KEY_INITIALIZED, false))
            put("autoProcess", p.getBoolean(SmsGatewaySettings.KEY_AUTO_PROCESS, true))
            put("processOld", p.getBoolean(SmsGatewaySettings.KEY_PROCESS_OLD, false))
            put("readSim", p.getInt(SmsGatewaySettings.KEY_READ_SIM, -1))
            put("sendSim", p.getInt(SmsGatewaySettings.KEY_SEND_SIM, -1))
            put("readSimSlot", p.getString(KEY_READ_SIM_SLOT, "") ?: "")
            put("sendSimSlot", p.getString(KEY_SEND_SIM_SLOT, "") ?: "")
            put("deviceId", SmsGatewaySettings.deviceId(ctx))
        }
    }

    @PluginMethod
    fun get(call: PluginCall) {
        call.resolve(snapshot())
    }

    @PluginMethod
    fun set(call: PluginCall) {
        try {
            val editor = SmsGatewaySettings.prefs(context).edit()
            if (call.hasOption("autoProcess")) editor.putBoolean(SmsGatewaySettings.KEY_AUTO_PROCESS, call.getBoolean("autoProcess", true) ?: true)
            if (call.hasOption("processOld")) editor.putBoolean(SmsGatewaySettings.KEY_PROCESS_OLD, call.getBoolean("processOld", false) ?: false)
            if (call.hasOption("readSim")) editor.putInt(SmsGatewaySettings.KEY_READ_SIM, call.getInt("readSim", -1) ?: -1)
            if (call.hasOption("sendSim")) editor.putInt(SmsGatewaySettings.KEY_SEND_SIM, call.getInt("sendSim", -1) ?: -1)
            if (call.hasOption("readSimSlot")) editor.putString(KEY_READ_SIM_SLOT, call.getString("readSimSlot", "") ?: "")
            if (call.hasOption("sendSimSlot")) editor.putString(KEY_SEND_SIM_SLOT, call.getString("sendSimSlot", "") ?: "")
            editor.putBoolean(SmsGatewaySettings.KEY_INITIALIZED, true)
            // commit() لضمان الكتابة قبل أن تقرأها الخدمة/العامل
            editor.commit()
            call.resolve(snapshot())
        } catch (e: Exception) {
            call.reject("SETTINGS_WRITE_FAILED: " + (e.message ?: ""))
        }
    }
}
