package com.kova.cash.plugins

import android.net.TrafficStats
import android.os.Process
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * TuaTrafficStats — قراءة استهلاك الشبكة من نظام أندرويد مباشرة.
 *
 * يُستخدم لقياس السرعة اللحظية (تنزيل/رفع) بنفس أسلوب تطبيقات مراقبة السرعة.
 *
 * - getUidTraffic: استهلاك التطبيق فقط (بدون أذونات)
 * - getDeviceTraffic: استهلاك الجهاز كامل (الأدق لمراقبة كرت كوفانت)
 * - isSupported: التحقق من دعم العدّادات على هذا الجهاز
 */
@CapacitorPlugin(name = "CovaTrafficStats")
class TuaTrafficStatsPlugin : Plugin() {

    @PluginMethod
    fun getUidTraffic(call: PluginCall) {
        try {
            val uid = Process.myUid()
            val rx = TrafficStats.getUidRxBytes(uid)
            val tx = TrafficStats.getUidTxBytes(uid)

            if (rx == TrafficStats.UNSUPPORTED.toLong() ||
                tx == TrafficStats.UNSUPPORTED.toLong()) {
                call.reject("UNSUPPORTED", "الجهاز لا يدعم عدّادات التطبيق")
                return
            }

            val result = JSObject()
            result.put("rxBytes", rx)
            result.put("txBytes", tx)
            result.put("timestamp", System.currentTimeMillis())
            call.resolve(result)

        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun getDeviceTraffic(call: PluginCall) {
        try {
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()

            if (rx == TrafficStats.UNSUPPORTED.toLong() ||
                tx == TrafficStats.UNSUPPORTED.toLong()) {
                call.reject("UNSUPPORTED", "الجهاز لا يدعم العدّادات الكلية")
                return
            }

            val result = JSObject()
            result.put("rxBytes", rx)
            result.put("txBytes", tx)
            result.put("timestamp", System.currentTimeMillis())
            call.resolve(result)

        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun isSupported(call: PluginCall) {
        try {
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val supported = rx != TrafficStats.UNSUPPORTED.toLong() &&
                            tx != TrafficStats.UNSUPPORTED.toLong()

            val result = JSObject()
            result.put("supported", supported)
            call.resolve(result)

        } catch (e: Exception) {
            val result = JSObject()
            result.put("supported", false)
            result.put("error", e.message)
            call.resolve(result)
        }
    }
}