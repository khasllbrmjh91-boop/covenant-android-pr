package com.kova.cash.plugins

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.provider.Telephony
import androidx.core.content.ContextCompat
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

/**
 * TuaSmsInbox — قراءة فعلية لرسائل الجهاز الواردة (SMS Inbox).
 *
 * الاستخدام الأساسي: قراءة رسائل المرسل "YOU" لمعرفة رصيد الرسائل المتبقي الحقيقي
 * بدل الرقم المحلي الوهمي.
 *
 * الدوال المتاحة من الواجهة (Capacitor.Plugins.TuaSmsInbox):
 *   - checkPermissions()            → { sms: 'granted' | 'denied' | 'prompt' }   (مدمجة من Capacitor)
 *   - requestAccess()               → يطلب READ_SMS + RECEIVE_SMS ثم يبدأ الاستماع اللحظي
 *   - readInbox({ sender, limit })  → { messages: [{ id, from, body, date }] } الأحدث أولاً
 *   - startListening()              → يبدأ الاستماع اللحظي (يُستدعى تلقائياً بعد منح الصلاحية)
 *
 * الأحداث (addListener):
 *   - "smsReceived" → { from, body, date }  عند وصول أي رسالة جديدة أثناء عمل التطبيق
 */
@CapacitorPlugin(
    name = "TuaSmsInbox",
    permissions = [
        Permission(
            strings = [
                Manifest.permission.READ_SMS,
                Manifest.permission.RECEIVE_SMS
            ],
            alias = "sms"
        )
    ]
)
class TuaSmsInboxPlugin : Plugin() {

    private var receiver: BroadcastReceiver? = null

    override fun load() {
        // لو الصلاحية ممنوحة مسبقاً نبدأ الاستماع مباشرة عند تحميل التطبيق
        if (getPermissionState("sms") == PermissionState.GRANTED) {
            registerLiveReceiver()
        }
    }

    override fun handleOnDestroy() {
        unregisterLiveReceiver()
        super.handleOnDestroy()
    }

    /* ═══════════════ الصلاحيات ═══════════════ */
    @PluginMethod
    fun requestAccess(call: PluginCall) {
        if (getPermissionState("sms") == PermissionState.GRANTED) {
            registerLiveReceiver()
            resolveState(call)
            return
        }
        requestPermissionForAlias("sms", call, "accessCallback")
    }

    @PermissionCallback
    private fun accessCallback(call: PluginCall) {
        if (getPermissionState("sms") == PermissionState.GRANTED) {
            registerLiveReceiver()
        }
        resolveState(call)
    }

    private fun resolveState(call: PluginCall) {
        val ret = JSObject()
        ret.put("sms", getPermissionState("sms").toString())
        call.resolve(ret)
    }

    /* ═══════════════ قراءة الصندوق الوارد ═══════════════ */
    @PluginMethod
    fun readInbox(call: PluginCall) {
        if (getPermissionState("sms") != PermissionState.GRANTED) {
            requestPermissionForAlias("sms", call, "readCallback")
            return
        }
        doRead(call)
    }

    @PermissionCallback
    private fun readCallback(call: PluginCall) {
        if (getPermissionState("sms") == PermissionState.GRANTED) {
            registerLiveReceiver()
            doRead(call)
        } else {
            call.reject("READ_SMS permission denied")
        }
    }

    private fun doRead(call: PluginCall) {
        val sender = (call.getString("sender") ?: "").trim()
        val limit = call.getInt("limit", 30) ?: 30
        val maxScan = 3000 // سقف أمان لعدد الرسائل الممسوحة

        try {
            val out = JSArray()
            val cursor = context.contentResolver.query(
                Uri.parse("content://sms/inbox"),
                arrayOf("_id", "address", "body", "date"),
                null, null, "date DESC"
            )

            cursor?.use { c ->
                val idIdx = c.getColumnIndexOrThrow("_id")
                val addrIdx = c.getColumnIndexOrThrow("address")
                val bodyIdx = c.getColumnIndexOrThrow("body")
                val dateIdx = c.getColumnIndexOrThrow("date")

                var scanned = 0
                while (c.moveToNext() && out.length() < limit && scanned < maxScan) {
                    scanned++
                    val address = (c.getString(addrIdx) ?: "").trim()
                    // المطابقة على معرّف المرسل بدون حساسية لحالة الأحرف
                    if (sender.isNotEmpty() && !address.equals(sender, ignoreCase = true)) continue

                    val msg = JSObject()
                    msg.put("id", c.getLong(idIdx))
                    msg.put("from", address)
                    msg.put("body", c.getString(bodyIdx) ?: "")
                    msg.put("date", c.getLong(dateIdx))
                    out.put(msg)
                }
            }

            val ret = JSObject()
            ret.put("messages", out)
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("READ_INBOX_FAILED: " + e.message, e)
        }
    }

    /* ═══════════════ الاستماع اللحظي ═══════════════ */
    @PluginMethod
    fun startListening(call: PluginCall) {
        if (getPermissionState("sms") != PermissionState.GRANTED) {
            call.reject("RECEIVE_SMS permission not granted")
            return
        }
        registerLiveReceiver()
        call.resolve()
    }

    private fun registerLiveReceiver() {
        if (receiver != null) return

        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
                val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
                if (parts.isEmpty()) return

                // الرسائل الطويلة تصل على أجزاء — نجمعها حسب المرسل
                val grouped = LinkedHashMap<String, StringBuilder>()
                var ts = System.currentTimeMillis()
                for (p in parts) {
                    val from = (p.originatingAddress ?: "").trim()
                    grouped.getOrPut(from) { StringBuilder() }.append(p.messageBody ?: "")
                    ts = p.timestampMillis
                }
                for ((from, body) in grouped) {
                    val data = JSObject()
                    data.put("from", from)
                    data.put("body", body.toString())
                    data.put("date", ts)
                    notifyListeners("smsReceived", data, true)
                }
            }
        }

        val filter = IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
        filter.priority = 999
        ContextCompat.registerReceiver(context, r, filter, ContextCompat.RECEIVER_EXPORTED)
        receiver = r
    }

    private fun unregisterLiveReceiver() {
        receiver?.let {
            try { context.unregisterReceiver(it) } catch (_: Exception) { }
        }
        receiver = null
    }
}
