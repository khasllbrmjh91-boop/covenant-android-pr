package com.kova.cash.plugins

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Locale

/**
 * SpeedOverlayService — طبقة عائمة تعرض سرعة الإنترنت فوق شريط الحالة
 * مثل TJ Speedo و Internet Speed Meter Lite
 *
 * تحتاج إذن SYSTEM_ALERT_WINDOW (يُطلب من المستخدم مرة واحدة)
 * يعمل كـ Foreground Service (يستمر حتى بعد إغلاق التطبيق)
 */
class SpeedOverlayService : Service() {

    companion object {
        const val PREFS_NAME = "cova_speed_settings"
        const val UPDATE_INTERVAL_MS = 1000L
        const val CHANNEL_ID = "cova_speed_overlay"
        const val CHANNEL_NAME = "طبقة سرعة الإنترنت"
        const val NOTIF_ID = 90002

        @Volatile
        var isRunning = false
    }

    private var windowManager: WindowManager? = null
    private var overlayRoot: LinearLayout? = null
    private var speedText: TextView? = null
    private var unitText: TextView? = null
    private var handler: Handler? = null
    private var updateRunnable: Runnable? = null
    private lateinit var prefs: SharedPreferences

    private var lastRxBytes = 0L
    private var lastTxBytes = 0L
    private var lastSampleTime = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!canDrawOverlays()) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundCompat()
        createOverlayView()
        isRunning = true

        handler = Handler(Looper.getMainLooper())
        updateRunnable = object : Runnable {
            override fun run() {
                try { updateSpeed() } catch (_: Exception) {}
                handler?.postDelayed(this, UPDATE_INTERVAL_MS)
            }
        }
        handler?.post(updateRunnable!!)

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        updateRunnable?.let { handler?.removeCallbacks(it) }
        handler = null
        removeOverlayView()
        try { NotificationManagerCompat.from(this).cancel(NOTIF_ID) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    // ═══════════════════════════════════════════════════════════
    // Foreground Service (يستمر حتى بعد إغلاق التطبيق، ومخفي من اللوحة)
    // ═══════════════════════════════════════════════════════════

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_MIN).apply {
                description = "خدمة تشغيل طبقة سرعة الإنترنت العائمة"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildHiddenNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("كوفانت")
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET) // ← إخفاء من اللوحة المنسدلة
            .build()
    }

    private fun startForegroundCompat() {
        val notification = buildHiddenNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14+ يتطلب تحديد نوع الخدمة الأمامية
                startForeground(
                    NOTIF_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (_: Exception) {
            // في حال فشل startForeground لأي سبب، لا نوقف الخدمة —
            // الطبقة العائمة نفسها لا تعتمد على الإشعار لتعمل
        }
    }

    // ═══════════════════════════════════════════════════════════
    // الطبقة العائمة (Overlay)
    // ═══════════════════════════════════════════════════════════

    /**
     * تحويل dp إلى px حسب كثافة الشاشة
     */
    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    private fun createOverlayView() {
        if (overlayRoot != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val numberView = TextView(this).apply {
            text = "0.0"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT
            includeFontPadding = false
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
            isClickable = false
            isFocusable = false
            isSingleLine = true
            minWidth = dpToPx(40)
            maxWidth = dpToPx(58)
        }

        val unitView = TextView(this).apply {
            text = "KB/s"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT
            includeFontPadding = false
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
            isClickable = false
            isFocusable = false
            isSingleLine = true
            visibility = View.VISIBLE
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, 0)
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = false
            isFocusable = false
            addView(numberView)
            addView(unitView)
        }

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 60
            y = 8
        }

        speedText = numberView
        unitText = unitView
        overlayRoot = root

        try {
            windowManager?.addView(root, params)
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun removeOverlayView() {
        try {
            overlayRoot?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {}
        overlayRoot = null
        speedText = null
        unitText = null
    }

    // ═══════════════════════════════════════════════════════════
    // قراءة وتنسيق السرعة
    // ═══════════════════════════════════════════════════════════

    /**
     * تحديث السرعة كل ثانية — يحدّث الرقم فقط، الوحدة "KB/s" ثابتة دائماً
     */
    private fun updateSpeed() {
        val now = System.currentTimeMillis()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()

        if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return

        if (lastSampleTime > 0L) {
            val elapsed = (now - lastSampleTime) / 1000.0
            if (elapsed > 0.5) {
                val rxDelta = (rx - lastRxBytes).coerceAtLeast(0L)
                val txDelta = (tx - lastTxBytes).coerceAtLeast(0L)
                val bps = (rxDelta + txDelta) / elapsed  // bytes/sec (تنزيل + رفع)

                speedText?.text = formatNumber(bps)
                // unitText ثابت على "KB/s" ولا يُعاد كتابته
            }
        }

        lastRxBytes = rx
        lastTxBytes = tx
        lastSampleTime = now
    }

    /**
     * يعيد الرقم فقط بالإنجليزية (Locale.US)، بوحدة KB/s ثابتة:
     *   < 10 كيلوبايت/ث   → رقم عشري بخانة واحدة (مثل 1.4)
     *   >= 10 كيلوبايت/ث  → رقم صحيح (مثل 50، 595)
     */
    private fun formatNumber(bps: Double): String {
        val kbValue = bps / 1024.0

        return when {
            kbValue < 10.0 -> String.format(Locale.US, "%.1f", kbValue)
            else -> String.format(Locale.US, "%.0f", kbValue)
        }
    }
}
