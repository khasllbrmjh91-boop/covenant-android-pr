package com.kova.cash.plugins

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.ScanResult
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.PermissionState
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

/**
 * TuaWifiManager
 * ──────────────
 * يطابق الواجهة اللي بيتوقعها js/wifi-module.js بالضبط:
 *   checkPermissions() / requestPermissions()  -> Capacitor بيوفرهم تلقائياً
 *                                                  لأي alias معرّف تحت (هنا "location")
 *   isWifiEnabled()
 *   openWifiSettings() / openAppSettings() / requestLocationEnable()
 *   scan({ minRssi })            -> { networks: [...] }
 *   connect({ ssid, password, timeout }) -> { success }
 *   disconnect()
 *   httpGet({ url, timeout })    -> { status, url, body }   (HTTP خام عبر شبكة الواي فاي — بدون قيود cleartext)
 *
 * ⚠️ ملاحظة مهمة عن الصلاحيات على أندرويد (سبب المشكلة اللي بتشوفها):
 * قراءة نتائج مسح شبكات الواي فاي (SSID) على أندرويد 8+ تتطلب:
 *   1) صلاحية ACCESS_FINE_LOCATION ممنوحة (runtime permission) — ده اللي
 *      بيظهره الكود في wifi-module.js كبطاقة "صلاحية الموقع مطلوبة".
 *   2) خدمة الموقع (GPS/Location) شغالة على مستوى الجهاز نفسه — حتى لو
 *      التطبيق معاه الصلاحية، لو الموقع مقفول من الإعدادات هترجع نتائج فاضية.
 * الكود في JS بيتوقع الحقلين دول بالظبط، والمشكلة الحالية إن هذا الملف
 * (الـ plugin الأصلي) مكانش موجود أصلاً في المشروع — فـ
 * window.Capacitor.Plugins.TuaWifiManager كان دايماً undefined.
 */
@CapacitorPlugin(
    name = "TuaWifiManager",
    permissions = [
        Permission(
            strings = [
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ],
            alias = "location"
        )
    ]
)
class TuaWifiManagerPlugin : Plugin() {

    private lateinit var wifiManager: WifiManager
    private lateinit var connectivityManager: ConnectivityManager

    private var scanReceiver: BroadcastReceiver? = null
    private var pendingScanCall: PluginCall? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun load() {
        val appCtx = context.applicationContext
        wifiManager = appCtx.getSystemService(Context.WIFI_SERVICE) as WifiManager
        connectivityManager = appCtx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    /* ═══════════════════════════════════════════
       📶 حالة الواي فاي
    ═══════════════════════════════════════════ */
    @PluginMethod
    fun isWifiEnabled(call: PluginCall) {
        val ret = JSObject()
        ret.put("enabled", wifiManager.isWifiEnabled)
        call.resolve(ret)
    }

    @PluginMethod
    fun openWifiSettings(call: PluginCall) {
        try {
            activity.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            call.resolve()
        } catch (e: Exception) {
            call.reject(e.message ?: "Could not open WiFi settings")
        }
    }

    @PluginMethod
    fun openAppSettings(call: PluginCall) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.fromParts("package", context.packageName, null)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            call.resolve()
        } catch (e: Exception) {
            call.reject(e.message ?: "Could not open app settings")
        }
    }

    @PluginMethod
    fun requestLocationEnable(call: PluginCall) {
        try {
            activity.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            call.resolve()
        } catch (e: Exception) {
            call.reject(e.message ?: "Could not open location settings")
        }
    }

    /* ═══════════════════════════════════════════
       🔍 مسح الشبكات (يحتاج صلاحية location + الموقع مفعّل)
    ═══════════════════════════════════════════ */
    @PluginMethod
    fun scan(call: PluginCall) {
        if (getPermissionState("location") != PermissionState.GRANTED) {
            requestPermissionForAlias("location", call, "scanPermCallback")
            return
        }
        doScan(call)
    }

    @PermissionCallback
    private fun scanPermCallback(call: PluginCall) {
        if (getPermissionState("location") == PermissionState.GRANTED) {
            doScan(call)
        } else {
            call.reject("Location permission denied", "PERMISSION_DENIED")
        }
    }

    private fun isLocationServiceEnabled(): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lm.isLocationEnabled
        } else {
            @Suppress("DEPRECATION")
            try {
                Settings.Secure.getInt(context.contentResolver, Settings.Secure.LOCATION_MODE) != Settings.Secure.LOCATION_MODE_OFF
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun doScan(call: PluginCall) {
        if (!wifiManager.isWifiEnabled) {
            call.reject("WiFi is disabled", "WIFI_OFF")
            return
        }
        if (!isLocationServiceEnabled()) {
            call.reject("Location services are off", "LOCATION_OFF")
            return
        }

        pendingScanCall = call

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                try { context.unregisterReceiver(this) } catch (_: Exception) {}
                scanReceiver = null
                resolveScanResults()
            }
        }
        scanReceiver = receiver
        context.registerReceiver(receiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))

        @Suppress("DEPRECATION")
        val started = wifiManager.startScan()

        if (!started) {
            // أندرويد بيقيّد عدد مرات المسح (throttling) — لو رفض، ارجع آخر نتائج متاحة
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
            scanReceiver = null
            resolveScanResults()
            return
        }

        // أمان إضافي: لو الـ broadcast ماوصلش (بيحصل مع الـ throttling الصارم في
        // أندرويد 9+ اللي بيسمح بأقل من مسح واحد كل دقيقتين)، ارجع بعد مهلة قصيرة
        mainHandler.postDelayed({
            if (pendingScanCall === call) {
                try { scanReceiver?.let { context.unregisterReceiver(it) } } catch (_: Exception) {}
                scanReceiver = null
                resolveScanResults()
            }
        }, 6000)
    }

    private fun resolveScanResults() {
        val call = pendingScanCall ?: return
        pendingScanCall = null
        try {
            @Suppress("DEPRECATION")
            val results: List<ScanResult> = wifiManager.scanResults
            val minRssi = call.getInt("minRssi", -100) ?: -100
            val currentSsid = currentConnectedSsid()

            val bestBySsid = LinkedHashMap<String, ScanResult>()
            for (r in results) {
                val ssid = r.SSID ?: continue
                if (ssid.isBlank()) continue
                if (r.level < minRssi) continue
                val existing = bestBySsid[ssid]
                if (existing == null || r.level > existing.level) bestBySsid[ssid] = r
            }

            val arr = JSArray()
            for ((ssid, r) in bestBySsid) {
                val o = JSObject()
                o.put("SSID", ssid)
                o.put("BSSID", r.BSSID)
                o.put("level", r.level)
                o.put("frequency", r.frequency)
                o.put("channel", frequencyToChannel(r.frequency))
                o.put("capabilities", r.capabilities ?: "")
                o.put("isConnected", ssid == currentSsid)
                arr.put(o)
            }

            val ret = JSObject()
            ret.put("networks", arr)
            call.resolve(ret)
        } catch (e: SecurityException) {
            call.reject("Missing permission to read scan results", "PERMISSION_DENIED")
        } catch (e: Exception) {
            call.reject(e.message ?: "Scan failed")
        }
    }

    private fun frequencyToChannel(freq: Int): Int = when {
        freq == 2484 -> 14
        freq in 2412..2472 -> (freq - 2412) / 5 + 1
        freq in 5170..5825 -> (freq - 5000) / 5
        freq in 5955..7115 -> (freq - 5950) / 5 + 1
        else -> 0
    }

    private fun currentConnectedSsid(): String? {
        return try {
            @Suppress("DEPRECATION")
            val info = wifiManager.connectionInfo
            var ssid = info?.ssid ?: return null
            if (ssid.startsWith("\"") && ssid.endsWith("\"") && ssid.length >= 2) {
                ssid = ssid.substring(1, ssid.length - 1)
            }
            if (ssid == "<unknown ssid>" || ssid.isBlank()) null else ssid
        } catch (e: Exception) {
            null
        }
    }

    /* ═══════════════════════════════════════════
       🔗 الاتصال بشبكة
       ⚠️ من أندرويد 10 (Q) فصاعداً، جوجل بتمنع التطبيقات العادية من فرض
       اتصال دائم/افتراضي بشبكة واي فاي زي ما كان ممكن قبل كده (enableNetwork
       القديمة بقت مقيدة على التطبيقات اللي مش نظام/device-owner). الحل
       المعتمد رسمياً هو WifiNetworkSpecifier: بيوصل شبكة "محلية فقط"
       (local-only) مربوطة بعملية التطبيق نفسه فقط عبر bindProcessToNetwork —
       وده كافي تماماً عشان طلبات تسجيل الدخول لبوابة الراوتر (10.78.0.1)
       تنجح من جوه التطبيق، لكنه مش هيخلي باقي التطبيقات على الجهاز تستخدم
       الإنترنت من الشبكة دي تلقائياً إلا لو المستخدم اختارها هو بنفسه من
       إعدادات النظام. ده قيد من جوجل نفسها وليس قصور في الكود.
    ═══════════════════════════════════════════ */
    @PluginMethod
    fun connect(call: PluginCall) {
        val ssid = call.getString("ssid")
        if (ssid.isNullOrBlank()) {
            call.reject("ssid is required")
            return
        }
        val password = call.getString("password") ?: ""
        val timeout = call.getInt("timeout", 20000) ?: 20000

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            connectModern(ssid, password, timeout, call)
        } else {
            connectLegacy(ssid, password, call)
        }
    }

    @Suppress("DEPRECATION")
    private fun connectLegacy(ssid: String, password: String, call: PluginCall) {
        try {
            val wc = WifiConfiguration()
            wc.SSID = "\"$ssid\""
            if (password.isBlank()) {
                wc.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE)
            } else {
                wc.preSharedKey = "\"$password\""
            }
            val netId = wifiManager.addNetwork(wc)
            if (netId == -1) {
                call.reject("Could not add network configuration")
                return
            }
            wifiManager.disconnect()
            wifiManager.enableNetwork(netId, true)
            wifiManager.reconnect()
            val ret = JSObject()
            ret.put("success", true)
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject(e.message ?: "Connect failed")
        }
    }

    private var activeNetworkCallback: ConnectivityManager.NetworkCallback? = null

    private fun connectModern(ssid: String, password: String, timeout: Int, call: PluginCall) {
        try {
            val specifierBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (password.isNotBlank()) {
                specifierBuilder.setWpa2Passphrase(password)
            }
            val specifier = specifierBuilder.build()

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specifier)
                .build()

            var resolved = false
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (resolved) return
                    resolved = true
                    try {
                        connectivityManager.bindProcessToNetwork(network)
                    } catch (_: Exception) {}
                    val ret = JSObject()
                    ret.put("success", true)
                    call.resolve(ret)
                }

                override fun onUnavailable() {
                    if (resolved) return
                    resolved = true
                    val ret = JSObject()
                    ret.put("success", false)
                    call.resolve(ret)
                }
            }
            activeNetworkCallback = callback
            connectivityManager.requestNetwork(request, callback, timeout)
        } catch (e: Exception) {
            call.reject(e.message ?: "Connect failed")
        }
    }

    /* ═══════════════════════════════════════════
       🌐 httpGet — جلب صفحة الراوتر (مثل http://www.c.com/status.html)
       • يعمل على Socket خام، فلا تنطبق عليه قيود cleartext في أندرويد 9+
       • يمر عبر شبكة الواي فاي نفسها (وليس بيانات الجوال) ويستخدم DNS الراوتر
         لحل www.c.com
    ═══════════════════════════════════════════ */
    @PluginMethod
    fun httpGet(call: PluginCall) {
        val url = call.getString("url")
        if (url.isNullOrBlank()) {
            call.reject("url is required")
            return
        }
        val timeout = call.getInt("timeout", 6000) ?: 6000
        Thread {
            try {
                call.resolve(rawHttpGet(url, timeout, 3))
            } catch (e: Exception) {
                call.reject((e.javaClass.simpleName + ": " + (e.message ?: "")).trim(), "HTTP_FAILED")
            }
        }.start()
    }

    private fun findWifiNetwork(): Network? {
        return try {
            @Suppress("DEPRECATION")
            connectivityManager.allNetworks.firstOrNull { n ->
                connectivityManager.getNetworkCapabilities(n)
                    ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun rawHttpGet(urlStr: String, timeout: Int, redirects: Int): JSObject {
        val u = java.net.URL(urlStr)
        val host = u.host
        val port = if (u.port == -1) 80 else u.port
        val path = (if (u.path.isNullOrEmpty()) "/" else u.path) + (if (u.query != null) "?" + u.query else "")

        val net = findWifiNetwork()
        val addr = if (net != null) net.getAllByName(host).first() else java.net.InetAddress.getByName(host)
        val socket = if (net != null) net.socketFactory.createSocket() else java.net.Socket()
        val bytes: ByteArray
        try {
            socket.soTimeout = timeout
            socket.connect(InetSocketAddress(addr, port), timeout)
            val req = "GET $path HTTP/1.1\r\nHost: $host\r\n" +
                "User-Agent: Mozilla/5.0 (Linux; Android) Kovant\r\n" +
                "Accept: text/html,*/*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n"
            socket.getOutputStream().apply { write(req.toByteArray(Charsets.ISO_8859_1)); flush() }
            val bos = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            val inp = socket.getInputStream()
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                bos.write(buf, 0, n)
                if (bos.size() > 2_000_000) break
            }
            bytes = bos.toByteArray()
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }

        var split = -1
        for (i in 0 until bytes.size - 3) {
            if (bytes[i] == 13.toByte() && bytes[i + 1] == 10.toByte() && bytes[i + 2] == 13.toByte() && bytes[i + 3] == 10.toByte()) {
                split = i; break
            }
        }
        if (split < 0) throw java.io.IOException("Empty or invalid HTTP response")

        val head = String(bytes, 0, split, Charsets.ISO_8859_1)
        val lines = head.split("\r\n")
        val status = lines[0].split(" ").getOrNull(1)?.toIntOrNull() ?: 0
        val headers = HashMap<String, String>()
        for (l in lines.drop(1)) {
            val idx = l.indexOf(':')
            if (idx > 0) headers[l.substring(0, idx).trim().lowercase()] = l.substring(idx + 1).trim()
        }

        if (status in listOf(301, 302, 303, 307, 308) && redirects > 0 && headers["location"] != null) {
            val next = java.net.URL(u, headers["location"]).toString()
            return rawHttpGet(next, timeout, redirects - 1)
        }

        var body = bytes.copyOfRange(split + 4, bytes.size)
        if ((headers["transfer-encoding"] ?: "").lowercase().contains("chunked")) body = dechunk(body)

        var charsetName = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(headers["content-type"] ?: "")?.groupValues?.get(1)
        if (charsetName == null) {
            val sniff = String(body, 0, minOf(body.size, 2048), Charsets.ISO_8859_1)
            charsetName = Regex("charset=[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(sniff)?.groupValues?.get(1)
        }
        val cs = try { java.nio.charset.Charset.forName(charsetName ?: "UTF-8") } catch (_: Exception) { Charsets.UTF_8 }

        val ret = JSObject()
        ret.put("status", status)
        ret.put("url", urlStr)
        ret.put("body", String(body, cs))
        return ret
    }

    private fun dechunk(b: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < b.size) {
            var j = i
            while (j + 1 < b.size && !(b[j] == 13.toByte() && b[j + 1] == 10.toByte())) j++
            if (j + 1 >= b.size) break
            val size = String(b, i, j - i, Charsets.ISO_8859_1).substringBefore(';').trim().toIntOrNull(16) ?: break
            if (size == 0) break
            val start = j + 2
            val end = minOf(start + size, b.size)
            out.write(b, start, end - start)
            i = end + 2
        }
        return out.toByteArray()
    }

    @PluginMethod
    fun disconnect(call: PluginCall) {
        try {
            activeNetworkCallback?.let {
                try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {}
            }
            activeNetworkCallback = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                connectivityManager.bindProcessToNetwork(null)
            } else {
                @Suppress("DEPRECATION")
                wifiManager.disconnect()
            }
            call.resolve()
        } catch (e: Exception) {
            call.reject(e.message ?: "Disconnect failed")
        }
    }
}
