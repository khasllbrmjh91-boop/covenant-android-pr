/* ============================================================
   جسر القراءة الفعلية لرسائل SMS من الجهاز — كوفانت
   ============================================================
   هذا الملف هو الجزء اللي كان ناقص فعلاً (اللي سبق وقلنا إنه
   محتاج مكوّن Capacitor حقيقي). لما التطبيق يتحول لتطبيق
   أندرويد أصلي عبر Capacitor (راجع CAPACITOR-README.md)، هذا
   الملف يشتغل تلقائياً بعد دخول الأدمن، ويستبدل الزر اليدوي
   بالكامل:

     1) يطلب صلاحية قراءة/استقبال الرسائل (READ_SMS / RECEIVE_SMS)
     2) يطلب الإعفاء من قيود توفير البطارية عشان الخدمة تفضل
        شغّالة في الخلفية دائماً.
     3) يستمع لحظياً لأي رسالة واردة جديدة، ويمررها مباشرة لنفس
        الدالة الموجودة أصلاً tuaReceiveIncomingSms() — بدون أي
        تدخل يدوي من الأدمن بعد كده.

   ⚠️ يعمل فقط:
     - داخل تطبيق Capacitor حقيقي على أندرويد (مش متصفح/PWA، ومش iOS).
     - لحساب الأدمن فقط.
============================================================ */

let _tuaSmsBridgeActive = false;

async function tuaInitNativeSmsBridge() {
    // فقط داخل تطبيق Capacitor أصلي
    if (typeof Capacitor === 'undefined' || !Capacitor.isNativePlatform || !Capacitor.isNativePlatform()) return;
    if (Capacitor.getPlatform && Capacitor.getPlatform() !== 'android') return;
    
    // فقط للأدمن
    if (!APP.user || !APP.user.isAdmin) return;
    
    if (_tuaSmsBridgeActive) return;
    _tuaSmsBridgeActive = true;
    
    try {
        const plugins = (Capacitor.Plugins || {});
        const SmsInbox = plugins.SmsInbox;
        const SmsWatcher = plugins.SmsWatcher;
        const BatteryOptimization = plugins.BatteryOptimization;
        
        if (!SmsWatcher) {
            console.warn('⚠️ مكوّن SmsWatcher غير مثبت — راجع خطوات التثبيت في CAPACITOR-README.md');
            _tuaSmsBridgeActive = false;
            return;
        }
        
        // 1) صلاحية قراءة/استقبال الرسائل
        if (SmsInbox) {
            const status = await SmsInbox.checkPermissions();
            if (status.sms !== 'granted') {
                const req = await SmsInbox.requestPermissions();
                if (req.sms !== 'granted') {
                    console.warn('⛔ رُفضت صلاحية قراءة الرسائل — الاستقبال التلقائي متوقف');
                    if (typeof tuaToast === 'function') {
                        tuaToast('🚫 صلاحية قراءة الرسائل مرفوضة — استخدم "إضافة رسالة يدوياً" مؤقتاً', 'error');
                    }
                    _tuaSmsBridgeActive = false;
                    return;
                }
            }
        }
        
        // 2) الإعفاء من قيود توفير البطارية
        if (BatteryOptimization) {
            try {
                const { enabled } = await BatteryOptimization.isBatteryOptimizationEnabled();
                if (enabled) await BatteryOptimization.requestIgnoreBatteryOptimization();
            } catch (e) {
                console.warn('⚠️ تعذر طلب الإعفاء من توفير البطارية:', e);
            }
        }
        
        console.log('✅ جسر SMS الفعلي شغّال — استماع لحظي لرسائل الإيداع بدأ');
        
        // 3) حلقة استماع دائمة
        while (_tuaSmsBridgeActive) {
            try {
                const msg = await SmsWatcher.watch();
                if (msg && msg.body) {
                    if (typeof tuaReceiveIncomingSms === 'function') {
                        await tuaReceiveIncomingSms(msg.from, msg.body);
                    }
                }
            } catch (e) {
                console.error('❌ خطأ أثناء الاستماع لرسائل SMS، إعادة المحاولة خلال 3 ثواني:', e);
                await new Promise(r => setTimeout(r, 3000));
            }
        }
    } catch (e) {
        console.error('❌ فشل تشغيل جسر SMS الفعلي:', e);
        _tuaSmsBridgeActive = false;
    }
}

function tuaStopNativeSmsBridge() {
    _tuaSmsBridgeActive = false;
}

/* ============================================================
   📱 كشف الشرائح الفعلية
   يستخدم TuaSmsSender Plugin (المُحدَّث — يحتوي على قراءة الشرائح)
   يرجع null لو التطبيق شغّال في متصفح/PWA
============================================================ */
async function tuaDetectRealSims() {
    if (typeof Capacitor === 'undefined' || !Capacitor.isNativePlatform || !Capacitor.isNativePlatform()) {
        return null;
    }
    
    const Plugin = (Capacitor.Plugins || {}).TuaSmsSender;
    if (!Plugin) {
        console.warn('⚠️ TuaSmsSender plugin not registered');
        return { installed: false };
    }
    
    try {
        const status = await Plugin.checkPermissions();
        if (status.readPhoneState !== 'granted') {
            const req = await Plugin.requestPermissions();
            if (req.readPhoneState !== 'granted') {
                return { denied: true };
            }
        }
        const result = await Plugin.getSimCards();
        return { simCards: result.simCards || [] };
    } catch (e) {
        console.error('Sim detection failed:', e);
        return { denied: true };
    }
}

/* ============================================================
   📤 إرسال SMS فعلي عبر شريحة محددة
   يعتمد على مكوّن مخصص TuaSmsSender
============================================================ */
async function tuaSendRealSms(number, text, subscriptionId) {
    if (typeof Capacitor === 'undefined' || !Capacitor.isNativePlatform || !Capacitor.isNativePlatform()) {
        throw new Error('NOT_NATIVE');
    }
    
    const TuaSmsSender = (Capacitor.Plugins || {}).TuaSmsSender;
    if (!TuaSmsSender) {
        throw new Error('PLUGIN_NOT_INSTALLED — راجع native-plugins/android/TuaSmsSenderPlugin.kt');
    }
    
    const opts = {
        number: String(number),
        text: String(text)
    };
    
    if (subscriptionId !== undefined && subscriptionId !== null && subscriptionId !== '') {
        opts.subscriptionId = Number(subscriptionId);
    }
    
    return TuaSmsSender.send(opts);
}