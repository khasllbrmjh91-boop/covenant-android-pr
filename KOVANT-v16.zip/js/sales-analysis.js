// ============================================================
// تحليل المبيعات العام — SalesAnalysis (نسخة مُحسَّنة)
// المصدر: Firebase Realtime Database
//   • treasury/transactions  → حركات المبيعات (حسب SALES_TYPES)
//   • kova_store/*/sold      → الكروت المباعة (للتوزيع حسب الفئة)
//
// التحسينات:
//   1) فلترة treasury من الخادم (orderByChild/timestamp + buffer 90 يوم)
//   2) Cache لـ categoryStats() و customerStats() (يمنع الحساب المتكرر)
//   3) إصلاح isTodayIncluded ليستخدم === بدل >=
//   4) Guards لـ $n و esc (fallback آمن)
//   5) معالجة "لا توجد بيانات سابقة" في growth pill
//   6) lastUpdate يتحدث عند تغيّر kova_store أيضاً
//   7) إبطال الـ cache تلقائياً عند أي snapshot جديد
//
// يعتمد على: database, $n, esc, showAlert, waitForFirebaseAuth (من firebase-config.js)
// ============================================================
(function () {
    'use strict';

    /* أنواع حركات الخزينة التي تُحسب مبيعات — عدّلها إذا تغيّر تعريف المبيعات */
    const SALES_TYPES = ['card_purchase', 'credit'];

    const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const DAY = 86400000;
    const YEAR_MIN = 2020, YEAR_MAX = 2040;
    const PALETTE = ['#10b981', '#3b82f6', '#8b5cf6', '#fbbf24', '#f59e0b', '#ef4444'];
    const TT_MS = 3500;
    const SOLID = '#101728';

    // ✨ نطاق احتياطي حول الفترة المختارة، لتقليل عمليات إعادة الاشتراك
    const SUBSCRIBE_BUFFER = 90 * DAY;

    // ---------- Guards (fallback إذا لم تُعرَّف الدوال عالمياً) ----------
    const _n = (typeof $n === 'function') ? $n : function (v) {
        if (v === null || v === undefined) return 0;
        const num = parseFloat(String(v).replace(/,/g, ''));
        return isNaN(num) ? 0 : num;
    };
    const _esc = (typeof esc === 'function') ? esc : function (s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, m => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        })[m] || m);
    };

    // ---------- الحالة العامة ----------
    const S = {
        from: null, to: null,
        zoom: 1, chartType: 'area',
        showCur: true, showPrev: true, showAvg: true, showPeak: true,
        dataset: null, ttKey: null,
        isLive: true, offsetMs: 5 * 30 * DAY, liveTimer: null,
        sales: [], sold: [],
        txRef: null, txFn: null, storeRef: null, storeFn: null,
        lastUpdate: null, resetScroll: true, loaded: false,
        opened: false, bound: false, suppress: false,
        subscribedFrom: null, subscribedTo: null
    };

    // ---------- Cache للإحصاءات ----------
    let _statsCache = { key: '', cats: null, cust: null };
    function _invalidateStatsCache() {
        _statsCache = { key: '', cats: null, cust: null };
    }

    let ttTimer = null, warnTimer = null;

    /* ---------- أدوات ---------- */
    const el = id => document.getElementById(id);
    const qa = s => [].slice.call(document.querySelectorAll('#salesAnalysisInterface ' + s));
    const pad = n => String(n).padStart(2, '0');
    const dkey = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
    const midnight = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const dim = (y, m) => new Date(y, m + 1, 0).getDate();
    const sum = a => a.reduce((x, y) => x + y, 0);
    const fmt = n => isFinite(n) ? Math.round(n).toLocaleString('en-US') : '0';
    const shortMoney = n => {
        if (!isFinite(n) || n === 0) return '0';
        if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
        if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
        if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
        return String(Math.round(n));
    };
    const fmtShort = d => pad(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    const fmtFull = d => d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear() + ' - ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    const modeAr = m => m === 'hour' ? 'بالساعة' : m === 'day' ? 'يومي' : m === 'month' ? 'شهري' : 'سنوي';
    const growthOf = (cur, prev) => prev > 0 ? ((cur - prev) / prev) * 100 : 0;
    const say = (msg, ok) => { if (typeof showAlert === 'function') showAlert(msg, ok !== false); };

    function setStatus(kind, title, sub) {
        const b = el('saStatus'); if (!b) return;
        if (!kind) { b.style.display = 'none'; return; }
        b.style.display = 'flex';
        b.className = 'sa-status' + (kind === 'error' ? ' error' : kind === 'warn' ? ' warn' : '');
        el('saStatusTitle').textContent = title || '';
        el('saStatusSub').textContent = sub || '';
    }

    /* ---------- تحويل البيانات ---------- */
    function normalizeTx(tx) {
        if (!tx || SALES_TYPES.indexOf(tx.type) === -1) return null;
        let ms = Number(tx.timestamp);
        if (!ms) ms = Date.parse(tx.date);
        // ✅ حماية: إذا كانت القيمة بالثواني، حوّلها إلى مللي ثانية
        if (ms > 0 && ms < 1e12) ms *= 1000;
        if (!ms || isNaN(ms)) return null;
        const amount = Math.abs(_n(tx.changeAmount));
        if (!isFinite(amount) || amount === 0) return null; // تجاهل الحركات الصفرية
        const d = new Date(ms);
        return {
            date: d, dateKey: dkey(d), hour: d.getHours(), y: d.getFullYear(), m: d.getMonth(),
            amount: amount,
            customer: String(tx.customerName || 'غير معروف')
        };
    }

    function collectSold(store) {
        const out = [];
        Object.keys(store || {}).forEach(catId => {
            if (catId === 'gift_cards') return;
            const cat = store[catId] || {};
            const sold = cat.sold || {};
            Object.keys(sold).forEach(id => {
                const it = sold[id] || {};
                const ms = Number(it.soldAt || it.timestamp || it.addedAt || 0);
                if (ms > 0) out.push({ ms: ms, cat: cat.name || catId });
            });
        });
        return out;
    }

    /* ---------- التجميع ---------- */
    function bucketKey(r, mode) {
        if (mode === 'hour') return r.dateKey + '|' + r.hour;
        if (mode === 'day') return r.dateKey;
        if (mode === 'month') return r.y + '-' + r.m;
        return String(r.y);
    }

    function aggregate(from, to, forceMode) {
        from = midnight(from); to = midnight(to);
        const totalDays = Math.round((to - from) / DAY) + 1;
        const mode = forceMode || (totalDays <= 3 ? 'hour' : totalDays <= 62 ? 'day' : totalDays <= 24 * 31 ? 'month' : 'year');
        const start = from.getTime();
        const end = new Date(to.getFullYear(), to.getMonth(), to.getDate() + 1).getTime();

        const idx = {};
        S.sales.forEach(r => {
            const t = r.date.getTime();
            if (t < start || t >= end) return;
            const k = bucketKey(r, mode);
            const b = idx[k] || (idx[k] = { s: 0, c: 0 });
            b.s += r.amount; b.c += 1;
        });

        const labels = [], full = [], values = [], txs = [];
        const push = (label, fullLabel, key) => {
            const b = idx[key];
            labels.push(label); full.push(fullLabel);
            values.push(b ? b.s : 0); txs.push(b ? b.c : 0);
        };

        if (mode === 'hour') {
            for (let d = new Date(from); d <= to; d = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1)) {
                const k = dkey(d);
                for (let h = 0; h < 24; h++) {
                    const hh = pad(h) + ':00';
                    const lbl = totalDays > 1 ? pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + ' ' + hh : hh;
                    push(lbl, d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + hh, k + '|' + h);
                }
            }
        } else if (mode === 'day') {
            for (let i = 0; i < totalDays; i++) {
                const d = new Date(from.getFullYear(), from.getMonth(), from.getDate() + i);
                push(pad(d.getDate()) + ' ' + MONTHS[d.getMonth()].slice(0, 3),
                    d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear(), dkey(d));
            }
        } else if (mode === 'month') {
            let cur = new Date(from.getFullYear(), from.getMonth(), 1);
            const last = new Date(to.getFullYear(), to.getMonth(), 1);
            while (cur <= last) {
                const y = cur.getFullYear(), m = cur.getMonth();
                push(MONTHS[m].slice(0, 4) + ' ' + String(y).slice(2), MONTHS[m] + ' ' + y, y + '-' + m);
                cur = new Date(y, m + 1, 1);
            }
        } else {
            for (let y = from.getFullYear(); y <= to.getFullYear(); y++) push(String(y), String(y), String(y));
        }
        return { labels: labels, full: full, values: values, txs: txs, mode: mode, totalDays: totalDays };
    }

    function previousRange(from, to, mode) {
        if (mode === 'hour' || mode === 'day') {
            const n = Math.round((midnight(to) - midnight(from)) / DAY) + 1;
            return {
                from: new Date(from.getFullYear(), from.getMonth(), from.getDate() - n),
                to: new Date(to.getFullYear(), to.getMonth(), to.getDate() - n)
            };
        }
        if (mode === 'month') {
            const n = (to.getFullYear() - from.getFullYear()) * 12 + (to.getMonth() - from.getMonth()) + 1;
            return {
                from: new Date(from.getFullYear(), from.getMonth() - n, 1),
                to: new Date(to.getFullYear(), to.getMonth() - n + 1, 0)
            };
        }
        const n = to.getFullYear() - from.getFullYear() + 1;
        return { from: new Date(from.getFullYear() - n, 0, 1), to: new Date(to.getFullYear() - n, 11, 31) };
    }

    function buildDataset() {
        const cur = aggregate(S.from, S.to);
        const pr = previousRange(S.from, S.to, cur.mode);
        const pa = aggregate(pr.from, pr.to, cur.mode);
        const prev = pa.values.slice(0, cur.values.length);
        while (prev.length < cur.values.length) prev.push(0);
        const today = midnight(new Date());
        cur.prev = prev;
        cur.prevTotal = sum(prev);
        cur.total = sum(cur.values);
        cur.count = sum(cur.txs);
        cur.periodLabel = fmtShort(S.from) + ' — ' + fmtShort(S.to);
        // ✅ إصلاح: مطابقة تامة، ليست أكبر أو يساوي
        cur.isTodayIncluded = midnight(S.to).getTime() === today.getTime();
        return cur;
    }

    /* ---------- Firebase ---------- */
    function _computeNeededRange() {
        const ds = aggregate(S.from, S.to);
        const pr = previousRange(S.from, S.to, ds.mode);
        const needFrom = Math.min(pr.from.getTime(), S.from.getTime());
        const needTo = Math.max(pr.to.getTime(), S.to.getTime()) + DAY;
        return { from: needFrom, to: needTo };
    }

    function _isRangeCovered() {
        if (S.subscribedFrom == null || S.subscribedTo == null) return false;
        const need = _computeNeededRange();
        return need.from >= S.subscribedFrom && need.to <= S.subscribedTo;
    }

    // ✅ الاشتراك في treasury مع فلترة من الخادم
    function attachTreasury() {
        // إلغاء الاشتراك القديم إن وجد
        if (S.txRef && S.txFn) { try { S.txRef.off('value', S.txFn); } catch (e) { } }

        const need = _computeNeededRange();
        // نضيف buffer لتقليل عمليات إعادة الاشتراك
        const minFrom = need.from - SUBSCRIBE_BUFFER;
        const maxTo = need.to + SUBSCRIBE_BUFFER;

        S.subscribedFrom = minFrom;
        S.subscribedTo = maxTo;

        // Firebase RTDB: ترتيب + تصفية على الخادم
        // يتطلب .indexOn: "timestamp" في القواعد لأفضل أداء
        S.txRef = database.ref('treasury/transactions')
            .orderByChild('timestamp')
            .startAt(minFrom)
            .endAt(maxTo);

        S.txFn = function (snap) {
            const all = snap.val() || {};
            const rows = [];
            Object.keys(all).forEach(k => {
                const r = normalizeTx(all[k]);
                if (r) rows.push(r);
            });
            S.sales = rows;
            S.loaded = true;
            S.lastUpdate = new Date();
            _invalidateStatsCache();
            refresh();
        };

        S.txRef.on('value', S.txFn, function (err) {
            console.error('[SalesAnalysis] treasury error:', err);
            setStatus('error', 'تعذّر قراءة بيانات المبيعات',
                (err && err.message) || 'تحقق من صلاحيات قاعدة البيانات');
            renderEmpty('تعذّر جلب البيانات', 'راجع الاتصال أو صلاحيات القراءة');
        });
    }

    // ✅ اشتراك في kova_store (يُنشأ مرة واحدة فقط)
    function attachStore() {
        if (S.storeRef) return; // موجود بالفعل

        S.storeRef = database.ref('kova_store');
        S.storeFn = function (snap) {
            S.sold = collectSold(snap.val());
            S.lastUpdate = new Date();
            _invalidateStatsCache();
            if (S.loaded) { renderCategories(); renderGauges(); }
        };
        S.storeRef.on('value', S.storeFn, function (err) {
            console.error('[SalesAnalysis] store error:', err);
        });
    }

    async function attach() {
        detach();
        if (typeof database === 'undefined') {
            setStatus('error', 'تعذّر الاتصال بقاعدة البيانات', 'أعد تحميل الصفحة');
            return;
        }
        try { if (typeof waitForFirebaseAuth === 'function') await waitForFirebaseAuth(); } catch (e) { }
        if (!S.opened) return;

        attachTreasury();
        attachStore();
    }

    function detach() {
        try { if (S.txRef && S.txFn) S.txRef.off('value', S.txFn); } catch (e) { }
        try { if (S.storeRef && S.storeFn) S.storeRef.off('value', S.storeFn); } catch (e) { }
        S.txRef = S.txFn = S.storeRef = S.storeFn = null;
        S.subscribedFrom = null;
        S.subscribedTo = null;
    }

    /* ---------- العرض ---------- */
    function refresh() {
        if (!S.opened || !S.from || !S.to) return;
        if (!S.loaded) { el('saDpcText').textContent = fmtShort(S.from) + ' — ' + fmtShort(S.to); return; }
        S.dataset = buildDataset();
        updatePickerDisplay();
        renderKPIs();
        renderChart(false);
        if (S.resetScroll) { const sc = el('saScroll'); if (sc) sc.scrollLeft = sc.scrollWidth; S.resetScroll = false; }
        renderTable();
        renderCategories();
        renderGauges();
        renderInsights();
        const ts = el('saLastUpdate'); if (ts) ts.textContent = fmtFull(S.lastUpdate || new Date());
        if (!S.sales.length) {
            setStatus('warn', 'لا توجد عمليات بيع مسجّلة بعد', 'ستظهر التحليلات فور تسجيل أول عملية بيع');
        } else {
            setStatus(null);
        }
    }

    function smoothPath(pts) {
        if (!pts.length) return '';
        if (pts.length === 1) return 'M ' + pts[0].x + ' ' + pts[0].y;
        let d = 'M ' + pts[0].x + ' ' + pts[0].y;
        for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
            const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
            const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
            d += ' C ' + c1x.toFixed(2) + ' ' + c1y.toFixed(2) + ', ' + c2x.toFixed(2) + ' ' + c2y.toFixed(2) + ', ' + p2.x.toFixed(2) + ' ' + p2.y.toFixed(2);
        }
        return d;
    }

    function renderSpark() {
        const d = S.dataset, svg = el('saSpark');
        if (!d || !d.values.length || !d.total) { svg.innerHTML = ''; return; }
        const W = 400, H = 70, P = 4, v = d.values;
        const mn = Math.min.apply(null, v), mx = Math.max.apply(null, v), span = (mx - mn) || 1;
        const pts = v.map((x, i) => ({ x: P + (i / ((v.length - 1) || 1)) * (W - P * 2), y: H - P - ((x - mn) / span) * (H - P * 2) }));
        const line = smoothPath(pts);
        svg.innerHTML = '<defs><linearGradient id="saHeroA" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff" stop-opacity=".5"/><stop offset="100%" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>' +
            '<path d="' + line + ' L ' + pts[pts.length - 1].x + ' ' + H + ' L ' + pts[0].x + ' ' + H + ' Z" fill="url(#saHeroA)"/>' +
            '<path d="' + line + '" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2" stroke-linecap="round"/>';
    }

    function renderKPIs() {
        const d = S.dataset; if (!d) return;
        const noPrev = d.prevTotal === 0;
        const g = growthOf(d.total, d.prevTotal);
        const avg = d.count > 0 ? d.total / d.count : 0;

        el('saTotal').innerHTML = fmt(d.total) + '<small>ريال</small>';
        el('saTotalSub').textContent = d.periodLabel;

        // ✅ إصلاح: رسالة واضحة عندما لا توجد بيانات سابقة
        const pill = el('saGrowthPill');
        if (noPrev) {
            pill.textContent = 'لا توجد بيانات سابقة';
            pill.className = 'sa-pill';
            pill.style.background = 'rgba(148,163,184,.18)';
            pill.style.borderColor = 'rgba(148,163,184,.3)';
            pill.style.color = '#94a3b8';
        } else {
            pill.textContent = (g >= 0 ? '▲ +' : '▼ ') + g.toFixed(1) + '% عن السابق';
            pill.className = 'sa-pill ' + (g >= 0 ? 'up' : 'down');
            pill.style.background = '';
            pill.style.borderColor = '';
            pill.style.color = '';
        }

        const gv = el('saGrowth');
        gv.textContent = noPrev ? '—' : ((g >= 0 ? '+' : '') + g.toFixed(1) + '%');
        gv.style.color = noPrev ? '#94a3b8' : (g >= 0 ? 'var(--green)' : 'var(--red)');

        el('saTx').textContent = fmt(d.count);
        el('saAvg').textContent = fmt(avg);
        el('saChartTitle').textContent = 'اتجاه المبيعات — ' + modeAr(d.mode);
        el('saChartPeriod').textContent = d.periodLabel;
        renderSpark();
    }

    /* ----- التلميح ----- */
    function hideTip() {
        clearTimeout(ttTimer);
        const t = el('saTooltip'); if (!t) return;
        t.classList.remove('visible'); t.setAttribute('aria-hidden', 'true');
        const bar = el('saTtFill'); if (bar) bar.classList.remove('run');
        S.ttKey = null;
        qa('.sa-pt.active').forEach(o => o.classList.remove('active'));
    }

    function showTip(node) {
        const tip = el('saTooltip'), card = el('saChartCard'), d = S.dataset;
        if (!tip || !card || !d) return;
        const val = parseFloat(node.getAttribute('data-val'));
        const label = node.getAttribute('data-label');
        const type = node.getAttribute('data-type');
        const idx = parseInt(node.getAttribute('data-idx'), 10);

        el('saTtHead').innerHTML = (type === 'prev' ? '🔴 ' : '🟢 ') + _esc(label);
        el('saTtHead').style.color = type === 'prev' ? '#f87171' : '#34d399';
        el('saTtVal').innerHTML = fmt(val) + '<small>ريال</small>';

        const box = el('saTtDelta');
        if (type !== 'prev' && d.prev[idx] !== undefined) {
            const p = d.prev[idx], diff = p > 0 ? ((val - p) / p) * 100 : 0, up = diff >= 0;
            if (p === 0) {
                box.innerHTML = '<span class="sa-tt-delta" style="background:rgba(148,163,184,.16);color:#94a3b8">لا توجد بيانات سابقة</span>';
            } else {
                box.innerHTML = '<span class="sa-tt-delta ' + (up ? 'up' : 'dn') + '">' + (up ? '▲' : '▼') + ' ' + Math.abs(diff).toFixed(1) + '% <small>مقارنة بالفترة السابقة</small></span>';
            }
        } else if (type === 'prev') {
            box.innerHTML = '<span class="sa-tt-delta" style="background:rgba(148,163,184,.16);color:#94a3b8">الفترة السابقة</span>';
        } else {
            box.innerHTML = '';
        }

        tip.classList.add('visible'); tip.setAttribute('aria-hidden', 'false');
        qa('.sa-pt.active').forEach(o => o.classList.remove('active'));
        qa('[data-type="' + type + '"][data-idx="' + idx + '"]').forEach(o => o.classList.add('active'));

        const m = node.getBoundingClientRect(), c = card.getBoundingClientRect();
        let left = m.left - c.left + m.width / 2 - tip.offsetWidth / 2;
        left = Math.max(8, Math.min(left, card.clientWidth - tip.offsetWidth - 8));
        let top = m.top - c.top - tip.offsetHeight - 14;
        if (top < 8) top = m.bottom - c.top + 14;
        tip.style.left = left + 'px'; tip.style.top = top + 'px';

        const bar = el('saTtFill');
        bar.classList.remove('run'); void bar.offsetWidth;
        bar.style.setProperty('--tt', TT_MS + 'ms'); bar.classList.add('run');
        clearTimeout(ttTimer); ttTimer = setTimeout(hideTip, TT_MS);
    }

    function bindTips() {
        qa('#saViewport [data-label]').forEach(node => {
            node.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') showTip(node); });
            node.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') hideTip(); });
            node.addEventListener('click', e => {
                e.stopPropagation();
                const key = node.getAttribute('data-type') + '-' + node.getAttribute('data-idx');
                if (S.ttKey === key && el('saTooltip').classList.contains('visible')) { hideTip(); return; }
                showTip(node); S.ttKey = key;
            });
        });
    }

    /* ----- المخطط الرئيسي ----- */
    function renderChart(animate) {
        const d = S.dataset, vp = el('saViewport');
        hideTip();
        el('saYAxis').innerHTML = '';
        if (!d || !d.values.length || (d.total === 0 && d.prevTotal === 0)) {
            vp.style.width = '';
            vp.innerHTML = '<div class="sa-empty"><i class="fas fa-chart-line"></i><b>لا توجد مبيعات في هذه الفترة</b><span>جرّب توسيع نطاق التاريخ أو اختيار فترة أخرى</span></div>';
            el('saHighlight').style.display = 'none';
            ['saStatPeak', 'saStatAvg', 'saStatLow', 'saStatVol'].forEach(i => el(i).textContent = '—');
            el('saStatPeakLbl').textContent = '—';
            el('saStatLowLbl').textContent = '—';
            return;
        }
        const n = d.labels.length;
        const W = Math.max(300, n * 40) * S.zoom;
        vp.style.width = W + 'px';

        const all = d.values.concat(S.showPrev ? d.prev : []);
        let maxV = Math.max.apply(null, all.concat([1])), minV = Math.min.apply(null, all.concat([0]));
        const span = (maxV - minV) || 1;
        maxV += span * 0.2; minV = Math.max(0, minV - span * 0.18);

        const H = 180, PT = 22, PB = 22, usable = H - PT - PB;
        const yOf = v => H - PB - ((v - minV) / (maxV - minV)) * usable;
        const xOf = i => n > 1 ? (i / (n - 1)) * (W - 44) + 22 : W / 2;

        const div = maxV >= 1e9 ? 1e9 : maxV >= 1e6 ? 1e6 : maxV >= 1e4 ? 1e3 : 1;
        el('saChartUnit').textContent = div === 1e9 ? 'بالمليار ريال' : div === 1e6 ? 'بالمليون ريال' : div === 1e3 ? 'بالألف ريال' : 'بالريال';
        const axisText = v => { const x = v / div; return x >= 100 || div === 1 ? String(Math.round(x)) : x >= 10 ? x.toFixed(1) : x.toFixed(2); };

        const avgV = d.total / n, avgY = yOf(avgV);
        const grid = [0.08, 0.29, 0.5, 0.71, 0.92].map(r => { const v = minV + r * (maxV - minV); return { y: yOf(v), text: axisText(v) }; });
        let near = 0, best = Infinity;
        grid.forEach((g, i) => { const dd = Math.abs(g.y - avgY); if (dd < best) { best = dd; near = i; } });
        el('saYAxis').innerHTML = grid.map((g, i) => '<span class="' + (i === near ? 'hl' : '') + '" style="top:' + g.y.toFixed(1) + 'px">' + g.text + '</span>').join('');

        const mk = (arr, lbl) => arr.map((v, i) => ({ x: xOf(i), y: yOf(v), val: v, label: lbl[i], idx: i }));
        const prevPts = mk(d.prev, d.full), curPts = mk(d.values, d.full);
        const peakVal = Math.max.apply(null, d.values), peakIdx = d.values.indexOf(peakVal), last = n - 1;
        const lineD = smoothPath(curPts), prevD = smoothPath(prevPts);
        const areaD = lineD + ' L ' + curPts[last].x + ' ' + (H - PB) + ' L ' + curPts[0].x + ' ' + (H - PB) + ' Z';
        const attrs = (p, type, i) => 'data-val="' + p.val + '" data-label="' + _esc(p.label) + '" data-type="' + type + '" data-idx="' + i + '"';

        let svg = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" style="display:block;overflow:visible"><defs>' +
            '<linearGradient id="saLineG" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#3b82f6"/><stop offset="50%" stop-color="#22d3ee"/><stop offset="100%" stop-color="#10b981"/></linearGradient>' +
            '<linearGradient id="saAreaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity=".4"/><stop offset="50%" stop-color="#3b82f6" stop-opacity=".14"/><stop offset="100%" stop-color="#3b82f6" stop-opacity=".01"/></linearGradient>' +
            '<linearGradient id="saBarG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity=".95"/><stop offset="100%" stop-color="#10b981" stop-opacity=".55"/></linearGradient>' +
            '<linearGradient id="saBarPk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#f59e0b" stop-opacity=".5"/></linearGradient>' +
            '<filter id="saGlow" x="-5%" y="-40%" width="110%" height="180%"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>' +
            '<filter id="saPk" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>';

        grid.forEach((g, i) => {
            const isAvg = i === near && S.showAvg;
            svg += '<line x1="0" y1="' + g.y.toFixed(1) + '" x2="' + W + '" y2="' + g.y.toFixed(1) + '" stroke="' + (isAvg ? 'rgba(167,139,250,.28)' : 'rgba(255,255,255,.06)') + '" stroke-dasharray="3,5" stroke-width=".8"/>';
        });

        if (S.chartType === 'bars' && S.showCur) {
            const bw = Math.max(4, (W - 60) / n * 0.55);
            curPts.forEach((p, i) => {
                const pk = i === peakIdx && S.showPeak;
                svg += '<rect x="' + (p.x - bw / 2).toFixed(1) + '" y="' + p.y.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(0, H - PB - p.y).toFixed(1) + '" rx="3" fill="url(#' + (pk ? 'saBarPk' : 'saBarG') + ')" class="' + (animate ? 'sa-pt-in' : '') + '" style="' + (animate ? 'animation-delay:' + i * 40 + 'ms' : '') + '" ' + attrs(p, 'cur', i) + ' opacity="' + (pk ? 1 : .88) + '"/>';
            });
            svg += '<path d="' + lineD + '" fill="none" stroke="#22d3ee" stroke-width="1.2" opacity=".5"/>';
        }
        if (S.chartType === 'area' && S.showCur) svg += '<path d="' + areaD + '" fill="url(#saAreaG)" opacity="0" class="sa-area"/>';
        if (S.showPrev) svg += '<path d="' + prevD + '" fill="none" stroke="#ef4444" stroke-width="1.9" stroke-dasharray="6,4" opacity=".72" stroke-linecap="round"/>';
        if (S.showCur && S.chartType !== 'bars') svg += '<path class="sa-chart-line" d="' + lineD + '" fill="none" stroke="url(#saLineG)" stroke-width="2.9" stroke-linecap="round" stroke-linejoin="round" filter="url(#saGlow)"/>';
        if (S.showAvg) svg += '<line x1="0" y1="' + avgY.toFixed(1) + '" x2="' + W + '" y2="' + avgY.toFixed(1) + '" stroke="#a78bfa" stroke-width="1.2" stroke-dasharray="2,4" opacity=".7"/><text x="' + (W - 4) + '" y="' + (avgY - 4).toFixed(1) + '" font-size="7.5" font-weight="900" fill="#a78bfa" text-anchor="end">AVG</text>';
        if (S.showPrev) {
            prevPts.forEach((p, i) => {
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="2.5" fill="#ef4444" stroke="' + SOLID + '" stroke-width="1.1" class="sa-pt" ' + attrs(p, 'prev', i) + '/>';
            });
        }
        if (S.showCur && S.chartType !== 'bars') {
            curPts.forEach((p, i) => {
                const isLast = i === last, pk = i === peakIdx && S.showPeak;
                const livePt = S.isLive && isLast && d.isTodayIncluded;
                const color = pk ? '#fbbf24' : livePt ? '#10b981' : isLast ? '#22d3ee' : '#10b981';
                const r = livePt ? 7 : pk ? 6 : isLast ? 5.5 : 4;
                if (livePt) svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="14" fill="none" stroke="#10b981" stroke-width="2" class="sa-pulse" opacity=".6"/>';
                else if (isLast && !pk) svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="9" fill="none" stroke="#22d3ee" stroke-width="1.5" class="sa-pulse"/>';
                const t = isLast ? 'now' : 'cur';
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="' + r + '" fill="' + color + '" stroke="' + SOLID + '" stroke-width="1.7" class="sa-pt ' + (animate ? 'sa-pt-in' : '') + '" style="' + (animate ? 'animation-delay:' + Math.min(i * 28, 720) + 'ms' : '') + '"' + (pk ? ' filter="url(#saPk)"' : '') + ' ' + attrs(p, t, i) + '/>';
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="14" fill="transparent" class="sa-pt" ' + attrs(p, t, i) + '/>';
            });
        }
        if (S.showPeak && S.showCur && peakVal > 0 && peakIdx !== last) {
            const pk = curPts[peakIdx], fy = Math.max(8, pk.y - 20);
            svg += '<g><circle cx="' + pk.x.toFixed(1) + '" cy="' + fy.toFixed(1) + '" r="8" fill="url(#saBarPk)" filter="url(#saPk)"/><text x="' + pk.x.toFixed(1) + '" y="' + (fy + 3).toFixed(1) + '" font-size="9" text-anchor="middle" fill="#1a1207" font-weight="900">★</text></g>';
        }
        svg += '</svg>';

        let axis = '<div class="sa-axis" style="width:' + W + 'px">';
        d.labels.forEach((lbl, i) => {
            const isLast = i === last, pk = i === peakIdx && S.showPeak && peakVal > 0;
            const live = S.isLive && isLast && d.isTodayIncluded;
            axis += '<span class="' + (live ? 'live-now' : isLast ? 'now' : pk ? 'peak-lbl' : '') + '" style="left:' + xOf(i).toFixed(1) + 'px">' + _esc(lbl) + '</span>';
        });
        vp.innerHTML = svg + axis + '</div>';

        const area = vp.querySelector('.sa-area');
        if (animate) {
            const ln = vp.querySelector('.sa-chart-line');
            if (ln) {
                try {
                    const len = ln.getTotalLength();
                    ln.style.strokeDasharray = len; ln.style.strokeDashoffset = len; ln.getBoundingClientRect();
                    requestAnimationFrame(() => { ln.style.strokeDashoffset = 0; });
                } catch (e) { }
            }
            if (area) { area.style.transition = 'opacity .9s ease .35s'; requestAnimationFrame(() => { area.style.opacity = '1'; }); }
        } else if (area) area.style.opacity = '1';

        bindTips();
        updateHighlight();
    }

    function updateHighlight() {
        const d = S.dataset; if (!d || !d.values.length) return;
        const n = d.values.length;
        const pk = Math.max.apply(null, d.values), pi = d.values.indexOf(pk);
        const lo = Math.min.apply(null, d.values), li = d.values.indexOf(lo);
        const avg = d.total / n;
        el('saHighlight').style.display = 'flex';
        el('saHlTitle').textContent = 'أعلى فترة: ' + d.full[pi];
        el('saHlSub').textContent = (avg > 0 ? '+' + (((pk - avg) / avg) * 100).toFixed(0) + '% فوق المتوسط' : 'لا توجد مبيعات');
        el('saHlVal').textContent = shortMoney(pk);
        el('saStatPeak').textContent = shortMoney(pk); el('saStatPeakLbl').textContent = d.labels[pi];
        el('saStatAvg').textContent = shortMoney(avg);
        el('saStatLow').textContent = shortMoney(lo); el('saStatLowLbl').textContent = d.labels[li];
        const variance = sum(d.values.map(v => Math.pow(v - avg, 2))) / n;
        const vol = avg > 0 ? (Math.sqrt(variance) / avg) * 100 : 0;
        const vv = el('saStatVol');
        vv.textContent = vol.toFixed(1) + '%';
        vv.style.color = vol > 25 ? 'var(--red)' : vol > 15 ? 'var(--gold)' : 'var(--green)';
    }

    function renderTable() {
        const d = S.dataset, box = el('saTable');
        if (!d || !d.total) { box.innerHTML = '<div class="sa-none">لا توجد مبيعات في الفترة المحددة</div>'; return; }
        box.innerHTML = d.labels.map((lbl, i) => {
            const has = d.prev[i] > 0;
            const g = growthOf(d.values[i], d.prev[i]);
            return '<div class="sa-row"><span class="l">' + _esc(lbl) + '</span><span class="v">' + fmt(d.values[i]) + '</span>' +
                '<span class="g" style="color:' + (!has ? 'var(--text-secondary)' : g >= 0 ? 'var(--green)' : 'var(--red)') + '">' + (has ? (g >= 0 ? '↑ ' : '↓ ') + Math.abs(g).toFixed(1) + '%' : '—') + '</span></div>';
        }).join('');
    }

    /* ✅ Cache-aware: categoryStats */
    function categoryStats() {
        if (!S.from || !S.to) return { cats: [], total: 0 };
        const key = 'cat:' + S.from.getTime() + '-' + S.to.getTime() + '-' + S.sold.length;
        if (_statsCache.key === key && _statsCache.cats) return _statsCache.cats;

        const start = midnight(S.from).getTime();
        const end = new Date(S.to.getFullYear(), S.to.getMonth(), S.to.getDate() + 1).getTime();
        const map = {};
        S.sold.forEach(c => { if (c.ms >= start && c.ms < end) map[c.cat] = (map[c.cat] || 0) + 1; });
        const cats = Object.keys(map).map(k => ({ name: k, count: map[k] })).sort((a, b) => b.count - a.count);
        cats.forEach((c, i) => { c.color = PALETTE[i % PALETTE.length]; });
        const result = { cats: cats, total: sum(cats.map(c => c.count)) };

        _statsCache.key = key;
        _statsCache.cats = result;
        return result;
    }

    /* ✅ Cache-aware: customerStats */
    function customerStats() {
        if (!S.from || !S.to) return [];
        const key = 'cust:' + S.from.getTime() + '-' + S.to.getTime() + '-' + S.sales.length;
        if (_statsCache.key === key && _statsCache.cust) return _statsCache.cust;

        const start = midnight(S.from).getTime();
        const end = new Date(S.to.getFullYear(), S.to.getMonth(), S.to.getDate() + 1).getTime();
        const map = {};
        S.sales.forEach(r => {
            const t = r.date.getTime();
            if (t < start || t >= end) return;
            const o = map[r.customer] || (map[r.customer] = { name: r.customer, amount: 0, count: 0 });
            o.amount += r.amount; o.count += 1;
        });
        const result = Object.keys(map).map(k => map[k]).sort((a, b) => b.amount - a.amount);

        _statsCache.key = key;
        _statsCache.cust = result;
        return result;
    }

    function renderCategories() {
        if (!S.opened) return;
        const st = categoryStats(), svgEl = el('saDonut');
        if (!st.total) {
            svgEl.innerHTML = '<circle cx="70" cy="70" r="52" fill="none" stroke="#1e293b" stroke-width="15"/>';
            el('saDonutTotal').textContent = '0';
            el('saCatList').innerHTML = '<div class="sa-none">لا توجد كروت مباعة في هذه الفترة</div>';
            return;
        }
        const R = 52, C = 2 * Math.PI * R;
        let off = 0, svg = '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="#1e293b" stroke-width="15"/>';
        st.cats.forEach(c => {
            const dash = (c.count / st.total) * C;
            svg += '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="' + c.color + '" stroke-width="15" stroke-dasharray="' + dash.toFixed(2) + ' ' + (C - dash).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 70 70)"/>';
            off += dash;
        });
        svgEl.innerHTML = svg;
        el('saDonutTotal').textContent = fmt(st.total);
        el('saCatList').innerHTML = st.cats.slice(0, 6).map(c =>
            '<div class="sa-cat"><i style="background:' + c.color + '"></i><span class="sa-cat-name">' + _esc(c.name) + '</span><span class="sa-cat-val" style="color:' + c.color + '">' + ((c.count / st.total) * 100).toFixed(0) + '%</span></div>').join('');
    }

    function gaugeSVG(pct, color) {
        const R = 18, C = 2 * Math.PI * R, dash = (Math.max(0, Math.min(100, pct)) / 100) * C;
        return '<svg width="44" height="44" viewBox="0 0 44 44"><circle cx="22" cy="22" r="' + R + '" fill="none" stroke="#1e293b" stroke-width="4"/><circle cx="22" cy="22" r="' + R + '" fill="none" stroke="' + color + '" stroke-width="4" stroke-linecap="round" stroke-dasharray="' + dash.toFixed(2) + ' ' + (C - dash).toFixed(2) + '"/></svg>';
    }

    function renderGauges() {
        const d = S.dataset; if (!d || !S.opened) return;
        const g = growthOf(d.total, d.prevTotal);
        const activePct = d.values.length ? (d.values.filter(v => v > 0).length / d.values.length) * 100 : 0;
        const cs = categoryStats();
        const topCat = cs.cats[0];
        const topCatPct = topCat ? (topCat.count / cs.total) * 100 : 0;
        const cust = customerStats();
        const top3 = d.total > 0 ? (sum(cust.slice(0, 3).map(c => c.amount)) / d.total) * 100 : 0;

        const items = [
            { k: 'معدل النمو', v: (d.prevTotal === 0 ? '—' : (g >= 0 ? '+' : '') + g.toFixed(1) + '%'), pct: d.prevTotal === 0 ? 0 : Math.min(100, Math.max(6, 50 + g)), c: '#10b981', s: d.prevTotal === 0 ? 'لا توجد بيانات سابقة' : 'مقارنة بالفترة السابقة' },
            { k: 'الفترات النشطة', v: activePct.toFixed(0) + '%', pct: activePct, c: '#3b82f6', s: 'فترات سُجّلت فيها مبيعات' },
            { k: 'أعلى فئة كروت', v: topCat ? topCatPct.toFixed(0) + '%' : '—', pct: topCatPct, c: '#fbbf24', s: topCat ? topCat.name : 'لا توجد كروت مباعة' },
            { k: 'أعلى 3 عملاء', v: top3.toFixed(0) + '%', pct: top3, c: '#8b5cf6', s: 'من إجمالي المبيعات' }
        ];
        el('saGauges').innerHTML = items.map(it =>
            '<div class="sa-gauge"><div class="sa-ring">' + gaugeSVG(it.pct, it.c) + '<b style="color:' + it.c + '">' + Math.round(it.pct) + '%</b></div>' +
            '<div class="sa-gi"><div class="sa-gk">' + _esc(it.k) + '</div><div class="sa-gv" style="color:' + it.c + '">' + _esc(it.v) + '</div><div class="sa-gs">' + _esc(it.s) + '</div></div></div>').join('');
    }

    function renderInsights() {
        const d = S.dataset, box = el('saInsights');
        if (!d || !d.total) { box.innerHTML = '<div class="sa-none">لا توجد بيانات كافية للتحليل</div>'; return; }
        const list = [];
        const g = growthOf(d.total, d.prevTotal);
        if (d.prevTotal <= 0) {
            list.push(['info', 'fa-circle-info', 'لا توجد مبيعات في الفترة السابقة للمقارنة بها.']);
        } else if (g >= 20) {
            list.push(['good', 'fa-rocket', 'نمو <b>قوي جداً</b> بنسبة +' + g.toFixed(1) + '% عن الفترة السابقة.']);
        } else if (g >= 5) {
            list.push(['good', 'fa-arrow-trend-up', 'نمو <b>إيجابي</b> بنسبة +' + g.toFixed(1) + '%.']);
        } else if (g >= 0) {
            list.push(['info', 'fa-arrow-right', 'نمو <b>طفيف</b> بنسبة +' + g.toFixed(1) + '%.']);
        } else {
            list.push(['bad', 'fa-arrow-trend-down', 'تراجع بنسبة <b>' + Math.abs(g).toFixed(1) + '%</b> عن الفترة السابقة.']);
        }

        const pk = Math.max.apply(null, d.values), pi = d.values.indexOf(pk);
        list.push(['info', 'fa-medal', 'أعلى فترة: <b>' + _esc(d.full[pi]) + '</b> بإجمالي <b>' + fmt(pk) + ' ريال</b>.']);
        list.push(['info', 'fa-receipt', 'عدد العمليات: <b>' + fmt(d.count) + '</b> · متوسط العملية <b>' + fmt(d.count ? d.total / d.count : 0) + ' ريال</b>.']);

        const cust = customerStats();
        if (cust.length) {
            list.push(['info', 'fa-user-check', 'أكثر العملاء شراءً: <b>' + _esc(cust[0].name) + '</b> بإجمالي <b>' + fmt(cust[0].amount) + ' ريال</b> (' + cust.length + ' عميل نشط).']);
        }
        list.push(['info', 'fa-calculator', 'عدد الفترات: <b>' + d.labels.length + '</b> · التجميع: <b>' + modeAr(d.mode) + '</b>.']);

        box.innerHTML = list.map(i => '<div class="sa-ins ' + i[0] + '"><i class="fas ' + i[1] + '"></i><span>' + i[2] + '</span></div>').join('');
    }

    function renderEmpty(title, sub) {
        el('saTotal').innerHTML = '0<small>ريال</small>';
        el('saTotalSub').textContent = '—';
        el('saGrowthPill').textContent = '—';
        el('saGrowth').textContent = '0%';
        el('saTx').textContent = '0';
        el('saAvg').textContent = '0';
        el('saSpark').innerHTML = '';
        el('saViewport').style.width = '';
        el('saViewport').innerHTML = '<div class="sa-empty"><i class="fas fa-triangle-exclamation"></i><b>' + _esc(title) + '</b><span>' + _esc(sub || '') + '</span></div>';
    }

    /* ---------- منتقي التاريخ ---------- */
    function fillMonths(sel, v) {
        sel.innerHTML = MONTHS.map((m, i) => '<option value="' + i + '">' + m + '</option>').join('');
        sel.value = v;
    }
    function fillYears(sel, v) {
        let h = '';
        for (let y = YEAR_MIN; y <= YEAR_MAX; y++) h += '<option value="' + y + '">' + y + '</option>';
        sel.innerHTML = h; sel.value = v;
    }
    function fillDays(sel, y, m, v) {
        const n = dim(y, m);
        let h = '';
        for (let d = 1; d <= n; d++) h += '<option value="' + d + '">' + pad(d) + '</option>';
        sel.innerHTML = h;
        sel.value = Math.min(v || 1, n);
    }
    function readPicker(p) {
        return new Date(+el(p + 'Year').value, +el(p + 'Month').value, +el(p + 'Day').value);
    }
    function setPicker(p, date) {
        fillYears(el(p + 'Year'), date.getFullYear());
        fillMonths(el(p + 'Month'), date.getMonth());
        fillDays(el(p + 'Day'), date.getFullYear(), date.getMonth(), date.getDate());
    }
    function flash(n) {
        if (!n) return;
        n.classList.remove('sa-flash');
        void n.offsetWidth;
        n.classList.add('sa-flash');
        setTimeout(() => n.classList.remove('sa-flash'), 750);
    }
    function flashAll(p) { ['Day', 'Month', 'Year'].forEach(x => flash(el(p + x))); }
    function syncDays(p) {
        const y = +el(p + 'Year').value, m = +el(p + 'Month').value, ds = el(p + 'Day');
        const cur = +ds.value || 1, nd = Math.min(cur, dim(y, m));
        fillDays(ds, y, m, nd);
        if (nd !== cur) flash(ds);
    }
    function warn(text) {
        const w = el('saWarn');
        el('saWarnText').textContent = text;
        w.classList.add('show');
        clearTimeout(warnTimer);
        warnTimer = setTimeout(() => w.classList.remove('show'), 2400);
    }
    function autoFix(changed) {
        if (S.suppress || S.isLive) return;
        const f = readPicker('saFrom'), t = readPicker('saTo');
        if (f > t) {
            if (changed === 'saFrom') { setPicker('saTo', f); flashAll('saTo'); warn('تم ضبط تاريخ النهاية ليطابق البداية'); }
            else { setPicker('saFrom', t); flashAll('saFrom'); warn('تم ضبط تاريخ البداية ليطابق النهاية'); }
        }
    }
    function updatePickerDisplay() {
        if (!S.from || !S.to) return;
        el('saDpcText').textContent = fmtShort(S.from) + ' — ' + fmtShort(S.to);
        if (S.dataset) el('saDpcMode').textContent = modeAr(S.dataset.mode);
    }

    function applyRange(silent) {
        let f = readPicker('saFrom'), t = readPicker('saTo');
        if (f > t) { const x = f; f = t; t = x; setPicker('saFrom', f); setPicker('saTo', t); warn('تم تبديل التواريخ تلقائياً'); }
        S.from = midnight(f); S.to = midnight(t);
        S.offsetMs = S.to.getTime() - S.from.getTime();
        S.resetScroll = true; S.zoom = 1;
        _invalidateStatsCache();

        if (S.isLive && S.to.getTime() < midnight(new Date()).getTime()) {
            setLive(false, true);
            warn('أُوقفت المتابعة المباشرة لأن الفترة لا تنتهي اليوم');
        }

        // ✅ إعادة الاشتراك إذا كانت الفترة الجديدة خارج النطاق المُشترك
        if (!_isRangeCovered()) {
            attachTreasury();
        } else {
            refresh();
        }

        if (!silent) say('تم تطبيق الفترة المحددة', true);
    }

    function quickRange(key) {
        const to = midnight(new Date()), from = new Date(to);
        switch (key) {
            case '7d': from.setDate(to.getDate() - 6); break;
            case '30d': from.setDate(to.getDate() - 29); break;
            case '90d': from.setDate(to.getDate() - 89); break;
            case '6m': from.setMonth(from.getMonth() - 5); from.setDate(1); break;
            case '1y': from.setFullYear(from.getFullYear() - 1); from.setDate(from.getDate() + 1); break;
            case 'thisMonth': from.setDate(1); break;
            case 'thisYear': from.setMonth(0); from.setDate(1); break;
        }
        return { from: from, to: to };
    }

    /* ---------- المتابعة المباشرة ---------- */
    function syncLiveDates() {
        const today = midnight(new Date());
        const from = midnight(new Date(today.getTime() - S.offsetMs));
        S.suppress = true;
        setPicker('saTo', today);
        setPicker('saFrom', from);
        S.suppress = false;
        S.from = from;
        S.to = today;
    }

    function setLive(on, silent) {
        S.isLive = on;
        const sw = el('saLiveToggle');
        el('saLive').classList.toggle('off', !on);
        sw.classList.toggle('on', on);
        sw.setAttribute('aria-checked', on ? 'true' : 'false');
        el('saLiveBadge').textContent = on ? 'LIVE' : 'MANUAL';
        el('saLiveBadge').classList.toggle('off', !on);
        el('saChartLive').style.display = on ? '' : 'none';
        el('saFromSec').classList.toggle('locked', on);
        el('saToSec').classList.toggle('locked', on);
        el('saFromHint').textContent = on ? 'البداية تتحرك تلقائياً مع اليوم' : 'الشهر والسنة يضبطان عدد الأيام تلقائياً';
        el('saToHint').textContent = on ? 'النهاية مثبّتة على تاريخ اليوم' : 'يُضبط النطاق تلقائياً لتفادي التعارض';
        ['saToDay', 'saToMonth', 'saToYear'].forEach(id => { el(id).disabled = on; });

        clearInterval(S.liveTimer);
        S.liveTimer = null;

        if (on) {
            syncLiveDates();
            S.liveTimer = setInterval(() => {
                if (!S.isLive) return;
                const prev = S.to ? S.to.getTime() : 0;
                syncLiveDates();
                if (prev !== S.to.getTime()) {
                    S.resetScroll = true;
                    _invalidateStatsCache();
                    // تاريخ اليوم تغيّر — نحتاج إعادة اشتراك حتى يظهر اليوم الجديد
                    if (!_isRangeCovered()) attachTreasury();
                    else refresh();
                }
            }, 60000);
            S.resetScroll = true;
            if (!_isRangeCovered()) attachTreasury();
            else refresh();
            if (!silent) say('المتابعة المباشرة مُفعّلة', true);
        } else if (!silent) {
            say('تم إيقاف المتابعة المباشرة', false);
        }
    }

    /* ---------- الربط (مرة واحدة) ---------- */
    function bind() {
        if (S.bound) return;
        S.bound = true;
        const now = new Date();
        const from = new Date(now.getFullYear(), now.getMonth() - 5, 1), to = midnight(now);
        setPicker('saFrom', from); setPicker('saTo', to);
        S.from = midnight(from); S.to = to;
        S.offsetMs = S.to.getTime() - S.from.getTime();

        ['saFrom', 'saTo'].forEach(p => {
            el(p + 'Year').addEventListener('change', () => { syncDays(p); autoFix(p); });
            el(p + 'Month').addEventListener('change', () => { syncDays(p); autoFix(p); });
            el(p + 'Day').addEventListener('change', () => autoFix(p));
        });

        el('saFromToday').addEventListener('click', () => {
            if (S.isLive) { say('المتابعة المباشرة تُحدّث التواريخ تلقائياً', false); return; }
            setPicker('saFrom', midnight(new Date())); flashAll('saFrom'); autoFix('saFrom');
        });
        el('saToToday').addEventListener('click', () => {
            if (S.isLive) { say('تاريخ النهاية مثبّت على اليوم تلقائياً', false); return; }
            setPicker('saTo', midnight(new Date())); flashAll('saTo'); autoFix('saTo');
        });

        el('saDpcToggle').addEventListener('click', () => el('saDpc').classList.toggle('open'));
        el('saApply').addEventListener('click', () => {
            applyRange(false);
            setTimeout(() => el('saDpc').classList.remove('open'), 350);
        });

        qa('.sa-chip').forEach(chip => chip.addEventListener('click', () => {
            const r = quickRange(chip.getAttribute('data-quick'));
            S.suppress = true;
            setPicker('saFrom', r.from);
            setPicker('saTo', r.to);
            S.suppress = false;
            qa('.sa-chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            setTimeout(() => chip.classList.remove('active'), 900);
            applyRange(true);
        }));

        const sw = el('saLiveToggle');
        sw.addEventListener('click', () => setLive(!S.isLive));
        sw.addEventListener('keydown', e => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setLive(!S.isLive); }
        });

        el('saZoomIn').addEventListener('click', () => { S.zoom = Math.min(3.2, +(S.zoom + 0.3).toFixed(2)); renderChart(false); });
        el('saZoomOut').addEventListener('click', () => { S.zoom = Math.max(0.75, +(S.zoom - 0.3).toFixed(2)); renderChart(false); });
        el('saZoomReset').addEventListener('click', () => { S.zoom = 1; renderChart(false); });

        qa('.sa-ctype').forEach(b => b.addEventListener('click', () => {
            qa('.sa-ctype').forEach(x => x.classList.remove('active'));
            b.classList.add('active');
            S.chartType = b.getAttribute('data-chart');
            renderChart(true);
        }));

        qa('.sa-lg').forEach(item => item.addEventListener('click', () => {
            const k = item.getAttribute('data-legend');
            if (k === 'cur') S.showCur = !S.showCur;
            if (k === 'prev') S.showPrev = !S.showPrev;
            if (k === 'avg') S.showAvg = !S.showAvg;
            if (k === 'peak') S.showPeak = !S.showPeak;
            item.classList.toggle('off');
            renderChart(false);
        }));

        el('saExport').addEventListener('click', exportCsv);

        document.addEventListener('click', e => {
            if (!S.opened) return;
            if (e.target.closest && (e.target.closest('#saViewport [data-label]') || e.target.closest('#saTooltip'))) return;
            if (el('saTooltip').classList.contains('visible')) hideTip();
        });
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape' && S.opened) hideTip();
        });

        let rt = null;
        window.addEventListener('resize', () => {
            clearTimeout(rt);
            rt = setTimeout(() => { if (S.opened && S.dataset) renderChart(false); }, 180);
        });
    }

    function exportCsv() {
        if (!S.from || !S.to) return;
        const start = midnight(S.from).getTime();
        const end = new Date(S.to.getFullYear(), S.to.getMonth(), S.to.getDate() + 1).getTime();
        const rows = S.sales.filter(r => r.date.getTime() >= start && r.date.getTime() < end).sort((a, b) => a.date - b.date);
        if (!rows.length) { say('لا توجد بيانات للتصدير في هذه الفترة', false); return; }
        const out = [['التاريخ', 'الوقت', 'المبلغ (ريال)', 'العميل']];
        rows.forEach(r => out.push([r.dateKey, pad(r.hour) + ':' + pad(r.date.getMinutes()), r.amount, r.customer]));
        const csv = '\uFEFF' + out.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
        const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
        const a = document.createElement('a');
        a.href = url;
        a.download = 'sales_' + dkey(S.from) + '_' + dkey(S.to) + '.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        say('تم تصدير ' + rows.length + ' عملية', true);
    }

    /* ---------- الواجهة العامة ---------- */
    window.SalesAnalysis = {
        open: function () {
            if (S.opened) return;
            S.opened = true;
            S.loaded = false;
            _invalidateStatsCache();
            bind();
            S.resetScroll = true;
            setLive(S.isLive, true);
            renderEmpty('جاري جلب البيانات…', 'يتم الآن قراءة المبيعات من قاعدة البيانات');
            attach();
        },
        close: function () {
            if (!S.opened) return;
            S.opened = false;
            S.loaded = false;
            detach();
            clearInterval(S.liveTimer);
            S.liveTimer = null;
            hideTip();
            _invalidateStatsCache();
        }
    };
})();