// ============================================================
// تحليل الوكلاء — AgentsAnalysis
// المصدر: Firebase Realtime Database (تحديث لحظي عبر on('value') — نفس أسلوب تحليل المستخدمين)
//   • users/{phone}                → بيانات الوكيل (userType: agent | pos | distributor أو isAgent=true)
//   • users/{agent}/history/*      → سجل حركات الوكيل الفعلي:
//        شراء كروت  (type:'out' + codes)        → بيع للمستخدم إن كان المستلم غير الوكيل
//        تحويل إلى X (type:'out')               → حوالة صادرة للمستخدمين
//        تحويل من X  (type:'in')                → حوالة واردة
//        إيداع       (type:'in')                → إيداع من الإدارة
//   • kova_store/{catId}/sold/*    → code → customerId (المستلم) + الفئة + السعر
//
// المبدأ: لا توجد بيانات وهمية. كل رقم يُحسب من حركات الوكيل الفعلية.
//   قيمة البيع = المبلغ المخصوم من رصيد الوكيل مقابل كروت سُلّمت لمستخدم آخر.
//   الكرت يُربط بمستلمه عبر الكود في سجل kova_store/sold (customerId).
//   الشراء الذي يكون مستلمه الوكيل نفسه يُعدّ "مخزوناً لنفسه" ولا يدخل في مبيعاته.
//
// تعريفات قابلة للتعديل (الثوابت في الأعلى):
//   نشط = نفّذ بيعاً أو حوالة خلال آخر ACTIVE_DAYS يوماً
//   VIP  = ضمن أعلى VIP_TOP_PCT من الوكلاء مبيعاً
//
// يعتمد على: database, $n, esc, showAlert, waitForFirebaseAuth, openChatWithUser
// ============================================================
(function () {
    'use strict';

    /* ---------- إعدادات ---------- */
    const ACTIVE_DAYS = 30;
    const VIP_TOP_PCT = 0.10;
    const PAGE_SIZE = 40;
    const BUYER_FIELDS = ['buyerPhone', 'customerId', 'soldTo', 'buyer']; // ترتيب الأولوية
    const SKIP_USERS = ['999'];                                           // نفس ما يتجاهله admin-logic

    const TYPES = {
        agent:       { label: 'وكيل',      icon: 'fa-store',         color: '#58b8e8' },
        pos:         { label: 'نقطة بيع',  icon: 'fa-cash-register', color: '#10b981' },
        distributor: { label: 'موزع',      icon: 'fa-truck-fast',    color: '#f59e0b' }
    };
    const KIND_META = {
        sale: { icon: 'fa-ticket',            color: '#3b82f6', sign: '+' },
        tout: { icon: 'fa-paper-plane',       color: '#fbbf24', sign: '-' },
        tin:  { icon: 'fa-arrow-down-long',   color: '#8b5cf6', sign: '+' },
        dep:  { icon: 'fa-building-columns',  color: '#34d399', sign: '+' },
        self: { icon: 'fa-boxes-stacked',     color: '#64748b', sign: '-' },
        unk:  { icon: 'fa-circle-question',   color: '#94a3b8', sign: '-' }
    };

    const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const DAY = 86400000;
    const PALETTE = ['#10b981', '#3b82f6', '#8b5cf6', '#fbbf24', '#f59e0b', '#ef4444'];
    const AV_COLORS = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];
    const TT_MS = 3500;
    const SOLID = '#101728';
    const PERIOD_LONG = { day: 'اليوم', week: 'آخر 7 أيام', month: 'آخر 30 يوماً', '3months': 'آخر 3 أشهر', year: 'آخر 12 شهراً', all: 'كل الفترات' };

    // ---------- Guards ----------
    const _n = (typeof $n === 'function') ? $n : function (v) {
        if (v === null || v === undefined) return 0;
        const num = parseFloat(String(v).replace(/,/g, ''));
        return isNaN(num) ? 0 : num;
    };
    const _esc = (typeof esc === 'function') ? esc : function (s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m] || m);
    };

    // ---------- الحالة ----------
    const S = {
        opened: false, bound: false, live: true, attachId: 0,
        usersRef: null, usersFn: null, storeRef: null, storeFn: null,
        usersRaw: null, storeRaw: null, gotUsers: false, gotStore: false,
        // بيانات مُشتقّة
        list: [], byId: {}, allUsers: {}, recsBy: {},
        totals: { amount: 0, cards: 0, agents: 0, sellers: 0, served: 0, tout: 0 }, unk: 0, undated: 0,
        lastUpdate: null, rebuildTimer: null, tick: null,
        // الواجهة
        view: 'list', search: '', sort: 'total-desc', typeFilter: '', visible: PAGE_SIZE,
        selected: null, period: 'month', metric: 'sales', chartType: 'area', zoom: 1,
        showCur: true, showPrev: true, showAvg: true, showPeak: true,
        dataset: null, ttKey: null, resetScroll: true
    };
    let ttTimer = null;

    /* ---------- أدوات ---------- */
    const el = id => document.getElementById(id);
    const qa = s => [].slice.call(document.querySelectorAll('#agentsAnalysisInterface ' + s));
    const pad = n => String(n).padStart(2, '0');
    const midnight = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const sum = a => a.reduce((x, y) => x + y, 0);
    const fmt = n => isFinite(n) ? Math.round(n).toLocaleString('en-US') : '0';
    const shortMoney = n => {
        if (!isFinite(n) || n === 0) return '0';
        if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
        if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
        if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
        return String(Math.round(n));
    };
    const fmtDay = d => d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    const fmtShort = d => pad(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    const fmtFull = d => fmtDay(d) + ' - ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    const modeAr = m => m === 'hour' ? 'بالساعة' : m === 'day' ? 'يومي' : m === 'week' ? 'أسبوعي' : m === 'month' ? 'شهري' : 'سنوي';
    const growthOf = (cur, prev) => prev > 0 ? ((cur - prev) / prev) * 100 : 0;
    const say = (msg, ok) => { if (typeof showAlert === 'function') showAlert(msg, ok !== false); };
    const maskCode = c => c ? (c.length <= 4 ? '••••' : '••••' + c.slice(-4)) : '—';

    function colorOf(key) {
        let h = 0;
        for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
        return AV_COLORS[h % AV_COLORS.length];
    }
    function initialOf(name) { return (String(name || '').trim().charAt(0) || '؟'); }

    // timestamp → ms (يقبل ثوانٍ / مللي ثانية / نص تاريخ). 0 = غير معروف
    function toMs(v) {
        if (v === null || v === undefined || v === '') return 0;
        let n = Number(v);
        if (!isFinite(n) || n <= 0) n = Date.parse(v);
        if (!isFinite(n) || n <= 0) return 0;
        if (n < 1e12) n *= 1000;
        return n < 946684800000 ? 0 : n; // قبل عام 2000 = قيمة غير صالحة
    }
    // صيغة العدد العربية: [مفرد, مثنى, 3–10, 11+]
    function arNum(n, f) {
        if (n === 1) return f[0];
        if (n === 2) return f[1];
        return n + ' ' + (n >= 3 && n <= 10 ? f[2] : f[3]);
    }
    function ago(ms) {
        if (!ms) return '—';
        const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
        if (s < 60) return 'الآن';
        const m = Math.floor(s / 60); if (m < 60) return 'منذ ' + arNum(m, ['دقيقة', 'دقيقتين', 'دقائق', 'دقيقة']);
        const h = Math.floor(m / 60); if (h < 24) return 'منذ ' + arNum(h, ['ساعة', 'ساعتين', 'ساعات', 'ساعة']);
        const d = Math.floor(h / 24); if (d < 30) return 'منذ ' + arNum(d, ['يوم', 'يومين', 'أيام', 'يوماً']);
        const mo = Math.floor(d / 30); if (mo < 12) return 'منذ ' + arNum(mo, ['شهر', 'شهرين', 'أشهر', 'شهراً']);
        const y = Math.floor(d / 365); return 'منذ ' + arNum(Math.max(1, y), ['سنة', 'سنتين', 'سنوات', 'سنة']);
    }
    function safeImg(v) {
        if (typeof v !== 'string') return '';
        return (/^data:image\//i.test(v) || /^https?:\/\//i.test(v)) ? v : '';
    }

    function setStatus(kind, title, sub) {
        const b = el('aaStatus'); if (!b) return;
        if (!kind) { b.style.display = 'none'; return; }
        b.style.display = 'flex';
        b.className = 'sa-status' + (kind === 'error' ? ' error' : kind === 'warn' ? ' warn' : '');
        el('aaStatusTitle').textContent = title || '';
        el('aaStatusSub').textContent = sub || '';
    }

    /* =====================================================================
       بناء البيانات من Firebase
       ===================================================================== */
    function rebuild() {
        const raw = S.usersRaw || {};
        const users = {}, byLast9 = {}, byAcc = {}, byName = {};

        Object.keys(raw).forEach(k => {
            if (SKIP_USERS.indexOf(k) !== -1) return;
            const u = raw[k];
            if (!u || typeof u !== 'object') return;
            const name = String(u.fullName || u.name || 'بدون اسم');
            users[k] = {
                phone: k,
                name: name,
                type: TYPES[u.userType] ? u.userType : (u.isAgent === true ? 'agent' : ''),
                account: (u.accountNumber !== undefined && u.accountNumber !== null) ? String(u.accountNumber) : '',
                balance: _n(u.balance),
                online: u.isOnline === true,
                lastSeen: toMs(u.lastSeen),
                createdAt: toMs(u.createdAt),
                avatar: safeImg(u.avatar)
            };
            const dg = k.replace(/\D/g, '');
            if (dg.length >= 7 && !byLast9[dg.slice(-9)]) byLast9[dg.slice(-9)] = k;
            if (users[k].account && !byAcc[users[k].account]) byAcc[users[k].account] = k;
            const nk = name.trim().toLowerCase();
            (byName[nk] || (byName[nk] = [])).push(k);
        });

        // ربط قيمة "المشتري/المستلم" بمستخدم موجود (مفتاح مباشر ← أرقام فقط ← آخر 9 أرقام ← رقم الحساب)
        function resolve(v) {
            if (v === null || v === undefined) return null;
            const s = String(v).trim();
            if (!s) return null;
            if (users[s]) return s;
            const dg = s.replace(/\D/g, '');
            if (dg && users[dg]) return dg;
            if (dg.length >= 7 && byLast9[dg.slice(-9)]) return byLast9[dg.slice(-9)];
            if (byAcc[s]) return byAcc[s];
            return null;
        }
        function resolveBuyer(it) {
            for (let i = 0; i < BUYER_FIELDS.length; i++) {
                const p = resolve(it[BUYER_FIELDS[i]]);
                if (p) return p;
            }
            return null;
        }
        // الاسم يُربط بمستخدم فقط إذا كان فريداً (سجل الحوالات يحفظ الاسم لا الرقم)
        function byNameUnique(n) {
            const a = byName[String(n || '').trim().toLowerCase()];
            return (a && a.length === 1) ? a[0] : null;
        }

        // فهرس الكروت المباعة: كود الكرت → المستلم + الفئة + السعر
        const codeIdx = {};
        const store = S.storeRaw || {};
        Object.keys(store).forEach(catId => {
            if (catId === 'gift_cards') return;
            const cat = store[catId];
            if (!cat || typeof cat !== 'object' || !cat.sold || typeof cat.sold !== 'object') return;
            const price = _n(cat.sellPrice), catName = String(cat.name || catId);
            Object.keys(cat.sold).forEach(id => {
                const it = cat.sold[id];
                if (!it || typeof it !== 'object' || it.code === undefined || it.code === null) return;
                codeIdx[String(it.code)] = { catId: catId, catName: catName, price: price, cust: resolveBuyer(it) };
            });
        });

        const recsBy = {}, servedAll = {};
        let unk = 0, undated = 0;
        const list = [];

        Object.keys(users).forEach(k => {
            const u = users[k];
            if (!u.type) return;
            const recs = [];
            const hist = raw[k] && raw[k].history;
            if (hist && typeof hist === 'object') {
                Object.keys(hist).forEach(hid => {
                    const h = hist[hid];
                    if (!h || typeof h !== 'object') return;
                    const t = String(h.type || ''), title = String(h.title || '');
                    const ms = toMs(h.timestamp), amount = _n(h.amount);
                    let codes = [];
                    if (Array.isArray(h.codes)) codes = h.codes;
                    else if (h.codes && typeof h.codes === 'object') codes = Object.keys(h.codes).map(x => h.codes[x]);
                    else if (h.cardCode) codes = String(h.cardCode).split(/\s*,\s*/);
                    codes = codes.map(c => String(c).trim()).filter(Boolean);

                    if (t === 'out' && (codes.length || /^شراء/.test(title))) {
                        const found = codes.map(c => codeIdx[c]).filter(Boolean);
                        let target = null;
                        if (found.length) {
                            const cnt = {};
                            found.forEach(f => { if (f.cust) cnt[f.cust] = (cnt[f.cust] || 0) + 1; });
                            Object.keys(cnt).forEach(c => { if (!target || cnt[c] > cnt[target]) target = c; });
                        }
                        const m = title.match(/شراء\s+(\d+)\s+كرت/);
                        const cards = codes.length || (m ? +m[1] : 1);
                        const tm = title.match(/من\s+(?:باقة\s+)?(.+?)(?:\s*\(SMS\))?\s*$/);
                        const catName = found.length ? found[0].catName : (tm ? tm[1] : 'غير محدد');
                        const catId = found.length ? found[0].catId : ('n:' + catName);
                        const kind = !target ? 'unk' : (target === k ? 'self' : 'sale');
                        recs.push({ kind: kind, ms: ms, amount: amount, cards: cards, catId: catId, catName: catName, user: target, userName: target ? users[target].name : '', codes: codes });
                    } else if (t === 'out' && /^تحويل/.test(title)) {
                        const nm = title.replace(/^تحويل(\s+إداري)?\s+إلى\s*/, '').trim();
                        recs.push({ kind: 'tout', ms: ms, amount: amount, cards: 0, user: byNameUnique(nm), userName: nm, codes: [] });
                    } else if (t === 'in' && /تحويل/.test(title)) {
                        const nm = title.replace(/^(استلام\s+)?تحويل(\s+إداري)?\s+من\s*/, '').trim();
                        recs.push({ kind: 'tin', ms: ms, amount: amount, cards: 0, user: byNameUnique(nm), userName: nm, codes: [] });
                    } else if (t === 'in' && /إيداع|ايداع|شحن/.test(title)) {
                        recs.push({ kind: 'dep', ms: ms, amount: amount, cards: 0, user: null, userName: 'الإدارة', codes: [] });
                    }
                });
            }
            recsBy[k] = recs;

            let amount = 0, cards = 0, toutAmt = 0, toutN = 0, lastMs = 0, sales = 0;
            const served = {};
            recs.forEach(r => {
                if (r.kind === 'sale') {
                    amount += r.amount; cards += r.cards; sales++;
                    served[r.user] = 1; servedAll[r.user] = 1;
                    if (r.ms > lastMs) lastMs = r.ms;
                    if (!r.ms) undated++;
                } else if (r.kind === 'tout') {
                    toutAmt += r.amount; toutN++;
                    const key = r.user || ('n:' + r.userName);
                    served[key] = 1; servedAll[key] = 1;
                    if (r.ms > lastMs) lastMs = r.ms;
                    if (!r.ms) undated++;
                } else if (r.kind === 'unk') unk++;
            });
            list.push(Object.assign({}, u, {
                amount: amount, cards: cards, sales: sales, toutAmt: toutAmt, toutN: toutN,
                served: Object.keys(served).length, lastMs: lastMs, rank: 0, vip: false
            }));
        });

        list.sort((a, b) => b.amount - a.amount || b.cards - a.cards || b.toutAmt - a.toutAmt || a.name.localeCompare(b.name, 'ar'));
        const sellers = list.filter(u => u.amount > 0);
        const vipCut = sellers.length ? Math.max(1, Math.ceil(sellers.length * VIP_TOP_PCT)) : 0;
        sellers.forEach((u, i) => { u.rank = i + 1; u.vip = i < vipCut; });

        const byId = {};
        list.forEach(u => { byId[u.phone] = u; });

        S.list = list; S.byId = byId; S.allUsers = users; S.recsBy = recsBy;
        S.unk = unk; S.undated = undated;
        S.totals = {
            amount: sum(list.map(u => u.amount)),
            cards: sum(list.map(u => u.cards)),
            tout: sum(list.map(u => u.toutAmt)),
            agents: list.length, sellers: sellers.length,
            served: Object.keys(servedAll).length
        };
    }

    // العمليات = تجميع كروت نفس الفئة المتقاربة زمنياً (طلب شراء واحد)
    function typeBadge(u) {
        const m = TYPES[u.type];
        if (!m) return '';
        return '<span class="ua-badge" style="color:' + m.color + ';background:' + m.color + '1f;border-color:' + m.color + '55"><i class="fas ' + m.icon + '"></i> ' + m.label + '</span>';
    }

    function isActive(u) { return !!u.lastMs && (Date.now() - u.lastMs) <= ACTIVE_DAYS * DAY; }
    function tierOf(u) { return u.vip ? 'vip' : isActive(u) ? 'act' : 'off'; }
    function badgeHTML(u) {
        const t = tierOf(u);
        if (t === 'vip') return '<span class="ua-badge vip"><i class="fas fa-crown"></i> VIP</span>';
        if (t === 'act') return '<span class="ua-badge act">● نشط</span>';
        return '<span class="ua-badge off">○ غير نشط</span>';
    }

    /* =====================================================================
       Firebase (اشتراك لحظي)
       ===================================================================== */
    function scheduleRebuild() {
        clearTimeout(S.rebuildTimer);
        S.rebuildTimer = setTimeout(function () {
            if (!S.opened || !S.gotUsers || !S.gotStore) return;
            rebuild();
            S.lastUpdate = new Date();
            renderAll();
        }, 60);
    }

    function onFail(what, err) {
        console.error('[AgentsAnalysis] ' + what + ' error:', err);
        setStatus('error', 'تعذّر قراءة ' + what, (err && err.message) || 'تحقق من صلاحيات قاعدة البيانات');
        const box = el('aaList');
        if (box && !S.list.length) box.innerHTML = '<div class="sa-none">تعذّر جلب البيانات</div>';
    }

    async function attach() {
        detach();
        const myId = ++S.attachId;
        if (typeof database === 'undefined') {
            setStatus('error', 'تعذّر الاتصال بقاعدة البيانات', 'أعد تحميل الصفحة');
            return;
        }
        try { if (typeof waitForFirebaseAuth === 'function') await waitForFirebaseAuth(); } catch (e) { }
        if (!S.opened || !S.live || myId !== S.attachId) return;

        S.usersRef = database.ref('users');
        S.usersFn = function (snap) { S.usersRaw = snap.val() || {}; S.gotUsers = true; scheduleRebuild(); };
        S.usersRef.on('value', S.usersFn, function (err) { onFail('بيانات الوكلاء', err); });

        S.storeRef = database.ref('kova_store');
        S.storeFn = function (snap) { S.storeRaw = snap.val() || {}; S.gotStore = true; scheduleRebuild(); };
        S.storeRef.on('value', S.storeFn, function (err) { onFail('الكروت المباعة', err); });
    }

    function detach() {
        S.attachId++;
        try { if (S.usersRef && S.usersFn) S.usersRef.off('value', S.usersFn); } catch (e) { }
        try { if (S.storeRef && S.storeFn) S.storeRef.off('value', S.storeFn); } catch (e) { }
        S.usersRef = S.usersFn = S.storeRef = S.storeFn = null;
        clearTimeout(S.rebuildTimer);
    }

    /* =====================================================================
       العرض 1 — القائمة
       ===================================================================== */
    function renderAll() {
        if (!S.opened) return;
        const ts = el('aaLastUpdate'); if (ts) ts.textContent = S.lastUpdate ? fmtFull(S.lastUpdate) : '—';
        renderStatus();
        if (S.view === 'detail') {
            if (!S.byId[S.selected]) { showList(); return; } // المستخدم حُذف
            renderDetail(false);
        } else {
            renderSummary();
            renderList();
        }
    }

    function renderStatus() {
        if (S.view === 'detail') { setStatus(null); return; }
        const notes = [];
        if (S.unk > 0) notes.push(fmt(S.unk) + ' عملية شراء لا يمكن ربطها بمستخدم مستلم (كروتها غير موجودة في سجل المبيعات) ولم تُحتسب');
        if (S.undated > 0) notes.push(fmt(S.undated) + ' عملية بدون تاريخ (تُحتسب في الإجمالي ولا تظهر في الرسم)');
        if (!S.list.length) setStatus('warn', 'لا يوجد وكلاء بعد', 'عيّن نوع المستخدم (وكيل / نقطة بيع / موزع) من إدارة المستخدمين لتظهر التحليلات');
        else if (notes.length) setStatus('warn', 'ملاحظات على البيانات', notes.join(' · '));
        else setStatus(null);
    }

    function renderSummary() {
        const t = S.totals;
        const active = S.list.filter(isActive).length;
        el('aaLTotal').innerHTML = fmt(t.amount) + '<small>ريال</small>';
        el('aaLCardsPill').textContent = fmt(t.cards) + ' كرت مباع';
        el('aaLServedPill').textContent = fmt(t.served) + ' مستخدم مخدوم';
        el('aaLTransPill').textContent = 'حوالات ' + shortMoney(t.tout);
        el('aaLCards').textContent = fmt(t.cards);
        el('aaLActive').textContent = fmt(active);
        el('aaLAgents').textContent = fmt(t.agents);
    }

    function sortedFiltered() {
        const q = S.search.trim().toLowerCase();
        const qd = q.replace(/\D/g, '');
        let arr = S.list;
        if (S.typeFilter) arr = arr.filter(u => u.type === S.typeFilter);
        if (q) {
            arr = arr.filter(u =>
                u.name.toLowerCase().indexOf(q) !== -1 ||
                u.phone.toLowerCase().indexOf(q) !== -1 ||
                (u.account && u.account.toLowerCase().indexOf(q) !== -1) ||
                (TYPES[u.type] && TYPES[u.type].label.indexOf(q) !== -1) ||
                (qd.length >= 3 && u.phone.replace(/\D/g, '').indexOf(qd) !== -1));
        }
        arr = arr.slice(); // S.list مرتّبة أصلاً: الأعلى مبيعاً
        if (S.sort === 'total-asc') arr.reverse();
        else if (S.sort === 'recent') arr.sort((a, b) => b.lastMs - a.lastMs || b.amount - a.amount);
        return arr;
    }

    function rowHTML(u, maxAmt) {
        const rank = (u.rank > 0 && u.rank <= 3)
            ? '<span class="ua-rank m' + u.rank + '" title="المرتبة ' + u.rank + '"><i class="fas fa-medal"></i></span>'
            : '<span class="ua-rank">' + (u.rank > 0 ? u.rank : '—') + '</span>';
        const pct = maxAmt > 0 && u.amount > 0 ? Math.max(3, (u.amount / maxAmt) * 100) : 0;
        const last = u.lastMs ? 'آخر نشاط ' + ago(u.lastMs) : 'لا نشاط بعد';
        return '<div class="ua-row" role="button" tabindex="0" data-phone="' + _esc(u.phone) + '">' +
            rank +
            '<div class="ua-av" style="background:' + colorOf(u.phone) + '">' + _esc(initialOf(u.name)) + (u.online ? '<span class="ua-dot" title="متصل الآن"></span>' : '') + '</div>' +
            '<div class="ua-main">' +
            '<div class="ua-line"><span class="ua-name">' + _esc(u.name) + '</span>' + typeBadge(u) + badgeHTML(u) + '</div>' +
            '<div class="ua-sub"><span><i class="fas fa-phone"></i><bdi dir="ltr">' + _esc(u.phone) + '</bdi></span>' +
            (u.account ? '<span><i class="fas fa-hashtag"></i>' + _esc(u.account) + '</span>' : '') + '</div>' +
            '<div class="ua-sub"><b>' + fmt(u.cards) + ' كرت</b><span>· ' + fmt(u.served) + ' مستخدم</span>' +
            (u.toutN ? '<span>· حوّل ' + shortMoney(u.toutAmt) + '</span>' : '') + '</div>' +
            '<div class="ua-sub"><span>' + last + '</span></div>' +
            '<div class="ua-bar"><i style="width:' + pct.toFixed(1) + '%"></i></div>' +
            '</div>' +
            '<div class="ua-side"><div class="ua-amt">' + fmt(u.amount) + '</div><small>ريال</small><i class="fas fa-chevron-left"></i></div>' +
            '</div>';
    }

    function renderList() {
        const box = el('aaList');
        if (!S.gotUsers || !S.gotStore) return;
        const arr = sortedFiltered();
        const maxAmt = S.list.length ? S.list[0].amount : 0; // شريط التقدم = نسبة من الأعلى دائماً
        const shown = arr.slice(0, S.visible);

        el('aaCount').textContent = arr.length === S.list.length
            ? fmt(arr.length) + ' وكيل'
            : fmt(arr.length) + ' من ' + fmt(S.list.length);

        if (!arr.length) {
            box.innerHTML = '<div class="sa-none">' + (S.search || S.typeFilter ? 'لا توجد نتائج مطابقة' : 'لا يوجد وكلاء') + '</div>';
        } else {
            box.innerHTML = shown.map(u => rowHTML(u, maxAmt)).join('');
        }
        const more = el('aaMore');
        if (arr.length > shown.length) {
            more.style.display = '';
            more.textContent = 'عرض المزيد (' + fmt(arr.length - shown.length) + ' متبقٍّ)';
        } else more.style.display = 'none';
    }

    function renderLoading() {
        el('aaLTotal').innerHTML = '0<small>ريال</small>';
        ['aaLCardsPill', 'aaLServedPill', 'aaLTransPill'].forEach(i => { el(i).textContent = '—'; });
        ['aaLCards', 'aaLActive', 'aaLAgents'].forEach(i => { el(i).textContent = '—'; });
        el('aaCount').textContent = '—';
        el('aaMore').style.display = 'none';
        el('aaList').innerHTML = '<div class="sa-empty"><i class="fas fa-circle-notch fa-spin"></i><b>جاري جلب البيانات…</b><span>يتم الآن قراءة الوكلاء وحركاتهم والكروت المباعة من قاعدة البيانات</span></div>';
    }

    /* =====================================================================
       التنقل بين العرضين
       ===================================================================== */
    function toTop() {
        try { window.scrollTo(0, 0); } catch (e) { }
        const root = el('agentsAnalysisInterface'); if (root) root.scrollTop = 0;
    }
    function showList() {
        hideTip();
        S.view = 'list'; S.selected = null; S.dataset = null;
        el('aaListView').classList.add('on');
        el('aaDetailView').classList.remove('on');
        renderAll();
        toTop();
    }
    function openDetail(phone) {
        if (!S.byId[phone]) return;
        S.view = 'detail'; S.selected = phone;
        S.period = 'month'; S.metric = 'sales'; S.zoom = 1; S.resetScroll = true;
        qa('#aaMetric button').forEach(b => b.classList.toggle('active', b.getAttribute('data-metric') === S.metric));
        qa('#aaPeriods .sa-chip').forEach(c => c.classList.toggle('active', c.getAttribute('data-period') === S.period));
        el('aaListView').classList.remove('on');
        el('aaDetailView').classList.add('on');
        renderDetail(true);
        toTop();
    }

    /* =====================================================================
       العرض 2 — تفاصيل المستخدم
       ===================================================================== */
    // ---------- حدود الفترات (Edges) ----------
    function buildEdges(mode, start, count) {
        const y = start.getFullYear(), m = start.getMonth(), d = start.getDate(), e = [];
        for (let i = 0; i <= count; i++) {
            if (mode === 'hour') e.push(new Date(y, m, d, i).getTime());
            else if (mode === 'day') e.push(new Date(y, m, d + i).getTime());
            else if (mode === 'week') e.push(new Date(y, m, d + 7 * i).getTime());
            else if (mode === 'month') e.push(new Date(y, m + i, 1).getTime());
            else e.push(new Date(y + i, 0, 1).getTime());
        }
        return e;
    }
    function labelsFor(mode, edges) {
        const labels = [], full = [];
        for (let i = 0; i < edges.length - 1; i++) {
            const a = new Date(edges[i]);
            if (mode === 'hour') { labels.push(pad(a.getHours()) + ':00'); full.push(fmtDay(a) + ' ' + pad(a.getHours()) + ':00'); }
            else if (mode === 'day') { labels.push(pad(a.getDate()) + ' ' + MONTHS[a.getMonth()].slice(0, 3)); full.push(fmtDay(a)); }
            else if (mode === 'week') {
                const b = new Date(edges[i + 1] - 1);
                labels.push(pad(a.getDate()) + ' ' + MONTHS[a.getMonth()].slice(0, 3));
                full.push('أسبوع ' + a.getDate() + ' ' + MONTHS[a.getMonth()] + ' — ' + b.getDate() + ' ' + MONTHS[b.getMonth()] + ' ' + b.getFullYear());
            }
            else if (mode === 'month') { labels.push(MONTHS[a.getMonth()].slice(0, 4) + ' ' + String(a.getFullYear()).slice(2)); full.push(MONTHS[a.getMonth()] + ' ' + a.getFullYear()); }
            else { labels.push(String(a.getFullYear())); full.push(String(a.getFullYear())); }
        }
        return { labels: labels, full: full };
    }
    function binIndex(edges, t) {
        const n = edges.length - 1;
        if (t < edges[0] || t >= edges[n]) return -1;
        let lo = 0, hi = n - 1;
        while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (edges[mid] <= t) lo = mid; else hi = mid - 1; }
        return lo;
    }
    function aggregate(recs, edges, metric) {
        const n = edges.length - 1;
        const amt = new Array(n).fill(0), cnt = new Array(n).fill(0), ops = new Array(n).fill(0);
        const want = metric === 'sales' ? 'sale' : 'tout';
        recs.forEach(r => {
            if (!r.ms || r.kind !== want) return;
            const i = binIndex(edges, r.ms);
            if (i >= 0) { amt[i] += r.amount; cnt[i] += (want === 'sale' ? r.cards : 1); ops[i]++; }
        });
        return { amt: amt, cards: cnt, ops: ops };
    }

    function periodSpec(period, recs) {
        const now = new Date(), today = midnight(now);
        const Y = today.getFullYear(), M = today.getMonth(), D = today.getDate();
        let mode, start, count, pstart = null, endDate = today, firstDay = null;
        if (period === 'day') { mode = 'hour'; start = today; count = now.getHours() + 1; pstart = new Date(Y, M, D - 1); }
        else if (period === 'week') { mode = 'day'; start = new Date(Y, M, D - 6); count = 7; pstart = new Date(Y, M, D - 13); }
        else if (period === 'month') { mode = 'day'; start = new Date(Y, M, D - 29); count = 30; pstart = new Date(Y, M, D - 59); }
        else if (period === '3months') { mode = 'week'; start = new Date(Y, M, D - 90); count = 13; pstart = new Date(Y, M, D - 181); }
        else if (period === 'year') { mode = 'month'; start = new Date(Y, M - 11, 1); count = 12; pstart = new Date(Y, M - 23, 1); }
        else {
            let first = 0, last = 0;
            recs.forEach(r => { if (!r.ms) return; if (!first || r.ms < first) first = r.ms; if (r.ms > last) last = r.ms; });
            if (!first) return { edges: null, mode: 'day' };
            const fd = midnight(new Date(first)), ld = midnight(new Date(Math.max(last, now.getTime())));
            endDate = ld; firstDay = fd;
            const span = Math.round((ld - fd) / DAY) + 1;
            if (span <= 62) { mode = 'day'; start = fd; count = span; }
            else {
                const months = (ld.getFullYear() - fd.getFullYear()) * 12 + (ld.getMonth() - fd.getMonth()) + 1;
                if (months <= 36) { mode = 'month'; start = new Date(fd.getFullYear(), fd.getMonth(), 1); count = months; }
                else { mode = 'year'; start = new Date(fd.getFullYear(), 0, 1); count = ld.getFullYear() - fd.getFullYear() + 1; }
            }
        }
        const spec = { mode: mode, edges: buildEdges(mode, start, count), pedges: pstart ? buildEdges(mode, pstart, count) : null };
        if (period === 'all') start = firstDay;
        spec.periodLabel = mode === 'hour' ? 'اليوم — ' + fmtShort(start) : fmtShort(start) + ' — ' + fmtShort(endDate);
        return spec;
    }

    function buildDataset(phone, period) {
        const recs = S.recsBy[phone] || [];
        const spec = periodSpec(period, recs);
        const inRecs = [];
        if (period === 'all') recs.forEach(r => inRecs.push(r));
        else if (spec.edges) {
            const t0 = spec.edges[0], t1 = spec.edges[spec.edges.length - 1];
            recs.forEach(r => { if (r.ms >= t0 && r.ms < t1) inRecs.push(r); });
        }
        const g = k => inRecs.filter(r => r.kind === k);
        const sales = g('sale'), touts = g('tout'), tins = g('tin'), deps = g('dep'), selfs = g('self');
        const served = {};
        sales.forEach(r => { served[r.user] = 1; });
        touts.forEach(r => { served[r.user || ('n:' + r.userName)] = 1; });
        const amt = a => sum(a.map(r => r.amount));
        const isSales = S.metric === 'sales';

        const d = {
            period: period, metric: S.metric, mode: spec.mode, labels: [], full: [], values: [], cardsArr: [], opsArr: [],
            prev: [], prevTotal: 0, hasPrev: !!(spec.pedges),
            periodLabel: spec.periodLabel || PERIOD_LONG[period], inRecs: inRecs,
            undated: period === 'all' ? recs.filter(r => !r.ms && (r.kind === 'sale' || r.kind === 'tout')).length : 0,
            sales: { amount: amt(sales), cards: sum(sales.map(r => r.cards)), ops: sales.length },
            tout: { amount: amt(touts), count: touts.length },
            tin: { amount: amt(tins), count: tins.length },
            dep: { amount: amt(deps), count: deps.length },
            self: { amount: amt(selfs), cards: sum(selfs.map(r => r.cards)) },
            served: Object.keys(served).length
        };
        d.total = isSales ? d.sales.amount : d.tout.amount;
        d.cards = isSales ? d.sales.cards : d.tout.count;
        d.ops = isSales ? d.sales.ops : d.tout.count;
        if (!spec.edges) return d;

        const lab = labelsFor(spec.mode, spec.edges), cur = aggregate(recs, spec.edges, S.metric);
        d.labels = lab.labels; d.full = lab.full; d.values = cur.amt; d.cardsArr = cur.cards; d.opsArr = cur.ops;
        d.prev = spec.pedges ? aggregate(recs, spec.pedges, S.metric).amt : new Array(d.values.length).fill(0);
        d.prevTotal = sum(d.prev);
        return d;
    }

    function renderDetail(animate) {
        const u = S.byId[S.selected]; if (!u) return;
        renderIdentity(u);
        S.dataset = buildDataset(u.phone, S.period);
        renderKPIs();
        renderChart(!!animate);
        if (S.resetScroll) { const sc = el('aaScroll'); if (sc) sc.scrollLeft = sc.scrollWidth; S.resetScroll = false; }
        renderCategories();
        renderTopUsers(u);
        renderInsights(u);
        renderTx(u);
        const lv = el('aaDetailLive');
        lv.classList.toggle('off', !S.live);
        lv.textContent = S.live ? 'تحليل مباشر' : 'المتابعة متوقفة';
    }

    function renderIdentity(u) {
        const av = el('aaIdAv');
        av.innerHTML = '';
        if (u.avatar) {
            const img = document.createElement('img');
            img.alt = '';
            img.onerror = function () { av.innerHTML = fallbackAv(u); };
            img.src = u.avatar;
            av.appendChild(img);
            if (u.online) av.insertAdjacentHTML('beforeend', '<span class="ua-dot"></span>');
        } else av.innerHTML = fallbackAv(u);
        el('aaIdName').textContent = u.name;
        el('aaIdBadge').innerHTML = typeBadge(u) + badgeHTML(u);
        const st = el('aaIdStatus');
        if (u.online) { st.textContent = '● متصل الآن'; st.className = 'ua-id-status on'; }
        else { st.textContent = u.lastSeen ? 'آخر ظهور: ' + ago(u.lastSeen) : 'آخر ظهور: غير مسجّل'; st.className = 'ua-id-status'; }
        el('aaIdPhone').textContent = u.phone;
        el('aaIdAcc').textContent = u.account || '—';
        el('aaIdBal').textContent = fmt(u.balance) + ' ريال';
        el('aaIdJoin').textContent = u.createdAt ? fmtDay(new Date(u.createdAt)) : '—';
    }
    function fallbackAv(u) {
        return '<div class="ua-av" style="background:' + colorOf(u.phone) + '">' + _esc(initialOf(u.name)) + '</div>' + (u.online ? '<span class="ua-dot"></span>' : '');
    }

    function renderSpark() {
        const d = S.dataset, svg = el('aaSpark');
        if (!d || !d.values.length || !d.total) { svg.innerHTML = ''; return; }
        const W = 400, H = 70, P = 4, v = d.values;
        const mn = Math.min.apply(null, v), mx = Math.max.apply(null, v), span = (mx - mn) || 1;
        const pts = v.map((x, i) => ({ x: P + (i / ((v.length - 1) || 1)) * (W - P * 2), y: H - P - ((x - mn) / span) * (H - P * 2) }));
        const line = smoothPath(pts);
        svg.innerHTML = '<defs><linearGradient id="aaHeroA" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff" stop-opacity=".5"/><stop offset="100%" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>' +
            '<path d="' + line + ' L ' + pts[pts.length - 1].x + ' ' + H + ' L ' + pts[0].x + ' ' + H + ' Z" fill="url(#aaHeroA)"/>' +
            '<path d="' + line + '" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2" stroke-linecap="round"/>';
    }

    function renderKPIs() {
        const d = S.dataset; if (!d) return;
        const isSales = d.metric === 'sales';
        const g = growthOf(d.total, d.prevTotal);
        const noPrev = !d.hasPrev || d.prevTotal === 0;
        el('aaHeroLbl').innerHTML = isSales
            ? '<i class="fas fa-coins"></i> قيمة الكروت المباعة للمستخدمين'
            : '<i class="fas fa-paper-plane"></i> إجمالي الحوالات للمستخدمين';
        el('aaTotal').innerHTML = fmt(d.total) + '<small>ريال</small>';
        el('aaTotalSub').textContent = d.periodLabel;

        const pill = el('aaGrowthPill');
        if (noPrev) {
            pill.textContent = d.hasPrev ? 'لا توجد بيانات سابقة' : 'كل الفترات';
            pill.className = 'sa-pill';
            pill.style.background = 'rgba(148,163,184,.18)';
            pill.style.borderColor = 'rgba(148,163,184,.3)';
            pill.style.color = '#94a3b8';
        } else {
            pill.textContent = (g >= 0 ? '▲ +' : '▼ ') + g.toFixed(1) + '% عن السابق';
            pill.className = 'sa-pill ' + (g >= 0 ? 'up' : 'down');
            pill.style.background = pill.style.borderColor = pill.style.color = '';
        }
        el('aaCards').textContent = fmt(d.sales.cards);
        el('aaOps').textContent = fmt(d.sales.ops);
        el('aaServed').textContent = fmt(d.served);
        el('aaTout').textContent = fmt(d.tout.amount);
        el('aaToutLbl').textContent = 'حوالات صادرة · ' + fmt(d.tout.count);
        el('aaTin').textContent = fmt(d.tin.amount);
        el('aaTinLbl').textContent = 'حوالات واردة · ' + fmt(d.tin.count);
        el('aaDep').textContent = fmt(d.dep.amount);
        el('aaDepLbl').textContent = 'إيداعات الإدارة · ' + fmt(d.dep.count);

        el('aaChartTitle').textContent = (isSales ? 'اتجاه مبيعات الكروت — ' : 'اتجاه الحوالات الصادرة — ') + modeAr(d.mode);
        let sub = d.periodLabel;
        if (d.undated > 0) sub += ' (' + fmt(d.undated) + ' عملية بدون تاريخ غير ظاهرة بالرسم)';
        el('aaChartPeriod').textContent = sub;
        el('aaChartLive').style.display = S.live ? '' : 'none';
        const lg = qa('.sa-lg[data-legend="prev"]')[0];
        if (lg) lg.classList.toggle('disabled', !d.hasPrev);
        renderSpark();
    }

    /* ----- التلميح ----- */
    function hideTip() {
        clearTimeout(ttTimer);
        const t = el('aaTooltip'); if (!t) return;
        t.classList.remove('visible'); t.setAttribute('aria-hidden', 'true');
        const bar = el('aaTtFill'); if (bar) bar.classList.remove('run');
        S.ttKey = null;
        qa('.sa-pt.active').forEach(o => o.classList.remove('active'));
    }

    function showTip(node) {
        const tip = el('aaTooltip'), card = el('aaChartCard'), d = S.dataset;
        if (!tip || !card || !d) return;
        const val = parseFloat(node.getAttribute('data-val'));
        const label = node.getAttribute('data-label');
        const type = node.getAttribute('data-type');
        const idx = parseInt(node.getAttribute('data-idx'), 10);

        el('aaTtHead').innerHTML = (type === 'prev' ? '🔴 ' : '🟢 ') + _esc(label);
        el('aaTtHead').style.color = type === 'prev' ? '#f87171' : '#34d399';
        el('aaTtVal').innerHTML = fmt(val) + '<small>ريال</small>';

        const box = el('aaTtDelta'), grey = 'background:rgba(148,163,184,.16);color:#94a3b8';
        if (type !== 'prev' && d.prev[idx] !== undefined && d.hasPrev) {
            const p = d.prev[idx], diff = p > 0 ? ((val - p) / p) * 100 : 0, up = diff >= 0;
            box.innerHTML = (p === 0
                ? '<span class="sa-tt-delta" style="' + grey + '">لا توجد بيانات سابقة</span>'
                : '<span class="sa-tt-delta ' + (up ? 'up' : 'dn') + '">' + (up ? '▲' : '▼') + ' ' + Math.abs(diff).toFixed(1) + '% <small>مقارنة بالفترة السابقة</small></span>');
        } else if (type === 'prev') {
            box.innerHTML = '<span class="sa-tt-delta" style="' + grey + '">الفترة السابقة</span>';
        } else box.innerHTML = '';
        if (type !== 'prev' && d.cardsArr[idx] !== undefined) {
            box.insertAdjacentHTML('beforeend', '<span class="sa-tt-delta" style="' + grey + ';margin-inline-start:4px">' + (d.metric === 'sales' ? fmt(d.cardsArr[idx]) + ' كرت · ' + fmt(d.opsArr[idx]) + ' عملية' : fmt(d.opsArr[idx]) + ' حوالة') + '</span>');
        }

        tip.classList.add('visible'); tip.setAttribute('aria-hidden', 'false');
        qa('.sa-pt.active').forEach(o => o.classList.remove('active'));
        qa('[data-type="' + type + '"][data-idx="' + idx + '"]').forEach(o => o.classList.add('active'));

        const m = node.getBoundingClientRect(), c = card.getBoundingClientRect();
        let left = m.left - c.left + m.width / 2 - tip.offsetWidth / 2;
        left = Math.max(8, Math.min(left, card.clientWidth - tip.offsetWidth - 8));
        let top = m.top - c.top - tip.offsetHeight - 14;
        if (top < 8) top = m.bottom - c.top + 14;
        tip.style.left = left + 'px'; tip.style.top = top + 'px';

        const bar = el('aaTtFill');
        bar.classList.remove('run'); void bar.offsetWidth;
        bar.style.setProperty('--tt', TT_MS + 'ms'); bar.classList.add('run');
        clearTimeout(ttTimer); ttTimer = setTimeout(hideTip, TT_MS);
    }

    function bindTips() {
        qa('#aaViewport [data-label]').forEach(node => {
            node.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') showTip(node); });
            node.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') hideTip(); });
            node.addEventListener('click', e => {
                e.stopPropagation();
                const key = node.getAttribute('data-type') + '-' + node.getAttribute('data-idx');
                if (S.ttKey === key && el('aaTooltip').classList.contains('visible')) { hideTip(); return; }
                showTip(node); S.ttKey = key;
            });
        });
    }

    function smoothPath(pts) {
        if (!pts.length) return '';
        if (pts.length === 1) return 'M ' + pts[0].x + ' ' + pts[0].y;
        let d = 'M ' + pts[0].x + ' ' + pts[0].y;
        for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
            const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
            const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
            d += ' C ' + c1x.toFixed(2) + ' ' + c1y.toFixed(2) + ', ' + c2x.toFixed(2) + ' ' + c2y.toFixed(2) + ', ' + p2.x.toFixed(2) + ' ' + p2.y.toFixed(2);
        }
        return d;
    }

    /* ----- المخطط الرئيسي (مساحة / خط / أعمدة) ----- */
    function renderChart(animate) {
        const d = S.dataset, vp = el('aaViewport');
        hideTip();
        el('aaYAxis').innerHTML = '';
        if (!d || !d.values.length || (d.total === 0 && d.prevTotal === 0 && !sum(d.values))) {
            vp.style.width = '';
            vp.innerHTML = '<div class="sa-empty"><i class="fas fa-chart-line"></i><b>لا توجد بيانات في هذه الفترة</b><span>جرّب اختيار فترة أطول أو "الكل"</span></div>';
            el('aaHighlight').style.display = 'none';
            ['aaStatPeak', 'aaStatAvg', 'aaStatLow', 'aaStatVol'].forEach(i => { el(i).textContent = '—'; });
            el('aaStatPeakLbl').textContent = '—';
            el('aaStatLowLbl').textContent = '—';
            return;
        }
        const showPrev = S.showPrev && d.hasPrev;
        const n = d.labels.length;
        const W = Math.max(300, n * 40) * S.zoom;
        vp.style.width = W + 'px';

        const all = d.values.concat(showPrev ? d.prev : []);
        let maxV = Math.max.apply(null, all.concat([1])), minV = Math.min.apply(null, all.concat([0]));
        const span = (maxV - minV) || 1;
        maxV += span * 0.2; minV = Math.max(0, minV - span * 0.18);

        const H = 180, PT = 22, PB = 22, usable = H - PT - PB;
        const yOf = v => H - PB - ((v - minV) / (maxV - minV)) * usable;
        const xOf = i => n > 1 ? (i / (n - 1)) * (W - 44) + 22 : W / 2;

        const div = maxV >= 1e9 ? 1e9 : maxV >= 1e6 ? 1e6 : maxV >= 1e4 ? 1e3 : 1;
        el('aaChartUnit').textContent = div === 1e9 ? 'بالمليار ريال' : div === 1e6 ? 'بالمليون ريال' : div === 1e3 ? 'بالألف ريال' : 'بالريال';
        const axisText = v => { const x = v / div; return x >= 100 || div === 1 ? String(Math.round(x)) : x >= 10 ? x.toFixed(1) : x.toFixed(2); };

        const avgV = sum(d.values) / n, avgY = yOf(Math.min(avgV, maxV));
        const grid = [0.08, 0.29, 0.5, 0.71, 0.92].map(r => { const v = minV + r * (maxV - minV); return { y: yOf(v), text: axisText(v) }; });
        let near = 0, best = Infinity;
        grid.forEach((g, i) => { const dd = Math.abs(g.y - avgY); if (dd < best) { best = dd; near = i; } });
        el('aaYAxis').innerHTML = grid.map((g, i) => '<span class="' + (i === near ? 'hl' : '') + '" style="top:' + g.y.toFixed(1) + 'px">' + g.text + '</span>').join('');

        const mk = (arr, lbl) => arr.map((v, i) => ({ x: xOf(i), y: yOf(v), val: v, label: lbl[i], idx: i }));
        const prevPts = mk(d.prev, d.full), curPts = mk(d.values, d.full);
        const peakVal = Math.max.apply(null, d.values), peakIdx = d.values.indexOf(peakVal), last = n - 1;
        const lineD = smoothPath(curPts), prevD = smoothPath(prevPts);
        const areaD = lineD + ' L ' + curPts[last].x + ' ' + (H - PB) + ' L ' + curPts[0].x + ' ' + (H - PB) + ' Z';
        const attrs = (p, type, i) => 'data-val="' + p.val + '" data-label="' + _esc(p.label) + '" data-type="' + type + '" data-idx="' + i + '"';

        let svg = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" style="display:block;overflow:visible"><defs>' +
            '<linearGradient id="aaLineG" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#3b82f6"/><stop offset="50%" stop-color="#22d3ee"/><stop offset="100%" stop-color="#10b981"/></linearGradient>' +
            '<linearGradient id="aaAreaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity=".4"/><stop offset="50%" stop-color="#3b82f6" stop-opacity=".14"/><stop offset="100%" stop-color="#3b82f6" stop-opacity=".01"/></linearGradient>' +
            '<linearGradient id="aaBarG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity=".95"/><stop offset="100%" stop-color="#10b981" stop-opacity=".55"/></linearGradient>' +
            '<linearGradient id="aaBarPk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#f59e0b" stop-opacity=".5"/></linearGradient>' +
            '<filter id="aaGlow" x="-5%" y="-40%" width="110%" height="180%"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>' +
            '<filter id="aaPk" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>';

        grid.forEach((g, i) => {
            const isAvg = i === near && S.showAvg;
            svg += '<line x1="0" y1="' + g.y.toFixed(1) + '" x2="' + W + '" y2="' + g.y.toFixed(1) + '" stroke="' + (isAvg ? 'rgba(167,139,250,.28)' : 'rgba(255,255,255,.06)') + '" stroke-dasharray="3,5" stroke-width=".8"/>';
        });

        if (S.chartType === 'bars' && S.showCur) {
            const bw = Math.max(4, (W - 60) / n * 0.55);
            curPts.forEach((p, i) => {
                const pk = i === peakIdx && S.showPeak && peakVal > 0;
                svg += '<rect x="' + (p.x - bw / 2).toFixed(1) + '" y="' + p.y.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(0, H - PB - p.y).toFixed(1) + '" rx="3" fill="url(#' + (pk ? 'aaBarPk' : 'aaBarG') + ')" class="' + (animate ? 'sa-pt-in' : '') + '" style="' + (animate ? 'animation-delay:' + Math.min(i * 40, 720) + 'ms' : '') + '" ' + attrs(p, 'cur', i) + ' opacity="' + (pk ? 1 : .88) + '"/>';
            });
            svg += '<path d="' + lineD + '" fill="none" stroke="#22d3ee" stroke-width="1.2" opacity=".5"/>';
        }
        if (S.chartType === 'area' && S.showCur) svg += '<path d="' + areaD + '" fill="url(#aaAreaG)" opacity="0" class="sa-area"/>';
        if (showPrev) svg += '<path d="' + prevD + '" fill="none" stroke="#ef4444" stroke-width="1.9" stroke-dasharray="6,4" opacity=".72" stroke-linecap="round"/>';
        if (S.showCur && S.chartType !== 'bars') svg += '<path class="sa-chart-line" d="' + lineD + '" fill="none" stroke="url(#aaLineG)" stroke-width="2.9" stroke-linecap="round" stroke-linejoin="round" filter="url(#aaGlow)"/>';
        if (S.showAvg) svg += '<line x1="0" y1="' + avgY.toFixed(1) + '" x2="' + W + '" y2="' + avgY.toFixed(1) + '" stroke="#a78bfa" stroke-width="1.2" stroke-dasharray="2,4" opacity=".7"/><text x="' + (W - 4) + '" y="' + (avgY - 4).toFixed(1) + '" font-size="7.5" font-weight="900" fill="#a78bfa" text-anchor="end">AVG</text>';
        if (showPrev) {
            prevPts.forEach((p, i) => {
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="2.5" fill="#ef4444" stroke="' + SOLID + '" stroke-width="1.1" class="sa-pt" ' + attrs(p, 'prev', i) + '/>';
            });
        }
        if (S.showCur && S.chartType !== 'bars') {
            curPts.forEach((p, i) => {
                const isLast = i === last, pk = i === peakIdx && S.showPeak && peakVal > 0;
                const livePt = S.live && isLast;
                const color = pk ? '#fbbf24' : livePt ? '#10b981' : isLast ? '#22d3ee' : '#10b981';
                const r = livePt ? 7 : pk ? 6 : isLast ? 5.5 : 4;
                if (livePt) svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="14" fill="none" stroke="#10b981" stroke-width="2" class="sa-pulse" opacity=".6"/>';
                else if (isLast && !pk) svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="9" fill="none" stroke="#22d3ee" stroke-width="1.5" class="sa-pulse"/>';
                const t = isLast ? 'now' : 'cur';
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="' + r + '" fill="' + color + '" stroke="' + SOLID + '" stroke-width="1.7" class="sa-pt ' + (animate ? 'sa-pt-in' : '') + '" style="' + (animate ? 'animation-delay:' + Math.min(i * 28, 720) + 'ms' : '') + '"' + (pk ? ' filter="url(#aaPk)"' : '') + ' ' + attrs(p, t, i) + '/>';
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="14" fill="transparent" class="sa-pt" ' + attrs(p, t, i) + '/>';
            });
        }
        if (S.showPeak && S.showCur && peakVal > 0 && peakIdx !== last && S.chartType !== 'bars') {
            const pk = curPts[peakIdx], fy = Math.max(8, pk.y - 20);
            svg += '<g><circle cx="' + pk.x.toFixed(1) + '" cy="' + fy.toFixed(1) + '" r="8" fill="url(#aaBarPk)" filter="url(#aaPk)"/><text x="' + pk.x.toFixed(1) + '" y="' + (fy + 3).toFixed(1) + '" font-size="9" text-anchor="middle" fill="#1a1207" font-weight="900">★</text></g>';
        }
        svg += '</svg>';

        // تخفيف ازدحام تسميات المحور
        const stepLbl = n > 24 ? Math.ceil(n / 24) : 1;
        let axis = '<div class="sa-axis" style="width:' + W + 'px">';
        d.labels.forEach((lbl, i) => {
            const isLast = i === last, pk = i === peakIdx && S.showPeak && peakVal > 0;
            if (i % stepLbl !== 0 && !isLast && !pk) return;
            const live = S.live && isLast;
            axis += '<span class="' + (live ? 'live-now' : isLast ? 'now' : pk ? 'peak-lbl' : '') + '" style="left:' + xOf(i).toFixed(1) + 'px">' + _esc(lbl) + '</span>';
        });
        vp.innerHTML = svg + axis + '</div>';

        const area = vp.querySelector('.sa-area');
        if (animate) {
            const ln = vp.querySelector('.sa-chart-line');
            if (ln) {
                try {
                    const len = ln.getTotalLength();
                    ln.style.strokeDasharray = len; ln.style.strokeDashoffset = len; ln.getBoundingClientRect();
                    requestAnimationFrame(() => { ln.style.strokeDashoffset = 0; });
                } catch (e) { }
            }
            if (area) { area.style.transition = 'opacity .9s ease .35s'; requestAnimationFrame(() => { area.style.opacity = '1'; }); }
        } else if (area) area.style.opacity = '1';

        bindTips();
        updateHighlight();
    }

    function updateHighlight() {
        const d = S.dataset; if (!d || !d.values.length) return;
        const n = d.values.length;
        const pk = Math.max.apply(null, d.values), pi = d.values.indexOf(pk);
        const lo = Math.min.apply(null, d.values), li = d.values.indexOf(lo);
        const avg = sum(d.values) / n;
        el('aaHighlight').style.display = 'flex';
        el('aaHlTitle').textContent = 'أعلى فترة: ' + d.full[pi];
        el('aaHlSub').textContent = (avg > 0 && pk > 0) ? '+' + (((pk - avg) / avg) * 100).toFixed(0) + '% فوق المتوسط' : 'لا توجد بيانات';
        el('aaHlVal').textContent = shortMoney(pk);
        el('aaStatPeak').textContent = shortMoney(pk); el('aaStatPeakLbl').textContent = d.labels[pi];
        el('aaStatAvg').textContent = shortMoney(avg);
        el('aaStatLow').textContent = shortMoney(lo); el('aaStatLowLbl').textContent = d.labels[li];
        const variance = sum(d.values.map(v => Math.pow(v - avg, 2))) / n;
        const vol = avg > 0 ? (Math.sqrt(variance) / avg) * 100 : 0;
        const vv = el('aaStatVol');
        vv.textContent = vol.toFixed(1) + '%';
        vv.style.color = vol > 25 ? 'var(--red)' : vol > 15 ? 'var(--gold)' : 'var(--green)';
    }

    /* ----- التوزيع حسب الفئة ----- */
    function categoryStats(recs) {
        const map = {};
        recs.forEach(r => {
            if (r.kind !== 'sale') return;
            const o = map[r.catId] || (map[r.catId] = { name: r.catName, count: 0, amount: 0 });
            o.count += (r.cards || 1); o.amount += r.amount;
        });
        const cats = Object.keys(map).map(k => map[k]).sort((a, b) => b.count - a.count || b.amount - a.amount);
        cats.forEach((c, i) => { c.color = PALETTE[i % PALETTE.length]; });
        return { cats: cats, total: sum(cats.map(c => c.count)) };
    }

    function renderCategories() {
        const d = S.dataset, svgEl = el('aaDonut');
        el('aaCatHint').textContent = PERIOD_LONG[S.period];
        const st = categoryStats(d ? d.inRecs : []);
        S.dataset.cats = st;
        if (!st.total) {
            svgEl.innerHTML = '<circle cx="70" cy="70" r="52" fill="none" stroke="#1e293b" stroke-width="15"/>';
            el('aaDonutTotal').textContent = '0';
            el('aaCatList').innerHTML = '<div class="sa-none">لا توجد كروت في هذه الفترة</div>';
            return;
        }
        const R = 52, C = 2 * Math.PI * R;
        let off = 0, svg = '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="#1e293b" stroke-width="15"/>';
        st.cats.forEach(c => {
            const dash = (c.count / st.total) * C;
            svg += '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="' + c.color + '" stroke-width="15" stroke-dasharray="' + dash.toFixed(2) + ' ' + (C - dash).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 70 70)"/>';
            off += dash;
        });
        svgEl.innerHTML = svg;
        el('aaDonutTotal').textContent = fmt(st.total);
        el('aaCatList').innerHTML = st.cats.slice(0, 6).map(c =>
            '<div class="sa-cat"><i style="background:' + c.color + '"></i><span class="sa-cat-name">' + _esc(c.name) + '</span><span class="sa-cat-val" style="color:' + c.color + '">' + fmt(c.count) + ' · ' + ((c.count / st.total) * 100).toFixed(0) + '%</span></div>').join('');
    }

    /* ----- أبرز المستخدمين المخدومين ----- */
    function renderTopUsers(u) {
        const d = S.dataset, box = el('aaTopUsers');
        const map = {};
        (d ? d.inRecs : []).forEach(r => {
            if (r.kind !== 'sale' && r.kind !== 'tout') return;
            const key = r.user || ('n:' + r.userName);
            const o = map[key] || (map[key] = { phone: r.user, name: r.userName || 'غير معروف', cards: 0, sAmt: 0, tN: 0, tAmt: 0, last: 0 });
            if (r.kind === 'sale') { o.cards += r.cards; o.sAmt += r.amount; } else { o.tN++; o.tAmt += r.amount; }
            if (r.ms > o.last) o.last = r.ms;
        });
        const arr = Object.keys(map).map(k => map[k]).sort((a, b) => (b.sAmt + b.tAmt) - (a.sAmt + a.tAmt));
        el('aaTopCount').textContent = arr.length ? fmt(arr.length) + ' مستخدم' : '—';
        if (!arr.length) { box.innerHTML = '<div class="sa-none">لا يوجد مستخدمون تعامل معهم الوكيل في هذه الفترة</div>'; return; }
        box.innerHTML = arr.slice(0, 6).map((x, i) => {
            const usr = x.phone && S.allUsers[x.phone];
            const key = x.phone || x.name;
            const parts = [];
            if (x.cards) parts.push(fmt(x.cards) + ' كرت');
            if (x.tN) parts.push(arNum(x.tN, ['حوالة', 'حوالتان', 'حوالات', 'حوالة']));
            return '<div class="ua-tx">' +
                '<div class="ua-av" style="width:34px;height:34px;font-size:13px;background:' + colorOf(key) + '">' + _esc(initialOf(x.name)) + '</div>' +
                '<div class="ua-tx-info"><div class="ua-tx-name">' + (i === 0 ? '👑 ' : '') + _esc(usr ? usr.name : x.name) + '</div>' +
                '<div class="ua-tx-sub">' + parts.join(' · ') + (x.last ? ' · ' + ago(x.last) : '') + '</div></div>' +
                '<div class="ua-tx-amt">' + fmt(x.sAmt + x.tAmt) + '</div></div>';
        }).join('');
    }

    /* ----- التحليل الذكي (من سلوك الشراء الفعلي) ----- */
    function renderInsights(u) {
        const d = S.dataset, box = el('aaInsights');
        const list = [];
        const PL = PERIOD_LONG[S.period];
        const isSales = S.metric === 'sales';
        const mName = isSales ? 'مبيعاته' : 'حوالاته';

        // 1) النشاط
        if (!u.lastMs) {
            list.push(['warn', 'fa-circle-exclamation', 'لم يُسجَّل لهذا الوكيل <b>أي بيع أو حوالة</b> للمستخدمين حتى الآن.']);
        } else {
            const days = Math.floor((Date.now() - u.lastMs) / DAY);
            if (days > ACTIVE_DAYS) list.push(['bad', 'fa-user-clock', 'لم ينفّذ أي بيع أو حوالة منذ <b>' + fmt(days) + ' يوماً</b> — يُنصح بالتواصل معه ومتابعة مخزونه.']);
            else if (days <= 1) list.push(['good', 'fa-user-check', 'وكيل <b>نشط</b> — آخر نشاط <b>' + ago(u.lastMs) + '</b>.']);
            else list.push(['info', 'fa-user-check', 'آخر نشاط <b>' + ago(u.lastMs) + '</b>.']);
        }

        // 2) النمو
        if (d && d.total > 0) {
            if (d.hasPrev && d.prevTotal > 0) {
                const g = growthOf(d.total, d.prevTotal);
                if (g >= 20) list.push(['good', 'fa-rocket', mName + ' في ' + PL + ' <b>نمت بقوة +' + g.toFixed(1) + '%</b> عن الفترة السابقة.']);
                else if (g >= 5) list.push(['good', 'fa-arrow-trend-up', 'نمو <b>إيجابي</b> بنسبة +' + g.toFixed(1) + '% عن الفترة السابقة.']);
                else if (g >= 0) list.push(['info', 'fa-arrow-right', mName + ' <b>مستقرة</b> (+' + g.toFixed(1) + '% عن الفترة السابقة).']);
                else list.push(['bad', 'fa-arrow-trend-down', 'تراجع بنسبة <b>' + Math.abs(g).toFixed(1) + '%</b> عن الفترة السابقة.']);
            } else if (d.hasPrev) {
                list.push(['info', 'fa-circle-info', 'لا توجد بيانات في الفترة السابقة للمقارنة بها.']);
            }
        } else if (u.lastMs) {
            list.push(['info', 'fa-circle-info', 'لا يوجد ' + (isSales ? 'بيع كروت' : 'حوالات') + ' في ' + PL + ' — إجمالي مبيعاته الكلي <b>' + fmt(u.amount) + ' ريال</b>.']);
        }

        // 3) توزيع النشاط بين البيع والحوالات
        if (d) {
            const sa = d.sales.amount, ta = d.tout.amount;
            if (sa > 0 && ta > 0) {
                const tp = (ta / (sa + ta)) * 100;
                list.push(['info', 'fa-scale-balanced', 'يوزّع نشاطه بين <b>بيع الكروت</b> (' + (100 - tp).toFixed(0) + '%) و<b>الحوالات للمستخدمين</b> (' + tp.toFixed(0) + '%).']);
            } else if (ta > 0) {
                list.push(['info', 'fa-paper-plane', 'ينشط في <b>الحوالات</b> فقط في ' + PL + ' — لم يبع كروتاً لمستخدمين.']);
            }
        }

        // 4) الفئة الأكثر مبيعاً
        const cs = d && d.cats;
        if (cs && cs.total) {
            const top = cs.cats[0];
            list.push(['info', 'fa-heart', 'الفئة <b>الأكثر مبيعاً</b>: <b style="color:' + top.color + '">' + _esc(top.name) + '</b> — ' + fmt(top.count) + ' كرت (' + ((top.count / cs.total) * 100).toFixed(0) + '%).']);
        }

        // 5) الذروة
        if (d && d.values.length && sum(d.values) > 0) {
            const pk = Math.max.apply(null, d.values), pi = d.values.indexOf(pk);
            list.push(['info', 'fa-medal', 'أنشط فترة: <b>' + _esc(d.full[pi]) + '</b> بإجمالي <b>' + fmt(pk) + ' ريال</b>.']);
        }

        // 6) متوسطات
        if (d && d.sales.ops > 0) list.push(['info', 'fa-receipt', 'متوسط عملية البيع <b>' + fmt(d.sales.amount / d.sales.ops) + ' ريال</b> · <b>' + (d.sales.cards / d.sales.ops).toFixed(1) + '</b> كرت لكل عملية.']);
        if (d && d.tout.count > 0) list.push(['info', 'fa-money-bill-transfer', 'متوسط الحوالة للمستخدم <b>' + fmt(d.tout.amount / d.tout.count) + ' ريال</b> (' + fmt(d.tout.count) + ' حوالة).']);

        // 7) المرتبة والحصة
        if (u.amount > 0 && S.totals.amount > 0) {
            const share = (u.amount / S.totals.amount) * 100;
            list.push(['info', 'fa-ranking-star', 'المرتبة <b>' + u.rank + '</b> من ' + fmt(S.totals.sellers) + ' وكيل بائع — يمثّل <b>' + share.toFixed(1) + '%</b> من مبيعات الوكلاء.']);
        }

        // 8) مخزون لنفسه + إيداعات
        if (d && d.self.cards > 0) list.push(['info', 'fa-boxes-stacked', 'اشترى لنفسه <b>' + fmt(d.self.cards) + ' كرت</b> (' + fmt(d.self.amount) + ' ريال) كمخزون — لا تدخل في مبيعاته.']);
        if (d && d.dep.amount > 0) list.push(['good', 'fa-building-columns', 'استلم من الإدارة إيداعات بقيمة <b>' + fmt(d.dep.amount) + ' ريال</b> (' + fmt(d.dep.count) + ' إيداع).']);

        box.innerHTML = list.length
            ? list.map(i => '<div class="sa-ins ' + i[0] + '"><i class="fas ' + i[1] + '"></i><span>' + i[2] + '</span></div>').join('')
            : '<div class="sa-none">لا توجد بيانات كافية للتحليل</div>';
    }

    /* ----- آخر 10 عمليات ----- */
    function renderTx(u) {
        const all = (S.recsBy[u.phone] || []).slice().sort((a, b) => b.ms - a.ms);
        const rows = all.slice(0, 10);
        el('aaTxCount').textContent = all.length ? 'من أصل ' + fmt(all.length) + ' عملية' : '—';
        if (!rows.length) { el('aaTx').innerHTML = '<div class="sa-none">لا توجد عمليات مسجّلة لهذا الوكيل</div>'; return; }
        el('aaTx').innerHTML = rows.map(r => {
            const m = KIND_META[r.kind] || KIND_META.unk;
            let title = '', who = '';
            if (r.kind === 'sale') { title = 'بيع ' + fmt(r.cards) + ' كرت · ' + r.catName; who = 'إلى ' + (r.userName || '—'); }
            else if (r.kind === 'tout') { title = 'حوالة للمستخدم'; who = 'إلى ' + (r.userName || '—'); }
            else if (r.kind === 'tin') { title = 'حوالة واردة'; who = 'من ' + (r.userName || '—'); }
            else if (r.kind === 'dep') { title = 'إيداع من الإدارة'; who = ''; }
            else if (r.kind === 'self') { title = 'شراء لنفسه · ' + fmt(r.cards) + ' كرت · ' + r.catName; who = 'مخزون'; }
            else { title = 'شراء ' + fmt(r.cards) + ' كرت · ' + r.catName; who = 'مستلم غير معروف'; }
            const when = r.ms ? fmtFull(new Date(r.ms)) + ' · ' + ago(r.ms) : 'بدون تاريخ';
            const out = (r.kind === 'tout' || r.kind === 'self' || r.kind === 'unk');
            return '<div class="ua-tx">' +
                '<div class="ua-tx-ico" style="background:' + m.color + '22;border-color:' + m.color + '55;color:' + m.color + '"><i class="fas ' + m.icon + '"></i></div>' +
                '<div class="ua-tx-info"><div class="ua-tx-name">' + _esc(title) + '</div>' +
                '<div class="ua-tx-sub">' + (who ? _esc(who) + ' · ' : '') + when + '</div></div>' +
                '<div class="ua-tx-amt" style="color:' + (out ? '#fbbf24' : '#34d399') + '">' + m.sign + fmt(r.amount) + '</div></div>';
        }).join('');
    }

    /* ----- تصدير CSV ----- */
    function csvCell(v) {
        if (typeof v === 'number') return String(v);
        let s = String(v === null || v === undefined ? '' : v);
        if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // حماية من حقن الصيغ في Excel
        return '"' + s.replace(/"/g, '""') + '"';
    }
    function exportCsv() {
        const u = S.byId[S.selected];
        if (!u || !S.dataset) return;
        const recs = S.dataset.inRecs.slice().sort((a, b) => a.ms - b.ms);
        if (!recs.length) { say('لا توجد عمليات للتصدير في هذه الفترة', false); return; }
        const names = { sale: 'بيع كروت لمستخدم', tout: 'حوالة صادرة لمستخدم', tin: 'حوالة واردة', dep: 'إيداع من الإدارة', self: 'شراء لنفسه (مخزون)', unk: 'شراء (مستلم غير معروف)' };
        const out = [['التاريخ', 'الوقت', 'نوع العملية', 'الفئة', 'عدد الكروت', 'المبلغ (ريال)', 'الطرف الآخر', 'الوكيل', 'الجوال', 'رقم الحساب']];
        recs.forEach(r => {
            const d = r.ms ? new Date(r.ms) : null;
            out.push([d ? d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) : 'بدون تاريخ', d ? pad(d.getHours()) + ':' + pad(d.getMinutes()) : '', names[r.kind] || r.kind, r.catName || '', r.cards || 0, r.amount, r.userName || '', u.name, u.phone, u.account]);
        });
        const csv = '\uFEFF' + out.map(r => r.map(csvCell).join(',')).join('\n');
        const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
        const a = document.createElement('a');
        a.href = url;
        a.download = 'agent_' + u.phone.replace(/[^\w-]/g, '') + '_' + S.period + '.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        say('تم تصدير ' + recs.length + ' عملية', true);
    }

    /* =====================================================================
       المتابعة المباشرة
       ===================================================================== */
    function setLiveUI() {
        const on = S.live, sw = el('aaLiveToggle');
        el('aaLive').classList.toggle('off', !on);
        sw.classList.toggle('on', on);
        sw.setAttribute('aria-checked', on ? 'true' : 'false');
        el('aaLiveBadge').textContent = on ? 'LIVE' : 'MANUAL';
        el('aaLiveBadge').classList.toggle('off', !on);
    }
    function setLive(on, silent) {
        S.live = on;
        setLiveUI();
        if (on) {
            S.gotUsers = S.gotStore = false;
            attach();
            if (!silent) say('المتابعة المباشرة مُفعّلة', true);
        } else {
            detach();
            if (!silent) say('تم إيقاف المتابعة المباشرة — البيانات المعروضة ثابتة', false);
        }
        if (S.view === 'detail') renderDetail(false);
    }

    /* =====================================================================
       الربط (مرة واحدة)
       ===================================================================== */
    function bind() {
        if (S.bound) return;
        S.bound = true;

        let st = null;
        el('aaSearch').addEventListener('input', e => {
            clearTimeout(st);
            st = setTimeout(() => { S.search = e.target.value; S.visible = PAGE_SIZE; renderList(); }, 120);
        });

        qa('#aaSort button').forEach(b => b.addEventListener('click', () => {
            S.sort = b.getAttribute('data-sort'); S.visible = PAGE_SIZE;
            qa('#aaSort button').forEach(x => x.classList.toggle('active', x === b));
            renderList();
        }));

        qa('#aaType button').forEach(b => b.addEventListener('click', () => {
            S.typeFilter = b.getAttribute('data-type'); S.visible = PAGE_SIZE;
            qa('#aaType button').forEach(x => x.classList.toggle('active', x === b));
            renderList();
        }));

        qa('#aaMetric button').forEach(b => b.addEventListener('click', () => {
            S.metric = b.getAttribute('data-metric'); S.resetScroll = true;
            qa('#aaMetric button').forEach(x => x.classList.toggle('active', x === b));
            renderDetail(true);
        }));

        el('aaMore').addEventListener('click', () => { S.visible += PAGE_SIZE; renderList(); });

        const listBox = el('aaList');
        listBox.addEventListener('click', e => {
            const row = e.target.closest && e.target.closest('.ua-row');
            if (row) openDetail(row.getAttribute('data-phone'));
        });
        listBox.addEventListener('keydown', e => {
            if (e.key !== 'Enter' && e.key !== ' ') return;
            const row = e.target.closest && e.target.closest('.ua-row');
            if (row) { e.preventDefault(); openDetail(row.getAttribute('data-phone')); }
        });

        el('aaBack').addEventListener('click', showList);

        qa('#aaPeriods .sa-chip').forEach(chip => chip.addEventListener('click', () => {
            S.period = chip.getAttribute('data-period'); S.zoom = 1; S.resetScroll = true;
            qa('#aaPeriods .sa-chip').forEach(c => c.classList.toggle('active', c === chip));
            renderDetail(true);
        }));

        const sw = el('aaLiveToggle');
        sw.addEventListener('click', () => setLive(!S.live));
        sw.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setLive(!S.live); } });

        el('aaZoomIn').addEventListener('click', () => { S.zoom = Math.min(3.2, +(S.zoom + 0.3).toFixed(2)); renderChart(false); });
        el('aaZoomOut').addEventListener('click', () => { S.zoom = Math.max(0.75, +(S.zoom - 0.3).toFixed(2)); renderChart(false); });
        el('aaZoomReset').addEventListener('click', () => { S.zoom = 1; renderChart(false); });

        qa('.sa-ctype').forEach(b => b.addEventListener('click', () => {
            qa('.sa-ctype').forEach(x => x.classList.remove('active'));
            b.classList.add('active');
            S.chartType = b.getAttribute('data-chart');
            renderChart(true);
        }));

        qa('.sa-lg').forEach(item => item.addEventListener('click', () => {
            const k = item.getAttribute('data-legend');
            if (k === 'cur') S.showCur = !S.showCur;
            if (k === 'prev') S.showPrev = !S.showPrev;
            if (k === 'avg') S.showAvg = !S.showAvg;
            if (k === 'peak') S.showPeak = !S.showPeak;
            item.classList.toggle('off');
            renderChart(false);
        }));

        el('aaExport').addEventListener('click', exportCsv);
        el('aaChat').addEventListener('click', () => {
            if (!S.selected) return;
            if (typeof openChatWithUser === 'function') openChatWithUser(S.selected);
            else say('ميزة المراسلة غير متاحة حالياً', false);
        });

        document.addEventListener('click', e => {
            if (!S.opened) return;
            if (e.target.closest && (e.target.closest('#aaViewport [data-label]') || e.target.closest('#aaTooltip'))) return;
            const t = el('aaTooltip');
            if (t && t.classList.contains('visible')) hideTip();
        });
        document.addEventListener('keydown', e => { if (e.key === 'Escape' && S.opened) hideTip(); });

        let rt = null;
        window.addEventListener('resize', () => {
            clearTimeout(rt);
            rt = setTimeout(() => { if (S.opened && S.view === 'detail' && S.dataset) renderChart(false); }, 180);
        });
    }

    /* =====================================================================
       الواجهة العامة
       ===================================================================== */
    window.AgentsAnalysis = {
        open: function () {
            if (S.opened) return;
            S.opened = true;
            bind();
            S.live = true;
            S.gotUsers = S.gotStore = false;
            S.view = 'list'; S.selected = null; S.dataset = null; S.visible = PAGE_SIZE; S.search = ''; S.typeFilter = '';
            el('aaListView').classList.add('on');
            el('aaDetailView').classList.remove('on');
            setLiveUI();
            setStatus(null);
            el('aaSearch').value = '';
            qa('#aaType button').forEach(x => x.classList.toggle('active', x.getAttribute('data-type') === ''));
            renderLoading();
            attach();
            clearInterval(S.tick);
            // تحديث الأزمنة النسبية ("منذ 3 دقائق") وحدود الفترات كل دقيقة
            S.tick = setInterval(() => { if (S.opened && S.gotUsers && S.gotStore) renderAll(); }, 60000);
        },
        close: function () {
            if (!S.opened) return;
            S.opened = false;
            detach();
            clearInterval(S.tick); S.tick = null;
            hideTip();
            // تحرير الذاكرة
            S.usersRaw = S.storeRaw = null; S.gotUsers = S.gotStore = false;
            S.list = []; S.byId = {}; S.allUsers = {}; S.recsBy = {};
            S.dataset = null; S.selected = null; S.view = 'list';
        },
        // يعيد true إذا عالج الرجوع داخلياً (من التفاصيل إلى القائمة) — يستخدمه router عند زر الرجوع
        back: function () {
            if (S.opened && S.view === 'detail') { showList(); return true; }
            return false;
        }
    };
})();
