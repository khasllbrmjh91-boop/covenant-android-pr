/* ============================================================
   COVA NET — WiFi Monitor
   جامع بيانات شبكات كوفانت في الخلفية (صامت)
   ─────────────────────────────────────────────────────────
   ✅ يرفع إلى Firebase: wifi_monitoring/{phone}/{pushKey}
   ✅ لا يتعارض مع wifi-module.js
   ✅ يستخدم TuaWifiManager الموجود
   ✅ ينتظر waitForFirebaseAuth قبل كل كتابة
============================================================ */
(function() {
    'use strict';
    if (window.__WIFI_MONITOR_LOADED__) return;
    window.__WIFI_MONITOR_LOADED__ = true;

    const WM_CONFIG = {
        scanInterval: 5 * 60 * 1000,
        firstRunDelay: 30 * 1000,
        minRssi: -95,
        kovantRegex: /coav|cova|kovant|كوفا|كوفانت/i,
        retentionDays: 30,
        storageKey: 'kovant_wifi_monitor_last_run',
        debug: false
    };

    const _wm = {
        running: false, timer: null, lastRun: 0, uploading: false,
        totalScans: 0, totalNetworksUploaded: 0, lastError: null
    };

    function _wmLog() {
        if (WM_CONFIG.debug) console.log.apply(console, ['[WiFiMonitor]'].concat(Array.prototype.slice.call(arguments)));
    }

    function _wmWarn() {
        console.warn.apply(console, ['[WiFiMonitor]'].concat(Array.prototype.slice.call(arguments)));
    }

    function _wmGetPlugin() {
        return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TuaWifiManager) || null;
    }

    function _wmIsKovantSSID(ssid) {
        return !!(ssid && WM_CONFIG.kovantRegex.test(ssid));
    }

    function _wmGetLocation() {
        return new Promise(function(resolve) {
            if (!navigator.geolocation) { resolve(null); return; }
            navigator.geolocation.getCurrentPosition(
                function(pos) {
                    resolve({
                        lat: pos.coords.latitude,
                        lng: pos.coords.longitude,
                        accuracy: pos.coords.accuracy || null
                    });
                },
                function() { resolve(null); },
                { enableHighAccuracy: false, timeout: 8000, maximumAge: 5 * 60 * 1000 }
            );
        });
    }

    function _wmScanNetworks() {
        const Wifi = _wmGetPlugin();
        if (!Wifi) return Promise.resolve([]);
        return Wifi.checkPermissions().then(function(perms) {
            if (perms.location !== 'granted') return [];
            return Wifi.scan({ minRssi: WM_CONFIG.minRssi }).then(function(result) {
                return (result && result.networks) || [];
            });
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
            return [];
        });
    }

    function _wmFilterKovant(networks) {
        return networks.filter(function(n) { return _wmIsKovantSSID(n.SSID); });
    }

    function _wmPreparePayload(networks) {
        if (!window.APP || !APP.user || !APP.user.phone) return Promise.resolve(null);
        return _wmGetLocation().then(function(location) {
            const timestamp = Date.now();
            const seen = {};
            const uniqueNetworks = [];
            for (let i = 0; i < networks.length; i++) {
                const net = networks[i];
                const bssid = net.BSSID || net.bssid || '';
                const key = bssid || net.SSID;
                if (seen[key]) continue;
                seen[key] = true;
                uniqueNetworks.push({
                    ssid: net.SSID || '(مخفية)',
                    bssid: bssid || null,
                    level: (typeof net.level === 'number') ? net.level : null,
                    frequency: net.frequency || null,
                    channel: net.channel || null,
                    capabilities: net.capabilities || null,
                    isConnected: net.isConnected === true
                });
            }
            return {
                phone: APP.user.phone,
                userName: APP.user.fullName || APP.user.phone,
                accountNumber: APP.user.accountNumber || null,
                timestamp: timestamp,
                dateStr: new Date(timestamp).toLocaleString('ar-YE'),
                lat: location ? location.lat : null,
                lng: location ? location.lng : null,
                accuracy: location ? location.accuracy : null,
                deviceName: (typeof getDeviceName === 'function') ? getDeviceName() : null,
                networks: uniqueNetworks,
                networksCount: uniqueNetworks.length
            };
        });
    }

    function _wmUpload(payload) {
        if (!payload) return Promise.resolve(false);
        const authWait = (typeof waitForFirebaseAuth === 'function')
            ? waitForFirebaseAuth()
            : Promise.resolve();
        return authWait.then(function() {
            if (typeof database === 'undefined') return false;
            const ref = database.ref('wifi_monitoring/' + payload.phone).push();
            return ref.set(payload).then(function() {
                _wm.totalNetworksUploaded += payload.networksCount;
                return true;
            });
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
            _wmWarn('❌ فشل الرفع:', _wm.lastError);
            return false;
        });
    }

    function _wmRunOnce() {
        if (_wm.uploading) return Promise.resolve();
        if (!window.APP || !APP.user || !APP.user.phone) return Promise.resolve();
        if (document.hidden) return Promise.resolve();

        _wm.uploading = true;
        return _wmScanNetworks().then(function(all) {
            const kovant = _wmFilterKovant(all);
            if (kovant.length === 0) return null;
            return _wmPreparePayload(kovant);
        }).then(function(payload) {
            if (!payload) return null;
            return _wmUpload(payload);
        }).then(function() {
            _wm.totalScans++;
            _wm.lastRun = Date.now();
            try { localStorage.setItem(WM_CONFIG.storageKey, String(_wm.lastRun)); } catch (e) {}
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
        }).then(function() {
            _wm.uploading = false;
        });
    }

    function _wmCleanupOldData() {
        if (!window.APP || !APP.user || !APP.user.phone) return Promise.resolve();
        const cutoff = Date.now() - (WM_CONFIG.retentionDays * 24 * 60 * 60 * 1000);
        const authWait = (typeof waitForFirebaseAuth === 'function')
            ? waitForFirebaseAuth()
            : Promise.resolve();
        return authWait.then(function() {
            return database.ref('wifi_monitoring/' + APP.user.phone).once('value');
        }).then(function(snap) {
            const data = snap.val() || {};
            const updates = {};
            let removed = 0;
            Object.keys(data).forEach(function(key) {
                const val = data[key];
                if (val && val.timestamp && val.timestamp < cutoff) {
                    updates['wifi_monitoring/' + APP.user.phone + '/' + key] = null;
                    removed++;
                }
            });
            if (removed > 0) return database.ref().update(updates);
            return null;
        }).catch(function() {});
    }

    function _wmStartTimer() {
        if (_wm.timer) clearInterval(_wm.timer);
        _wm.timer = setInterval(_wmRunOnce, WM_CONFIG.scanInterval);
    }

    function _wmStopTimer() {
        if (_wm.timer) {
            clearInterval(_wm.timer);
            _wm.timer = null;
        }
    }

    window.WiFiMonitor = {
        start: function() {
            if (_wm.running) return;
            _wm.running = true;
            setTimeout(_wmRunOnce, WM_CONFIG.firstRunDelay);
            _wmStartTimer();
            setTimeout(_wmCleanupOldData, 2 * 60 * 1000);
        },
        stop: function() {
            _wm.running = false;
            _wmStopTimer();
        },
        runNow: _wmRunOnce,
        getStatus: function() {
            return {
                running: _wm.running,
                lastRun: _wm.lastRun,
                totalScans: _wm.totalScans,
                totalNetworksUploaded: _wm.totalNetworksUploaded,
                lastError: _wm.lastError
            };
        }
    };

    function _wmWatchUser() {
        let loggedIn = false;
        setInterval(function() {
            const hasUser = !!(window.APP && APP.user && APP.user.phone);
            if (hasUser && !loggedIn) {
                loggedIn = true;
                window.WiFiMonitor.start();
            } else if (!hasUser && loggedIn) {
                loggedIn = false;
                window.WiFiMonitor.stop();
            }
        }, 3000);

        document.addEventListener('visibilitychange', function() {
            if (!document.hidden && _wm.running) {
                const since = Date.now() - _wm.lastRun;
                if (since > WM_CONFIG.scanInterval) {
                    setTimeout(_wmRunOnce, 3000);
                }
            }
        });
    }

    function _wmBootstrap() {
        _wmWatchUser();
        _wmLog('✅ WiFi Monitor loaded');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', _wmBootstrap);
    } else {
        _wmBootstrap();
    }
})();