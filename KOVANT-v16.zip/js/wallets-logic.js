/* ============================================================
   إدارة المحافظ البنكية — مدمجة ضمن لوحة الأدمن (كوفانت)
   جميع الأسماء مسبوقة بـ Wlt/wlt لتفادي أي تعارض مع باقي النظام
============================================================ */

/* ============================================================
   WltStore — متصل الآن بقاعدة بيانات Firebase الحقيقية (Realtime DB)
   المسار: wallets/{id}  — يُقرأ منه تلقائياً في صفحة "غذي حسابي"
   لدى المستخدم (js/topup.js) عبر مستمع لحظي (on value)
============================================================ */
const WltStore = {
    data: { wallets: [] },
    _listenerAttached: false,

    load() {
        if (this._listenerAttached) return;
        this._listenerAttached = true;
        database.ref('wallets').on('value', snap => {
            const val = snap.val() || {};
            this.data.wallets = Object.keys(val).map(id => ({ id, ...val[id] }));
            wltRenderList();
            if (typeof topupRenderBankList === 'function') topupRenderBankList();
        }, err => {
            console.error('❌ فشل تحميل المحافظ من قاعدة البيانات:', err);
        });
    },

    async addWallet(w) {
        await waitForFirebaseAuth();
        const ref = database.ref('wallets').push();
        await ref.set({ ...w, createdAt: Date.now() });
        return ref.key;
    },
    async updateWallet(id, updates) {
        await waitForFirebaseAuth();
        await database.ref('wallets/' + id).update(updates);
    },
    async deleteWallet(id) {
        await waitForFirebaseAuth();
        await database.ref('wallets/' + id).remove();
    },
    getWallet(id) { return this.data.wallets.find(w => w.id === id); }
};

let wltFilter = 'all';
let wltEditingId = null;
let wltCurrentSteps = [];

function wltToast(message, type) {
    type = type || 'success';
    const colors = { success: '#3b82f6', error: '#ef4444', warn: '#f59e0b', info: '#94a3b8' };
    const toast = document.createElement('div');
    toast.textContent = message;
    Object.assign(toast.style, {
        position: 'fixed', bottom: '100px', left: '50%', transform: 'translateX(-50%)',
        background: colors[type] || colors.success, color: '#fff',
        padding: '12px 24px', borderRadius: '12px', fontSize: '13px', fontWeight: '700',
        fontFamily: 'Cairo, sans-serif', zIndex: '9999', boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
        maxWidth: '85%', textAlign: 'center', whiteSpace: 'pre-line', opacity: '0', transition: 'opacity .3s'
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.style.opacity = '1');
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 2500);
}

/* ============================================================
   التنقل الداخلي
============================================================ */
function wltGoTo(view) {
    document.querySelectorAll('#walletsManagementInterface .wlt-subpage').forEach(el => el.classList.remove('active'));
    const target = document.getElementById('wltSub-' + view);
    if (target) target.classList.add('active');

    const titles = { list: 'إدارة المحافظ البنكية', form: wltEditingId ? 'تعديل المحفظة' : 'محفظة جديدة' };
    const titleEl = document.getElementById('wltPageTitle');
    if (titleEl) titleEl.textContent = titles[view] || 'إدارة المحافظ البنكية';

    const backBtn = document.getElementById('wltBackBtn');
    if (backBtn) {
        if (view === 'form') backBtn.onclick = function () { wltCloseForm(); };
        else backBtn.onclick = function () { navigateTo('adminSystemInterface', true); };
    }

    const fab = document.getElementById('wltFab');
    if (fab) fab.style.display = (view === 'list') ? 'flex' : 'none';

    if (view === 'list') wltRenderList();

    const content = document.querySelector('#walletsManagementInterface .page-content');
    if (content) content.scrollTop = 0;
}

/* ============================================================
   عرض القائمة
============================================================ */
function wltRenderList() {
    const list = document.getElementById('wlt-list');
    if (!list) return;

    const total = WltStore.data.wallets.length;
    const active = WltStore.data.wallets.filter(w => w.active).length;
    const inactive = total - active;

    document.getElementById('wltTotal').textContent = total;
    document.getElementById('wltActiveCount').textContent = active;
    document.getElementById('wltInactiveCount').textContent = inactive;

    const search = (document.getElementById('wltSearch')?.value || '').toLowerCase().trim();
    let wallets = [...WltStore.data.wallets];

    if (wltFilter === 'active') wallets = wallets.filter(w => w.active);
    else if (wltFilter === 'inactive') wallets = wallets.filter(w => !w.active);

    if (search) {
        wallets = wallets.filter(w => (w.name || '').toLowerCase().includes(search) || (w.senderId || '').toLowerCase().includes(search));
    }

    if (wallets.length === 0) {
        list.innerHTML = `
            <div class="empty-state">
                <i class="fa-solid fa-building-columns"></i>
                <p>${WltStore.data.wallets.length === 0 ? 'لا توجد محافظ بعد' : 'لا توجد نتائج'}</p>
                ${WltStore.data.wallets.length === 0 ? `<button class="btn-primary-gold" style="width:auto;margin-top:14px;padding:10px 22px;" onclick="wltOpenForm()"><i class="fa-solid fa-plus"></i> أضف محفظتك الأولى</button>` : ''}
            </div>`;
        return;
    }

    list.innerHTML = wallets.map(w => wltRenderCard(w)).join('');
}

function wltRenderCard(w) {
    const statusClass = w.active ? 'is-active' : 'is-inactive';
    const badgeClass = w.active ? 'active' : 'inactive';
    const badgeIcon = w.active ? 'fa-circle-check' : 'fa-circle-pause';
    const badgeText = w.active ? 'مفعّلة' : 'معطّلة';
    const stepsCount = (w.steps || []).length;
    const fieldsCount = w.fields ? Object.keys(w.fields).filter(k => w.fields[k]).length : 0;

    return `
        <div class="wlt-card ${statusClass}">
            <div class="wlt-card-top">
                <div class="wlt-logo" style="background:${w.color}22;color:${w.color};">
                    ${w.logo ? `<img src="${w.logo}" alt="" onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\\'fa-solid fa-building-columns\\'></i>';">` : `<i class="fa-solid fa-building-columns"></i>`}
                </div>
                <div class="wlt-info">
                    <h3>${w.name || 'بدون اسم'}</h3>
                    <p>${w.senderId || '—'}</p>
                </div>
                <div class="wlt-status-badge ${badgeClass}"><i class="fa-solid ${badgeIcon}"></i> ${badgeText}</div>
            </div>

            <div class="wlt-card-stats">
                <div class="wlt-stat-block"><i class="fa-solid fa-list-ol"></i><span class="wlt-stat-value">${stepsCount}</span><span class="wlt-stat-label">خطوة</span></div>
                <div class="wlt-stat-block"><i class="fa-solid fa-pen-to-square"></i><span class="wlt-stat-value">${fieldsCount}</span><span class="wlt-stat-label">حقول</span></div>
                <div class="wlt-stat-block"><i class="fa-solid fa-palette"></i><span class="wlt-stat-value" style="color:${w.color};font-family:inherit;font-size:10.5px;">${w.color}</span><span class="wlt-stat-label">اللون</span></div>
            </div>

            <div class="wlt-card-actions">
                <div class="wlt-toggle-wrap">
                    <span class="wlt-toggle-label">${w.active ? 'مفعّلة' : 'معطّلة'}</span>
                    <label class="wlt-toggle"><input type="checkbox" ${w.active ? 'checked' : ''} onchange="wltToggleActive('${w.id}', this.checked)"><span class="wlt-slider"></span></label>
                </div>
                <div class="wlt-actions-btns">
                    <button class="wlt-action-btn edit" onclick="wltEditWallet('${w.id}')" title="تعديل"><i class="fa-solid fa-pen"></i></button>
                    <button class="wlt-action-btn delete" onclick="wltDeleteWallet('${w.id}')" title="حذف"><i class="fa-solid fa-trash"></i></button>
                </div>
            </div>
        </div>`;
}

function wltSetFilter(btn) {
    document.querySelectorAll('#walletsManagementInterface .wlt-filter-chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    wltFilter = btn.dataset.filter;
    wltRenderList();
}

async function wltToggleActive(id, active) {
    try {
        await WltStore.updateWallet(id, { active });
        wltToast(active ? '✅ تم تفعيل المحفظة' : '⭕ تم تعطيل المحفظة', active ? 'success' : 'warn');
    } catch (e) {
        console.error(e);
        wltToast('❌ فشل تحديث الحالة، تحقق من الاتصال', 'error');
        wltRenderList();
    }
}

async function wltDeleteWallet(id) {
    const w = WltStore.getWallet(id);
    if (!w) return;
    if (!confirm(`⚠️ هل تريد حذف محفظة "${w.name}"؟\nلا يمكن التراجع!`)) return;
    try {
        await WltStore.deleteWallet(id);
        wltToast('✅ تم حذف المحفظة', 'success');
    } catch (e) {
        console.error(e);
        wltToast('❌ فشل حذف المحفظة، تحقق من الاتصال', 'error');
    }
}

/* ============================================================
   نموذج الإضافة/التعديل
============================================================ */
function wltOpenForm() {
    wltEditingId = null;
    document.getElementById('wltSaveBtn').textContent = 'إنشاء';
    wltResetForm();
    wltGoTo('form');
}

function wltEditWallet(id) {
    const w = WltStore.getWallet(id);
    if (!w) return;
    wltEditingId = id;
    document.getElementById('wltSaveBtn').textContent = 'حفظ التعديلات';

    document.getElementById('wltSenderId').value = w.senderId || '';
    document.getElementById('wltName').value = w.name || '';
    document.getElementById('wltCardDesc').value = w.cardDesc || '';
    document.getElementById('wltFormTitle').value = w.formTitle || '';
    document.getElementById('wltBeneficiaryAccount').value = w.beneficiaryAccount || '';
    document.getElementById('wltBeneficiaryName').value = w.beneficiaryName || '';
    document.getElementById('wltLogoUrl').value = '';
    document.getElementById('wltActiveToggle').checked = w.active !== false;

    const preview = document.getElementById('wltLogoPreview');
    if (w.logo) { preview.innerHTML = `<img src="${w.logo}">`; preview.dataset.imageUrl = w.logo; }
    else preview.innerHTML = '<i class="fa-solid fa-building-columns"></i>';

    const colorInput = document.querySelector(`#walletsManagementInterface input[name="wltColor"][value="${w.color}"]`);
    if (colorInput) colorInput.checked = true;

    wltCurrentSteps = [...(w.steps || [])];
    wltRenderStepsEditor();

    if (w.fields) {
        document.getElementById('wltFieldAmountLabel').value = w.fields.amountLabel || 'المبلغ';
        document.getElementById('wltFieldRefLabel').value = w.fields.refLabel || 'رقم المرجع';
        document.getElementById('wltFieldHintText').value = w.fields.hint || '';
        document.getElementById('wltFieldSubmitLabel').value = w.fields.submitLabel || 'تأكيد';
    }

    wltGoTo('form');
}

function wltCloseForm() {
    if (!confirm('هل تريد الإلغاء؟ سيتم فقدان التعديلات غير المحفوظة')) return;
    wltEditingId = null;
    wltGoTo('list');
}

/* الشعار */
function wltHandleLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { wltToast('حجم الصورة يجب أن يكون أقل من 2MB', 'error'); return; }
    const reader = new FileReader();
    reader.onload = (e) => {
        const preview = document.getElementById('wltLogoPreview');
        preview.innerHTML = `<img src="${e.target.result}">`;
        preview.dataset.imageData = e.target.result;
        delete preview.dataset.imageUrl;
        document.getElementById('wltLogoUrl').value = '';
    };
    reader.readAsDataURL(file);
}

function wltPreviewLogoFromUrl(url) {
    const preview = document.getElementById('wltLogoPreview');
    if (!url || url.trim() === '') return;
    const img = new Image();
    img.onload = () => { preview.innerHTML = `<img src="${url}">`; preview.dataset.imageUrl = url; delete preview.dataset.imageData; };
    img.onerror = () => { preview.innerHTML = '<i class="fa-solid fa-triangle-exclamation" style="color:var(--red)"></i>'; };
    img.src = url;
}

/* الخطوات */
function wltRenderStepsEditor() {
    const container = document.getElementById('wltStepsList');
    if (!container) return;
    if (wltCurrentSteps.length === 0) {
        container.innerHTML = `<div style="color:var(--text-secondary);font-size:12px;text-align:center;padding:12px;">لا توجد خطوات — أضف خطوة جديدة</div>`;
        return;
    }
    container.innerHTML = wltCurrentSteps.map((step, i) => `
        <div class="wlt-step-item">
            <div class="wlt-step-num">${i + 1}</div>
            <input type="text" class="wlt-step-input" value="${String(step).replace(/"/g, '&quot;')}" oninput="wltUpdateStep(${i}, this.value)" placeholder="اكتب نص الخطوة...">
            <button type="button" class="wlt-step-remove" onclick="wltRemoveStep(${i})"><i class="fa-solid fa-xmark"></i></button>
        </div>`).join('');
}

function wltAddStep() {
    wltCurrentSteps.push('');
    wltRenderStepsEditor();
    setTimeout(() => {
        const inputs = document.querySelectorAll('#walletsManagementInterface .wlt-step-input');
        inputs[inputs.length - 1]?.focus();
    }, 50);
}

function wltUpdateStep(i, v) { if (wltCurrentSteps[i] !== undefined) wltCurrentSteps[i] = v; }
function wltRemoveStep(i) { wltCurrentSteps.splice(i, 1); wltRenderStepsEditor(); }

/* حفظ */
async function wltSaveWallet() {
    const senderId = document.getElementById('wltSenderId').value.trim();
    const name = document.getElementById('wltName').value.trim();
    const cardDesc = document.getElementById('wltCardDesc').value.trim();
    const formTitle = document.getElementById('wltFormTitle').value.trim();
    const beneficiaryAccount = document.getElementById('wltBeneficiaryAccount').value.trim();
    const beneficiaryName = document.getElementById('wltBeneficiaryName').value.trim();
    const preview = document.getElementById('wltLogoPreview');
    const logo = preview.dataset.imageData || preview.dataset.imageUrl || '';
    const color = document.querySelector('#walletsManagementInterface input[name="wltColor"]:checked')?.value || '#3b82f6';
    const active = document.getElementById('wltActiveToggle').checked;

    if (!senderId) { wltToast('❌ أدخل معرف المرسل', 'error'); return; }
    if (!name) { wltToast('❌ أدخل اسم المحفظة', 'error'); return; }
    if (!beneficiaryAccount) { wltToast('❌ أدخل رقم حساب المستفيد', 'error'); return; }
    if (!beneficiaryName) { wltToast('❌ أدخل اسم المستفيد', 'error'); return; }

    const fields = {
        amountLabel: document.getElementById('wltFieldAmountLabel').value.trim() || 'المبلغ',
        refLabel: document.getElementById('wltFieldRefLabel').value.trim() || 'رقم المرجع',
        hint: document.getElementById('wltFieldHintText').value.trim(),
        submitLabel: document.getElementById('wltFieldSubmitLabel').value.trim() || 'تأكيد'
    };

    const walletData = {
        senderId, name,
        cardDesc: cardDesc || 'اتبع الخطوات المطلوبة',
        formTitle: formTitle || `غذي حسابك عبر ${name}`,
        beneficiaryAccount, beneficiaryName,
        logo, color, active,
        steps: wltCurrentSteps.filter(s => s.trim()),
        fields
    };

    const saveBtn = document.getElementById('wltSaveBtn');
    const originalBtnText = saveBtn ? saveBtn.textContent : '';
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'جاري الحفظ...'; }

    try {
        if (wltEditingId) {
            await WltStore.updateWallet(wltEditingId, walletData);
            wltToast('✅ تم حفظ التعديلات', 'success');
        } else {
            await WltStore.addWallet(walletData);
            wltToast(`✅ تم إنشاء محفظة "${name}"`, 'success');
        }
        wltEditingId = null;
        wltGoTo('list');
    } catch (e) {
        console.error('❌ فشل حفظ المحفظة:', e);
        wltToast('❌ فشل الحفظ، تحقق من الاتصال بالإنترنت', 'error');
    } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = originalBtnText; }
    }
}

function wltResetForm() {
    document.getElementById('wltSenderId').value = '';
    document.getElementById('wltName').value = '';
    document.getElementById('wltCardDesc').value = 'اتبع الخطوات المطلوبة خطوة بخطوة';
    document.getElementById('wltFormTitle').value = '';
    document.getElementById('wltBeneficiaryAccount').value = '';
    document.getElementById('wltBeneficiaryName').value = '';
    document.getElementById('wltLogoUrl').value = '';
    document.getElementById('wltFieldAmountLabel').value = 'المبلغ الصافي';
    document.getElementById('wltFieldRefLabel').value = 'رقم المرجع';
    document.getElementById('wltFieldHintText').value = 'رقم المرجع موجود في بيانات العملية بتطبيق البنك';
    document.getElementById('wltFieldSubmitLabel').value = 'تأكيد';
    document.getElementById('wltActiveToggle').checked = true;

    const preview = document.getElementById('wltLogoPreview');
    preview.innerHTML = '<i class="fa-solid fa-building-columns"></i>';
    delete preview.dataset.imageData;
    delete preview.dataset.imageUrl;

    const defaultColor = document.querySelector('#walletsManagementInterface input[name="wltColor"][value="#3b82f6"]');
    if (defaultColor) defaultColor.checked = true;

    wltCurrentSteps = [
        'أودع من تطبيق البنك إلى حساب المستفيد',
        'اذهب إلى عرض البيان',
        'انسخ رقم المرجع',
        'أدخل المبلغ ورقم المرجع في كوفانت',
        'اضغط تأكيد'
    ];
    wltRenderStepsEditor();
}

/* تصدير */
function wltExportWallets() {
    if (WltStore.data.wallets.length === 0) { wltToast('لا توجد محافظ للتصدير', 'warn'); return; }
    const data = JSON.stringify(WltStore.data.wallets, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `wallets_${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
    wltToast('✅ تم تصدير المحافظ', 'success');
}

/* ============================================================
   نقطة الدخول — تُستدعى من navigateTo() في router.js
============================================================ */
function loadWalletsManagementAdmin() {
    WltStore.load();
    wltEditingId = null;
    wltGoTo('list');
}

WltStore.load();
