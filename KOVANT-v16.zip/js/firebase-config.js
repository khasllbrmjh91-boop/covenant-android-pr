// ============================================================
// GLOBAL APP STATE — يُعرّف أولاً
// ============================================================
var APP = {
    user: null,
    notifications: [],
    storeData: {},
    adminUsers: [],
    adminCurrentSection: 'system',
    selectedCategoryId: null,
    selectedCategory: null,
    hiddenBalance: false,
    soundEnabled: false,
    html5Qr: null,              // ✅ إصلاح: كانت null&& (خطأ صياغة قاتل)
    revenueChart: null,
    currentTicketId: null,
    selectedMessage: null,
    toastTimeout: null,
    longPressTimer: null,
    typingTimeout: null,
    adminOnline: false,
    viewedUserOnline: false,
    _adminUsersListener: null,
    _adminDevicesListener: null,
    _notifListenerPhone: null
};

// ============================================================
// FIREBASE CONFIG
// ============================================================
const firebaseConfig = {
    apiKey: "AIzaSyDlFl3HpaDntr7yejTqXS8y9-z48mJCv2I",
    authDomain: "kova-cash.firebaseapp.com",
    databaseURL: "https://kova-cash-default-rtdb.firebaseio.com",
    projectId: "kova-cash",
    storageBucket: "kova-cash.firebasestorage.app",
    messagingSenderId: "17301396708",
    appId: "1:17301396708:web:589afc94c232c6b2bfe0f1",
    measurementId: "G-RFTLPZEEGQ"
};

// تهيئة Firebase
firebase.initializeApp(firebaseConfig);

// ============================================================
// ✅ حراسة جاهزية Firebase Auth
// ============================================================
// قواعد أمان Firebase الحالية تشترط auth != null (وأحياناً auth.token.isAdmin)
// لكل كتابة على مسارات محمية زي kova_store. تسجيل الدخول لـ Firebase Auth
// عبر signInWithCustomToken() يحصل مرة وحدة وقت تسجيل الدخول التفاعلي، لكن
// عند إعادة تحميل الصفحة (F5 أو فتح PWA من جديد)، استعادة هذه الجلسة من
// Firebase SDK نفسه تصير بشكل غير متزامن (Async) في الخلفية — قد تستغرق
// جزء من الثانية. أي كتابة تحصل قبل اكتمالها كانت ستفشل بخطأ صلاحيات
// (permission-denied) رغم أن المستخدم "يبدو" مسجّل دخول بواجهة التطبيق —
// وهذا سبب مرجّح جداً لظهور "حدث خطأ أثناء الحفظ" بشكل متقطع لا يمكن توقعه.
// الحل: ننتظر أول إشعار من onAuthStateChanged قبل أي عملية حسّاسة.
// ============================================================
let _authReadyResolve;
const APP_AUTH_READY = new Promise(resolve => { _authReadyResolve = resolve; });
firebase.auth().onAuthStateChanged(user => {
    console.log(user ? '✅ Firebase Auth جاهزة، uid=' + user.uid : '⚠️ Firebase Auth: لا يوجد مستخدم مسجّل');
    _authReadyResolve(user);
});
// استخدم: await waitForFirebaseAuth() قبل أي database.ref(...).set/update/push
// على مسار محمي بقواعد auth != null، خصوصاً مباشرة بعد فتح الصفحة.
async function waitForFirebaseAuth(timeoutMs = 4000) {
    if (firebase.auth().currentUser) return firebase.auth().currentUser;
    const initialUser = await Promise.race([
        APP_AUTH_READY,
        new Promise(resolve => setTimeout(() => resolve(null), timeoutMs))
    ]);
    // APP_AUTH_READY قد يكون حُسم بقيمة null قبل تسجيل الدخول التفاعلي؛
    // نعيد فحص currentUser بعد signInWithCustomToken بدلاً من الاعتماد على
    // نتيجة الإقلاع القديمة.
    if (initialUser) return initialUser;
    return firebase.auth().currentUser || null;
}

// ============================================================
// ✅ Capacitor: كشف إن كنا جوه تطبيق أصلي (Android/iOS) وليس متصفح/PWA
// ============================================================
function isNativeApp() {
    return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

// تعريف database و messaging في النطاق العام
var database = firebase.database();
var messaging = null;
// firebase.messaging() تعتمد على Service Worker + Push API، وغير مضمونة
// (وأحياناً بترمي خطأ) جوه WebView الخاص بـ Capacitor، فنتجنبها هناك كلياً
// ونستخدم بدلها @capacitor-firebase/messaging (شوف registerDeviceNative).
if (!isNativeApp()) {
    try {
        messaging = firebase.messaging();
    } catch (e) {
        console.warn('⚠️ تعذّر تهيئة Firebase Messaging (Web):', e.message);
    }
}

// ============================================================
// TREASURY LOG
// ============================================================
// ✅ عند أي إضافة/تعديل لحركة الخزينة، نُبطل كاش admin-logic.js حتى
// تظهر الأرقام المحدّثة في لوحة التحكم بدون انتظار انتهاء TTL (30 ثانية).
async function updateTreasuryBalance(delta, details = {}) {
    await waitForFirebaseAuth();
    const authUser = firebase.auth().currentUser;
    if (!authUser || !APP.user || APP.user.isAdmin !== true) {
        throw new Error('جلسة Firebase للمسؤول غير جاهزة أو المستخدم ليس مسؤولاً');
    }

    const amount = Number(delta);
    if (!Number.isFinite(amount) || amount === 0) {
        throw new Error('قيمة حركة الخزينة غير صحيحة');
    }

    const timestamp = Date.now();
    const transactionKey = database.ref('treasury/transactions').push().key;
    const ledgerKey = database.ref('full_ledger').push().key;
    const movement = {
        type: details.type || 'treasury_adjustment',
        changeAmount: amount,
        amount: Math.abs(amount),
        direction: amount < 0 ? 'debit' : 'credit',
        date: new Date(timestamp).toISOString(),
        dateStr: new Date(timestamp).toLocaleString('ar-YE'),
        timestamp,
        details: details.details || '',
        customerName: details.customerName || (APP.user.fullName || APP.user.phone),
        invoiceNumber: details.invoiceNumber || null,
        performedBy: APP.user.fullName || APP.user.phone,
        performedByUid: authUser.uid,
        status: 'completed'
    };

    const balanceRef = database.ref('treasury/summary/balance');
    let committed = false;
    try {
        const balanceTx = await balanceRef.transaction(current => (Number(current) || 0) + amount);
        if (!balanceTx.committed) throw new Error('تعذر تحديث treasury/summary/balance');
        committed = true;

        const updates = {};
        updates['treasury/transactions/' + transactionKey] = movement;
        updates['full_ledger/' + ledgerKey] = {
            ...movement,
            ledgerType: 'treasury',
            treasuryTransactionId: transactionKey
        };
        updates['treasury/summary/updatedAt'] = timestamp;
        await database.ref().update(updates);

        if (window._TreasuryCache && typeof window._TreasuryCache.invalidate === 'function') {
            window._TreasuryCache.invalidate();
        }
        console.log('✅ تم تحديث الخزينة:', amount, 'الرصيد الجديد:', balanceTx.snapshot.val());
        return Number(balanceTx.snapshot.val()) || 0;
    } catch (error) {
        console.error('❌ فشل تحديث الخزينة أو ledger:', error);
        if (committed) {
            try {
                await balanceRef.transaction(current => (Number(current) || 0) - amount);
            } catch (rollbackError) {
                console.error('❌ فشل rollback لرصيد الخزينة:', rollbackError);
                throw new Error(`${error.message} — وفشل rollback أيضاً: ${rollbackError.message}`);
            }
        }
        throw error;
    }
}

async function logTreasuryTransaction(type, changeAmount, details, customerName = null, invoiceNumber = null) {
    return updateTreasuryBalance(changeAmount, {
        type,
        details,
        customerName,
        invoiceNumber
    });
}

// ============================================================
// UPDATE USER BALANCE
// ============================================================
async function updateUserBalance(phone, amount, type, title, description, extraData) {
    // ✅ إصلاح: انتظر جاهزية Firebase Auth قبل الكتابة على مسار محمي
    await waitForFirebaseAuth();
    const userRef = database.ref('users/' + phone);
    const amountNum = $n(amount);
    let finalBalance = 0;
    try {
        await userRef.child('balance').transaction(current => {
            let currentNum = $n(current);
            let newBalance;
            if (type === 'in' || type === 'deposit') {
                newBalance = currentNum + amountNum;
            } else if (type === 'out' || type === 'withdraw') {
                if (currentNum < amountNum) throw new Error('الرصيد غير كافٍ');
                newBalance = currentNum - amountNum;
            } else {
                newBalance = currentNum;
            }
            finalBalance = newBalance;
            return newBalance;
        });

        const historyRef = userRef.child('history').push();
        await historyRef.set({
            type: type,
            amount: amountNum,
            title: title || (type === 'in' ? 'إيداع' : 'سحب'),
            date: new Date().toLocaleString('ar-YE'),
            timestamp: Date.now(),
            balanceAfter: finalBalance,
            ...extraData
        });
        await userRef.child('lastTransaction').set({
            type: type,
            amount: amountNum,
            timestamp: Date.now(),
            balanceAfter: finalBalance,
            description: description || ''
        });

        if (APP.user && APP.user.phone === phone) {
            APP.user.balance = finalBalance;
        }
        return finalBalance;
    } catch (error) {
        console.error('❌ فشل تحديث الرصيد:', error);
        throw error;
    }
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================
const $id = (id) => document.getElementById(id);

const $n = (v) => {
    if (v === null || v === undefined) return 0;
    let str = String(v);
    str = str.replace(/,/g, '');
    const num = Number(str);
    return isNaN(num) ? 0 : num;
};

const $fmt = (v) => $n(v).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

const $fmtNotif = (v) => {
    let num = $n(v).toFixed(2);
    num = num.replace(/\.00$/, '');
    return num.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

// ✅ محسّن: يعالج " و ' بالإضافة إلى & < > (يمنع XSS بشكل كامل)
const esc = (s) => {
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, m => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[m] || m);
};

function showAlert(msg, isSuccess) {
    const el = document.getElementById('customAlert');
    if (!el) return;
    document.getElementById('alertTextMsg').textContent = msg;
    el.querySelector('i').className = isSuccess ? 'fa-regular fa-circle-check' : 'fa-regular fa-circle-exclamation';
    el.querySelector('i').style.color = isSuccess ? '#58b8e8' : '#ef4444';
    el.classList.add('show');
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.classList.remove('show'), 4000);
}

// ============================================================
// SEND VIA MY SERVER (إرسال إشعارات عبر الخادم)
// ============================================================
const NOTIFY_SERVER_URL = 'https://kovant-backend3.onrender.com/send';

function sendViaMyServer(phone, title, body) {
    (async () => {
        try {
            let token = null;
            const tokenSnap = await database.ref(`user_tokens/${phone}/token`).once('value');
            token = tokenSnap.val();
            if (!token) {
                const fcmSnap = await database.ref(`users/${phone}/fcmToken`).once('value');
                token = fcmSnap.val();
            }
            if (!token) {
                console.warn(`⚠️ sendViaMyServer: لا يوجد توكن إشعارات للرقم ${phone}`);
                return;
            }

            fetch(NOTIFY_SERVER_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token, title, body, phone })
            }).then(res => {
                if (!res.ok) {
                    console.error(`❌ sendViaMyServer: الخادم رد بخطأ ${res.status}`);
                } else {
                    console.log(`✅ sendViaMyServer: تم إرسال الإشعار للرقم ${phone}`);
                }
            }).catch(err => {
                console.error('❌ sendViaMyServer: فشل الاتصال:', err);
            });
        } catch (err) {
            console.error('❌ sendViaMyServer: فشل جلب التوكن:', err);
        }
    })();
}

// ============================================================
// REGISTER DEVICE (Push Notifications) — نسخة آمنة تماماً
// ============================================================
async function registerDevice(userPhone) {
    console.log('🔹 بدء تسجيل الجهاز للرقم:', userPhone);

    // ✅ جوه تطبيق Capacitor (Android/iOS) نستخدم الإشعارات الأصلية Native
    // بدل Web Push (اللي مش موثوقة على Android جوه WebView، ومش شغالة إطلاقاً على iOS)
    if (isNativeApp()) {
        return registerDeviceNative(userPhone);
    }

    // ✅ التحقق من وجود Notification API (يمنع الخطأ ReferenceError)
    if (typeof Notification === 'undefined') {
        console.warn('⚠️ Notification API غير متاحة في هذه البيئة');
        return null;
    }

    if (!messaging) {
        console.warn('⚠️ Firebase Messaging غير مهيأ؛ سيتم تجاوز تسجيل الإشعارات');
        return null;
    }

    if (!('serviceWorker' in navigator)) {
        console.warn('⚠️ Service Worker غير متاح؛ سيتم تجاوز تسجيل الإشعارات');
        return null;
    }

    try {
        let permission = await Notification.requestPermission();
        console.log('🔹 إذن الإشعارات:', permission);

        if (permission !== 'granted') {
            console.warn('❌ المستخدم رفض الإشعارات');
            return null;
        }

        // ✅ Worker registration is centralized in bootstrap.js. This function only
        // consumes an existing registration and never blocks startup by registering it.
        const swRegistration = await navigator.serviceWorker.getRegistration('/firebase-messaging-sw.js');
        if (!swRegistration) {
            console.warn('⚠️ لم يتم تسجيل FCM Service Worker؛ سيتم تجاوز تسجيل التوكن');
            return null;
        }

        const token = await messaging.getToken({
            vapidKey: 'BKaHIinYPemLY0hQmhLcQgMqRT-ahn08kw0lkvO08NDhgd1ICC5kHiZV8IHeLKLzfnioBg9IGegkhFMbwLN8sUA',
            serviceWorkerRegistration: swRegistration
        });

        console.log('✅ تم الحصول على التوكن:', token);

        await database.ref(`user_tokens/${userPhone}`).set({
            token: token,
            updatedAt: Date.now(),
            device: navigator.userAgent || 'متصفح'
        });

        await database.ref(`users/${userPhone}/fcmToken`).set(token);

        console.log('✅ تم حفظ التوكن في قاعدة البيانات');
        return token;

    } catch (error) {
        console.error('❌ فشل التسجيل:', error);
        return null;
    }
}

// ============================================================
// ✅ تسجيل الإشعارات الأصلية (Native) عبر @capacitor-firebase/messaging
// ============================================================
// يتطلب: npm i @capacitor-firebase/messaging ثم npx cap sync
// يحفظ التوكن في نفس مسارات قاعدة البيانات (user_tokens/... و users/.../fcmToken)
// فالباك إند الحالي (kovant-backend3.onrender.com) يبعت الإشعارات بنفس الطريقة
// بدون أي تعديل — لأن Firebase Admin messaging.send() يقبل توكن FCM سواء
// جاء من متصفح (Web Push) أو من تطبيق أصلي (Android/iOS)، الآلية واحدة.
async function registerDeviceNative(userPhone) {
    try {
        // ✅ نستخدم @capacitor-firebase/messaging (وليس @capacitor/push-notifications الخام)
        // لأنه بيرجع توكن FCM حقيقي على Android وعلى iOS معاً. البديل الخام
        // بيرجع على iOS توكن APNs فقط، وده مش هيشتغل مع سيرفرك الحالي
        // (kovant-backend3) اللي بيبعت الإشعارات عبر Firebase Admin بتوكن FCM.
        const FirebaseMessaging = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.FirebaseMessaging;
        if (!FirebaseMessaging) {
            console.error('❌ FirebaseMessaging plugin غير مثبت. شغّل: npm i @capacitor-firebase/messaging ثم npx cap sync');
            return null;
        }

        let permStatus = await FirebaseMessaging.checkPermissions();
        if (permStatus.receive === 'prompt' || permStatus.receive === 'prompt-with-rationale') {
            permStatus = await FirebaseMessaging.requestPermissions();
        }
        if (permStatus.receive !== 'granted') {
            console.warn('❌ المستخدم رفض إذن الإشعارات (Native)');
            return null;
        }

        // نشيل أي مستمعين قدامى (مثلاً لو registerDevice اتنادى أكتر من مرة)
        await FirebaseMessaging.removeAllListeners();

        // إشعار وصل والتطبيق مفتوح بالمقدمة (Foreground)
        FirebaseMessaging.addListener('notificationReceived', (event) => {
            console.log('📩 إشعار (Native, Foreground):', event);
            const n = event.notification || {};
            const title = n.title || 'كوفانت';
            const body = n.body || '';
            if (title && body && typeof showFloatingToast === 'function') {
                showFloatingToast(title, body);
            }
        });

        // المستخدم ضغط على الإشعار (سواء والتطبيق مفتوح أو مقفول)
        FirebaseMessaging.addListener('notificationActionPerformed', (event) => {
            console.log('👆 تم الضغط على إشعار (Native):', event.notification);
        });

        // تحديث التوكن في قاعدة البيانات لو اتجدد لاحقاً (نادر لكن بيحصل)
        FirebaseMessaging.addListener('tokenReceived', async (event) => {
            console.log('🔄 توكن FCM اتجدد (Native):', event.token);
            try {
                await database.ref(`user_tokens/${userPhone}`).set({
                    token: event.token,
                    updatedAt: Date.now(),
                    device: typeof getDeviceName === 'function' ? getDeviceName() : 'تطبيق'
                });
                await database.ref(`users/${userPhone}/fcmToken`).set(event.token);
            } catch (e) {
                console.error('❌ فشل حفظ توكن FCM المُجدد:', e);
            }
        });

        const { token } = await FirebaseMessaging.getToken();
        console.log('✅ تم الحصول على توكن FCM (Native):', token);

        await database.ref(`user_tokens/${userPhone}`).set({
            token: token,
            updatedAt: Date.now(),
            device: typeof getDeviceName === 'function' ? getDeviceName() : 'تطبيق'
        });
        await database.ref(`users/${userPhone}/fcmToken`).set(token);
        console.log('✅ تم حفظ توكن الإشعارات (Native) في قاعدة البيانات');

        return token;

    } catch (error) {
        console.error('❌ فشل التسجيل (Native):', error);
        return null;
    }
}

// ============================================================
// استقبال الإشعارات في المقدمة (Foreground) — للويب/PWA فقط
// ============================================================
if (!isNativeApp() && typeof messaging !== 'undefined' && messaging && messaging.onMessage) {
    messaging.onMessage((payload) => {
        console.log('📩 إشعار أمامي:', payload);
        const title = payload.notification?.title || 'كوفانت';
        const body = payload.notification?.body || '';

        if (title && body) {
            showFloatingToast(title, body);
        }

        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(title, { body, icon: '/icons/icon-192.png' });
        }
    });
}

function showFloatingToast(title, message) {
    const toast = document.getElementById('floatingToastMain');
    if (!toast) return;
    const msgEl = document.getElementById('toastMessageMain');
    if (msgEl) msgEl.textContent = `${title}: ${message}`;
    toast.classList.add('visible');
    // ✅ إصلاح: توحيد استخدام APP.toastTimeout بدلاً من window.toastTimeout
    if (APP.toastTimeout) clearTimeout(APP.toastTimeout);
    APP.toastTimeout = setTimeout(() => toast.classList.remove('visible'), 5000);
}

// ============================================================
// دوال إضافية
// ============================================================
function generateDeviceId() {
    let d = localStorage.getItem('deviceId');
    if (!d) {
        d = 'dev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15);
        localStorage.setItem('deviceId', d);
    }
    return d;
}

function getDeviceFingerprint() {
    const localId = generateDeviceId();
    const raw = [localId, navigator.userAgent || 'unknown', navigator.language || 'en', window.screen.width + 'x' + window.screen.height].join('###');
    return CryptoJS.SHA256(raw).toString(CryptoJS.enc.Hex);
}

async function hashPassword(password) {
    const enc = new TextEncoder().encode(password);
    const buf = await crypto.subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function getDeviceName() {
    const ua = navigator.userAgent;
    let name = 'جهاز غير معروف';
    if (/Android/i.test(ua)) {
        const m = ua.match(/Android\s([\d.]+)/);
        name = 'Android ' + (m ? m[1] : '');
    } else if (/iPhone|iPad|iPod/i.test(ua)) {
        name = 'iOS ' + (ua.match(/OS\s([\d_]+)/) ? ua.match(/OS\s([\d_]+)/)[1].replace(/_/g, '.') : '');
    } else if (/Windows/i.test(ua)) name = 'Windows';
    else if (/Mac/i.test(ua)) name = 'Mac';
    else if (/Linux/i.test(ua)) name = 'Linux';
    if (/Chrome/i.test(ua) && !/Edg/i.test(ua)) name += ' Chrome';
    else if (/Firefox/i.test(ua)) name += ' Firefox';
    else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) name += ' Safari';
    else if (/Edg/i.test(ua)) name += ' Edge';
    return name.trim() || 'جهاز غير معروف';
}

async function getDeviceAnalytics() {
    const ua = navigator.userAgent;
    let os = 'غير معروف';
    let osVersion = '';
    let deviceModel = '';
    let browser = 'غير معروف';
    let deviceType = 'desktop';

    const uaData = navigator.userAgentData;
    if (uaData) {
        try {
            const hints = await uaData.getHighEntropyValues(['platformVersion', 'model', 'fullVersionList']);
            os = uaData.platform || os;
            osVersion = hints.platformVersion || '';
            if (os === 'Android' && osVersion) os = `Android ${osVersion.split('.')[0]}`;
            else if (osVersion) os = `${os} ${osVersion}`;
            deviceModel = hints.model || '';
            deviceType = uaData.mobile ? 'mobile' : 'desktop';
            const brands = hints.fullVersionList || uaData.brands || [];
            const mainBrand = brands.find(b => !/Not.?A.?Brand/i.test(b.brand));
            if (mainBrand) browser = `${mainBrand.brand} ${mainBrand.version || ''}`.trim();
        } catch (e) {
            console.warn('userAgentData hints failed, falling back:', e.message);
        }
    }

    if (os === 'غير معروف') {
        if (/Android/i.test(ua)) os = 'Android';
        else if (/iPhone|iPad|iPod/i.test(ua)) os = 'iOS';
        else if (/Windows/i.test(ua)) os = 'Windows';
        else if (/Mac/i.test(ua)) os = 'macOS';
        else if (/Linux/i.test(ua)) os = 'Linux';
    }
    if (browser === 'غير معروف') {
        if (/Edg/i.test(ua)) browser = 'Edge';
        else if (/Chrome/i.test(ua)) browser = 'Chrome';
        else if (/Firefox/i.test(ua)) browser = 'Firefox';
        else if (/Safari/i.test(ua)) browser = 'Safari';
    }
    if (!uaData) {
        if (/Tablet|iPad/i.test(ua)) deviceType = 'tablet';
        else if (/Mobile|Android|iPhone/i.test(ua)) deviceType = 'mobile';
    }

    return { os, browser, deviceType, deviceModel: deviceModel || null, language: navigator.language || null };
}

function generateAccountNumber() {
    return '40' + Math.floor(10000000 + Math.random() * 90000000).toString();
}

async function isAccountNumberUnique(acc) {
    const snap = await database.ref('users').orderByChild('accountNumber').equalTo(acc).once('value');
    return !snap.exists();
}

async function getUniqueAccountNumber() {
    for (let i = 0; i < 20; i++) {
        const c = generateAccountNumber();
        if (await isAccountNumberUnique(c)) return c;
    }
    throw new Error('تعذر توليد رقم حساب فريد');
}

async function isDeviceLinkedToOtherAccount(deviceId, excludePhone) {
    const snap = await database.ref('users').once('value');
    if (!snap.val()) return false;
    for (const k in snap.val()) {
        const d = snap.val()[k];
        if (d.phone === excludePhone) continue;
        if (d.devices && d.devices[deviceId]) return true;
    }
    return false;
}

function getTimeAgo(ts) {
    const diff = Date.now() - ts;
    const s = Math.floor(diff / 1000);
    if (s < 10) return 'الآن';
    if (s < 60) return `منذ ${s} ثانية`;
    const m = Math.floor(s / 60);
    if (m < 60) return `منذ ${m} دقيقة`;
    const h = Math.floor(m / 60);
    if (h < 60) return `منذ ${h} ساعة`;
    const d = Math.floor(h / 24);
    if (d < 7) return `منذ ${d} يوم`;
    const w = Math.floor(d / 7);
    if (w < 4) return `منذ ${w} أسبوع`;
    const mo = Math.floor(d / 30);
    if (mo < 12) return `منذ ${mo} شهر`;
    return `منذ ${Math.floor(d / 365)} سنة`;
}

function getLastSeenText(lastSeen) {
    if (!lastSeen) return 'غير مسجل';
    const ts = typeof lastSeen === 'number' ? lastSeen : parseInt(lastSeen);
    if (isNaN(ts)) return 'غير مسجل';
    const diff = Date.now() - ts;
    const s = Math.floor(diff / 1000);
    if (s < 10) return 'الآن';
    if (s < 60) return `منذ ${s} ثانية`;
    const m = Math.floor(s / 60);
    if (m < 60) return `منذ ${m} دقيقة`;
    const h = Math.floor(m / 60);
    if (h < 60) return `منذ ${h} ساعة`;
    const d = Math.floor(h / 24);
    if (d < 7) return `منذ ${d} يوم`;
    const w = Math.floor(d / 7);
    if (w < 4) return `منذ ${w} أسبوع`;
    const mo = Math.floor(d / 30);
    if (mo < 12) return `منذ ${mo} شهر`;
    return `منذ ${Math.floor(d / 365)} سنة`;
}

function copyToClipboard(text, successMsg) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            showAlert(successMsg || 'تم النسخ');
        }).catch(() => {
            fallbackCopy(text, successMsg);
        });
    } else {
        fallbackCopy(text, successMsg);
    }
}

function fallbackCopy(text, successMsg) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showAlert(successMsg || 'تم النسخ');
}

// ============================================================
// توليد رموز الإحالة والأدمن
// ============================================================
function generateReferralCode(length = 6) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

async function isReferralCodeUnique(code) {
    const snap = await database.ref('users').orderByChild('referralCode').equalTo(code).once('value');
    return !snap.exists();
}

async function getUniqueReferralCode() {
    for (let i = 0; i < 20; i++) {
        const code = generateReferralCode();
        if (await isReferralCodeUnique(code)) return code;
    }
    throw new Error('تعذر توليد كود إحالة فريد');
}

function generateAdminCode(length = 8) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

async function isAdminCodeUnique(code) {
    const snap = await database.ref('admin_codes').orderByChild('code').equalTo(code).once('value');
    return !snap.exists();
}

async function getUniqueAdminCode() {
    for (let i = 0; i < 20; i++) {
        const code = generateAdminCode();
        if (await isAdminCodeUnique(code)) return code;
    }
    throw new Error('تعذر توليد كود أدمن فريد');
}

async function registerAdminCode(code, adminPhone, adminName) {
    await database.ref('admin_codes/' + code).set({
        code: code,
        adminPhone: adminPhone,
        adminName: adminName,
        createdAt: Date.now(),
        isActive: true,
        usedBy: null
    });
    return code;
}

async function verifyAdminCode(code) {
    const snap = await database.ref('admin_codes/' + code).once('value');
    const data = snap.val();
    if (!data || !data.isActive) return null;
    return data;
}