/* واجهة المستخدم لخدمة سداد — الأسعار تأتي من sadaq/pricing عبر الخادم. */
(function (window, document) {
    'use strict';
    let offers = {};
    function token() { return typeof window.getAuthToken === 'function' ? window.getAuthToken() : (window.APP && window.APP.token) || localStorage.getItem('token') || ''; }
    function api(path, options) {
        const opts = Object.assign({ headers: {} }, options || {});
        opts.headers = Object.assign({ 'Content-Type': 'application/json', Authorization: 'Bearer ' + token() }, opts.headers);
        return fetch(path, opts).then(async response => { const data = await response.json().catch(() => ({})); if (!response.ok || data.success === false) throw new Error(data.error || 'فشل الطلب'); return data; });
    }
    function esc(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function show(message, ok) { const box = document.getElementById('sadaqMessage'); if (box) { box.textContent = message; box.className = 'sadaq-msg ' + (ok ? 'ok' : 'error'); } }
    function phone() { return String((window.APP && window.APP.user && (window.APP.user.phone || window.APP.user.phoneNumber)) || '').trim(); }
    function renderOffers() {
        const list = document.getElementById('sadaqOffers'); if (!list) return;
        const rows = Object.entries(offers).filter(([, offer]) => offer && offer.active !== false);
        list.innerHTML = rows.length ? rows.map(([id, offer]) => `<button class="sadaq-offer" onclick="window.sadaqChoose('${esc(id)}')"><strong>${esc(offer.name || id)}</strong><span>${Number(offer.sell || 0).toFixed(2)} YER</span></button>`).join('') : '<div class="sadaq-empty">لا توجد باقات مفعّلة حالياً</div>';
    }
    async function loadOffers() {
        try { const data = await api('/api/sadaq/offers-list', { method: 'POST', body: JSON.stringify({ mobile: phone() }) }); offers = data.offers || {}; renderOffers(); }
        catch (error) { show(error.message, false); }
    }
    async function query() {
        const mobile = (document.getElementById('sadaqMobile') || {}).value || phone();
        try { const data = await api('/api/sadaq/query', { method: 'POST', body: JSON.stringify({ mobile }) }); document.getElementById('sadaqResult').textContent = JSON.stringify(data.result || data, null, 2); show('تم تنفيذ الاستعلام', true); }
        catch (error) { show(error.message, false); }
    }
    async function choose(id) {
        const mobile = (document.getElementById('sadaqMobile') || {}).value || phone(); const offer = offers[id];
        if (!offer) return; if (!confirm(`تفعيل ${offer.name || id} بسعر ${Number(offer.sell || 0).toFixed(2)} ريال؟`)) return;
        try { const data = await api('/api/sadaq/offer', { method: 'POST', body: JSON.stringify({ mobile, offerid: id, method: 'New' }) }); show(data.status === 'pending' ? 'العملية قيد المعالجة' : 'تم تفعيل الباقة بنجاح', true); document.getElementById('sadaqResult').textContent = JSON.stringify(data.result || data, null, 2); }
        catch (error) { show(error.message, false); }
    }
    window.sadaqLoad = function () { const input = document.getElementById('sadaqMobile'); if (input && !input.value) input.value = phone(); loadOffers(); };
    window.sadaqQuery = query;
    window.sadaqChoose = choose;
    const page = document.getElementById('sadaqInterface');
    if (page) new MutationObserver(() => { if (page.classList.contains('active')) window.sadaqLoad(); }).observe(page, { attributes: true, attributeFilter: ['class'] });
})(window, document);
