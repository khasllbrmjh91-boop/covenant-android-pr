/* ============================================================
   KovaNet Offline Queue — IndexedDB only
   Stores previously authenticated profiles and pending financial
   operations. No external storage library is used.
============================================================ */
(function () {
    'use strict';

    const DB_NAME = 'kova-net-offline';
    const DB_VERSION = 1;
    const OP_STORE = 'operations';
    const PROFILE_STORE = 'profiles';
    const API_BASE = 'https://kovant-backend3.onrender.com';
    let dbPromise = null;
    let syncing = false;
    let offlineAlertSent = false;

    function openDb() {
        if (dbPromise) return dbPromise;
        dbPromise = new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = function (event) {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(OP_STORE)) {
                    const store = db.createObjectStore(OP_STORE, { keyPath: 'id' });
                    store.createIndex('status', 'status', { unique: false });
                    store.createIndex('createdAt', 'createdAt', { unique: false });
                }
                if (!db.objectStoreNames.contains(PROFILE_STORE)) {
                    db.createObjectStore(PROFILE_STORE, { keyPath: 'phone' });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error || new Error('تعذر فتح التخزين المحلي'));
        });
        return dbPromise;
    }

    async function transaction(storeName, mode, callback) {
        const db = await openDb();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, mode);
            const store = tx.objectStore(storeName);
            let result;
            try { result = callback(store); } catch (error) { reject(error); return; }
            tx.oncomplete = () => resolve(result);
            tx.onerror = () => reject(tx.error || new Error('فشلت عملية التخزين المحلي'));
            tx.onabort = () => reject(tx.error || new Error('أُلغيت عملية التخزين المحلي'));
        });
    }

    function requestResult(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async function saveProfile(profile) {
        if (!profile || !profile.phone) return;
        await transaction(PROFILE_STORE, 'readwrite', store => {
            store.put({ phone: String(profile.phone), profile: profile, savedAt: Date.now() });
        });
    }

    async function getProfile(phone) {
        if (!phone) return null;
        const db = await openDb();
        const tx = db.transaction(PROFILE_STORE, 'readonly');
        const value = await requestResult(tx.objectStore(PROFILE_STORE).get(String(phone)));
        return value ? value.profile : null;
    }

    async function enqueue(type, payload) {
        const id = payload.operationId || ('OFF-' + Date.now() + '-' + Math.random().toString(36).slice(2, 10));
        const operation = {
            id,
            type,
            payload: Object.assign({}, payload, { operationId: id }),
            status: 'pending',
            attempts: 0,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            lastError: null
        };
        await transaction(OP_STORE, 'readwrite', store => store.put(operation));
        updatePendingUi();
        return operation;
    }

    async function getPending() {
        const db = await openDb();
        const tx = db.transaction(OP_STORE, 'readonly');
        const request = tx.objectStore(OP_STORE).index('status').getAll('pending');
        const result = await requestResult(request);
        return (result || []).sort((a, b) => a.createdAt - b.createdAt);
    }

    async function updateOperation(operation) {
        await transaction(OP_STORE, 'readwrite', store => store.put(operation));
    }

    async function removeOperation(id) {
        await transaction(OP_STORE, 'readwrite', store => store.delete(id));
    }

    async function sendOperation(operation) {
        const token = typeof getAuthToken === 'function' ? getAuthToken() : localStorage.getItem('auth_token');
        if (!token) throw new Error('انتهت الجلسة، سجّل الدخول لمزامنة العمليات');
        const isTransfer = operation.type === 'transfer';
        const url = isTransfer ? API_BASE + '/transfer' : API_BASE + '/api/purchase-package';
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token,
            'Idempotency-Key': operation.id
        };
        const response = await fetch(url, {
            method: 'POST',
            headers,
            body: JSON.stringify(operation.payload)
        });
        let data = null;
        try { data = await response.json(); } catch (e) { throw new Error('استجابة الخادم غير صالحة'); }
        if (!response.ok || !data.success) {
            const error = new Error(data.error || 'رفض الخادم العملية');
            error.status = response.status;
            throw error;
        }
        return data;
    }

    function applySyncedResult(operation, data) {
        if (typeof APP === 'undefined' || !APP.user) return;
        if (typeof data.newBalance === 'number') APP.user.balance = data.newBalance;
        if (window.KovaOfflineQueue && typeof window.KovaOfflineQueue.saveProfile === 'function') {
            window.KovaOfflineQueue.saveProfile(APP.user).catch(() => {});
        }
        if (typeof updateUserUI === 'function') updateUserUI(APP.user, APP.user.phone);
        if (typeof renderLastTransactions === 'function') renderLastTransactions();
        if (typeof showAlert === 'function') {
            showAlert(operation.type === 'transfer' ? 'تمت مزامنة التحويل المعلّق' : 'تمت مزامنة الشراء المعلّق', true);
        }
    }

    async function sync() {
        if (syncing || !navigator.onLine) return { synced: 0, failed: 0 };
        syncing = true;
        let synced = 0;
        let failed = 0;
        try {
            const pending = await getPending();
            for (const operation of pending) {
                operation.attempts = (operation.attempts || 0) + 1;
                operation.updatedAt = Date.now();
                try {
                    const data = await sendOperation(operation);
                    await removeOperation(operation.id);
                    applySyncedResult(operation, data);
                    synced++;
                } catch (error) {
                    operation.lastError = error.message || String(error);
                    await updateOperation(operation);
                    failed++;
                    if (error.status === 401 || error.status === 403) break;
                }
            }
        } finally {
            syncing = false;
            updatePendingUi();
        }
        if (synced && typeof showAlert === 'function') showAlert('اكتملت مزامنة العمليات المؤجلة', true);
        return { synced, failed };
    }

    async function pendingCount() {
        try { return (await getPending()).length; } catch (e) { return 0; }
    }

    function updatePendingUi() {
        pendingCount().then(count => {
            document.querySelectorAll('[data-offline-pending-count]').forEach(el => {
                el.textContent = count ? String(count) : '';
                el.style.display = count ? '' : 'none';
            });
            const banner = document.getElementById('offlineStatusBanner');
            if (banner && !navigator.onLine && count) {
                banner.setAttribute('data-pending', count);
            }
        }).catch(() => {});
    }

    function ensureStatusBanner() {
        let banner = document.getElementById('offlineStatusBanner');
        if (banner) return banner;
        banner = document.createElement('div');
        banner.id = 'offlineStatusBanner';
        banner.setAttribute('role', 'status');
        banner.innerHTML = '<i class="fa-solid fa-wifi-slash" aria-hidden="true"></i><span class="offline-status-text">لا يوجد إنترنت</span><span class="offline-pending" data-offline-pending-count style="display:none"></span>';
        document.body.appendChild(banner);
        return banner;
    }

    function updateConnectivityUi(isOnline) {
        const banner = ensureStatusBanner();
        document.body.classList.toggle('is-offline', !isOnline);
        banner.classList.toggle('visible', !isOnline);
        const text = banner.querySelector('.offline-status-text');
        if (text) text.textContent = isOnline ? 'تمت استعادة الاتصال' : 'لا يوجد إنترنت';
        if (isOnline) {
            setTimeout(() => banner.classList.remove('visible'), 2600);
            if (typeof APP !== 'undefined' && APP.user && typeof subscribeToUserData === 'function') {
                subscribeToUserData(APP.user.phone);
            }
            sync().then(result => {
                if (result.synced && typeof sendViaMyServer === 'function' && APP && APP.user && APP.user.phone) {
                    sendViaMyServer(APP.user.phone, 'تمت استعادة الاتصال', 'تمت مزامنة ' + result.synced + ' عملية معلّقة بنجاح.');
                }
            });
        } else {
            updatePendingUi();
        }
        if (typeof window.updateBalanceConnectivity === 'function') window.updateBalanceConnectivity(isOnline);
    }

    async function sendOfflineSmsAlert() {
        if (offlineAlertSent || !APP || !APP.user) return;
        offlineAlertSent = true;
        const target = APP.user.adminPhone || localStorage.getItem('admin_phone') || localStorage.getItem('adminPhone');
        if (!target || !window.Capacitor || !Capacitor.isNativePlatform || !Capacitor.isNativePlatform()) return;
        const plugin = Capacitor.Plugins && Capacitor.Plugins.TuaSmsSender;
        if (!plugin) return;
        try {
            await plugin.send({ number: String(target), text: 'تنبيه كوفانت: جهاز المستخدم ' + APP.user.phone + ' فقد الاتصال بالإنترنت في ' + new Date().toLocaleString('ar-YE') });
        } catch (e) { console.warn('تعذر إرسال SMS الانقطاع:', e.message || e); }
    }

    window.KovaOfflineQueue = { saveProfile, getProfile, enqueue, getPending, pendingCount, sync, updateConnectivityUi };
    window.addEventListener('offline', () => { updateConnectivityUi(false); sendOfflineSmsAlert(); });
    window.addEventListener('online', () => { offlineAlertSent = false; updateConnectivityUi(true); });
    document.addEventListener('DOMContentLoaded', () => updateConnectivityUi(navigator.onLine));
})();
