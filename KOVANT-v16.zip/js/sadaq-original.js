    
        const phoneInput = document.getElementById('phoneInput');
        const digitCount = document.getElementById('digitCount');
        const tabs = document.getElementById('tabs');
        const contentArea = document.getElementById('contentArea');
        const netInfo = document.getElementById('netInfo');
        const mainContent = document.getElementById('mainContent');

        let _currentOffer = null;
        let _currentBalance = 0;
        let _confirmData = null;

        phoneInput.addEventListener('input', () => {
            const v = phoneInput.value.replace(/\D/g, '');
            phoneInput.value = v;
            digitCount.textContent = v.length;
            detectNetwork(v);
            toggleServices(v.length);
        });

        function clearPhone() {
            phoneInput.value = '';
            digitCount.textContent = '0';
            detectNetwork('');
            toggleServices(0);
            phoneInput.focus();
        }

        function toggleServices(length) {
            if (length === 9) {
                mainContent.classList.add('top-aligned');
                tabs.classList.add('show');
                contentArea.classList.add('show');
            } else {
                mainContent.classList.remove('top-aligned');
                tabs.classList.remove('show');
                contentArea.classList.remove('show');
            }
        }

        function detectNetwork(num) {
            const prefix = num.substring(0, 2);
            const badge = document.getElementById('networkBadge');
            let net = null;
            if (prefix === '77' || prefix === '78') net = { name: 'يمن موبايل', short: 'يمن' };
            else if (prefix === '73') net = { name: 'YOU', short: 'YOU' };
            else if (prefix === '71') net = { name: 'سبأفون', short: 'سبأ' };
            if (net) {
                netInfo.textContent = net.name;
                netInfo.style.color = '#a62639';
            } else {
                netInfo.textContent = 'أدخل الرقم';
                netInfo.style.color = '#a62639';
            }
        }

        const TAX_RATE = 0.15;
        function calcNet() {
            const amt = parseFloat(document.getElementById('amountInput').value) || 0;
            const net = amt / (1 + TAX_RATE);
            document.getElementById('netAmount').value = net > 0 ? net.toFixed(2) : '';
        }

        function switchTab(btn) {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
            document.querySelector(`[data-panel="${btn.dataset.tab}"]`).classList.add('active');
            mainContent.scrollTop = 0;
            if (btn.dataset.tab === 'packages') queryNumberInfo();
            if (btn.dataset.tab === 'fawri' && !document.getElementById('fawriGrid').children.length) loadFawriCards();
        }

        const FAWRI_CARDS = [
            { qty: 200, price: 248, days: '8 أيام' },
            { qty: 400, price: 485, days: '16 يوم' },
            { qty: 600, price: 722, days: '24 يوم' },
            { qty: 800, price: 958, days: '32 يوم' },
            { qty: 1000, price: 1195, days: '40 يوم' },
            { qty: 1200, price: 1435, days: '48 يوم' },
            { qty: 2200, price: 2629, days: '88 يوم' }
        ];

        function loadFawriCards() {
            const grid = document.getElementById('fawriGrid');
            grid.innerHTML = FAWRI_CARDS.map(c => `
                <div class="fawri-card" onclick="selectFawri(${c.qty}, ${c.price}, '${c.days}')">
                    <div class="fawri-head">
                        <span>فئة</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z"/>
                        </svg>
                    </div>
                    <div class="fawri-num">${c.qty}</div>
                    <div class="fawri-label">السعر</div>
                    <div class="fawri-price">${c.price} ريال</div>
                    <div class="fawri-days">${c.days}</div>
                </div>
            `).join('');
        }

        function selectFawri(qty, price, days) {
            if (!confirm(`تأكيد شراء فئة ${qty} (${days}) بسعر ${price} ريال؟`)) return;
            submitPayment('fawri', { qty, price, days });
        }

        async function queryNumberInfo() {
            const phone = phoneInput.value.trim();
            if (phone.length !== 9) return;

            document.getElementById('loanIcon').textContent = '⏳';
            document.getElementById('loanStatus').textContent = '...';
            document.getElementById('numberType').textContent = '...';
            document.getElementById('numberBalance').textContent = '...';
            document.getElementById('subscriptionsList').innerHTML = '<div class="loading">جاري الاستعلام...</div>';

            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), 35000);
            try {
                const idToken = (typeof getAuthToken === 'function' ? getAuthToken() : '') || localStorage.getItem('auth_token') || localStorage.getItem('admin_jwt');
                if (!idToken) throw new Error('يجب تسجيل الدخول');
                const res = await fetch('/api/sadaq/query', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + idToken },
                    body: JSON.stringify({ phone }),
                    signal: ctrl.signal
                });
                const result = await res.json().catch(() => ({}));
                if (res.ok && result.success) renderNumberInfo(result.result || result.data || result);
                else renderNumberInfoError(result.error || result.message || 'فشل الاستعلام');
            } catch (e) {
                renderNumberInfoError(e.name === 'AbortError' ? 'انتهت المهلة، حاول مرة أخرى' : (e.message || 'تعذر الاستعلام'));
            } finally {
                clearTimeout(timer);
            }

            const list = document.getElementById('categoriesList');
            if (list.querySelector('.loading')) loadCategories();
        }

        function renderNumberInfo(data) {
            const loanIcon = document.getElementById('loanIcon');
            const loanStatus = document.getElementById('loanStatus');
            if (data.isDebtor === undefined) {
                loanIcon.textContent = '—';
                loanStatus.textContent = '—';
                loanStatus.style.color = '';
            } else if (data.isDebtor) {
                loanIcon.textContent = '😞';
                loanStatus.textContent = 'متسلف';
                loanStatus.style.color = '#b83333';
            } else {
                loanIcon.textContent = '😊';
                loanStatus.textContent = 'غير متسلف';
                loanStatus.style.color = '#1b7c3f';
            }
            document.getElementById('numberType').textContent = data.numberType || (data.mobileType === undefined ? '—' : (String(data.mobileType) === '1' ? 'فوترة' : 'دفع مسبق'));
            document.getElementById('numberBalance').textContent = (Number(data.balance) || 0).toFixed(2);
            _currentBalance = Number(data.balance) || 0;

            const list = document.getElementById('subscriptionsList');
            if (!data.subscriptions || data.subscriptions.length === 0) {
                list.innerHTML = '<div class="loading">لا توجد اشتراكات</div>';
                return;
            }
            list.innerHTML = data.subscriptions.map(s => `
                <div class="sub-item ${s.alt ? 'alt' : ''}">
                    <button class="sub-btn ${s.canRenew ? '' : 'check'}"
                            onclick="${s.canRenew ? `renewSubscription('${s.name}')` : ''}">
                        ${s.canRenew ? '↻' : '✓'}
                    </button>
                    <div class="sub-info">
                        <span class="sub-name">${s.name}</span>
                        <div class="sub-dates">
                            <div><span class="lbl-sub">الاشتراك:</span> ${s.subscribedAt}</div>
                            <div><span class="lbl-end">الانتهاء:</span> ${s.expiresAt}</div>
                        </div>
                    </div>
                </div>
            `).join('');
        }

        function renderNumberInfoError(msg) {
            document.getElementById('loanIcon').textContent = '⚠️';
            document.getElementById('loanStatus').textContent = '—';
            document.getElementById('numberType').textContent = '—';
            document.getElementById('numberBalance').textContent = '—';
            document.getElementById('subscriptionsList').innerHTML = `<div class="loading" style="color:#a62639;">${msg}</div>`;
        }

        function renewSubscription(subName) {
            if (!confirm(`تجديد "${subName}"؟`)) return;
            submitPayment('renew', { subscriptionName: subName });
        }

        const CATEGORIES = [
            { id: 'hadaya', name: 'باقات هدايا', icon: '3G' },
            { id: 'fawri', name: 'باقات فوري', icon: '4G' },
            { id: 'volte', name: 'باقات فولتي VoLTE', icon: '4G' },
            { id: 'monthly', name: 'باقات الإنترنت الشهرية', icon: '⇅' },
            { id: '10days', name: 'باقات إنترنت 10 أيام', icon: '10' }
        ];

        const OFFERS = {
            hadaya: [
                { offerid:'A68329', name:'هدايا - الشهرية', price:1500, days:30, minutes:400, sms:100, data:'400 ميجا', type:'فوتوة', sub:'شريحة', popular: true },
                { offerid:'A44330', name:'هدايا - الاسبوعيه', price:600, days:7, minutes:250, sms:50, data:'250 ميجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A66328', name:'هدايا توفير 250', price:250, days:7, minutes:0, sms:0, data:'250 ميجا', type:'فوتوة', sub:'شريحة' }
            ],
            fawri: [
                { offerid:'A5533822', name:'سوبر فوري الشهرية', price:2000, days:30, minutes:250, sms:250, data:'2 جيجا', type:'فوتوة', sub:'شريحة', popular: true }
            ],
            volte: [
                { offerid:'A4990004', name:'VoLTE يومي', price:400, days:2, minutes:40, sms:40, data:'1 جيجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A4990005', name:'VoLTE أسبوعي', price:1400, days:7, minutes:200, sms:200, data:'2 جيجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A4990001', name:'VoLTE شهري', price:2400, days:30, minutes:300, sms:300, data:'4 جيجا', type:'فوتوة', sub:'شريحة', popular: true }
            ],
            monthly: [
                { offerid:'A69351', name:'باقة 150 ميجا', price:500, days:30, data:'150 ميجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A69352', name:'باقة 300 ميجا', price:900, days:30, data:'300 ميجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A69354', name:'باقة 450 ميجا', price:1300, days:30, data:'450 ميجا', type:'فوتوة', sub:'شريحة', popular: true },
                { offerid:'A69355', name:'باقة 700 ميجا', price:1800, days:30, data:'700 ميجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A69357', name:'باقة 3 جيجا', price:4500, days:30, data:'3 جيجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A69358', name:'باقة 5 جيجا', price:7000, days:30, data:'5 جيجا', type:'فوتوة', sub:'شريحة' }
            ],
            '10days': [
                { offerid:'A74331', name:'باقة 1 جيجا', price:1400, days:10, data:'1 جيجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A74339', name:'باقة 2 جيجا', price:2600, days:10, data:'2 جيجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A74345', name:'باقة 4 جيجا', price:4800, days:10, data:'4 جيجا', type:'فوتوة', sub:'شريحة' },
                { offerid:'A74351', name:'باقة 6 جيجا', price:6000, days:10, data:'6 جيجا', type:'فوتوة', sub:'شريحة' }
            ]
        };

        async function loadCategories() {
            const wrapper = document.getElementById('categoriesList');
            try {
                const token = (typeof getAuthToken === 'function' ? getAuthToken() : '') || localStorage.getItem('auth_token') || localStorage.getItem('admin_jwt');
                if (!token) throw new Error('يجب تسجيل الدخول');
                const response = await fetch('/api/sadaq/offers-list', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ mobile: phoneInput.value.trim() }) });
                const data = await response.json();
                if (!response.ok || data.success === false) throw new Error(data.error || data.message || 'تعذر تحميل الباقات');
                const remote = data.offers || {};
                const rows = Object.entries(remote).map(([id, offer]) => ({ offerid: id, name: offer.name || id, price: Number(offer.sell || offer.price || offer.cost || 0), days: offer.days || 0, data: offer.data || '', type: offer.type || '', sub: offer.sub || '', popular: offer.popular === true }));
                if (rows.length) { OFFERS.monthly = rows; }
            } catch (error) {
                wrapper.innerHTML = '<div class="loading" style="color:#a62639;">' + error.message + '</div>';
                return;
            }
            wrapper.innerHTML = CATEGORIES.map(c => `
                <div class="cat-block" data-cat="${c.id}">
                    <button class="cat-header" onclick="toggleCategory('${c.id}')">
                        <span class="cat-arrow">
                            <svg viewBox="0 0 24 24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="6 9 12 15 18 9"/>
                            </svg>
                        </span>
                        <span class="cat-name">${c.name}</span>
                        <span class="cat-icon">${c.icon}</span>
                    </button>
                    <div class="cat-body">
                        <div class="cat-body-inner" id="catBody-${c.id}"></div>
                    </div>
                </div>
            `).join('');
        }

        function toggleCategory(catId) {
            const blocks = document.querySelectorAll('.cat-block');
            const target = document.querySelector(`.cat-block[data-cat="${catId}"]`);
            const wasOpen = target.classList.contains('open');
            blocks.forEach(b => b.classList.remove('open'));
            if (!wasOpen) {
                target.classList.add('open');
                const body = document.getElementById('catBody-' + catId);
                if (!body.innerHTML.trim()) body.innerHTML = renderOffers(catId);
            }
        }

        function renderOffers(catId) {
            const offers = OFFERS[catId] || [];
            if (offers.length === 0) return '<div class="loading">لا توجد باقات في هذه الفئة</div>';

            return offers.map(o => {
                const isPopular = o.popular === true;
                const dataParts = (o.data || '').split(' ');
                const dataNum = dataParts[0] || '—';
                const dataUnit = dataParts.slice(1).join(' ') || 'إنترنت';
                const typeClass = o.type === 'فوتوة' ? 'green' : '';
                const subClass = o.sub === 'شريحة' ? 'purple' : '';

                return `
                <div class="offer-card-v3" onclick="selectOffer('${o.offerid}', ${o.price}, '${o.name}')">
                    ${isPopular ? `
                        <div class="offer-badge">
                            <svg viewBox="0 0 24 24"><path d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z"/></svg>
                            الأكثر طلباً
                        </div>
                    ` : ''}

                    <div class="offer-v3-head">
                        <div class="offer-v3-logo">
                            <img src="https://c.top4top.io/p_3935fwjpc1.jpg"
                                 alt="يمن موبايل"
                                 onerror="this.style.display='none'; this.parentElement.innerHTML='<div class=\'fallback-logo\'><span>يمن</span><span>موبايل</span></div>';">
                        </div>
                        <div class="offer-v3-info">
                            <div class="offer-v3-name">${o.name}</div>
                            <div class="offer-v3-tags">
                                ${o.type ? `<span class="offer-v3-tag ${typeClass}">${o.type}</span>` : ''}
                                ${o.sub ? `<span class="offer-v3-tag ${subClass}">${o.sub}</span>` : ''}
                            </div>
                        </div>
                    </div>

                    <div class="offer-v3-price-row">
                        <span class="offer-v3-price-num">${o.price}</span>
                        <span class="offer-v3-price-currency">ريال</span>
                    </div>

                    <div class="offer-v3-features">
                        <div class="offer-v3-feat">
                            <div class="offer-v3-feat-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
                            <div class="offer-v3-feat-val">${o.days || 0}</div>
                            <div class="offer-v3-feat-lbl">يوم</div>
                        </div>
                        <div class="offer-v3-feat">
                            <div class="offer-v3-feat-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div>
                            <div class="offer-v3-feat-val">${o.minutes || 0}</div>
                            <div class="offer-v3-feat-lbl">دقيقة</div>
                        </div>
                        <div class="offer-v3-feat">
                            <div class="offer-v3-feat-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
                            <div class="offer-v3-feat-val">${o.sms || 0}</div>
                            <div class="offer-v3-feat-lbl">رسالة</div>
                        </div>
                        <div class="offer-v3-feat">
                            <div class="offer-v3-feat-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div>
                            <div class="offer-v3-feat-val">${dataNum}</div>
                            <div class="offer-v3-feat-lbl">${dataUnit}</div>
                        </div>
                    </div>
                </div>
                `;
            }).join('');
        }

        function selectOffer(offerid, price, name) {
            _currentOffer = { offerid, price, name };
            document.getElementById('sheetTitle').textContent = name;
            document.getElementById('sheetPriceInput').value = price;
            document.getElementById('sheetBalanceValue').textContent = _currentBalance.toFixed(2);

            const isDebtor = document.getElementById('loanIcon').textContent === '😞';
            const loanRow = document.getElementById('sheetLoanRow');
            if (isDebtor) {
                loanRow.style.display = 'flex';
                const loanAmount = 122.0;
                document.getElementById('sheetLoanLabel').textContent = `تسديد مبلغ السلفة ${loanAmount.toFixed(1)} ريال`;
                document.getElementById('sheetLoanCheck').checked = false;
            } else {
                loanRow.style.display = 'none';
            }

            recalcSheet();
            document.getElementById('sheetOverlay').classList.add('show');
            document.getElementById('packageSheet').classList.add('show');
        }

        function closePackageSheet() {
            document.getElementById('sheetOverlay').classList.remove('show');
            document.getElementById('packageSheet').classList.remove('show');
            _currentOffer = null;
        }

        function onLoanChange() { recalcSheet(); }

        function recalcSheet() {
            const price = parseFloat(document.getElementById('sheetPriceInput').value) || 0;
            const net = price / (1 + 0.15);
            document.getElementById('sheetNetValue').textContent = net.toFixed(2);
        }

        function activateFromWallet() {
            if (!_currentOffer) return;
            const price = parseFloat(document.getElementById('sheetPriceInput').value) || _currentOffer.price;
            if (_currentBalance < price) { alert('رصيدك غير كافٍ لتفعيل الباقة'); return; }
            if (!confirm(`تفعيل "${_currentOffer.name}" من رصيدك (${price} ريال)؟`)) return;
            submitPayment('billoffer', { offerid: _currentOffer.offerid, price, name: _currentOffer.name, source: 'wallet' });
            closePackageSheet();
        }

        function deletePackage() {
            if (!_currentOffer) return;
            if (!confirm(`حذف الباقة "${_currentOffer.name}"؟`)) return;
            submitPayment('deleteoffer', { offerid: _currentOffer.offerid, name: _currentOffer.name });
            closePackageSheet();
        }

        function confirmPackage() {
            if (!_currentOffer) return;
            const price = parseFloat(document.getElementById('sheetPriceInput').value) || _currentOffer.price;
            const payLoan = document.getElementById('sheetLoanCheck').checked;

            _confirmData = {
                offerid: _currentOffer.offerid,
                name: _currentOffer.name,
                price, phone: phoneInput.value.trim(),
                payLoan, received: ''
            };

            document.getElementById('cfPackage').textContent = _currentOffer.name;
            document.getElementById('cfPhone').textContent = _confirmData.phone;
            document.getElementById('cfAmount').textContent = price;
            document.getElementById('cfTotal').textContent = price;
            document.getElementById('cfReceivedInput').value = '';
            document.getElementById('cfTotalText').textContent = `*اجمالي التكلفة : ${numberToArabicWords(price)}`;

            document.getElementById('sheetOverlay').classList.remove('show');
            document.getElementById('packageSheet').classList.remove('show');
            document.getElementById('confirmOverlay').classList.add('show');
        }

        function numPress(key) {
            const input = document.getElementById('cfReceivedInput');
            let val = input.value;
            if (key === 'DEL') val = val.slice(0, -1);
            else if (key === 'CLEAR') val = '';
            else val = val + key;
            input.value = val;
            if (_confirmData) _confirmData.received = val;
        }

        function numberToArabicWords(num) {
            const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
            const tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
            const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
            num = Math.floor(num);
            if (num === 0) return 'صفر';
            let result = [];
            if (num >= 100) { result.push(hundreds[Math.floor(num / 100)]); num %= 100; }
            if (num > 0) {
                if (num < 20) result.push(ones[num]);
                else {
                    const o = num % 10, t = Math.floor(num / 10);
                    result.push(o > 0 ? ones[o] + ' و' + tens[t] : tens[t]);
                }
            }
            return result.join(' و');
        }

        function closeConfirmModal() {
            document.getElementById('confirmOverlay').classList.remove('show');
            _confirmData = null;
        }

        function sendViaWhatsApp() {
            if (!_confirmData) return;
            const msg = `تأكيد طلب%0A%0Aالخدمة: يمن موبايل%0Aالباقة: ${_confirmData.name}%0Aالرقم: ${_confirmData.phone}%0Aالسعر: ${_confirmData.price} ريال`;
            window.open('https://wa.me/?text=' + msg, '_blank');
        }

        function sendViaSMS() {
            if (!_confirmData) return;
            const msg = `تأكيد: ${_confirmData.name} - ${_confirmData.phone} - ${_confirmData.price} ريال`;
            window.location.href = 'sms:?body=' + encodeURIComponent(msg);
        }

        async function confirmFinalOrder() {
            if (!_confirmData) return;
            if (!_confirmData.received || parseFloat(_confirmData.received) <= 0) {
                if (!confirm('لم تدخل المبلغ المستلم. المتابعة؟')) return;
            }
            const data = _confirmData;
            closeConfirmModal();
            await submitPayment('billoffer', {
                offerid: data.offerid, price: data.price,
                name: data.name, payLoan: data.payLoan, received: data.received
            });
        }

        async function submitPayment(type, extra) {
            const phone = phoneInput.value.trim();
            if (phone.length !== 9) return showResult(type, 'error', 'أدخل رقم جوال صحيح (9 أرقام)');

            let payload = { phone, type };
            if (type === 'balance' || type === 'rial') {
                const inputId = type === 'balance' ? 'amountInput' : 'rialAmount';
                const amt = document.getElementById(inputId).value;
                if (!amt || amt <= 0) return showResult(type, 'error', 'أدخل المبلغ');
                payload.amount = parseInt(amt);
            } else if (type === 'bulk') {
                const amt = document.getElementById('bulkAmount').value;
                if (!amt || amt <= 0) return showResult(type, 'error', 'أدخل الكمية');
                payload.amount = parseInt(amt);
            } else if (type === 'fawri') {
                payload.qty = extra.qty; payload.amount = extra.price; payload.days = extra.days;
            } else if (type === 'billoffer') {
                payload.offerid = extra.offerid; payload.amount = extra.price; payload.method = 'New';
                if (extra.payLoan !== undefined) payload.payLoan = extra.payLoan;
                if (extra.received !== undefined) payload.received = extra.received;
                if (extra.source !== undefined) payload.source = extra.source;
            } else if (type === 'renew') {
                payload.subscriptionName = extra.subscriptionName;
            } else if (type === 'deleteoffer') {
                payload.offerid = extra.offerid; payload.method = 'Remove';
            }

            showResult(type, 'pending', '⏳ جاري الإرسال...');

            try {
                const idToken = (typeof getAuthToken === 'function' ? getAuthToken() : '') || localStorage.getItem('auth_token') || localStorage.getItem('admin_jwt');
                if (!idToken) return showResult(type, 'error', 'يجب تسجيل الدخول أولاً');
                const endpoint = (type === 'billoffer' || type === 'renew' || type === 'deleteoffer') ? '/api/sadaq/offer' : '/api/sadaq/pay';
                const res = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + idToken },
                    body: JSON.stringify(payload)
                });
                const result = await res.json();
                if (result.success) showResult(type, 'success', '✅ ' + (result.message || 'تم التسديد بنجاح'));
                else if (result.status === 'pending_reconciliation') showResult(type, 'pending', '⏳ ' + (result.error || 'العملية قيد التحقق، لا تكررها'));
                else showResult(type, 'error', '❌ ' + (result.error || result.message || 'فشلت العملية'));
            } catch (e) {
                showResult(type, 'error', '❌ تعذر الاتصال بالسيرفر');
            }
        }

        function showResult(type, cls, msg) {
            const boxId = (type === 'billoffer' || type === 'renew' || type === 'deleteoffer') ? 'packages' : type;
            const box = document.getElementById('result-' + boxId);
            if (!box) return;
            box.className = 'result-box ' + cls;
            box.textContent = msg;
        }

        function inquiryBalance() {
            const phone = phoneInput.value.trim();
            if (phone.length !== 9) return showResult('balance', 'error', 'أدخل رقم جوال صحيح');
            showResult('balance', 'pending', '⏳ جاري الاستعلام...');
            queryNumberInfo();
        }
        function inquiryBulk() {
            const phone = phoneInput.value.trim();
            if (phone.length !== 9) return showResult('bulk', 'error', 'أدخل رقم جوال صحيح');
            showResult('bulk', 'pending', '⏳ جاري الاستعلام...');
            queryNumberInfo();
        }
        function inquiryRial() {
            const phone = phoneInput.value.trim();
            if (phone.length !== 9) return showResult('rial', 'error', 'أدخل رقم جوال صحيح');
            showResult('rial', 'pending', '⏳ جاري الاستعلام...');
            queryNumberInfo();
        }

        function pickContact() { alert('ميزة دليل الهاتف — قيد التطوير'); }

        toggleServices(0);
        detectNetwork('');
        loadFawriCards();
    
