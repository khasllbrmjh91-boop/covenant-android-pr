// ═══════════════════════════════════════════════════════════════════
// عدادات خريطة الشبكة — JavaScript
// يعمل داخل صفحة SPA (#countersMapInterface)
// يُستدعى عبر: window.CountersMap.open() / window.CountersMap.close()
// ═══════════════════════════════════════════════════════════════════

(function(){
'use strict';

const STORAGE_KEY='ak_mikrotik_network_v24';
const ANALYZE_KEY='coavnet_devices';
const DEFAULT_HINT_HTML='<i class="fas fa-map-marker-alt"></i> حرّك الخريطة لتحديد الموقع <button onclick="App.cancelLocation()">إلغاء</button>';

const MODEM_SVG='<svg viewBox="0 0 40 30" xmlns="http://www.w3.org/2000/svg" fill="none" style="width:100%;height:100%;display:block"><path d="M 4 13 Q 2 15 4 17" stroke="#fff" stroke-width="1.2" stroke-linecap="round"/><path d="M 2 11 Q -1 15 2 19" stroke="#fff" stroke-width="1.2" stroke-linecap="round" opacity="0.5"/><path d="M 36 13 Q 38 15 36 17" stroke="#fff" stroke-width="1.2" stroke-linecap="round"/><path d="M 38 11 Q 41 15 38 19" stroke="#fff" stroke-width="1.2" stroke-linecap="round" opacity="0.5"/><line x1="13" y1="18" x2="10" y2="6" stroke="#fff" stroke-width="1.4" stroke-linecap="round"/><circle cx="10" cy="6" r="1" fill="#fff"/><line x1="27" y1="18" x2="30" y2="6" stroke="#fff" stroke-width="1.4" stroke-linecap="round"/><circle cx="30" cy="6" r="1" fill="#fff"/><rect x="8" y="18" width="24" height="8" rx="1.5" fill="rgba(255,255,255,0.2)" stroke="#fff" stroke-width="1.3"/><circle cx="12" cy="22" r="0.9" fill="#10b981"/><circle cx="15.5" cy="22" r="0.9" fill="#10b981"/><circle cx="19" cy="22" r="0.9" fill="#f59e0b"/><circle cx="22.5" cy="22" r="0.9" fill="#10b981"/><circle cx="26" cy="22" r="0.9" fill="#10b981"/></svg>';

const ICON_DEFS={
    main:{color:'#a855f7',icon:'fa-tower-cell',label:'البرج الرئيسي',size:56},
    tower:{color:'#c084fc',icon:'fa-tower-cell',label:'برج M5',size:48},
    backhaul:{color:'#f97316',icon:'fa-satellite-dish',label:'صحن Backhaul',size:44},
    sector5:{color:'#8b5cf6',icon:'fa-broadcast-tower',label:'أنتينا M5',size:42},
    sector2:{color:'#ec4899',icon:'fa-tower-broadcast',label:'قطاع 2.4GHz',size:42},
    modem:{color:'#06b6d4',icon:'fa-server',label:'مودم',size:38},
    backup:{color:'#fbbf24',icon:'fa-shield-alt',label:'احتياطي',size:32},
    cpe:{color:'#fbbf24',icon:'fa-satellite-dish',label:'استقبال',size:28},
    client_router:{color:'#06b6d4',icon:'fa-house-signal',label:'راوتر عميل',size:22},
    ap:{color:'#3b82f6',icon:'fa-wifi',label:'AP داخلي',size:22}
};

const VLAN_PALETTE={1:'#06b6d4',10:'#f59e0b',20:'#8b5cf6',30:'#ec4899',40:'#14b8a6',50:'#f97316',100:'#ef4444',200:'#3b82f6',300:'#84cc16'};
const DEFAULT_VLAN_COLOR='#64748b';
const ONLINE_COLOR='#10b981';
const OFFLINE_COLOR='#ef4444';

const MY_LOCATION_ICON=L.divIcon({className:'my-location-icon',html:'<div style="position:relative;width:22px;height:22px"><div style="position:absolute;inset:-6px;border-radius:50%;border:2px solid rgba(59,130,246,0.8);animation:locatePulse 1.8s infinite ease-out"></div><div style="position:absolute;inset:0;border-radius:50%;background:#3b82f6;border:3px solid #fff;box-shadow:0 0 14px #3b82f6"></div></div>',iconSize:[22,22],iconAnchor:[11,11]});

const PREVIEW_ICON=L.divIcon({className:'preview-icon',html:'<div style="width:40px;height:40px;border-radius:50%;background:#10b981;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;box-shadow:0 0 20px #10b981;border:3px solid #fff;animation:pulse 1.5s infinite"><i class="fas fa-map-pin"></i></div>',iconSize:[40,40],iconAnchor:[20,20]});

const state={
    nodes:[],users:[],map:null,
    layers:{links:null,nodes:null,users:null,street:null,satellite:null,labels:null},
    currentFilter:'all',currentMapType:'street',
    isPickingLocation:false,pendingLocation:null,markerPreview:null,
    selectedType:null,myLocationMarker:null,myLocationCircle:null,
    highlightedVlan:null,highlightedPath:null,currentDetailsId:null,is3D:false,
    baseZoom:15,
    pickPrev:null
};

const Utils={
showToast:function(msg,type,duration){
    type=type||'';
    duration=duration||3200;
    const t=document.getElementById('toast');
    if(!t) return;
    t.textContent=msg;
    t.className='toast show '+type;
    clearTimeout(t._to);
    t._to=setTimeout(function(){t.className='toast '+type;},duration);
},
geoErrorMessage:function(err){
    if(!err)return 'تعذر تحديد الموقع';
    if(err.code===1)return 'تم رفض إذن الوصول';
    if(err.code===2)return 'الموقع غير متاح';
    if(err.code===3)return 'انتهت مهلة التحديد';
    return 'تعذر تحديد الموقع';
},
getVlanColor:function(vlan){
    if(!vlan)return DEFAULT_VLAN_COLOR;
    if(VLAN_PALETTE[vlan])return VLAN_PALETTE[vlan];
    var hue=(vlan*137.508)%360;
    return 'hsl('+Math.round(hue)+',70%,55%)';
},
isNodeOnline:function(node){
    if(!node)return true;
    if(node.status==='offline')return false;
    if(typeof node.mainRssi==='number'&&node.mainRssi<-80)return false;
    return true;
},
getLinkColor:function(fromNode){
    return Utils.isNodeOnline(fromNode)?ONLINE_COLOR:OFFLINE_COLOR;
},

pingIP:function(ip){
    return new Promise(function(resolve){
        if(!ip || ip==='-'){resolve(true);return;}
        var done=false, img=new Image();
        var t=setTimeout(function(){if(!done){done=true;resolve(false);}},3000);
        img.onload=img.onerror=function(){
            if(!done){done=true;clearTimeout(t);resolve(true);}
        };
        img.src='http://'+ip+'/favicon.ico?_='+Date.now();
    });
},

syncToAnalyzePage:function(name, ip){
    if(!ip || ip==='-' || ip==='') return;
    try{
        var arr=[];
        try{ arr=JSON.parse(localStorage.getItem(ANALYZE_KEY)||'[]'); }catch(e){ arr=[]; }
        if(!Array.isArray(arr)) arr=[];
        if(!arr.some(function(d){return d.ip===ip;})){
            arr.push({id:Date.now()+Math.random(),name:name,ip:ip,status:'unknown'});
            localStorage.setItem(ANALYZE_KEY,JSON.stringify(arr));
        }
    }catch(e){}
},

getLineAnchor:function(node){
    return {lat:node.lat, lng:node.lng};
},

makeCurvedPath:function(lat1,lng1,lat2,lng2,cf){
    var mLat=(lat1+lat2)/2,mLng=(lng1+lng2)/2;
    var dx=lng2-lng1,dy=lat2-lat1;
    var d=Math.sqrt(dx*dx+dy*dy);
    if(d===0)return[[lat1,lng1],[lat2,lng2]];
    var pX=-dy/d,pY=dx/d;
    var c=cf||0.15;
    var cLat=mLat+pY*d*c,cLng=mLng+pX*d*c;
    var pts=[];
    for(var i=0;i<=28;i++){
        var t=i/28,u=1-t;
        pts.push([u*u*lat1+2*u*t*cLat+t*t*lat2,u*u*lng1+2*u*t*cLng+t*t*lng2]);
    }
    return pts;
},
interpolatePath:function(path,t){
    if(!path||!path.length)return null;
    if(path.length===1)return path[0];
    var seg=Math.max(0,Math.min(1,t))*(path.length-1);
    var idx=Math.min(Math.floor(seg),path.length-2);
    var lt=seg-idx;
    var p1=path[idx],p2=path[idx+1];
    return[p1[0]+(p2[0]-p1[0])*lt,p1[1]+(p2[1]-p1[1])*lt];
},

addArrowMarker:function(path,color,layerGroup,size){
    if(!path||path.length<2)return;
    var pos=Utils.interpolatePath(path,0.72),dir=Utils.interpolatePath(path,0.80);
    if(!pos||!dir)return;
    var latRad=(pos[0]+dir[0])/2*Math.PI/180;
    var dLat=dir[0]-pos[0],dLng=(dir[1]-pos[1])*Math.cos(latRad);
    var angle=Math.atan2(dLat,dLng)*180/Math.PI+180;
    var s=(size||12)+4;
    var icon=L.divIcon({
        className:'ak-arrow-marker',
        html:'<div style="width:'+s+'px;height:'+s+'px;display:flex;align-items:center;justify-content:center"><svg width="'+s+'" height="'+s+'" viewBox="0 0 14 14" style="transform:rotate('+angle+'deg);transform-origin:center;display:block"><polygon points="2,3 12,7 2,11" fill="'+color+'" stroke="rgba(10,16,31,0.95)" stroke-width="1.2" stroke-linejoin="round"/></svg></div>',
        iconSize:[s,s],iconAnchor:[s/2,s/2]
    });
    L.marker(pos,{icon:icon,interactive:false,zIndexOffset:100}).addTo(layerGroup);
},

drawLink:function(fromNode,toNode,layerGroup,opts){
    opts=opts||{};
    var child=fromNode, parent=toNode;
    var pAnchor = Utils.getLineAnchor(parent);
    var cAnchor = Utils.getLineAnchor(child);
    var weight=opts.weight||2, opacity=opts.opacity||0.85, dashed=opts.dashed||false;
    var cf=opts.curveFactor!==undefined?opts.curveFactor:0.15;
    var path;
    if(cf!==0){
        path=Utils.makeCurvedPath(pAnchor.lat,pAnchor.lng,cAnchor.lat,cAnchor.lng,cf);
    }else{
        path=[[pAnchor.lat,pAnchor.lng],[cAnchor.lat,cAnchor.lng]];
    }

    var childOnline = Utils.isNodeOnline(child);
    var parentOnline = Utils.isNodeOnline(parent);

    if(parentOnline && !childOnline){
        var splitIdx = Math.floor(path.length * 0.45);
        var greenPart = path.slice(0, splitIdx+1);
        var redPart = path.slice(splitIdx);

        L.polyline(path,{color:OFFLINE_COLOR,weight:weight+5,opacity:0.15,lineCap:'round',lineJoin:'round'}).addTo(layerGroup);
        L.polyline(greenPart,{color:ONLINE_COLOR,weight:weight,opacity:opacity,dashArray:dashed?'6,6':null,lineCap:'round',lineJoin:'round'}).addTo(layerGroup);
        L.polyline(redPart,{color:OFFLINE_COLOR,weight:weight,opacity:opacity,dashArray:dashed?'6,6':null,lineCap:'round',lineJoin:'round'}).addTo(layerGroup);
        Utils.addArrowMarker(redPart,OFFLINE_COLOR,layerGroup,weight>=2?16:14);
        return;
    }

    var color=opts.color||Utils.getLinkColor(child);
    L.polyline(path,{color:color,weight:weight,opacity:opacity,dashArray:dashed?'6,6':null,lineCap:'round',lineJoin:'round'}).addTo(layerGroup);
    Utils.addArrowMarker(path,color,layerGroup,weight>=2?16:14);
},

makeVlanBadge:function(vlan,highlighted,small){
    if(!vlan)return '';
    var color=Utils.getVlanColor(vlan);
    var pulse=highlighted?'animation:vlanPulse 1.2s infinite ease-in-out;':'';
    if(small){
        return '<div style="position:absolute;top:-5px;right:-5px;min-width:14px;height:14px;padding:0 3px;border-radius:7px;background:'+color+';color:#fff;font-size:8px;font-weight:900;display:flex;align-items:center;justify-content:center;border:1.5px solid #0a101f;box-shadow:0 1px 4px rgba(0,0,0,0.7);'+pulse+'">'+vlan+'</div>';
    }
    return '<div style="position:absolute;top:-6px;right:-6px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:'+color+';color:#fff;font-size:10px;font-weight:900;display:flex;align-items:center;justify-content:center;border:2px solid #0a101f;box-shadow:0 2px 6px rgba(0,0,0,0.7);'+pulse+'">'+vlan+'</div>';
},

makeNameLabel:function(node,isTower){
    if(!node.name) return '';
    var bg = isTower ? 'rgba(107,33,168,0.95)' : 'rgba(10,16,31,0.92)';
    var border = isTower ? '#a855f7' : 'rgba(255,255,255,0.15)';
    var color = isTower ? '#e9d5ff' : '#fff';
    return '<div class="node-name-label" style="position:absolute;bottom:100%;left:50%;'+
           'transform:translateX(-50%);margin-bottom:8px;white-space:nowrap;'+
           'background:'+bg+';color:'+color+';'+
           'font-size:10px;font-weight:800;padding:3px 9px;border-radius:7px;'+
           'border:1.5px solid '+border+';'+
           'box-shadow:0 3px 10px rgba(0,0,0,0.7);'+
           'direction:rtl;pointer-events:none;letter-spacing:0.2px">'+
           node.name+
           '<div style="position:absolute;top:100%;left:50%;transform:translateX(-50%);'+
           'width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;'+
           'border-top:5px solid '+bg+';margin-top:-1px"></div>'+
           '</div>';
},

makeTxRxBadge:function(node){
    var txTypes=['main','tower','sector5','sector2','backhaul'];
    var rxTypes=['cpe'];
    var isTX = txTypes.indexOf(node.type)!==-1;
    var isRX = rxTypes.indexOf(node.type)!==-1;
    if(!isTX && !isRX) return '';

    var bg = isTX ? '#ef4444' : '#10b981';
    var arrow = isTX ? '↑' : '↓';
    var label = isTX ? 'TX' : 'RX';
    var glow = isTX ? 'rgba(239,68,68,0.8)' : 'rgba(16,185,129,0.8)';

    return '<div style="position:absolute;top:-10px;left:-6px;'+
           'background:'+bg+';color:#fff;'+
           'font-size:8px;font-weight:900;padding:2px 5px;border-radius:7px;'+
           'border:1.5px solid #0a101f;letter-spacing:0.3px;'+
           'display:flex;align-items:center;gap:2px;direction:ltr;'+
           'box-shadow:0 0 6px '+glow+',0 1px 3px rgba(0,0,0,0.8);z-index:5">'+
           '<span style="font-size:9px;line-height:1">'+arrow+'</span>'+
           '<span>'+label+'</span>'+
           '</div>';
},

makeNodeIcon:function(node){
    var isHL=state.highlightedVlan!==null&&node.vlan===state.highlightedVlan;
    var badge=Utils.makeVlanBadge(node.vlan,isHL,false);
    var dimmed=state.highlightedVlan!==null&&node.vlan!==state.highlightedVlan;
    var extra=dimmed?'opacity:0.35;filter:grayscale(0.7);':(isHL?'transform:scale(1.12);':'');

    if(node.type==='modem'){
        var modemLabel = Utils.makeNameLabel(node, false);
        var modemSize = 38;
        return L.divIcon({
            className:'node-icon',
            html:'<div style="position:relative;width:'+modemSize+'px;height:'+modemSize+'px;'+extra+'">'+modemLabel+'<div style="width:100%;height:100%;border-radius:50%;background:linear-gradient(135deg,#0e7490,#06b6d4);display:flex;align-items:center;justify-content:center;border:2.5px solid #fff;padding:6px;box-sizing:border-box;color:#fff">'+MODEM_SVG+'</div>'+badge+'</div>',
            iconSize:[modemSize,modemSize],iconAnchor:[modemSize/2,modemSize/2]
        });
    }

    if(node.type==='main' || node.type==='tower'){
        var isMain = node.type==='main';
        var size = isMain ? 56 : 48;
        var color = isMain ? '#a855f7' : '#c084fc';
        var glow  = isMain ? '#a855f7' : '#c084fc';
        var nameLabel = Utils.makeNameLabel(node, true);
        var txRx = Utils.makeTxRxBadge(node);

        return L.divIcon({
            className:'node-icon',
            html:'<div style="position:relative;width:'+size+'px;height:'+size+'px;'+extra+'">'+
                    nameLabel+
                    txRx+
                    '<div style="width:100%;height:100%;border-radius:50%;'+
                         'background:linear-gradient(135deg,'+color+',#6b21a8);'+
                         'display:flex;align-items:center;justify-content:center;'+
                         'color:#fff;font-size:'+(size/2.1)+'px;'+
                         'border:2.5px solid #fff;'+
                         'box-shadow:0 0 16px '+glow+',0 4px 10px rgba(0,0,0,0.7)">'+
                        '<i class="fas fa-tower-cell"></i>'+
                    '</div>'+
                    badge+
                 '</div>',
            iconSize:[size,size],
            iconAnchor:[size/2,size/2]
        });
    }

    var def=ICON_DEFS[node.type]||ICON_DEFS.ap;
    var bg=def.color,icon=def.icon,sz=def.size;
    var defLabel = Utils.makeNameLabel(node, false);
    var defTxRx = Utils.makeTxRxBadge(node);
    return L.divIcon({
        className:'node-icon',
        html:'<div style="position:relative;width:'+sz+'px;height:'+sz+'px;'+extra+'">'+defLabel+defTxRx+'<div style="width:100%;height:100%;border-radius:50%;background:'+bg+';display:flex;align-items:center;justify-content:center;color:#fff;font-size:'+(sz/2.2)+'px;border:2.5px solid #fff;box-shadow:0 0 14px '+bg+'"><i class="fas '+icon+'"></i></div>'+badge+'</div>',
        iconSize:[sz,sz],iconAnchor:[sz/2,sz/2]
    });
},

makeUserIcon:function(user){
    var bg='#10b981';
    if(user.mainRssi<-80)bg='#ef4444';
    else if(user.mainRssi<-70)bg='#fbbf24';

    var isHL=state.highlightedVlan!==null&&user.vlan===state.highlightedVlan;
    var badge=Utils.makeVlanBadge(user.vlan,isHL,true);
    var dimmed=state.highlightedVlan!==null&&user.vlan!==state.highlightedVlan;
    var extra=dimmed?'opacity:0.3;filter:grayscale(0.8);':(isHL?'transform:scale(1.15);':'');
    var vb=user.vlan?'outline:2px solid '+Utils.getVlanColor(user.vlan)+';outline-offset:1px;':'';
    var lbl=Utils.makeNameLabel({name:user.deviceName},false);

    return L.divIcon({
        className:'user-icon',
        html:'<div style="position:relative;width:18px;height:18px;'+extra+'">'+
                lbl+
                '<div style="width:100%;height:100%;border-radius:50%;background:'+bg+
                ';display:flex;align-items:center;justify-content:center;'+
                'color:#fff;font-size:9px;border:2px solid #fff;'+vb+
                'box-shadow:0 0 8px '+bg+'">'+
                '<i class="fas fa-user"></i>'+
                '</div>'+badge+
             '</div>',
        iconSize:[18,18],
        iconAnchor:[9,9]
    });
},
getTypeLabel:function(type){return (ICON_DEFS[type]&&ICON_DEFS[type].label)||'جهاز';}
};

const MapManager={
init:function(){
    var mapEl = document.getElementById('map');
    if(!mapEl) return;

    state.map=L.map('map',{
        center:[15.3694,44.1910],
        zoom:15,
        zoomControl:false,
        attributionControl:false,
        zoomSnap:0.5,
        zoomDelta:0.5
    });

    state.baseZoom = state.map.getZoom();

    state.layers.street=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19});
    state.layers.satellite=L.tileLayer(
        'https://mt{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
        {subdomains:['0','1','2','3'],maxZoom:21,attribution:'© Google'}
    );

    if(!state.map.getPane('satLabelsPane')){
        var p=state.map.createPane('satLabelsPane');
        p.style.zIndex=380;
        p.style.pointerEvents='none';
    }
    state.layers.labels=L.tileLayer(
        'https://mt{s}.google.com/vt/lyrs=h&x={x}&y={y}&z={z}',
        {subdomains:['0','1','2','3'],maxZoom:21,opacity:0.9,pane:'satLabelsPane'}
    );

    state.layers.street.addTo(state.map);
    state.layers.links=L.layerGroup().addTo(state.map);
    state.layers.nodes=L.layerGroup().addTo(state.map);
    state.layers.users=L.layerGroup().addTo(state.map);

    state.map.on('zoomend',function(){
        if(state.highlightedPath){
            MapManager.highlightPath(state.highlightedPath);
        }else if(state.layers && state.layers.links){
            MapManager.renderLinksAndUsers(state.currentFilter);
        }
    });

    state.map.on('click',function(e){
        if(state.is3D){
            Utils.showToast('في وضع 3D النقر معطّل — ارجع إلى 2D للتحديد','info',2200);
            return;
        }
        if(state.isPickingLocation){
            state.map.panTo([e.latlng.lat,e.latlng.lng],{animate:true,duration:0.45});
            return;
        }
        if(state.highlightedPath){
            state.highlightedPath=null;
            MapManager.renderAll();
        }
        UI.closeMapMenu();
    });

    state.map.on('move',function(){
        if(state.isPickingLocation){
            var c=state.map.getCenter();
            state.pendingLocation={lat:c.lat,lng:c.lng};
            UI.updatePickCoords();
        }
    });
},

highlightPath:function(nodeId){
    var cur=state.nodes.find(function(n){return n.id===nodeId;});
    if(!cur){return;}
    var path=[cur];
    while(cur && cur.parentIds && cur.parentIds.length>0){
        var par=state.nodes.find(function(n){return n.id===cur.parentIds[0];});
        if(!par) break;
        path.push(par);
        cur=par;
    }

    state.layers.links.clearLayers();

    for(var i=0;i<path.length-1;i++){
        var child=path[i];
        var parent=path[i+1];
        var cA=Utils.getLineAnchor(child);
        var pA=Utils.getLineAnchor(parent);
        var curve=Utils.makeCurvedPath(pA.lat,pA.lng,cA.lat,cA.lng,0.15);
        var color=Utils.getLinkColor(child);
        L.polyline(curve,{color:color,weight:9,opacity:0.35,lineCap:'round'}).addTo(state.layers.links);
        L.polyline(curve,{color:color,weight:4,opacity:1,lineCap:'round'}).addTo(state.layers.links);
        Utils.addArrowMarker(curve,color,state.layers.links,16);
    }

    var names=path.map(function(n){return n.name;}).reverse();
    Utils.showToast('📍 المسار: '+names.join(' ← '),'success',5000);
},

toggleTilt:function(){
    var wrap=document.querySelector('#countersMapInterface .map-wrapper');
    var btn=document.getElementById('tiltBtn');
    var icon=document.getElementById('tiltIcon');
    var txt=document.getElementById('tiltText');
    if(!wrap) return;
    state.is3D=!state.is3D;
    var active=state.is3D;
    wrap.classList.toggle('mode-3d',active);
    if(btn) btn.classList.toggle('active',active);
    if(icon) icon.className=active?'fas fa-map':'fas fa-mountain';
    if(txt) txt.textContent=active?'2D':'3D';
    Utils.showToast(active?'🏔️ وضع 3D مفعّل':'🗺️ وضع الخريطة العادي','info',2500);
    setTimeout(function(){if(state.map) state.map.invalidateSize();},600);
},

toggleLayer:function(){
    if(!state.map) return;
    if(state.currentMapType==='street'){
        state.map.removeLayer(state.layers.street);
        state.layers.satellite.addTo(state.map);
        state.layers.labels.addTo(state.map);
        state.currentMapType='satellite';
        var mapEl=document.getElementById('map');
        if(mapEl) mapEl.classList.add('satellite-mode');
        var btn=document.getElementById('layerToggleBtn');
        if(btn) btn.classList.add('satellite-active');
        var ic=document.getElementById('layerIcon');
        if(ic) ic.className='fas fa-map';
        var tx=document.getElementById('layerText');
        if(tx) tx.textContent='خريطة';
    }else{
        state.map.removeLayer(state.layers.satellite);
        if(state.map.hasLayer(state.layers.labels))state.map.removeLayer(state.layers.labels);
        state.layers.street.addTo(state.map);
        state.currentMapType='street';
        var mapEl2=document.getElementById('map');
        if(mapEl2) mapEl2.classList.remove('satellite-mode');
        var btn2=document.getElementById('layerToggleBtn');
        if(btn2) btn2.classList.remove('satellite-active');
        var ic2=document.getElementById('layerIcon');
        if(ic2) ic2.className='fas fa-satellite';
        var tx2=document.getElementById('layerText');
        if(tx2) tx2.textContent='قمر صناعي';
    }
},

showMyLocation:function(lat,lng,accuracy){
    if(!state.map) return;
    if(state.myLocationMarker)state.map.removeLayer(state.myLocationMarker);
    if(state.myLocationCircle)state.map.removeLayer(state.myLocationCircle);
    if(accuracy&&isFinite(accuracy)){
        state.myLocationCircle=L.circle([lat,lng],{radius:Math.min(Math.max(accuracy,5),800),color:'#3b82f6',weight:1,opacity:0.6,fillColor:'#3b82f6',fillOpacity:0.12,interactive:false}).addTo(state.map);
    }
    state.myLocationMarker=L.marker([lat,lng],{icon:MY_LOCATION_ICON,zIndexOffset:1200}).addTo(state.map);
    var accTxt=(accuracy&&isFinite(accuracy))?('دقة ±'+Math.round(accuracy)+' م'):'تم التحديد عبر GPS';
    state.myLocationMarker.bindPopup('<div class="popup-title">موقعي الحالي</div><span class="popup-sub">'+accTxt+'</span>',{offset:[0,-10],closeButton:false,autoClose:true}).openPopup();
    state.map.flyTo([lat,lng],17,{duration:0.8});
},

clearMyLocation:function(){
    if(!state.map) return;
    if(state.myLocationMarker){state.map.removeLayer(state.myLocationMarker);state.myLocationMarker=null;}
    if(state.myLocationCircle){state.map.removeLayer(state.myLocationCircle);state.myLocationCircle=null;}
    var btn=document.getElementById('locateBtn');
    if(btn)btn.classList.remove('active');
},

toggleFullscreen:function(){
    var mc=document.getElementById('mapCard');
    var eb=document.getElementById('expandBtn');
    var bb=document.getElementById('backBtn');
    if(!mc) return;
    mc.classList.toggle('fullscreen');
    if(mc.classList.contains('fullscreen')){
        if(eb) eb.classList.add('hidden');
        if(bb) bb.classList.remove('hidden');
    }else{
        if(eb) eb.classList.remove('hidden');
        if(bb) bb.classList.add('hidden');
    }
    setTimeout(function(){if(state.map) state.map.invalidateSize();},350);
},

renderNodes:function(filter){
    if(!state.layers.nodes) return;
    state.layers.nodes.clearLayers();
    state.nodes.forEach(function(node){
        if(filter!=='all'&&filter!=='clear'){
            if(filter==='main'&&node.type!=='main'&&node.type!=='backup')return;
            if(filter==='tower'&&node.type!=='tower')return;
            if(filter==='sector'&&node.type!=='sector5'&&node.type!=='sector2')return;
            if(filter==='backhaul'&&node.type!=='backhaul')return;
            if(filter==='cpe'&&node.type!=='cpe')return;
            if(filter==='client'&&node.type!=='client_router')return;
            if(filter==='ap'&&node.type!=='ap'&&node.type!=='tower')return;
            if(filter==='users')return;
            if(filter==='vlan'&&!node.vlan)return;
        }
        var parentLine='';
        if(node.parentIds&&node.parentIds.length>0){
            var names=node.parentIds.map(function(pid){return state.nodes.find(function(n){return n.id===pid;});}).filter(Boolean).map(function(p){return p.name;}).join(', ');
            if(names)parentLine='<span class="popup-parent"><i class="fas fa-arrow-up"></i> متصل بـ: '+names+'</span>';
        }
        var ipLine=node.ip&&node.ip!=='-'?'<span class="popup-ip"><i class="fas fa-globe"></i> '+node.ip+'</span>':'';
        var vlanLine=node.vlan?'<span class="popup-sub" style="color:'+Utils.getVlanColor(node.vlan)+';font-weight:800;margin-top:2px">🏷️ VLAN '+node.vlan+'</span>':'';
        var bandLine=node.band?'<span class="popup-sub" style="color:#fbbf24;font-weight:700">'+(node.band==='5'?'📻 5GHz':'📻 2.4GHz')+'</span>':'';
        var statusLine='';
        if(node.status==='offline'){statusLine='<span class="popup-sub" style="color:#ef4444;font-weight:700">🔴 منقطع</span>';}
        else if(node.status==='online'){statusLine='<span class="popup-sub" style="color:#10b981;font-weight:700">🟢 متصل</span>';}
        var popup='<div class="popup-title">'+node.name+'</div><span class="popup-sub">'+Utils.getTypeLabel(node.type)+'</span>'+statusLine+bandLine+ipLine+vlanLine+parentLine;

        var zOff = (node.type==='main') ? 500 : (node.type==='tower') ? 400 : 0;

        L.marker([node.lat,node.lng],{icon:Utils.makeNodeIcon(node),zIndexOffset:zOff})
            .addTo(state.layers.nodes)
            .bindPopup(popup,{offset:[0,-15],closeButton:false,autoClose:true})
            .on('click',function(e){
                L.DomEvent.stopPropagation(e);
                UI.openDetails(node.id);
            });
    });
},

renderLinksAndUsers:function(filter){
    if(!state.layers.users || !state.layers.links)return;
    state.layers.users.clearLayers();
    state.layers.links.clearLayers();

    if(state.highlightedVlan!==null){
        state.nodes.forEach(function(node){
            if(node.vlan!==state.highlightedVlan)return;
            if(node.parentIds&&node.parentIds.length>0){
                node.parentIds.forEach(function(pid,idx){
                    var parent=state.nodes.find(function(n){return n.id===pid;});
                    if(parent){var cf=node.parentIds.length>1?((idx%2===0?1:-1)*(0.20+Math.floor(idx/2)*0.12)):0.18;Utils.drawLink(node,parent,state.layers.links,{weight:3,opacity:1,curveFactor:cf,dashed:false});}
                });
            }
        });
        state.users.forEach(function(user){
            if(user.vlan!==state.highlightedVlan)return;
            var parent=state.nodes.find(function(n){return n.id===user.parentId;});
            if(parent){Utils.drawLink({lat:user.lat,lng:user.lng,type:'user',mainRssi:user.mainRssi},parent,state.layers.links,{weight:1.8,opacity:0.9,dashed:true,curveFactor:0.14});}
        });
        this._renderUsers('vlan-highlight',state.highlightedVlan);
        return;
    }

    if(filter==='vlan'){
        state.nodes.forEach(function(node){
            if(!node.vlan)return;
            if(node.parentIds&&node.parentIds.length>0){
                node.parentIds.forEach(function(pid,idx){
                    var parent=state.nodes.find(function(n){return n.id===pid;});
                    if(parent){var cf=node.parentIds.length>1?((idx%2===0?1:-1)*(0.20+Math.floor(idx/2)*0.12)):0.18;Utils.drawLink(node,parent,state.layers.links,{weight:2.5,opacity:0.9,curveFactor:cf,dashed:false});}
                });
            }
        });
        state.users.forEach(function(user){
            if(!user.vlan)return;
            var parent=state.nodes.find(function(n){return n.id===user.parentId;});
            if(parent){Utils.drawLink({lat:user.lat,lng:user.lng,type:'user',mainRssi:user.mainRssi},parent,state.layers.links,{weight:1.8,opacity:0.8,dashed:true,curveFactor:0.14});}
        });
        this._renderUsers('vlan-all');
        return;
    }

    var drawn=new Set();
    state.nodes.forEach(function(node){
        if(filter!=='all'&&filter!=='clear'&&filter!=='ap'&&filter!=='users'){
            if(filter==='main'&&node.type!=='main'&&node.type!=='backup')return;
            if(filter==='tower'&&node.type!=='tower')return;
            if(filter==='sector'&&node.type!=='sector5'&&node.type!=='sector2')return;
            if(filter==='backhaul'&&node.type!=='backhaul')return;
            if(filter==='cpe'&&node.type!=='cpe')return;
            if(filter==='client'&&node.type!=='client_router')return;
        }
        if(filter==='ap'&&node.type!=='ap'&&node.type!=='tower')return;
        if(filter==='users'&&node.type!=='client_router')return;

        if(node.parentIds&&node.parentIds.length>0){
            node.parentIds.forEach(function(pid,idx){
                var parent=state.nodes.find(function(n){return n.id===pid;});
                if(parent){
                    var pk=node.id+'->'+parent.id;
                    if(drawn.has(pk))return;
                    drawn.add(pk);
                    if(node.type==='backup'&&parent.type==='main')return;

                    var cf=0.18;
                    if(node.parentIds.length>1){var sign=idx%2===0?1:-1;cf=sign*(0.20+Math.floor(idx/2)*0.12);}

                    Utils.drawLink(node,parent,state.layers.links,{weight:2,opacity:0.85,dashed:false,curveFactor:cf});
                }
            });
        }
    });

    this._renderUsers(filter);
},

_renderUsers:function(filter,onlyVlan){
    state.users.forEach(function(user){
        var status='online',label='متصل',sc='#10b981';
        if(user.mainRssi<-80){status='offline';label='منقطع';sc='#ef4444';}
        else if(user.mainRssi<-70){status='weak';label='ضعيف';sc='#fbbf24';}
        var draw=false;
        if(filter==='vlan-highlight')draw=user.vlan===onlyVlan;
        else if(filter==='vlan-all')draw=!!user.vlan;
        else if(filter==='all'||filter==='ap'||filter==='clear'||filter==='users'||filter==='vlan'||filter==='client')draw=true;
        else if(filter===status)draw=true;
        if(!draw)return;
        var parent=state.nodes.find(function(n){return n.id===user.parentId;});
        var pn=parent?parent.name:'-';
        var ip=user.ip?'<span class="popup-ip"><i class="fas fa-globe"></i> '+user.ip+'</span>':'';
        var vl=user.vlan?'<span class="popup-sub" style="color:'+Utils.getVlanColor(user.vlan)+';font-weight:800">🏷️ VLAN '+user.vlan+'</span>':'';
        var pl=parent?'<span class="popup-parent"><i class="fas fa-arrow-up"></i> متصل بـ: '+pn+'</span>':'';
        var popup='<div class="popup-title">'+user.deviceName+'</div><span class="popup-sub" style="color:'+sc+'">'+label+' • '+user.mainRssi+' dBm</span>'+ip+vl+pl;
        L.marker([user.lat,user.lng],{icon:Utils.makeUserIcon(user)}).addTo(state.layers.users).bindPopup(popup,{offset:[0,-12],closeButton:false,autoClose:true}).on('click',function(e){
            L.DomEvent.stopPropagation(e);
            UI.openDetails(user.userId);
        });
        if(parent&&filter!=='vlan-highlight'){
            Utils.drawLink({lat:user.lat,lng:user.lng,type:'user',mainRssi:user.mainRssi},parent,state.layers.links,{weight:1.3,opacity:0.75,dashed:true,curveFactor:0.14});
        }
    });
},

renderAll:function(){
    if(!state.map || !state.layers.nodes) return;
    this.renderNodes(state.currentFilter);
    if(state.highlightedPath){
        this.highlightPath(state.highlightedPath);
    }else{
        this.renderLinksAndUsers(state.currentFilter);
    }
}
};

/* 🗄️ مزوّد البيانات */
const DataLoader={
load:function(){
    state.nodes=[];
    state.users=[];
    try{
        var raw=localStorage.getItem(STORAGE_KEY);
        if(raw){
            var data=JSON.parse(raw);
            if(data && Array.isArray(data.nodes)) state.nodes=data.nodes;
            if(data && Array.isArray(data.users)) state.users=data.users;
        }
    }catch(e){
        console.warn('لا توجد بيانات محفوظة:',e);
    }
},

save:function(){
    try{
        localStorage.setItem(STORAGE_KEY,JSON.stringify({
            nodes:state.nodes,
            users:state.users
        }));
    }catch(e){}
},

api:{
    fetchAll:function(){
        return fetch('/api/network/all')
            .then(function(r){return r.json();})
            .then(function(data){
                state.nodes = data.nodes || [];
                state.users = data.users || [];
                DataLoader.save();
                return data;
            });
    },
    addNode:function(node){
        return fetch('/api/network/nodes',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(node)
        }).then(function(r){return r.json();});
    },
    deleteNode:function(id){
        return fetch('/api/network/nodes/'+id,{method:'DELETE'});
    },
    updateNode:function(id,data){
        return fetch('/api/network/nodes/'+id,{
            method:'PUT',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(data)
        }).then(function(r){return r.json();});
    }
}
};

const UI={
init:function(){
    window.App={
        toggleFullscreen:MapManager.toggleFullscreen,toggleLayer:MapManager.toggleLayer,
        toggleTilt:MapManager.toggleTilt,
        locateMe:UI.locateMe,clearMyLocation:MapManager.clearMyLocation,
        useCurrentLocation:UI.useCurrentLocation,finishGeoPick:UI.finishGeoPick,
        selectVlanChip:UI.selectVlanChip,
        selectVlanFromLegend:UI.selectVlanFromLegend,
        toggleMapMenu:UI.toggleMapMenu,closeMapMenu:UI.closeMapMenu,
        toggleDropdownPanel:UI.toggleDropdownPanel,toggleFilters:UI.toggleFilters,
        showToast:Utils.showToast,setFilter:UI.setFilter,rebootNetwork:UI.rebootNetwork,
        openAddModal:UI.openAddModal,closeAddModal:UI.closeAddModal,
        selectIcon:UI.selectIcon,
        startLocationPick:UI.startLocationPick,endLocationPick:UI.endLocationPick,
        cancelLocation:UI.cancelLocation,confirmPick:UI.confirmPick,
        updatePickCoords:UI.updatePickCoords,
        saveDevice:UI.saveDevice,
        openAnalyze:UI.openAnalyze,openAnalyzeOld:UI.openAnalyzeOld,
        closeAnalyze:UI.closeAnalyze,
        openAlerts:UI.openAlerts,openReports:UI.openReports,
        closeDetails:UI.closeDetails,
        detailsShowPath:UI.detailsShowPath,
        detailsZoomTo:UI.detailsZoomTo,
        detailsPing:UI.detailsPing
    };

    MapManager.init();

    var vlanInput = document.getElementById('deviceVlan');
    if(vlanInput) vlanInput.addEventListener('input',UI.syncVlanChips);

    DataLoader.load();
    MapManager.renderAll();
    UI.updateStatistics();
    UI.updateVlanLegend();

    if(state.nodes.length>0 || state.users.length>0){
        var allPts=[].concat(
            state.nodes.map(function(n){return [n.lat,n.lng];}),
            state.users.map(function(u){return [u.lat,u.lng];})
        );
        if(allPts.length>0){
            try{
                state.map.fitBounds(L.latLngBounds(allPts).pad(0.3));
            }catch(e){}
        }
    }else{
        setTimeout(function(){Utils.showToast('📭 لا توجد أجهزة — أضف جهازاً للبدء','info',3500);},900);
    }

    document.addEventListener('click',function(e){
        var dd=document.getElementById('mapDropdown');
        if(!dd || !dd.classList.contains('open'))return;
        var tt=document.getElementById('mapTitleText');
        if(dd.contains(e.target)||(tt&&tt.contains(e.target)))return;
        UI.closeMapMenu();
    });

    if(!localStorage.getItem('ak_welcomed_v6')){
        setTimeout(function(){Utils.showToast('👋 مرحباً بك في خريطة الشبكة','info',4000);localStorage.setItem('ak_welcomed_v6','1');},1200);
    }
},

openDetails:function(nodeId){
    var node=state.nodes.find(function(n){return n.id===nodeId;});
    if(!node){
        var user=state.users.find(function(u){return u.userId===nodeId;});
        if(user) UI.openUserDetails(user);
        return;
    }
    state.currentDetailsId=nodeId;

    var def=ICON_DEFS[node.type]||ICON_DEFS.ap;
    var iconWrap=document.getElementById('detailsIconWrap');
    var isTower=(node.type==='main'||node.type==='tower');
    var color=isTower?'#a855f7':def.color;
    var darkColor=isTower?'#6b21a8':'rgba(0,0,0,0.4)';
    if(iconWrap){
        iconWrap.style.background='linear-gradient(135deg,'+color+','+darkColor+')';
        iconWrap.style.boxShadow='0 0 18px '+color;
    }
    var iconEl=document.getElementById('detailsIcon');
    if(iconEl) iconEl.className=isTower?'fas fa-tower-cell':('fas '+def.icon);
    var nameEl=document.getElementById('detailsName');
    if(nameEl) nameEl.textContent=node.name||'—';
    var typeEl=document.getElementById('detailsType');
    if(typeEl) typeEl.textContent=Utils.getTypeLabel(node.type);

    var statusEl=document.getElementById('detailsStatus');
    if(statusEl){
        statusEl.className='details-status';
        if(node.status==='offline'){statusEl.classList.add('offline');statusEl.querySelector('.status-text').textContent='منقطع';}
        else if(node.status==='online'){statusEl.classList.add('online');statusEl.querySelector('.status-text').textContent='متصل';}
        else{statusEl.classList.add('unknown');statusEl.querySelector('.status-text').textContent='غير محدد';}
    }

    var ipEl=document.getElementById('detailsIP');
    if(ipEl) ipEl.textContent=node.ip&&node.ip!=='-'?node.ip:'—';
    var vlanEl=document.getElementById('detailsVlan');
    if(vlanEl){
        vlanEl.textContent=node.vlan||'—';
        vlanEl.style.color=node.vlan?Utils.getVlanColor(node.vlan):'#64748b';
    }

    var bandItem=document.getElementById('detailsBandItem');
    if(bandItem){
        if(node.band){
            bandItem.style.display='flex';
            var bandEl=document.getElementById('detailsBand');
            if(bandEl) bandEl.textContent=node.band==='5'?'5 GHz':'2.4 GHz';
        }else{
            bandItem.style.display='none';
        }
    }

    var typeFullEl=document.getElementById('detailsTypeFull');
    if(typeFullEl) typeFullEl.textContent=Utils.getTypeLabel(node.type);

    var parentEl=document.getElementById('detailsParent');
    if(parentEl){
        if(node.parentIds&&node.parentIds.length>0){
            var parents=node.parentIds.map(function(pid){
                var p=state.nodes.find(function(n){return n.id===pid;});
                return p?p.name:'—';
            }).filter(Boolean);
            if(parents.length){parentEl.textContent=parents.join(' + ');parentEl.classList.remove('empty');}
            else{parentEl.textContent='لا يوجد';parentEl.classList.add('empty');}
        }else{parentEl.textContent='لا يوجد (جهاز جذر)';parentEl.classList.add('empty');}
    }

    var childrenEl=document.getElementById('detailsChildren');
    if(childrenEl){
        var children=state.nodes.filter(function(n){return n.parentIds && n.parentIds.indexOf(node.id)!==-1;});
        if(children.length){
            childrenEl.textContent=children.length+' جهاز ('+children.slice(0,2).map(function(c){return c.name;}).join(', ')+(children.length>2?'...':'')+')';
            childrenEl.classList.remove('empty');
        }else{childrenEl.textContent='لا توجد أجهزة متصلة';childrenEl.classList.add('empty');}
    }

    var latEl=document.getElementById('detailsLat');
    if(latEl) latEl.textContent=node.lat.toFixed(6);
    var lngEl=document.getElementById('detailsLng');
    if(lngEl) lngEl.textContent=node.lng.toFixed(6);

    var ov=document.getElementById('detailsOverlay');
    if(ov) ov.classList.add('show');
    document.body.style.overflow='hidden';
},

openUserDetails:function(user){
    state.currentDetailsId=user.userId;
    var iconWrap=document.getElementById('detailsIconWrap');
    var bg=user.mainRssi<-80?'#ef4444':(user.mainRssi<-70?'#fbbf24':'#10b981');
    if(iconWrap){
        iconWrap.style.background='linear-gradient(135deg,'+bg+',rgba(0,0,0,0.4))';
        iconWrap.style.boxShadow='0 0 18px '+bg;
    }
    var iconEl=document.getElementById('detailsIcon');
    if(iconEl) iconEl.className='fas fa-user';
    var nameEl=document.getElementById('detailsName');
    if(nameEl) nameEl.textContent=user.deviceName||'—';
    var typeEl=document.getElementById('detailsType');
    if(typeEl) typeEl.textContent='مستخدم';

    var statusEl=document.getElementById('detailsStatus');
    if(statusEl){
        statusEl.className='details-status';
        if(user.mainRssi<-80){statusEl.classList.add('offline');statusEl.querySelector('.status-text').textContent='منقطع';}
        else if(user.mainRssi<-70){statusEl.classList.add('weak');statusEl.querySelector('.status-text').textContent='ضعيف';}
        else{statusEl.classList.add('online');statusEl.querySelector('.status-text').textContent='متصل';}
    }

    var ipEl=document.getElementById('detailsIP');
    if(ipEl) ipEl.textContent=user.ip||'—';
    var vlanEl=document.getElementById('detailsVlan');
    if(vlanEl){
        vlanEl.textContent=user.vlan||'—';
        vlanEl.style.color=user.vlan?Utils.getVlanColor(user.vlan):'#64748b';
    }
    var bandItem=document.getElementById('detailsBandItem');
    if(bandItem) bandItem.style.display='none';
    var typeFullEl=document.getElementById('detailsTypeFull');
    if(typeFullEl) typeFullEl.textContent='مستخدم';

    var parent=state.nodes.find(function(n){return n.id===user.parentId;});
    var parentEl=document.getElementById('detailsParent');
    if(parentEl){
        if(parent){parentEl.textContent=parent.name;parentEl.classList.remove('empty');}
        else{parentEl.textContent='—';parentEl.classList.add('empty');}
    }

    var childrenEl=document.getElementById('detailsChildren');
    if(childrenEl){
        childrenEl.textContent='—';
        childrenEl.classList.add('empty');
    }
    var latEl=document.getElementById('detailsLat');
    if(latEl) latEl.textContent=user.lat.toFixed(6);
    var lngEl=document.getElementById('detailsLng');
    if(lngEl) lngEl.textContent=user.lng.toFixed(6);

    var ov=document.getElementById('detailsOverlay');
    if(ov) ov.classList.add('show');
    document.body.style.overflow='hidden';
},

closeDetails:function(){
    var ov=document.getElementById('detailsOverlay');
    if(ov) ov.classList.remove('show');
    document.body.style.overflow='';
    state.currentDetailsId=null;
},

detailsShowPath:function(){
    if(!state.currentDetailsId)return;
    var id=state.currentDetailsId;
    UI.closeDetails();
    state.highlightedPath=id;
    MapManager.highlightPath(id);
},

detailsZoomTo:function(){
    if(!state.currentDetailsId)return;
    var node=state.nodes.find(function(n){return n.id===state.currentDetailsId;});
    if(!node){
        var user=state.users.find(function(u){return u.userId===state.currentDetailsId;});
        if(user&&state.map)state.map.flyTo([user.lat,user.lng],18,{duration:.8});
        UI.closeDetails();
        return;
    }
    if(state.map)state.map.flyTo([node.lat,node.lng],18,{duration:.8});
    UI.closeDetails();
},

detailsPing:function(){
    if(!state.currentDetailsId)return;
    var node=state.nodes.find(function(n){return n.id===state.currentDetailsId;});
    if(!node||!node.ip||node.ip==='-'){Utils.showToast('لا يوجد IP لهذا الجهاز','error');return;}
    var btn=document.getElementById('detailsPingBtn');
    if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-circle-notch fa-spin"></i> فحص';}
    Utils.pingIP(node.ip).then(function(alive){
        node.status=alive?'online':'offline';
        DataLoader.save();
        MapManager.renderAll();
        UI.updateStatistics();
        if(btn){
            btn.disabled=false;
            btn.innerHTML='<i class="fas fa-satellite-dish"></i> فحص';
        }
        var statusEl=document.getElementById('detailsStatus');
        if(statusEl){
            statusEl.className='details-status '+(alive?'online':'offline');
            statusEl.querySelector('.status-text').textContent=alive?'متصل':'منقطع';
        }
        Utils.showToast(alive?'✅ متصل':'❌ غير متصل',alive?'success':'error');
    });
},

toggleMapMenu:function(){
    var dd=document.getElementById('mapDropdown');
    var tt=document.getElementById('mapTitleText');
    if(!dd) return;
    var open=!dd.classList.contains('open');
    dd.classList.toggle('open',open);
    if(tt) tt.classList.toggle('menu-open',open);
    if(open&&!dd.querySelector('.dropdown-item.open'))UI.toggleDropdownPanel('stats');
},
closeMapMenu:function(){
    var dd=document.getElementById('mapDropdown');
    if(dd) dd.classList.remove('open');
    var tt=document.getElementById('mapTitleText');
    if(tt) tt.classList.remove('menu-open');
},
toggleDropdownPanel:function(key){
    document.querySelectorAll('#countersMapInterface #mapDropdown .dropdown-item').forEach(function(item){
        if(item.dataset.key===key)item.classList.toggle('open');
        else item.classList.remove('open');
    });
},
toggleFilters:function(){
    var p=document.getElementById('bottomFilters');
    var f=document.getElementById('filterFab');
    if(!p) return;
    var open=p.classList.toggle('open');
    if(f) f.classList.toggle('active',open);
},

openAnalyze:function(){
    var tpl=document.getElementById('coavnetTemplate');
    var frame=document.getElementById('coavnetFrame');
    var overlay=document.getElementById('coavnetOverlay');
    if(!tpl||!frame||!overlay) return;
    var head='<!DOCTYPE html><html lang="ar" dir="rtl"><head>'+
        '<meta charset="UTF-8">'+
        '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">'+
        '<meta name="theme-color" content="#050a15">'+
        '<title>COAV NET - تحليل الأجهزة</title>'+
        '</head><body>';
    frame.removeAttribute('data-loaded');
    frame.srcdoc = head + tpl.innerHTML + '</body></html>';
    overlay.classList.add('show');
    overlay.setAttribute('aria-hidden','false');
    document.body.style.overflow='hidden';
},
closeAnalyze:function(){
    var overlay=document.getElementById('coavnetOverlay');
    if(!overlay) return;
    overlay.classList.remove('show');
    overlay.setAttribute('aria-hidden','true');
    document.body.style.overflow='';
},

openAnalyzeOld:function(){Utils.showToast('تحليل الأجهزة قريباً...','success');},

updateVlanLegend:function(){
    var legend=document.getElementById('vlanLegend');
    var body=document.getElementById('vlanLegendBody');
    if(!legend||!body) return;
    var map=new Map();
    state.nodes.forEach(function(n){if(!n.vlan)return;if(!map.has(n.vlan))map.set(n.vlan,{n:0,u:0});map.get(n.vlan).n++;});
    state.users.forEach(function(u){if(!u.vlan)return;if(!map.has(u.vlan))map.set(u.vlan,{n:0,u:0});map.get(u.vlan).u++;});
    if(map.size===0){legend.classList.add('hidden');return;}
    legend.classList.remove('hidden');
    var sorted=Array.from(map.keys()).sort(function(a,b){return a-b;});
    body.innerHTML=sorted.map(function(v){
        var color=Utils.getVlanColor(v),c=map.get(v),t=c.n+c.u,active=state.highlightedVlan===v;
        return '<div class="vlan-legend-item '+(active?'active':'')+'" onclick="App.selectVlanFromLegend('+v+')"><span class="vlan-legend-color" style="background:'+color+'"></span><span class="vlan-legend-label">VLAN '+v+'</span><span class="vlan-legend-count">'+t+'</span></div>';
    }).join('');
},

selectVlanFromLegend:function(vlan){
    if(state.highlightedVlan===vlan){state.highlightedVlan=null;Utils.showToast('تم إلغاء إبراز VLAN '+vlan);}
    else{
        state.highlightedVlan=vlan;
        var n=state.nodes.filter(function(x){return x.vlan===vlan;}).length;
        var u=state.users.filter(function(x){return x.vlan===vlan;}).length;
        Utils.showToast('🎯 VLAN '+vlan+' — '+n+' جهاز + '+u+' مستخدم','success');
    }
    MapManager.renderAll();
    UI.updateVlanLegend();
},

selectVlanChip:function(chip){
    var inp=document.getElementById('deviceVlan');
    if(inp) inp.value=chip.dataset.vlan;
    document.querySelectorAll('#countersMapInterface .vlan-chip').forEach(function(c){c.classList.remove('active');});
    chip.classList.add('active');
},
syncVlanChips:function(){
    var inp=document.getElementById('deviceVlan');
    if(!inp) return;
    var v=inp.value.trim();
    document.querySelectorAll('#countersMapInterface .vlan-chip').forEach(function(c){c.classList.toggle('active',c.dataset.vlan===v);});
},

showHint:function(h){
    var e=document.getElementById('locationHint');
    if(!e) return;
    e.innerHTML=h;
    e.classList.add('show');
},
hideHint:function(){
    var e=document.getElementById('locationHint');
    if(!e) return;
    e.classList.remove('show');
    e.innerHTML=DEFAULT_HINT_HTML;
},

updatePickCoords:function(){
    var el=document.getElementById('pickCoords');
    if(!el||!state.pendingLocation)return;
    el.textContent=state.pendingLocation.lat.toFixed(6)+' , '+state.pendingLocation.lng.toFixed(6);
},

locateMe:function(){
    if(!navigator.geolocation){Utils.showToast('المتصفح لا يدعم تحديد الموقع','error');return;}
    var b=document.getElementById('locateBtn');
    if(b&&b.classList.contains('locating'))return;
    if(b){
        b.classList.add('locating');
        var ic=document.getElementById('locateIcon');
        if(ic) ic.className='fas fa-circle-notch fa-spin';
        var tx=document.getElementById('locateText');
        if(tx) tx.textContent='جاري التحديد';
    }
    navigator.geolocation.getCurrentPosition(function(p){
        if(b){
            b.classList.remove('locating');
            b.classList.add('active');
        }
        var ic=document.getElementById('locateIcon');
        if(ic) ic.className='fas fa-location-crosshairs';
        var tx=document.getElementById('locateText');
        if(tx) tx.textContent='موقعي';
        MapManager.showMyLocation(p.coords.latitude,p.coords.longitude,p.coords.accuracy);
        Utils.showToast('تم تحديد الموقع ✓','success');
    },function(e){
        if(b)b.classList.remove('locating');
        var ic=document.getElementById('locateIcon');
        if(ic) ic.className='fas fa-location-crosshairs';
        var tx=document.getElementById('locateText');
        if(tx) tx.textContent='موقعي';
        Utils.showToast(Utils.geoErrorMessage(e),'error');
    },{enableHighAccuracy:true,timeout:12000,maximumAge:30000});
},

useCurrentLocation:function(){
    if(!navigator.geolocation){Utils.showToast('المتصفح لا يدعم تحديد الموقع','error');return;}
    var gb=document.getElementById('geoBtn');
    if(gb&&gb.disabled)return;
    if(gb){
        gb.disabled=true;
        gb.innerHTML='<i class="fas fa-circle-notch fa-spin"></i> جاري التحديد...';
    }
    var modal=document.getElementById('addModal');
    if(modal) modal.classList.remove('show');
    UI.showHint('<i class="fas fa-circle-notch fa-spin"></i> جاري تحديد موقعك...');
    navigator.geolocation.getCurrentPosition(function(p){
        if(gb){
            gb.disabled=false;
            gb.classList.add('selected');
            gb.innerHTML='<i class="fas fa-check-circle"></i> تم ✓';
        }
        var lat=p.coords.latitude,lng=p.coords.longitude;
        state.pendingLocation={lat:lat,lng:lng};
        if(state.markerPreview&&state.map)state.map.removeLayer(state.markerPreview);
        if(state.map) state.markerPreview=L.marker([lat,lng],{icon:PREVIEW_ICON}).addTo(state.map);
        MapManager.showMyLocation(lat,lng,p.coords.accuracy);
        var lb=document.getElementById('locationBtn');
        if(lb){
            lb.classList.add('selected');
            lb.innerHTML='<i class="fas fa-check-circle"></i> تم التحديد ✓';
        }
        UI.showHint('<i class="fas fa-check-circle" style="color:#34d399"></i> تم التحديد <button onclick="App.finishGeoPick()">متابعة</button>');
    },function(e){
        if(gb){
            gb.disabled=false;
            gb.classList.remove('selected');
            gb.innerHTML='<i class="fas fa-location-crosshairs"></i> موقعي (GPS)';
        }
        UI.hideHint();
        var modal=document.getElementById('addModal');
        if(modal) modal.classList.add('show');
        Utils.showToast(Utils.geoErrorMessage(e),'error');
    },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
},

finishGeoPick:function(){
    UI.hideHint();
    var modal=document.getElementById('addModal');
    if(modal) modal.classList.add('show');
},

startLocationPick:function(){
    if(!state.selectedType){Utils.showToast('اختر أيقونة الجهاز أولاً','error');return;}
    if(state.is3D){Utils.showToast('لا يمكن التحديد في وضع 3D','error');return;}

    var modal=document.getElementById('addModal');
    if(modal) modal.classList.remove('show');

    state.isPickingLocation=true;
    state.pickPrev={
        mapType:state.currentMapType,
        fullscreen:document.getElementById('mapCard').classList.contains('fullscreen')
    };

    var mc=document.getElementById('mapCard');
    if(mc&&!mc.classList.contains('fullscreen')) MapManager.toggleFullscreen();
    if(state.currentMapType!=='satellite') MapManager.toggleLayer();

    var iface=document.getElementById('countersMapInterface');
    if(iface) iface.classList.add('pick-mode');
    var pin=document.getElementById('centerPickPin');
    if(pin) pin.classList.add('show');
    var bar=document.getElementById('pickConfirmBar');
    if(bar) bar.classList.add('show');
    UI.showHint('<i class="fas fa-map-marker-alt"></i> حرّك الخريطة لوضع الدبوس على الموقع المطلوب');

    setTimeout(function(){
        if(state.map) state.map.invalidateSize();
        if(state.map){
            var c=state.map.getCenter();
            state.pendingLocation={lat:c.lat,lng:c.lng};
            UI.updatePickCoords();
        }
    },420);
},

confirmPick:function(){
    if(!state.pendingLocation){Utils.showToast('حرّك الخريطة لتحديد الموقع','error');return;}
    Utils.showToast('✓ تم تأكيد الموقع بنجاح','success');
    UI.endLocationPick();
},

endLocationPick:function(){
    state.isPickingLocation=false;
    var iface=document.getElementById('countersMapInterface');
    if(iface) iface.classList.remove('pick-mode');
    var pin=document.getElementById('centerPickPin');
    if(pin) pin.classList.remove('show');
    var bar=document.getElementById('pickConfirmBar');
    if(bar) bar.classList.remove('show');
    UI.hideHint();

    if(state.pickPrev && state.pickPrev.mapType==='street' && state.currentMapType==='satellite'){
        MapManager.toggleLayer();
    }
    var mc=document.getElementById('mapCard');
    if(state.pickPrev && !state.pickPrev.fullscreen && mc && mc.classList.contains('fullscreen')){
        MapManager.toggleFullscreen();
    }
    state.pickPrev=null;

    var modal=document.getElementById('addModal');
    if(modal) modal.classList.add('show');
    var lb=document.getElementById('locationBtn');
    if(lb){
        lb.classList.add('selected');
        lb.innerHTML='<i class="fas fa-check-circle"></i> تم التحديد ✓';
    }
    setTimeout(function(){if(state.map) state.map.invalidateSize();},420);
},

cancelLocation:function(){
    UI.hideHint();
    state.isPickingLocation=false;
    var iface=document.getElementById('countersMapInterface');
    if(iface) iface.classList.remove('pick-mode');
    var pin=document.getElementById('centerPickPin');
    if(pin) pin.classList.remove('show');
    var bar=document.getElementById('pickConfirmBar');
    if(bar) bar.classList.remove('show');
    if(state.markerPreview&&state.map){state.map.removeLayer(state.markerPreview);state.markerPreview=null;}
    state.pendingLocation=null;

    if(state.pickPrev && state.pickPrev.mapType==='street' && state.currentMapType==='satellite'){
        MapManager.toggleLayer();
    }
    var mc=document.getElementById('mapCard');
    if(state.pickPrev && !state.pickPrev.fullscreen && mc && mc.classList.contains('fullscreen')){
        MapManager.toggleFullscreen();
    }
    state.pickPrev=null;

    var modal=document.getElementById('addModal');
    if(modal) modal.classList.add('show');
    setTimeout(function(){if(state.map) state.map.invalidateSize();},420);
},

updateStatistics:function(){
    var total=state.nodes.length+state.users.length;
    var online=0,weak=0,offline=0;
    state.users.forEach(function(u){if(u.mainRssi<-80)offline++;else if(u.mainRssi<-70)weak++;else online++;});
    state.nodes.forEach(function(n){
        if(n.status==='offline')offline++;
        else online++;
    });
    var els={
        statTotal:document.getElementById('statTotal'),
        statOnline:document.getElementById('statOnline'),
        statWeak:document.getElementById('statWeak'),
        statOffline:document.getElementById('statOffline')
    };
    if(els.statTotal) els.statTotal.textContent=total;
    if(els.statOnline) els.statOnline.textContent=online;
    if(els.statWeak) els.statWeak.textContent=weak;
    if(els.statOffline) els.statOffline.textContent=offline;
},

openAddModal:function(){
    var modal=document.getElementById('addModal');
    if(modal) modal.classList.add('show');
    var el;
    el=document.getElementById('deviceName'); if(el) el.value='';
    el=document.getElementById('deviceIP'); if(el) el.value='';
    el=document.getElementById('deviceVlan'); if(el) el.value='';
    el=document.getElementById('deviceParent'); if(el) el.value='';
    el=document.getElementById('locationBtn');
    if(el){
        el.classList.remove('selected');
        el.innerHTML='<i class="fas fa-map-pin"></i> تحديد يدوي';
    }
    document.querySelectorAll('#countersMapInterface .vlan-chip').forEach(function(c){c.classList.remove('active');});
    var gb=document.getElementById('geoBtn');
    if(gb){
        gb.disabled=false;
        gb.classList.remove('selected');
        gb.innerHTML='<i class="fas fa-location-crosshairs"></i> موقعي (GPS)';
    }
    document.querySelectorAll('#countersMapInterface .icon-option').forEach(function(o){o.classList.remove('selected');});
    state.selectedType=null;
    var pg=document.getElementById('parentGroup');
    if(pg) pg.style.display='none';
    state.pendingLocation=null;
    if(state.markerPreview&&state.map){state.map.removeLayer(state.markerPreview);state.markerPreview=null;}
},

closeAddModal:function(){
    var modal=document.getElementById('addModal');
    if(modal) modal.classList.remove('show');
    if(state.isPickingLocation || state.pickPrev) UI.cancelLocation();
    if(state.markerPreview&&state.map){state.map.removeLayer(state.markerPreview);state.markerPreview=null;}
    state.pendingLocation=null;
},

selectIcon:function(type,el){
    document.querySelectorAll('#countersMapInterface .icon-option').forEach(function(o){o.classList.remove('selected');});
    el.classList.add('selected');
    state.selectedType=type;
    UI.refreshParentList(type);
},

refreshParentList:function(type){
    var sel=document.getElementById('deviceParent');
    var grp=document.getElementById('parentGroup');
    if(!sel||!grp) return;
    if(type==='main'){grp.style.display='none';return;}
    grp.style.display='block';
    var allowed=[];
    if(type==='backup')allowed=['main'];
    else if(type==='modem')allowed=['main','backup'];
    else if(type==='tower')allowed=['main','backup'];
    else if(type==='sector5'||type==='sector2')allowed=['tower'];
    else if(type==='backhaul')allowed=['tower'];
    else if(type==='ap')allowed=['tower'];
    else if(type==='cpe')allowed=['sector5','sector2'];
    else if(type==='client_router')allowed=['cpe'];
    sel.innerHTML='<option value="">-- بدون ربط --</option>';
    var parents=state.nodes.filter(function(n){return allowed.indexOf(n.type)!==-1;});
    if(parents.length===0&&allowed.length>0){
        var lbl=allowed.map(function(t){return Utils.getTypeLabel(t);}).join(' أو ');
        var o=document.createElement('option');
        o.value='';o.disabled=true;
        o.textContent='⚠️ لا يوجد '+lbl;
        sel.appendChild(o);
    }
    parents.forEach(function(n){
        var o=document.createElement('option');
        o.value=n.id;
        var bandTxt=n.band?' • '+n.band+'GHz':'';
        var vlanTxt=n.vlan?' • VLAN '+n.vlan:'';
        o.textContent=n.name+' ('+Utils.getTypeLabel(n.type)+bandTxt+vlanTxt+')';
        sel.appendChild(o);
    });
},

saveDevice:function(){
    var type=state.selectedType;
    var nameEl=document.getElementById('deviceName');
    var ipEl=document.getElementById('deviceIP');
    var pidEl=document.getElementById('deviceParent');
    var vEl=document.getElementById('deviceVlan');
    var name=nameEl?nameEl.value.trim():'';
    var ip=ipEl?ipEl.value.trim():'';
    var pid=pidEl?pidEl.value:'';
    var vRaw=vEl?vEl.value.trim():'';
    var vNum=vRaw?parseInt(vRaw,10):null;
    var vlan=(vNum&&vNum>0&&vNum<=4094)?vNum:null;

    if(!type){Utils.showToast('اختر نوع الجهاز أولاً','error');return;}
    if(!name){Utils.showToast('أدخل اسم الجهاز','error');return;}
    if(!state.pendingLocation){Utils.showToast('حدّد موقع الجهاز على الخريطة','error');return;}

    if(!vlan && pid){
        var par=state.nodes.find(function(n){return n.id===pid;});
        if(par && par.vlan) vlan=par.vlan;
    }

    var newNode={
        id:'node_'+Date.now(),
        lat:state.pendingLocation.lat,
        lng:state.pendingLocation.lng,
        name:name,
        type:type,
        ip:ip||'-',
        vlan:vlan,
        parentIds:pid?[pid]:[],
        status:'online'
    };
    if(type==='sector5') newNode.band='5';
    if(type==='sector2') newNode.band='2.4';

    state.nodes.push(newNode);
    DataLoader.save();
    MapManager.renderAll();
    UI.updateStatistics();
    UI.updateVlanLegend();
    UI.closeAddModal();

    if(ip && ip!=='-'){
        Utils.syncToAnalyzePage(name, ip);
    }

    var ipRegex=/^(\d{1,3}\.){3}\d{1,3}$/;
    if(ip && ip!=='-' && ipRegex.test(ip)){
        Utils.showToast('🔍 جاري فحص '+ip+'...','info',1800);
        Utils.pingIP(ip).then(function(alive){
            newNode.status = alive ? 'online' : 'offline';
            DataLoader.save();
            MapManager.renderAll();
            UI.updateStatistics();
            Utils.showToast(alive ? '✅ الجهاز متصل — خط أخضر' : '❌ الجهاز غير متصل — خط أحمر',
                alive ? 'success' : 'error', 3500);
        });
    }else{
        Utils.showToast('✅ تم إضافة الجهاز بنجاح','success');
    }
},

openAlerts:function(){Utils.showToast('🔔 لا توجد تنبيهات جديدة حالياً','info');},
openReports:function(){Utils.showToast('📊 التقارير قادمة قريباً','info');},

rebootNetwork:function(){
    if(!confirm('إعادة تحميل بيانات الشبكة؟'))return;
    Utils.showToast('🔄 جاري المزامنة...','info');
    DataLoader.api.fetchAll()
        .then(function(){
            MapManager.renderAll();
            UI.updateStatistics();
            UI.updateVlanLegend();
            Utils.showToast('✅ تمت المزامنة مع الخادم','success');
        })
        .catch(function(){
            DataLoader.load();
            MapManager.renderAll();
            UI.updateStatistics();
            UI.updateVlanLegend();
            Utils.showToast('⚠️ تعذر الاتصال — تم التحميل محلياً','info');
        });
},

setFilter:function(filter,el){
    state.currentFilter=filter;
    document.querySelectorAll('#countersMapInterface #bottomFilters .filter-item').forEach(function(i){i.classList.remove('active');});
    if(el)el.classList.add('active');
    if(filter==='clear'){state.highlightedVlan=null;state.highlightedPath=null;state.currentFilter='all';UI.updateVlanLegend();}
    MapManager.renderAll();
}
};

// ═══════════════════════════════════════════════════════════════════
// ✅ Public API — يُستدعى من router.js
// ═══════════════════════════════════════════════════════════════════
window.CountersMap = {
    _inited: false,

    open: function() {
        var self = this;
        if (!self._inited) {
            self._inited = true;
            UI.init();
            setTimeout(function() {
                if (state.map) state.map.invalidateSize();
            }, 400);
        } else {
            setTimeout(function() {
                if (state.map) state.map.invalidateSize();
            }, 150);
        }
    },

    close: function() {
        // إغلاق أي نوافذ/حالات مفتوحة عند مغادرة الصفحة
        try {
            if (state.isPickingLocation) UI.cancelLocation();
            if (document.getElementById('addModal') && document.getElementById('addModal').classList.contains('show')) {
                UI.closeAddModal();
            }
            if (document.getElementById('detailsOverlay') && document.getElementById('detailsOverlay').classList.contains('show')) {
                UI.closeDetails();
            }
            if (state.map) state.map.invalidateSize();
        } catch(e) { console.warn('CountersMap.close error:', e); }
    }
};

console.log('✅ counters-map.js loaded');

})();