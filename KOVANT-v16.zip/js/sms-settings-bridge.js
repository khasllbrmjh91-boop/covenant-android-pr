/* ============================================================
 * COVANT — SMS SETTINGS BRIDGE
 * جسر الإعدادات بين الواجهة والكود الأصلي (SharedPreferences "sms_gateway_prefs")
 *
 * - مصدر الحقيقة داخل التطبيق: SharedPreferences (عبر المكوّن الأصلي TuaSmsSettings).
 * - localStorage (SmsStore) يبقى كنسخة مرآة مؤقتة للتوافق (كتابة مزدوجة).
 * - خارج تطبيق أندرويد (متصفح/PWA): كل شيء يعمل على localStorage فقط كالسابق.
 *
 * المفاتيح الأصلية: autoProcess(bool, الافتراضي true) processOld(bool, الافتراضي false) readSim(int) sendSim(int) deviceId(string)
 * readSim/sendSim = subscriptionId، والقيمة -1 = الكل/الافتراضي.
 * ============================================================ */
(function (window, document) {
    'use strict';

    if (window.SmsSettingsBridge) return;

    const state = { cache: null, nativeInitialized: false, syncing: null };

    function isNativeAndroid() {
        return typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform() &&
            (!Capacitor.getPlatform || Capacitor.getPlatform() === 'android');
    }
    function plugin() {
        if (!isNativeAndroid()) return null;
        return (Capacitor.Plugins || {}).TuaSmsSettings || null;
    }
    function store() {
        if (typeof SmsStore !== 'undefined') return SmsStore;
        return window.SmsStore || null;
    }
    // SmsStore لا يُحمَّل من localStorage إلا عند الطلب؛ لو كتبنا فوقه قبل ذلك ضاع السجل والاشتراك واختيار الشرائح.
    let hydrated = false;
    function ensureLoaded() {
        if (hydrated) return;
        hydrated = true;
        const st = store();
        if (st && typeof st.load === 'function') {
            try { st.load(); } catch (e) { console.warn('SmsSettingsBridge: SmsStore.load failed', e); }
        }
    }
    function validSlot(v) { return (typeof v === 'string' && /^(\d+|both)$/.test(v)) ? v : ''; }
    function notifyFail(message, detail) {
        state.lastError = message + (detail ? ' — ' + detail : '');
        console.error('SmsSettingsBridge:', state.lastError);
        if (typeof smsToast === 'function') { try { smsToast('⚠️ ' + message, 'warn'); } catch (e) {} }
    }

    function hasSubId(v) { return v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v)); }

    /* ---------- تحويل بين تمثيل الواجهة وتمثيل الأصلي ---------- */
    function simToInt(value, subId) {
        if (value === 'both') return -1;
        return hasSubId(subId) ? Number(subId) : -1;
    }
    function intToSim(subId, prevValue, prevSub, role) {
        const st = store();
        const sims = (st && st.data && st.data.detectedSims) || [];
        if (subId >= 0) {
            const i = sims.findIndex(function (s) { return Number(s.subscriptionId) === subId; });
            const slot = i >= 0 ? String((sims[i].simSlotIndex != null ? sims[i].simSlotIndex : i) + 1) : (prevValue || '1');
            return { value: slot, sub: String(subId) };
        }
        if (role === 'read') return { value: sims.length > 1 ? 'both' : (prevValue && prevValue !== 'both' ? prevValue : '1'), sub: null };
        return { value: prevValue || '1', sub: null };
    }

    function localSnapshot() {
        ensureLoaded();
        const st = store();
        const d = (st && st.data) || {};
        const s = d.settings || {};
        const sim = d.simSettings || {};
        return {
            autoProcess: s.autoProcess !== false,
            // الافتراضي false: لا نعتبره مفعّلاً إلا إذا كان true صراحةً
            processOld: s.processOld === true,
            readSim: simToInt(sim.readSim, sim.readSubscriptionId),
            sendSim: simToInt(sim.sendSim, sim.sendSubscriptionId),
            readSimSlot: validSlot(sim.readSim),
            sendSimSlot: validSlot(sim.sendSim),
            deviceId: d.deviceId || null
        };
    }

    /* ---------- تطبيق قيم الأصلي على SmsStore + الواجهة ---------- */
    function applyToStore(n) {
        ensureLoaded();
        const st = store();
        if (!st || !st.data || !n) return;
        const before = st.data.settings || {};
        st.data.settings = Object.assign({}, before, { autoProcess: !!n.autoProcess, processOld: !!n.processOld });

        const prev = st.data.simSettings || {};
        const r = intToSim(Number(n.readSim), prev.readSim, prev.readSubscriptionId, 'read');
        const s = intToSim(Number(n.sendSim), prev.sendSim, prev.sendSubscriptionId, 'send');
        // اسم الخيار الحقيقي (1 / 2 / both) محفوظ أصلياً؛ نفضّله على الاستنتاج من detectedSims (قد تكون غير محمّلة)
        st.data.simSettings = Object.assign({}, prev, {
            readSim: validSlot(n.readSimSlot) || r.value, readSubscriptionId: r.sub,
            sendSim: validSlot(n.sendSimSlot) || s.value, sendSubscriptionId: s.sub
        });
        if (n.deviceId) st.data.deviceId = n.deviceId;
        st.save();

        if (typeof smsUpdateBalanceDisplay === 'function') { try { smsUpdateBalanceDisplay(); } catch (e) {} }
        if (typeof smsLoadSavedSimSettings === 'function') { try { smsLoadSavedSimSettings(); } catch (e) {} }

        if (before.autoProcess === false && n.autoProcess === true) emitChange({ autoProcess: true });
    }

    function emitChange(detail) {
        try { window.dispatchEvent(new CustomEvent('sms-settings-changed', { detail: detail })); } catch (e) {}
    }

    /* ---------- قراءة من الأصلي (عند الفتح / الاستئناف) ---------- */
    async function sync() {
        const p = plugin();
        if (!p) return null;
        if (state.syncing) return state.syncing;
        ensureLoaded();
        state.syncing = (async function () {
            try {
                let n = await p.get();
                if (!n.initialized) {
                    // أول تشغيل بعد التحديث: ارفع اختيارات المستخدم الحالية بدل أن تُمحى بالقيم الافتراضية
                    const local = localSnapshot();
                    n = await p.set({
                        // processOld لا يُنقل من localStorage: القيمة القديمة هناك كانت true افتراضياً ولم يكن لها أي أثر،
                        // وترحيلها كان سيبدأ رفع 7 أيام من الرسائل فور التحديث. يبقى false حتى يفعّله المستخدم يدوياً.
                        autoProcess: local.autoProcess, processOld: false,
                        readSim: local.readSim, sendSim: local.sendSim,
                        readSimSlot: local.readSimSlot, sendSimSlot: local.sendSimSlot
                    });
                }
                state.cache = n;
                state.nativeInitialized = true;
                applyToStore(n);
                return n;
            } catch (error) {
                console.warn('SmsSettingsBridge.sync failed:', error);
                return null;
            } finally {
                state.syncing = null;
            }
        })();
        return state.syncing;
    }

    /* ---------- كتابة إلى الأصلي عند كل تغيير ---------- */
    async function push(partial) {
        const p = plugin();
        if (!p) {
            if (isNativeAndroid()) notifyFail('المكوّن الأصلي TuaSmsSettings غير مسجّل في MainActivity');
            return null;
        }
        try {
            // لا نكتب قبل أول مزامنة حتى لا تُستبدل اختيارات المستخدم القديمة بقيم افتراضية
            if (!state.nativeInitialized) await ready;
            const n = await p.set(partial);
            state.cache = n;
            // تحقق أن الأصلي خزّن فعلاً ما أرسلناه
            const bad = Object.keys(partial).filter(function (k) { return n[k] !== partial[k]; });
            if (bad.length) notifyFail('لم يُحفظ الإعداد في الجهاز', bad.join(', '));
            else state.lastError = null;
            emitChange(partial);
            return n;
        } catch (error) {
            notifyFail('تعذّر حفظ الإعداد في الجهاز', String(error && (error.message || error)));
            return null;
        }
    }

    function pushSims() {
        const l = localSnapshot();
        return push({ readSim: l.readSim, sendSim: l.sendSim, readSimSlot: l.readSimSlot, sendSimSlot: l.sendSimSlot });
    }

    /* ---------- قراءات سريعة للمستهلكين ---------- */
    function isAutoProcess() {
        if (state.cache) return state.cache.autoProcess !== false;
        const st = store();
        return !(st && st.data && st.data.settings && st.data.settings.autoProcess === false);
    }

    async function getSendSubscriptionId() {
        const p = plugin();
        if (p) {
            try { const n = await p.get(); state.cache = n; return Number(n.sendSim) >= 0 ? Number(n.sendSim) : null; }
            catch (e) { /* ننزل إلى النسخة المحلية */ }
        }
        const st = store();
        const sub = st && st.data && st.data.simSettings && st.data.simSettings.sendSubscriptionId;
        return hasSubId(sub) ? Number(sub) : null;
    }

    // للتشخيص من console: await SmsSettingsBridge.debug()
    async function debug() {
        const p = plugin();
        let native = null;
        try { native = p ? await p.get() : null; } catch (e) { native = { error: String(e) }; }
        return { native: native, local: localSnapshot(), cache: state.cache, lastError: state.lastError, hydrated: hydrated };
    }

    const ready = sync().then(function (n) { return n; }, function () { return null; });

    /* ---------- الاستئناف (resume) ---------- */
    function onResume() { sync(); }
    try {
        const App = (typeof Capacitor !== 'undefined' && Capacitor.Plugins) ? Capacitor.Plugins.App : null;
        if (App && typeof App.addListener === 'function') {
            App.addListener('appStateChange', function (st) { if (st && st.isActive) onResume(); });
            App.addListener('resume', onResume);
        }
    } catch (e) {}
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') onResume(); });

    window.SmsSettingsBridge = {
        ready: ready,
        sync: sync,
        push: push,
        pushSims: pushSims,
        isAutoProcess: isAutoProcess,
        getSendSubscriptionId: getSendSubscriptionId,
        debug: debug,
        get cache() { return state.cache; },
        get isNative() { return !!plugin(); }
    };
}(window, document));
