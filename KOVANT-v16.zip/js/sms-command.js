/* ============================================================
 * COVANT — SMS COMMAND
 * بناء أوامر العمليات المشفرة وإرسالها من جهاز المستخدم إلى الأدمن
 * ============================================================ */
(function (window) {
    'use strict';

    if (window.SMSCommand) return;

    const ADMIN_PHONE = '730598196';
    const PENDING_KEY = 'covant_sms_pending_commands_v1';
    const MAX_PENDING = 50;

    function value(value) { return String(value == null ? '' : value).trim(); }

    function generateSessionId() {
        const random = Math.random().toString(36).slice(2, 10).toUpperCase();
        return 'SMS-' + Date.now().toString(36).toUpperCase() + '-' + random;
    }

    function readPending() {
        try {
            const raw = window.localStorage.getItem(PENDING_KEY);
            const parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (error) { return []; }
    }

    function savePending(item) {
        const list = readPending().filter(function (entry) { return entry.sessionId !== item.sessionId; });
        list.push(Object.assign({}, item, { savedAt: Date.now(), status: 'pending' }));
        try { window.localStorage.setItem(PENDING_KEY, JSON.stringify(list.slice(-MAX_PENDING))); } catch (error) {}
        return item;
    }

    // مفتاح التشفير المحلي يُنشأ مرة واحدة لكل تثبيت للتطبيق.
    // ملاحظة: يجب حماية تخزين الجهاز نفسه (قفل الشاشة/Keystore) في نسخة Android.
    async function getLocalSecretKey() {
        if (!window.CryptoJS || !window.CryptoJS.lib || !window.CryptoJS.lib.WordArray) {
            throw new Error('مكتبة التشفير غير متاحة');
        }
        let key = window.localStorage.getItem('covant_secret_key');
        if (!key) {
            key = window.CryptoJS.lib.WordArray.random(256 / 8).toString();
            window.localStorage.setItem('covant_secret_key', key);
        }
        return key;
    }

    async function cacheSmsSecret(phone, secret) {
        const normalizedPhone = value(phone);
        const normalizedSecret = value(secret);
        if (!normalizedPhone || !normalizedSecret) throw new Error('بيانات مفتاح SMS غير صالحة');
        const key = await getLocalSecretKey();
        const encrypted = window.CryptoJS.AES.encrypt(normalizedSecret, key).toString();
        window.localStorage.setItem('covant_sms_secret_' + normalizedPhone, encrypted);
        return true;
    }

    async function getCachedSmsSecret(phone) {
        const encrypted = window.localStorage.getItem('covant_sms_secret_' + value(phone));
        if (!encrypted) return null;
        try {
            const key = await getLocalSecretKey();
            const decrypted = window.CryptoJS.AES.decrypt(encrypted, key).toString(window.CryptoJS.enc.Utf8);
            return value(decrypted) || null;
        } catch (error) {
            return null;
        }
    }

    async function getUserSecret(phone) {
        const normalizedPhone = value(phone);
        if (!normalizedPhone) return null;

        // الأولوية دائماً للنسخة المحلية حتى يعمل الجهاز دون إنترنت.
        const cached = await getCachedSmsSecret(normalizedPhone);
        if (cached) return cached;
        if (!window.navigator || !window.navigator.onLine) return null;
        if (!window.database || typeof window.database.ref !== 'function') return null;

        const secretRef = window.database.ref('users/' + normalizedPhone + '/sms_secret');
        const snapshot = await secretRef.once('value');
        let secret = value(snapshot.val());
        if (!secret) {
            if (!window.CryptoJS || !window.CryptoJS.lib || !window.CryptoJS.lib.WordArray) {
                throw new Error('مكتبة التشفير غير متاحة لإنشاء مفتاح SMS');
            }
            secret = window.CryptoJS.lib.WordArray.random(256 / 8).toString();
            await secretRef.set(secret);
        }
        await cacheSmsSecret(normalizedPhone, secret);
        return secret;
    }

    function hmac(data, secret) {
        if (!window.CryptoJS || !window.CryptoJS.HmacSHA256) throw new Error('مكتبة التشفير غير متاحة');
        return window.CryptoJS.HmacSHA256(data, secret).toString(window.CryptoJS.enc.Hex);
    }

    async function generateSignature(data, secret) {
        const key = secret || await getUserSecret(window.APP && window.APP.user && window.APP.user.phone);
        if (!key) throw new Error('مفتاح SMS غير متاح محلياً؛ اتصل بالإنترنت مرة واحدة لإعداده');
        return hmac(data, key);
    }

    async function sendNative(message) {
        const smsUrl = 'sms:' + ADMIN_PHONE + '?body=' + encodeURIComponent(String(message));
        window.location.href = smsUrl;
        return { success: true, method: 'system-sms-composer', number: ADMIN_PHONE };
    }

    async function buildAndSend(type, fields, fromPhone, secret) {
        const sessionId = generateSessionId();
        const timestamp = Date.now();
        const data = [type, sessionId].concat(fields.map(value)).concat([String(timestamp)]).join(':');
        const signature = await generateSignature(data, secret || await getUserSecret(fromPhone));
        const message = 'CVT:' + data + ':' + signature;
        await sendNative(message);
        savePending({ sessionId: sessionId, type: type, data: data, message: message, ts: timestamp, to: ADMIN_PHONE });
        return { success: true, sessionId: sessionId, message: message };
    }

    async function sendTransferSMS(from, to, amount) {
        return buildAndSend('TR', [from, to, amount], from);
    }

    async function sendCardPurchaseSMS(buyer, pkgId, count, recipient) {
        return buildAndSend('CR', [buyer, pkgId, count, recipient], buyer);
    }

    async function sendTopupSMS(phone, amount, bankRef) {
        return buildAndSend('TP', [phone, amount, bankRef], phone);
    }

    async function sendBalanceQuery(phone) {
        return buildAndSend('BQ', [phone], phone);
    }

    window.SMSCommand = {
        ADMIN_PHONE: ADMIN_PHONE,
        generateSessionId: generateSessionId,
        generateSignature: generateSignature,
        sendTransferSMS: sendTransferSMS,
        sendCardPurchaseSMS: sendCardPurchaseSMS,
        sendTopupSMS: sendTopupSMS,
        sendBalanceQuery: sendBalanceQuery,
        getLocalSecretKey: getLocalSecretKey,
        cacheSmsSecret: cacheSmsSecret,
        getCachedSmsSecret: getCachedSmsSecret,
        getUserSecret: getUserSecret,
        getPending: readPending,
        savePending: savePending
    };
}(window));
