/* ============================================================
   إدارة SMS — مدمجة ضمن لوحة الأدمن (كوفانت)
   جميع الأسماء مسبوقة بـ Sms/sms لتفادي أي تعارض مع باقي النظام
============================================================ */

const SmsStore = {
    KEY: 'koufant_sms_data_v1',

    data: {
        deviceId: null,
        smsBalance: 100,
        totalSmsPurchased: 100,
        smsSent: 0,
        smsFailed: 0,
        smsPending: 0,
        subscriptionEnd: null,
        settings: { autoProcess: true, processOld: false },
        simSettings: { readSim: '1', sendSim: '1', savedAt: null },
        smsLog: [],
        createdAt: null
    },

    load() {
        try {
            const saved = localStorage.getItem(this.KEY);
            if (saved) {
                const parsed = JSON.parse(saved);
                this.data = { ...this.data, ...parsed };
                if (this.data.subscriptionEnd && typeof this.data.subscriptionEnd === 'string') {
                    this.data.subscriptionEnd = new Date(this.data.subscriptionEnd);
                }
            } else {
                this.init();
            }
        } catch (e) {
            console.error('فشل تحميل بيانات SMS:', e);
            this.init();
        }
    },

    init() {
        this.data.deviceId = this.generateDeviceId();
        this.data.subscriptionEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        this.data.createdAt = new Date().toISOString();
        this.data.smsLog = [{
            id: this.uid(), type: 'received', phone: 'نظام',
            body: '🎉 تم تفعيل جهاز SMS — 100 رسالة مجانية',
            timestamp: new Date().toISOString()
        }];
        this.save();
    },

    save() {
        try {
            const toSave = { ...this.data };
            if (toSave.subscriptionEnd instanceof Date) toSave.subscriptionEnd = toSave.subscriptionEnd.toISOString();
            localStorage.setItem(this.KEY, JSON.stringify(toSave));
        } catch (e) { console.error('فشل حفظ بيانات SMS:', e); }
    },

    generateDeviceId() {
        return 'DEV-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    },
    uid() { return 'id_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8); },

    consumeSms(phone, body) {
        if (this.data.smsBalance <= 0) throw new Error('لا يوجد رصيد');
        this.data.smsBalance -= 1;
        this.data.smsSent = (this.data.smsSent || 0) + 1;
        const entry = { id: this.uid(), type: 'sent', phone, body, timestamp: new Date().toISOString() };
        this.data.smsLog.unshift(entry);
        if (this.data.smsLog.length > 500) this.data.smsLog = this.data.smsLog.slice(0, 500);
        this.save();
        return entry;
    },

    logFailed(phone, body, reason) {
        this.data.smsFailed = (this.data.smsFailed || 0) + 1;
        const entry = { id: this.uid(), type: 'failed', phone, body, reason, timestamp: new Date().toISOString() };
        this.data.smsLog.unshift(entry);
        this.save();
        return entry;
    },

    reset() { localStorage.removeItem(this.KEY); this.load(); },

    getSummary() {
        const subEnd = this.data.subscriptionEnd instanceof Date ? this.data.subscriptionEnd : new Date(this.data.subscriptionEnd);
        const daysLeft = Math.ceil((subEnd.getTime() - Date.now()) / 86400000);
        return {
            remaining: this.data.smsBalance || 0,
            total: this.data.totalSmsPurchased || 100,
            used: (this.data.totalSmsPurchased || 100) - (this.data.smsBalance || 0),
            daysLeft: Math.max(0, daysLeft),
            isExpired: daysLeft <= 0,
            isLow: this.data.smsBalance > 0 && this.data.smsBalance <= 10,
            isZero: this.data.smsBalance === 0,
            subscriptionEnd: subEnd,
            deviceId: this.data.deviceId,
            smsSent: this.data.smsSent || 0,
            smsFailed: this.data.smsFailed || 0,
            smsPending: this.data.smsPending || 0
        };
    }
};

// SmsStore معرَّف بـ const فلا يظهر على window تلقائياً — الملفات الأخرى تقرأ window.SmsStore
window.SmsStore = SmsStore;

let smsCurrentView = 'main';
let smsFilter = 'all';
let smsPermissionGranted = false;
let smsAutoCommands = [];
let smsAutoCommandsListenerAttached = false;
let smsAutoRefreshTimer = null;
let smsRawInboxListenerAttached = false;

/* ============================================================
   العمليات التلقائية — قراءة وعرض أوامر SMS المنفذة آلياً
   لا يتم عرض نص SMS الخام أو الأسرار الحساسة في هذه الشاشة.
============================================================ */
function smsAutoEscape(value) {
    if (typeof esc === 'function') return esc(value);
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
    });
}

function smsAutoTimestamp(command) {
    return Number(command && (command.executedAt || command.receivedAt || command.ts || command.timestamp)) || 0;
}

function smsAutoTypeLabel(command) {
    const code = String(command && (command.code || command.type) || '').toUpperCase();
    return ({ TR: 'تحويل', CR: 'شراء كروت', TP: 'تغذية', BQ: 'استعلام رصيد' })[code] || code || 'عملية SMS';
}

function smsAutoStatus(command) {
    const status = String(command && command.status || '').toLowerCase();
    return {
        pending: { label: 'معلقة', className: 'pending', icon: 'fa-clock' },
        processing: { label: 'قيد التنفيذ', className: 'pending', icon: 'fa-spinner' },
        executed: { label: 'منفذة', className: '', icon: 'fa-circle-check' },
        rejected: { label: 'مرفوضة', className: 'failed', icon: 'fa-circle-xmark' }
    }[status] || { label: status || 'غير معروفة', className: 'failed', icon: 'fa-circle-question' };
}

function loadAutoStats() {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const stats = smsAutoCommands.reduce(function (result, command) {
        const status = String(command.status || '').toLowerCase();
        if (status === 'pending' || status === 'processing') result.pending += 1;
        if (status === 'rejected') result.rejected += 1;
        if (status === 'executed' && smsAutoTimestamp(command) >= todayStart.getTime()) result.executedToday += 1;
        return result;
    }, { pending: 0, executedToday: 0, rejected: 0 });

    const pendingEl = document.getElementById('autoStatPending');
    const executedEl = document.getElementById('autoStatExecuted');
    const rejectedEl = document.getElementById('autoStatRejected');
    if (pendingEl) pendingEl.textContent = stats.pending;
    if (executedEl) executedEl.textContent = stats.executedToday;
    if (rejectedEl) rejectedEl.textContent = stats.rejected;
    return stats;
}

function renderAutoCommands() {
    const list = document.getElementById('autoCommandsList');
    if (!list) return;
    const commands = smsAutoCommands.slice().sort((a, b) => smsAutoTimestamp(b) - smsAutoTimestamp(a)).slice(0, 20);
    if (!commands.length) {
        list.innerHTML = '<div class="empty-state"><i class="fa-solid fa-inbox"></i><p>لا توجد عمليات تلقائية بعد</p></div>';
        return;
    }

    list.innerHTML = commands.map(function (command) {
        const state = smsAutoStatus(command);
        const ts = smsAutoTimestamp(command) ? new Date(smsAutoTimestamp(command)) : null;
        const time = ts ? ts.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' }) : '—';
        const date = ts ? ts.toLocaleDateString('ar-YE') : '—';
        const phone = command.from || command.phone || command.buyer || '—';
        const target = command.to || command.recipient || command.bankRef || '—';
        const amount = command.amount != null ? `${smsAutoEscape(command.amount)} ريال` : '—';
        const signature = command.sig ? '✅' : '—';
        return `<div class="sms-item ${state.className}">
            <div class="sms-item-header">
                <div class="sms-item-status"><i class="fa-solid ${state.icon}"></i><span class="sms-item-status-text">${smsAutoEscape(state.label)} — ${smsAutoEscape(smsAutoTypeLabel(command))}</span></div>
                <div class="sms-item-time">${smsAutoEscape(time)}</div>
            </div>
            <div class="sms-item-phone"><i class="fa-solid fa-user"></i> ${smsAutoEscape(phone)}</div>
            <div class="sms-item-body">إلى: ${smsAutoEscape(target)}<br>المبلغ: ${amount}</div>
            <div class="sms-item-footer"><span><i class="fa-regular fa-calendar"></i> ${smsAutoEscape(date)}</span><span>التوقيع: ${signature}</span></div>
        </div>`;
    }).join('');
}

async function loadAutoCommands() {
    if (!window.database || typeof window.database.ref !== 'function') return [];
    try {
        const snapshot = await window.database.ref('sms_commands').limitToLast(100).once('value');
        const value = snapshot.val() || {};
        smsAutoCommands = Object.keys(value).map(id => Object.assign({ id: id }, value[id] || {}));
        loadAutoStats();
        renderAutoCommands();
        return smsAutoCommands;
    } catch (error) {
        console.error('❌ فشل تحميل العمليات التلقائية:', error);
        return [];
    }
}

function listenToRawSMSInbox() {
    if (smsRawInboxListenerAttached || !window.database || typeof window.database.ref !== 'function') return;
    smsRawInboxListenerAttached = true;
    window.database.ref('sms_raw_inbox').limitToLast(100).on('child_added', async function (snapshot) {
        const raw = snapshot.val() || {};
        if (raw.processed === true) return;
        const text = raw.body || raw.message || raw.text;
        if (!text || !window.SMSAutoProcessor || typeof window.SMSAutoProcessor.processIncomingSMS !== 'function') return;
        try {
            await window.SMSAutoProcessor.processIncomingSMS({ body: text, sender: raw.sender || null, timestamp: raw.timestamp || Date.now() });
            await snapshot.ref.update({ processed: true, processedAt: Date.now() });
        } catch (error) {
            console.error('❌ فشل معالجة SMS الخام:', error);
            await snapshot.ref.update({ processingError: error.message || 'failed', processingErrorAt: Date.now() });
        }
    }, function (error) {
        smsRawInboxListenerAttached = false;
        console.error('❌ فشل مراقبة sms_raw_inbox:', error);
    });
}

function smsAttachAutoCommandsListener() {
    if (smsAutoCommandsListenerAttached || !window.database || typeof window.database.ref !== 'function') return;
    smsAutoCommandsListenerAttached = true;
    window.database.ref('sms_commands').limitToLast(100).on('value', function (snapshot) {
        const value = snapshot.val() || {};
        smsAutoCommands = Object.keys(value).map(id => Object.assign({ id: id }, value[id] || {}));
        loadAutoStats();
        renderAutoCommands();
    }, function (error) {
        console.error('❌ فشل مراقبة العمليات التلقائية:', error);
    });
}

function smsStartAutoRefresh() {
    if (smsAutoRefreshTimer) return;
    smsAutoRefreshTimer = setInterval(function () {
        loadAutoCommands();
    }, 30000);
}

function smsToast(message, type) {
    type = type || 'success';
    const colors = { success: '#3b82f6', error: '#ef4444', warn: '#f59e0b', info: '#94a3b8' };
    const toast = document.createElement('div');
    toast.textContent = message;
    Object.assign(toast.style, {
        position: 'fixed', bottom: '100px', left: '50%', transform: 'translateX(-50%)',
        background: colors[type] || colors.success, color: '#fff',
        padding: '12px 24px', borderRadius: '12px', fontSize: '13px', fontWeight: '700',
        fontFamily: 'Cairo, sans-serif', zIndex: '9999', boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
        maxWidth: '85%', textAlign: 'center', whiteSpace: 'pre-line', opacity: '0', transition: 'opacity .3s'
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.style.opacity = '1');
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3000);
}

/* ============================================================
   التنقل الداخلي (يعمل فوق صفحة smsManagementInterface الرئيسية)
============================================================ */
function smsGoTo(view) {
    smsCurrentView = view;

    document.querySelectorAll('#smsManagementInterface .sms-subpage').forEach(el => el.classList.remove('active'));
    const target = document.getElementById('smsSub-' + view);
    if (target) target.classList.add('active');

    const titles = { main: 'إدارة SMS', auto: 'العمليات التلقائية', log: 'سجل الرسائل', settings: 'إعدادات SMS', sim: 'إعدادات شرائح الاتصال' };
    const titleEl = document.getElementById('smsPageTitle');
    if (titleEl) titleEl.textContent = titles[view] || 'إدارة SMS';

    const backBtn = document.getElementById('smsBackBtn');
    if (backBtn) {
        if (view === 'sim') backBtn.onclick = function () { smsGoTo('settings'); };
        else backBtn.onclick = function () { navigateTo('adminSystemInterface', true); };
    }

    const nav = document.getElementById('smsBottomNav');
    if (nav) nav.style.setProperty('display', (view === 'sim') ? 'none' : 'flex', 'important');
    document.querySelectorAll('#smsBottomNav .nav-btn').forEach(b => b.classList.remove('active'));
    const navMap = { main: 0, auto: 1, log: 2, settings: 4 };
    if (view in navMap) document.querySelectorAll('#smsBottomNav .nav-btn')[navMap[view]]?.classList.add('active');

    if (view === 'main' || view === 'settings') smsUpdateBalanceDisplay();
    // عند فتح الإعدادات: اقرأ القيم الحقيقية من SharedPreferences وحدّث الأزرار بعد وصول الرد (وليس قبله)
    if (view === 'settings' && window.SmsSettingsBridge) window.SmsSettingsBridge.sync();
    if (view === 'auto') { loadAutoCommands(); loadAutoStats(); renderAutoCommands(); }
    if (view === 'log') smsRenderLog();
    if (view === 'sim') smsRenderSimState();

    const content = document.querySelector('#smsManagementInterface .page-content');
    if (content) content.scrollTop = 0;
}

/* ============================================================
   معرّف الجهاز
============================================================ */
function smsCopyDeviceId() {
    const id = SmsStore.data.deviceId;
    navigator.clipboard.writeText(id).then(() => {
        smsToast('✅ تم نسخ معرّف الجهاز', 'success');
    }).catch(() => {
        const t = document.createElement('textarea');
        t.value = id; document.body.appendChild(t); t.select();
        document.execCommand('copy'); t.remove();
        smsToast('✅ تم نسخ معرّف الجهاز', 'success');
    });
}

function smsResetDevice() {
    if (!confirm('⚠️ هل تريد إعادة تعيين جهاز SMS؟\nسيتم حذف كل البيانات نهائياً.')) return;
    if (!confirm('هل أنت متأكد؟ لا يمكن التراجع!')) return;
    SmsStore.reset();
    if (window.SmsSettingsBridge) {
        // أعد الإعدادات الأصلية للقيم الافتراضية ثم اقرأها (معرّف الجهاز يبقى ANDROID_ID)
        window.SmsSettingsBridge.push({ autoProcess: true, processOld: false, readSim: -1, sendSim: -1 })
            .then(function () { return window.SmsSettingsBridge.sync(); });
    }
    smsToast('✅ تمت إعادة التعيين', 'success');
    smsUpdateBalanceDisplay();
    smsGoTo('settings');
}

/* ============================================================
   الشرائح
============================================================ */
async function smsGrantPermission() {
    const isNative = typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform();

    if (isNative && typeof tuaDetectRealSims === 'function') {
        const result = await tuaDetectRealSims();
        if (!result) { // احتياط: مش المفروض يوصل هنا لأننا فحصنا isNative فوق
            smsToast('⚠️ تعذر الوصول لبيانات الشريحة', 'error');
            return;
        }
        if (result.installed === false) {
            smsToast('⚠️ مكوّن قراءة الشرائح غير مثبت — راجع CAPACITOR-README.md', 'error');
            return;
        }
        if (result.denied) {
            smsToast('🚫 تم رفض صلاحية قراءة حالة الهاتف', 'error');
            return;
        }
        SmsStore.data.detectedSims = result.simCards;
        SmsStore.save();
        smsPermissionGranted = true;
        smsRenderSimState();
        smsToast('✅ تم منح الصلاحية', 'success');
    } else {
        // خارج تطبيق Capacitor (متصفح/PWA) — معاينة فقط، مفيش صلاحية حقيقية تُطلب
        smsPermissionGranted = true;
        SmsStore.data.detectedSims = null; // null = وضع معاينة، استخدم الخيارات الثابتة الموجودة في index.html
        smsRenderSimState();
        smsToast('✅ تم منح الصلاحية (معاينة داخل المتصفح — بدون جهاز فعلي)', 'success');
    }
}

function smsRenderSimState() {
    const perm = document.getElementById('sms-sim-permission-state');
    const list = document.getElementById('sms-sim-list-state');
    if (!perm || !list) return;
    if (smsPermissionGranted) {
        perm.style.display = 'none';
        list.style.display = 'block';
        smsRenderDetectedSimBanner();
        smsRenderSimOptions();
        smsLoadSavedSimSettings();
    } else {
        perm.style.display = 'flex';
        list.style.display = 'none';
    }
}

/* ============================================================
   بانر عدد الشرائح الحقيقي — يستبدل النص الثابت
============================================================ */
function smsRenderDetectedSimBanner() {
    const banner = document.querySelector('#sms-sim-list-state .sms-warning-banner span');
    if (!banner) return;
    const sims = SmsStore.data.detectedSims;
    if (!sims) { banner.textContent = 'وضع المعاينة — لا يوجد جهاز فعلي متصل حالياً.'; return; }
    if (sims.length === 0) banner.textContent = '⚠️ لم يتم العثور على أي شريحة اتصال على الجهاز.';
    else if (sims.length === 1) banner.textContent = `تم اكتشاف شريحة واحدة فقط على الجهاز${sims[0].carrierName ? ' (' + sims[0].carrierName + ')' : ''}.`;
    else banner.textContent = `تم اكتشاف ${sims.length} شرائح على الجهاز.`;
}

/* ============================================================
   بناء خيارات الشرائح ديناميكياً من البيانات الحقيقية
   (لو detectedSims = null، يعني وضع معاينة، فنسيب الخيارات
   الثابتة الموجودة أصلاً في index.html زي ما هي)
============================================================ */
function smsRenderSimOptions() {
    const sims = SmsStore.data.detectedSims;
    if (!sims) return;

    ['read', 'send'].forEach(role => {
        const anyOption = document.querySelector(`#sms-sim-list-state .sim-option[data-role="${role}"]`);
        const container = anyOption ? anyOption.parentElement : null;
        if (!container) return;
        container.querySelectorAll('.sim-option').forEach(el => el.remove());

        sims.forEach((sim, idx) => {
            const value = String((sim.simSlotIndex != null ? sim.simSlotIndex : idx) + 1);
            const label = sim.carrierName ? `شريحة ${value} — ${sim.carrierName}` : `شريحة ${value}`;
            const div = document.createElement('div');
            div.className = 'sim-option' + (idx === 0 ? ' active' : '');
            div.dataset.role = role;
            div.dataset.value = value;
            if (sim.subscriptionId != null) div.dataset.subscriptionId = String(sim.subscriptionId);
            div.onclick = function () { smsSelectSimOption(div); };
            div.innerHTML = `<div class="sim-option-right"><div class="sim-icon-box"><i class="fa-solid fa-sim-card"></i></div><div class="sim-option-text"><h4>${esc(label)}</h4><p>${role === 'read' ? 'يُستقبل عليها الرسائل' : 'يُرسل عبرها الرسائل'}</p></div></div><div class="sim-radio"></div>`;
            container.appendChild(div);
        });

        if (sims.length > 1) {
            const div = document.createElement('div');
            div.className = 'sim-option';
            div.dataset.role = role;
            div.dataset.value = 'both';
            div.onclick = function () { smsSelectSimOption(div); };
            div.innerHTML = `<div class="sim-option-right"><div class="sim-icon-box"><i class="fa-solid fa-sim-card"></i></div><div class="sim-option-text"><h4>كلا الشريحتين</h4><p>النظام سيتعامل مع كلا الشريحتين</p></div></div><div class="sim-radio"></div>`;
            container.appendChild(div);
        }
    });
}

function smsSelectSimOption(el) {
    const role = el.dataset.role;
    if (!role) return;
    document.querySelectorAll(`#smsManagementInterface .sim-option[data-role="${role}"]`).forEach(o => o.classList.remove('active'));
    el.classList.add('active');
}

function smsSaveSimSettings() {
    const readEl = document.querySelector('#smsManagementInterface .sim-option[data-role="read"].active');
    const sendEl = document.querySelector('#smsManagementInterface .sim-option[data-role="send"].active');
    if (!readEl || !sendEl) { smsToast('اختر شريحة القراءة والإرسال', 'warn'); return; }

    SmsStore.data.simSettings = {
        readSim: readEl.dataset.value,
        readSubscriptionId: readEl.dataset.subscriptionId || null,
        sendSim: sendEl.dataset.value,
        sendSubscriptionId: sendEl.dataset.subscriptionId || null,
        savedAt: new Date().toISOString()
    };
    SmsStore.save();
    if (window.SmsSettingsBridge) window.SmsSettingsBridge.pushSims();
    smsUpdateSimHint();
    smsToast('✅ تم حفظ إعدادات الشرائح', 'success');
}

function smsLoadSavedSimSettings() {
    const s = SmsStore.data.simSettings;
    if (!s) return;
    const readEl = document.querySelector(`#smsManagementInterface .sim-option[data-role="read"][data-value="${s.readSim}"]`);
    const sendEl = document.querySelector(`#smsManagementInterface .sim-option[data-role="send"][data-value="${s.sendSim}"]`);
    if (readEl) { document.querySelectorAll('#smsManagementInterface .sim-option[data-role="read"]').forEach(o => o.classList.remove('active')); readEl.classList.add('active'); }
    if (sendEl) { document.querySelectorAll('#smsManagementInterface .sim-option[data-role="send"]').forEach(o => o.classList.remove('active')); sendEl.classList.add('active'); }
}

function smsUpdateSimHint() {
    const s = SmsStore.data.simSettings;
    const el = document.getElementById('smsSimHint');
    if (!el || !s) return;
    const label = v => v === 'both' ? 'كلا الشريحتين' : `شريحة ${v}`;
    el.textContent = `قراءة: ${label(s.readSim)} — إرسال: ${label(s.sendSim)}`;
}

/* ============================================================
   عرض البيانات
============================================================ */
function smsUpdateBalanceDisplay() {
    const s = SmsStore.getSummary();

    const devText = document.getElementById('smsDeviceIdText');
    if (devText) devText.textContent = s.deviceId;

    const smsEl = document.getElementById('smsMainRemaining');
    if (smsEl) {
        smsEl.textContent = s.remaining;
        smsEl.style.color = (s.isZero || s.isExpired) ? 'var(--red)' : ((s.isLow || s.daysLeft <= 7) ? 'var(--orange)' : '#58b8e8');
    }

    const usedEl = document.getElementById('smsMainUsed'); if (usedEl) usedEl.textContent = s.used;
    const totalEl = document.getElementById('smsMainTotal'); if (totalEl) totalEl.textContent = s.total;

    const barEl = document.getElementById('smsMainBar');
    if (barEl) {
        const pct = s.total > 0 ? Math.round((s.remaining / s.total) * 100) : 0;
        barEl.style.width = pct + '%';
        barEl.style.background = s.isZero ? 'var(--red)' : (s.isLow ? 'var(--orange)' : 'var(--blue)');
    }

    const subEl = document.getElementById('smsMainSubDate');
    if (subEl) {
        if (s.isExpired) subEl.innerHTML = '⚠️ انتهى الاشتراك';
        else if (s.daysLeft <= 7) subEl.innerHTML = `⏰ ينتهي خلال ${s.daysLeft} يوم`;
        else subEl.textContent = `الاشتراك حتى ${s.subscriptionEnd.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}`;
    }

    const sentEl = document.getElementById('smsStatSent'); if (sentEl) sentEl.textContent = s.smsSent;
    const failEl = document.getElementById('smsStatFailed'); if (failEl) failEl.textContent = s.smsFailed;
    const pendEl = document.getElementById('smsStatPending'); if (pendEl) pendEl.textContent = s.smsPending;

    const todayEl = document.getElementById('smsStatToday');
    if (todayEl) {
        const today = SmsStore.data.smsLog.filter(x => Date.now() - new Date(x.timestamp).getTime() < 86400000).length;
        todayEl.textContent = today;
    }

    const warnEl = document.getElementById('smsBalanceWarning');
    if (warnEl) {
        if (s.isLow || (s.daysLeft > 0 && s.daysLeft <= 7)) {
            warnEl.classList.add('show');
            const t = document.getElementById('smsBalanceWarningText');
            if (t) t.textContent = s.isLow ? `رصيد الرسائل منخفض (متبقي ${s.remaining})` : `اشتراكك ينتهي خلال ${s.daysLeft} يوم`;
        } else warnEl.classList.remove('show');
    }

    const dangerEl = document.getElementById('smsBalanceDanger');
    if (dangerEl) { if (s.isZero || s.isExpired) dangerEl.classList.add('show'); else dangerEl.classList.remove('show'); }

    const setBal = document.getElementById('smsSettingsBalance'); if (setBal) setBal.textContent = s.remaining;
    const setUsed = document.getElementById('smsSettingsUsed'); if (setUsed) setUsed.textContent = s.used;
    const setTotal = document.getElementById('smsSettingsTotal'); if (setTotal) setTotal.textContent = s.total;
    const setBar = document.getElementById('smsSettingsBar');
    if (setBar) {
        const pct = s.total > 0 ? Math.round((s.remaining / s.total) * 100) : 0;
        setBar.style.width = pct + '%';
        setBar.style.background = s.isZero ? 'var(--red)' : (s.isLow ? 'var(--orange)' : 'var(--blue)');
    }

    const autoT = document.getElementById('smsAutoProcessToggle'); if (autoT) autoT.checked = SmsStore.data.settings?.autoProcess !== false;
    const oldT = document.getElementById('smsProcessOldToggle'); if (oldT) oldT.checked = SmsStore.data.settings?.processOld === true;

    smsUpdateSimHint();
    if (typeof smsYouRenderStatus === 'function') smsYouRenderStatus();
}

/* ============================================================
   سجل الرسائل
============================================================ */
function smsRenderLog() {
    const list = document.getElementById('sms-list');
    if (!list) return;

    const search = document.getElementById('smsSearch')?.value || '';
    let filtered = [...SmsStore.data.smsLog];
    if (smsFilter !== 'all') filtered = filtered.filter(s => s.type === smsFilter);
    if (search) {
        const q = search.toLowerCase();
        filtered = filtered.filter(s => (s.phone || '').includes(q) || (s.body || '').toLowerCase().includes(q));
    }

    if (filtered.length === 0) {
        list.innerHTML = `<div class="empty-state"><i class="fa-solid fa-inbox"></i><p>لا توجد رسائل</p></div>`;
        return;
    }

    list.innerHTML = filtered.map(s => {
        const ts = new Date(s.timestamp);
        const dateStr = ts.toLocaleDateString('ar-EG');
        const timeStr = ts.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        const statusClass = s.type === 'sent' ? '' : (s.type === 'failed' ? 'failed' : (s.type === 'received' ? 'received' : 'pending'));
        const statusIcon = s.type === 'sent' ? 'fa-circle-check' : (s.type === 'failed' ? 'fa-circle-xmark' : (s.type === 'received' ? 'fa-arrow-down' : 'fa-clock'));
        const statusText = s.type === 'sent' ? 'مُرسلة' : (s.type === 'failed' ? 'فاشلة' : (s.type === 'received' ? 'مستقبلة' : 'قيد الإرسال'));
        return `
            <div class="sms-item ${statusClass}">
                <div class="sms-item-header">
                    <div class="sms-item-status"><i class="fa-solid ${statusIcon}"></i><span class="sms-item-status-text">${statusText}</span></div>
                    <div class="sms-item-time">${timeStr}</div>
                </div>
                <div class="sms-item-phone"><i class="fa-solid fa-phone"></i> ${s.phone || '—'}</div>
                <div class="sms-item-body">${s.body || '—'}</div>
                <div class="sms-item-footer">
                    <span><i class="fa-regular fa-calendar"></i> ${dateStr}</span>
                    ${s.reason ? `<span style="color:#ff9aa2"><i class="fa-solid fa-circle-info"></i> ${s.reason}</span>` : ''}
                </div>
            </div>`;
    }).join('');
}

function smsSetFilter(btn) {
    document.querySelectorAll('#smsManagementInterface .sms-filter-chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    smsFilter = btn.dataset.filter;
    smsRenderLog();
}

/* ============================================================
   إرسال SMS تجريبي
============================================================ */
async function smsSendTest() {
    const s = SmsStore.getSummary();
    if (s.isZero) { smsToast('❌ لا يوجد رصيد رسائل', 'error'); return; }
    if (s.isExpired) { smsToast('❌ انتهى الاشتراك', 'error'); return; }

    const phone = prompt('📱 أدخل رقم الجوال:', '+967771234567');
    if (!phone || phone.length < 9) { if (phone !== null) smsToast('رقم الجوال غير صحيح', 'error'); return; }

    const body = prompt('💬 أدخل نص الرسالة:', 'مرحباً من كوفانت — رسالة تجريبية');
    if (!body || body.length < 2) { if (body !== null) smsToast('النص قصير جداً', 'error'); return; }

    const simInfo = SmsStore.data.simSettings;
    const simLabel = simInfo ? (simInfo.sendSim === 'both' ? 'كلا الشريحتين' : `شريحة ${simInfo.sendSim}`) : 'شريحة 1';
    const isNative = typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform();

    // ============================================================
    // داخل تطبيق Capacitor حقيقي: إرسال فعلي عبر مكوّن TuaSmsSender
    // ============================================================
    if (isNative && typeof tuaSendRealSms === 'function') {
        smsToast(`جارٍ الإرسال فعلياً عبر ${simLabel}...`, 'info');
        try {
            let subId = simInfo && simInfo.sendSubscriptionId ? simInfo.sendSubscriptionId : null;
            if (subId == null && window.SmsSettingsBridge) subId = await window.SmsSettingsBridge.getSendSubscriptionId();
            await tuaSendRealSms(phone, body, subId);
            SmsStore.consumeSms(phone, body);
            smsToast(`✅ تم الإرسال فعلياً — متبقي ${SmsStore.data.smsBalance}`, 'success');
        } catch (e) {
            SmsStore.logFailed(phone, body, e.message || 'فشل الإرسال');
            smsToast('❌ فشل الإرسال الفعلي: ' + (e && e.message ? e.message : ''), 'error');
        }
        smsUpdateBalanceDisplay();
        if (smsCurrentView === 'log') smsRenderLog();
        return;
    }

    // ============================================================
    // خارج تطبيق Capacitor (متصفح/PWA): معاينة/محاكاة فقط — لا يُرسل شيء فعلياً
    // ============================================================
    smsToast(`(معاينة) جارٍ الإرسال عبر ${simLabel}...`, 'info');
    setTimeout(() => {
        try {
            const shouldFail = Math.random() < 0.05;
            if (shouldFail) {
                SmsStore.logFailed(phone, body, 'محاكاة فشل الإرسال (معاينة)');
                smsToast('❌ فشل الإرسال (معاينة)', 'error');
            } else {
                SmsStore.consumeSms(phone, body);
                smsToast(`✅ تم الإرسال (معاينة) — متبقي ${SmsStore.data.smsBalance}`, 'success');
            }
            smsUpdateBalanceDisplay();
            if (smsCurrentView === 'log') smsRenderLog();
        } catch (e) {
            smsToast('❌ ' + e.message, 'error');
        }
    }, 600);
}

/* ============================================================
   الإعدادات
============================================================ */
function smsToggleSetting(key, value) {
    SmsStore.data.settings[key] = value;
    SmsStore.save();
    // كتابة مزدوجة: localStorage (فوق) + SharedPreferences الأصلية
    if (window.SmsSettingsBridge) window.SmsSettingsBridge.push({ [key]: !!value });
    smsToast(value ? '✅ تم التفعيل' : '⭕ تم التعطيل', 'success');
}

function smsRefresh() {
    smsToast('جارٍ التحديث...', 'info');
    if (typeof smsYouSync === 'function') smsYouSync(false);
    setTimeout(() => {
        smsUpdateBalanceDisplay();
        if (smsCurrentView === 'log') smsRenderLog();
        if (smsCurrentView === 'sim') smsRenderSimState();
        smsToast('✅ تم التحديث', 'success');
    }, 300);
}

/* ============================================================
   نقطة الدخول — تُستدعى من navigateTo() في router.js
============================================================ */
function loadSmsManagementAdmin() {
    if (!SmsStore.data.deviceId) SmsStore.load();
    // اقرأ الإعدادات الحقيقية من SharedPreferences عند فتح الصفحة
    if (window.SmsSettingsBridge) window.SmsSettingsBridge.sync();
    smsAttachAutoCommandsListener();
    listenToRawSMSInbox();
    smsStartAutoRefresh();
    smsGoTo('main');
    if (typeof smsYouSync === 'function') smsYouSync(false);
}


/* ============================================================
   عرض SMS من Firebase — طبقة البيانات الحقيقية
   لا تستخدم أرقام localStorage للإحصائيات أو السجل.
   ============================================================ */
(function installFirebaseSmsDashboard(window, document) {
    'use strict';

    var realSmsState = {
        queue: {},
        inbox: {},
        commands: {},
        listenersAttached: false,
        refreshTimer: null
    };

    function realSmsDb() {
        return window.database && typeof window.database.ref === 'function' ? window.database : null;
    }

    function realSmsSet(id, value) {
        var el = document.getElementById(id);
        if (el) el.textContent = value == null ? '—' : String(value);
    }

    function realSmsTime(value) {
        var ts = Number(value) || 0;
        return ts ? new Date(ts).toLocaleString('ar-YE', { dateStyle: 'short', timeStyle: 'short' }) : '—';
    }

    function realSmsTodayStart() {
        var d = new Date();
        d.setHours(0, 0, 0, 0);
        return d.getTime();
    }

    function realSmsValues(value) {
        return value && typeof value === 'object' ? Object.keys(value).map(function (key) {
            return Object.assign({ id: key }, value[key] || {});
        }) : [];
    }

    function realSmsStats() {
        var queue = realSmsValues(realSmsState.queue);
        var inbox = realSmsValues(realSmsState.inbox);
        var commands = realSmsValues(realSmsState.commands);
        var today = realSmsTodayStart();
        var stats = { sent: 0, failed: 0, pending: 0, sentToday: 0, received: inbox.length, executed: 0, rejected: 0 };

        queue.forEach(function (msg) {
            var status = String(msg.status || '').toLowerCase();
            if (status === 'sent') {
                stats.sent += 1;
                if (Number(msg.sentAt || msg.updatedAt || msg.createdAt) >= today) stats.sentToday += 1;
            } else if (status === 'failed') {
                stats.failed += 1;
            } else if (status === 'pending' || status === 'sending') {
                stats.pending += 1;
            }
        });
        commands.forEach(function (cmd) {
            var status = String(cmd.status || '').toLowerCase();
            if (status === 'executed') stats.executed += 1;
            if (status === 'rejected') stats.rejected += 1;
        });
        return stats;
    }

    function realSmsRenderStats() {
        var stats = realSmsStats();
        realSmsSet('smsStatSent', stats.sent);
        realSmsSet('smsStatFailed', stats.failed);
        realSmsSet('smsStatToday', stats.sentToday);
        realSmsSet('smsStatPending', stats.pending);

        // إجمالي الاستخدام الحقيقي من الطابور؛ لا نفترض حصة 300 أو 100 رسالة.
        var total = stats.sent + stats.failed + stats.pending;
        realSmsSet('smsMainUsed', stats.sent);
        realSmsSet('smsMainTotal', total);
        realSmsSet('smsSettingsUsed', stats.sent);
        realSmsSet('smsSettingsTotal', total);

        // لا يوجد مسار Firebase للحصة/الرصيد في المشروع؛ لا تعرض قيمة وهمية.
        var remaining = document.getElementById('smsMainRemaining');
        var settingsBalance = document.getElementById('smsSettingsBalance');
        if (remaining) remaining.textContent = '—';
        if (settingsBalance) settingsBalance.textContent = '—';
        var source = document.getElementById('smsBalanceSource');
        if (source) source.textContent = 'الإحصائيات من Firebase — رصيد الشريحة يحدّث من رسائل المشغل';

        var bar = document.getElementById('smsMainBar');
        if (bar) {
            var denominator = Math.max(total, 1);
            bar.style.width = Math.min(100, Math.round((stats.sent / denominator) * 100)) + '%';
        }
        return stats;
    }

    async function loadRealSmsStats() {
        var db = realSmsDb();
        if (!db) return null;
        try {
            var results = await Promise.all([
                db.ref('sms_queue').once('value'),
                db.ref('sms_raw_inbox').once('value'),
                db.ref('sms_commands').once('value')
            ]);
            realSmsState.queue = results[0].val() || {};
            realSmsState.inbox = results[1].val() || {};
            realSmsState.commands = results[2].val() || {};
            return realSmsRenderStats();
        } catch (error) {
            console.error('❌ فشل تحميل إحصائيات SMS من Firebase:', error);
            return null;
        }
    }

    function realSmsLogEntries() {
        var entries = [];
        realSmsValues(realSmsState.queue).forEach(function (msg) {
            var status = String(msg.status || '').toLowerCase();
            var type = status === 'sent' ? 'sent' : (status === 'failed' ? 'failed' : 'pending');
            entries.push({
                id: msg.id,
                type: type,
                label: type === 'sent' ? 'مُرسلة' : (type === 'failed' ? 'فاشلة' : 'قيد الإرسال'),
                icon: type === 'sent' ? 'fa-circle-check' : (type === 'failed' ? 'fa-circle-xmark' : 'fa-clock'),
                phone: msg.to || '—',
                body: msg.message || '—',
                timestamp: msg.sentAt || msg.updatedAt || msg.createdAt || 0,
                attempts: msg.attempts || 0,
                reason: msg.lastError || ''
            });
        });
        realSmsValues(realSmsState.inbox).forEach(function (msg) {
            entries.push({
                id: msg.id,
                type: 'received',
                label: msg.processed ? 'مستقبلة / معالجة' : 'مستقبلة / غير معالجة',
                icon: msg.processed ? 'fa-circle-check' : 'fa-arrow-down',
                phone: msg.sender || '—',
                body: msg.body || msg.message || '—',
                timestamp: msg.timestamp || 0,
                attempts: 0,
                reason: msg.processingError || ''
            });
        });
        return entries.sort(function (a, b) { return Number(b.timestamp) - Number(a.timestamp); });
    }

    function realSmsRenderLog() {
        var list = document.getElementById('sms-list');
        if (!list) return;
        var entries = realSmsLogEntries();
        var searchEl = document.getElementById('smsSearch');
        var query = String(searchEl && searchEl.value || '').trim().toLowerCase();
        if (smsFilter && smsFilter !== 'all') entries = entries.filter(function (entry) { return entry.type === smsFilter; });
        if (query) entries = entries.filter(function (entry) {
            return String(entry.phone).toLowerCase().indexOf(query) >= 0 || String(entry.body).toLowerCase().indexOf(query) >= 0;
        });
        if (!entries.length) {
            list.innerHTML = '<div class="empty-state"><i class="fa-solid fa-inbox"></i><p>لا توجد رسائل في Firebase</p></div>';
            return;
        }
        list.innerHTML = entries.slice(0, 200).map(function (entry) {
            var color = entry.type === 'sent' ? '' : (entry.type === 'failed' ? 'failed' : (entry.type === 'received' ? 'received' : 'pending'));
            var reason = entry.reason ? '<span style="color:#ff9aa2"><i class="fa-solid fa-circle-info"></i> ' + smsAutoEscape(entry.reason) + '</span>' : '';
            return '<div class="sms-item ' + color + '">' +
                '<div class="sms-item-header"><div class="sms-item-status"><i class="fa-solid ' + entry.icon + '"></i><span class="sms-item-status-text">' + smsAutoEscape(entry.label) + '</span></div><div class="sms-item-time">' + smsAutoEscape(realSmsTime(entry.timestamp)) + '</div></div>' +
                '<div class="sms-item-phone"><i class="fa-solid fa-phone"></i> <b dir="ltr">' + smsAutoEscape(entry.phone) + '</b></div>' +
                '<div class="sms-item-body">' + smsAutoEscape(entry.body) + '</div>' +
                '<div class="sms-item-footer"><span><i class="fa-regular fa-calendar"></i> ' + smsAutoEscape(realSmsTime(entry.timestamp)) + '</span>' + (entry.attempts ? '<span>محاولات: ' + entry.attempts + '</span>' : '') + reason + '</div></div>';
        }).join('');
    }

    function attachRealSmsListeners() {
        var db = realSmsDb();
        if (!db || realSmsState.listenersAttached) return false;
        realSmsState.listenersAttached = true;
        db.ref('sms_queue').on('value', function (snapshot) {
            realSmsState.queue = snapshot.val() || {};
            realSmsRenderStats();
            if (typeof smsCurrentView === 'undefined' || smsCurrentView === 'log') realSmsRenderLog();
        });
        db.ref('sms_raw_inbox').on('value', function (snapshot) {
            realSmsState.inbox = snapshot.val() || {};
            realSmsRenderStats();
            if (typeof smsCurrentView === 'undefined' || smsCurrentView === 'log') realSmsRenderLog();
        });
        db.ref('sms_commands').on('value', function (snapshot) {
            realSmsState.commands = snapshot.val() || {};
            realSmsRenderStats();
        });
        loadRealSmsStats();
        return true;
    }

    // هذه الدوال تحل محل العرض المحلي القديم عند استدعائها من smsGoTo وواجهة الصفحة.
    window.loadRealSmsStats = loadRealSmsStats;
    window.loadRealSmsLog = async function () {
        await loadRealSmsStats();
        realSmsRenderLog();
    };
    window.smsUpdateBalanceDisplay = function () {
        realSmsRenderStats();
        var dev = document.getElementById('smsDeviceIdText');
        if (dev && window.SmsStore && window.SmsStore.data) dev.textContent = window.SmsStore.data.deviceId || '—';
    };
    window.smsRenderLog = realSmsRenderLog;

    function startDashboard() {
        if (attachRealSmsListeners()) {
            if (realSmsState.refreshTimer) clearInterval(realSmsState.refreshTimer);
            realSmsState.refreshTimer = setInterval(function () {
                loadRealSmsStats();
                if (typeof smsCurrentView !== 'undefined' && smsCurrentView === 'log') realSmsRenderLog();
            }, 30000);
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startDashboard);
    else startDashboard();
    window.addEventListener('userLoggedIn', startDashboard);
    window.addEventListener('adminModeEnabled', startDashboard);
}(window, document));
