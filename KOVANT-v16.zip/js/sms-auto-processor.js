/* ============================================================
 * COVANT — SMS AUTO PROCESSOR
 * استقبال أوامر SMS الموقعة وتنفيذها تلقائياً على جهاز الأدمن
 * ============================================================ */
(function (window, document) {
    'use strict';

    if (window.SMSAutoProcessor) return;

    const CONFIG = { maxPerMinute: 10, queueLimit: 50, lockTimeoutMs: 5 * 60 * 1000 };
    const state = { started: false, processing: false, timer: null, processedAt: [], listener: false, lastError: null };
    const API_BASE = 'https://kovant-backend3.onrender.com';

    function db() { return window.database && typeof window.database.ref === 'function' ? window.database : null; }
    function s(value) { return String(value == null ? '' : value).trim(); }
    function n(value) { const number = Number(String(value == null ? '' : value).replace(/,/g, '')); return Number.isFinite(number) ? number : 0; }
    function id(prefix) { return prefix + '-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 8).toUpperCase(); }
    function canProcess() { const cut = Date.now() - 60000; state.processedAt = state.processedAt.filter(t => t > cut); return state.processedAt.length < CONFIG.maxPerMinute; }

    async function getAdminJWT() {
        if (!window.APP || !window.APP.user || !window.APP.user.isAdmin) {
            throw new Error('يجب تسجيل دخول الأدمن');
        }
        const memoryToken = window.__adminJWT;
        const memoryExpiry = Number(window.__adminJWTExpiry || 0);
        if (memoryToken && memoryExpiry > Date.now() + 5000) return memoryToken;

        const token = localStorage.getItem('auth_token') || localStorage.getItem('admin_jwt');
        const expiry = Number(localStorage.getItem('auth_expiry') || localStorage.getItem('admin_jwt_expiry') || 0);
        if (!token || (expiry && expiry <= Date.now() + 5000)) {
            throw new Error('JWT الأدمن غير متوفر أو منتهي — سجّل الدخول من جديد');
        }
        window.__adminJWT = token;
        window.__adminJWTExpiry = expiry || Date.now() + 60 * 1000;
        return token;
    }

    async function callServerAPI(endpoint, body, operationId) {
        const jwt = await getAdminJWT();
        const response = await fetch(API_BASE + endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + jwt,
                'Idempotency-Key': operationId || ''
            },
            body: JSON.stringify(body)
        });
        let data;
        try { data = await response.json(); } catch (error) { throw new Error('استجابة غير صالحة من الخادم'); }
        if (!response.ok) throw new Error(data.error || 'فشل الاتصال بالخادم');
        return data;
    }

    async function sendSMS(phone, message, txId) {
        if (!db() || !phone) return;
        await db().ref('sms_queue').push({ to: s(phone), message: s(message), from: 'COVANT', txId: txId || null, status: 'pending', attempts: 0, createdAt: Date.now() });
    }

    async function recordLog(sessionId, action, extra) {
        if (!db()) return;
        await db().ref('sms_auto_log').push(Object.assign({ sessionId: sessionId, action: action, timestamp: Date.now() }, extra || {}));
    }

    async function rejectCommand(idValue, command, reason) {
        if (db()) await db().ref('sms_commands/' + idValue).update({ status: 'rejected', rejectedAt: Date.now(), rejectReason: reason });
        await recordLog(command && command.sessionId, 'rejected', { reason: reason });
        const messages = { insufficient_balance: 'رصيدك غير كافٍ', invalid_signature: 'تعذر التحقق من توقيع الطلب', expired: 'انتهت صلاحية الطلب', duplicate_session: 'تمت معالجة الطلب مسبقاً', not_enough_cards: 'لا توجد كروت كافية', invalid_command: 'بيانات الطلب غير صالحة' };
        if (command && command.from) await sendSMS(command.from, '❌ كوفانت: ' + (messages[reason] || 'فشلت العملية'), command.sessionId);
    }

    async function claim(idValue) {
        const result = await db().ref('sms_commands/' + idValue + '/status').transaction(function (current) { return current === 'pending' ? 'processing' : undefined; });
        return !!(result && result.committed);
    }

    async function findUserByAccount(accountNumber) {
        const snapshot = await db().ref('users').once('value');
        const users = snapshot.val() || {};
        for (const phone of Object.keys(users)) if (s(users[phone].accountNumber) === s(accountNumber)) return { phone: phone, data: users[phone] };
        return null;
    }

    async function executeTransfer(command) {
        try {
            const data = await callServerAPI('/sms/transfer', {
                from: command.from,
                toAccount: command.to,
                amount: command.amount,
                note: 'تحويل عبر SMS',
                sessionId: command.sessionId
            }, command.sessionId);
            return {
                success: true,
                txId: data.txId || command.sessionId,
                newBalance: data.newBalance,
                recipientPhone: data.recipient && data.recipient.phone
            };
        } catch (error) {
            return { success: false, error: error.message || 'failed' };
        }
    }

    async function executeCardPurchase(command) {
        try {
            const data = await callServerAPI('/sms/purchase-package', {
                buyer: command.buyer,
                packageId: command.pkgId,
                count: command.count,
                customerId: command.recipient || command.buyer,
                sessionId: command.sessionId
            }, command.sessionId);
            return {
                success: true,
                txId: data.txId || command.sessionId,
                codes: data.codes || [],
                newBalance: data.newBalance
            };
        } catch (error) {
            return { success: false, error: error.message || 'failed' };
        }
    }

    async function executeTopup(command) {
        const requestSnapshot = await db().ref('topup_requests').orderByChild('phone').equalTo(command.phone).once('value');
        const requests = requestSnapshot.val() || {};
        let requestId = null;
        Object.keys(requests).forEach(function (key) { if (requests[key].status === 'pending' && s(requests[key].reference) === s(command.bankRef) && n(requests[key].amount) === command.amount) requestId = key; });
        if (!requestId) return { success: false, error: 'topup_request_not_found' };
        const requestRef = db().ref('topup_requests/' + requestId + '/status');
        const claim = await requestRef.transaction(current => current === 'pending' ? 'processing' : undefined);
        if (!claim.committed) return { success: false, error: 'duplicate_session' };
        const balanceRef = db().ref('users/' + command.phone + '/balance');
        const balanceTx = await balanceRef.transaction(current => n(current) + command.amount);
        if (!balanceTx.committed) { await requestRef.set('pending'); return { success: false, error: 'failed' }; }
        const txId = id('TOP');
        const timestamp = Date.now();
        await db().ref().update({
            ['topup_requests/' + requestId + '/status']: 'confirmed',
            ['topup_requests/' + requestId + '/confirmedAt']: timestamp,
            ['topup_requests/' + requestId + '/confirmedVia']: 'sms_auto',
            ['transactions/' + txId]: { txId: txId, type: 'topup', phone: command.phone, amount: command.amount, reference: command.bankRef, timestamp: timestamp, via: 'sms_auto' }
        });
        return { success: true, txId: txId, newBalance: n(balanceTx.snapshot.val()) };
    }

    async function executeBalanceQuery(command) {
        const userSnapshot = await db().ref('users/' + command.phone).once('value');
        const user = userSnapshot.val();
        if (!user) return { success: false, error: 'user_not_found' };
        return { success: true, txId: id('BAL'), balance: n(user.balance) };
    }

    async function sendConfirmations(command, result) {
        if (command.code === 'TR') {
            await sendSMS(command.from, '✅ كوفانت\nتم تحويل ' + command.amount + ' ريال إلى ' + command.to + '\nرصيدك: ' + result.newBalance + '\nالعملية: ' + result.txId, result.txId);
            await sendSMS(result.recipientPhone, '💰 كوفانت\nتم إيداع ' + command.amount + ' ريال\nالعملية: ' + result.txId, result.txId);
        } else if (command.code === 'CR') {
            await sendSMS(command.buyer, '✅ كوفانت\nتم شراء ' + command.count + ' كرت للعميل رقم: ' + command.recipient + '\nرصيدك بعد العملية: ' + result.newBalance + '\nالعملية: ' + result.txId, result.txId);
            await sendSMS(command.recipient, '🎫 كوفانت — بطاقات إنترنت\n' + result.codes.map(code => 'الكود: ' + code).join('\n') + '\nالعملية: ' + result.txId, result.txId);
        } else if (command.code === 'TP') {
            await sendSMS(command.phone, '✅ كوفانت\nتم تأكيد تغذية حسابك بمبلغ ' + command.amount + ' ريال\nرصيدك: ' + result.newBalance + '\nالعملية: ' + result.txId, result.txId);
        } else if (command.code === 'BQ') {
            await sendSMS(command.phone, '💰 كوفانت\nرصيدك الحالي: ' + result.balance + ' ريال\nالعملية: ' + result.txId, result.txId);
        }
    }

    async function executeCommand(idValue, command) {
        if (!canProcess() || !await claim(idValue)) return;
        try {
            const validation = window.SMSParser.validateCommand(command);
            if (!validation.valid) return rejectCommand(idValue, command, validation.reason);
            const secretSnapshot = await db().ref('users/' + s(command.from || command.phone || command.buyer) + '/sms_secret').once('value');
            if (!await window.SMSParser.verifySignature(command, secretSnapshot.val())) return rejectCommand(idValue, command, 'invalid_signature');
            let result;
            if (command.code === 'TR') result = await executeTransfer(command);
            else if (command.code === 'CR') result = await executeCardPurchase(command);
            else if (command.code === 'TP') result = await executeTopup(command);
            else result = await executeBalanceQuery(command);
            if (!result.success) return rejectCommand(idValue, command, result.error);
            await db().ref('sms_commands/' + idValue).update({ status: 'executed', executedAt: Date.now(), result: result });
            await db().ref('sms_processed/' + command.sessionId).set({ processedAt: Date.now(), commandId: idValue });
            window.SMSParser.markProcessed(command.sessionId);
            await recordLog(command.sessionId, 'executed', { type: command.type, txId: result.txId });
            await sendConfirmations(command, result);
            state.processedAt.push(Date.now());
        } catch (error) {
            state.lastError = error;
            await rejectCommand(idValue, command, error.message || 'failed');
        }
    }

    // المعالجة التلقائية: تُقرأ من SharedPreferences (عبر الجسر) مع احتياط localStorage
    function autoOn() {
        if (window.SmsSettingsBridge) return window.SmsSettingsBridge.isAutoProcess();
        try {
            const st = window.SmsStore;
            return !(st && st.data && st.data.settings && st.data.settings.autoProcess === false);
        } catch (e) { return true; }
    }

    async function processIncomingSMS(sms) {
        if (!autoOn()) return;
        try {
            const command = window.SMSParser.parseIncomingSMS(sms && (sms.body || sms.message || sms.text));
            const validation = window.SMSParser.validateCommand(command || {});
            if (!command || !validation.valid) return;
            await db().ref('sms_commands/' + command.sessionId).transaction(function (current) { return current || Object.assign({}, command, { status: 'pending', receivedAt: Date.now() }); });
            await processQueue();
        } catch (error) { state.lastError = error; }
    }

    async function processQueue() {
        if (!db() || !navigator.onLine || state.processing || !autoOn()) return;
        state.processing = true;
        try {
            const snapshot = await db().ref('sms_commands').orderByChild('status').equalTo('pending').limitToFirst(CONFIG.queueLimit).once('value');
            const commands = snapshot.val() || {};
            for (const key of Object.keys(commands)) { if (!canProcess()) break; await executeCommand(key, commands[key]); }
        } catch (error) { state.lastError = error; }
        finally { state.processing = false; }
    }

    async function start() {
        if (state.started || !db() || !window.APP || !window.APP.user || !window.APP.user.isAdmin) return { started: false };
        state.started = true;
        if (window.SMSNativeBridge && typeof window.SMSNativeBridge.startListening === 'function') window.SMSNativeBridge.startListening(processIncomingSMS);
        state.timer = setInterval(processQueue, 60000);
        window.addEventListener('online', processQueue);
        await processQueue();
        return { started: true };
    }

    // عند إعادة تفعيل المعالجة التلقائية: عالج ما تراكم
    window.addEventListener('sms-settings-changed', function (event) {
        if (event && event.detail && event.detail.autoProcess === true) processQueue();
    });

    function stop() { state.started = false; clearInterval(state.timer); state.timer = null; }

    window.SMSAutoProcessor = { state: state, start: start, stop: stop, processQueue: processQueue, processIncomingSMS: processIncomingSMS, executeCommand: executeCommand, executeTransfer: executeTransfer, executeCardPurchase: executeCardPurchase, executeTopup: executeTopup, executeBalanceQuery: executeBalanceQuery, sendSMS: sendSMS };
    document.addEventListener('DOMContentLoaded', function () { setTimeout(function () { if (window.APP && window.APP.user && window.APP.user.isAdmin) start(); }, 3000); });
}(window, document));
