// ============================================================
// bootstrap.js — non-blocking startup services
// ============================================================

/**
 * Register optional workers exactly once.
 *
 * The authentication UI is deliberately revealed before this function runs.
 * A missing worker, a 404, or an invalid worker script affects only caching /
 * push notifications and must never block the login screen.
 */
async function registerOptionalWorkers() {
    const isNative = !!(
        window.Capacitor &&
        typeof window.Capacitor.isNativePlatform === 'function' &&
        window.Capacitor.isNativePlatform()
    );

    if (isNative || !('serviceWorker' in navigator)) return;

    const workers = [
        { path: '/service-worker.js', label: 'كاش' },
        { path: '/firebase-messaging-sw.js', label: 'إشعارات' }
    ];

    for (const worker of workers) {
        try {
            const existing = await navigator.serviceWorker.getRegistration(worker.path);
            if (existing) {
                console.log(`✅ Service Worker (${worker.label}) مسجل مسبقاً`);
                continue;
            }

            await navigator.serviceWorker.register(worker.path, { scope: '/' });
            console.log(`✅ Service Worker (${worker.label}) مسجل بنجاح`);
        } catch (error) {
            // ✅ Graceful degradation: optional worker failure is warning-only.
            console.warn(`⚠️ تعذر تسجيل Service Worker (${worker.label}) — تم تجاوز الخطأ:`, error);
        }
    }
}

// ✅ Never await optional workers from the main startup path.
if (typeof window.revealAuthUI === 'function') window.revealAuthUI();
void registerOptionalWorkers();
