// ============================================================
// تحليل المستخدمين — UsersAnalysis
// المصدر: Firebase Realtime Database (تحديث لحظي عبر on('value') — نفس أسلوب SDK المستخدم في التطبيق)
//   • users/{phone}             → الاسم، رقم الحساب، الرصيد، الاتصال، آخر ظهور، الانضمام، الصورة
//   • kova_store/{catId}        → name, sellPrice
//   • kova_store/{catId}/sold/* → buyerPhone (أو customerId/soldTo/buyer)، soldAt (أو timestamp/addedAt)، code
//
// المبدأ: لا توجد أي بيانات وهمية. كل رقم يُحسب من الكروت المباعة الفعلية:
//   مبلغ الكرت = kova_store/{catId}/sellPrice  ·  الكرت يُنسب للمستخدم الذي يطابق رقم مشتريه.
//
// تعريفات قابلة للتعديل (الثوابت في الأعلى):
//   نشط   = اشترى خلال آخر ACTIVE_DAYS يوماً
//   VIP   = ضمن أعلى VIP_TOP_PCT من المشترين إجمالاً
//   عملية = كروت من نفس الفئة لنفس المستخدم بينها أقل من OP_GAP_MS (طلب شراء واحد)
//
// يعتمد على: database, $n, esc, showAlert, waitForFirebaseAuth, openChatWithUser
// ============================================================
(function () {
    'use strict';

    /* ---------- إعدادات ---------- */
    const ACTIVE_DAYS = 30;
    const VIP_TOP_PCT = 0.10;
    const OP_GAP_MS = 10 * 1000;
    const PAGE_SIZE = 40;
    const BUYER_FIELDS = ['buyerPhone', 'customerId', 'soldTo', 'buyer']; // ترتيب الأولوية
    const SKIP_USERS = ['999'];                                           // نفس ما يتجاهله admin-logic

    const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const DAY = 86400000;
    const PALETTE = ['#10b981', '#3b82f6', '#8b5cf6', '#fbbf24', '#f59e0b', '#ef4444'];
    const AV_COLORS = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];
    const TT_MS = 3500;
    const SOLID = '#101728';
    const PERIOD_LONG = { day: 'اليوم', week: 'آخر 7 أيام', month: 'آخر 30 يوماً', '3months': 'آخر 3 أشهر', year: 'آخر 12 شهراً', all: 'كل الفترات' };

    // ---------- Guards ----------
    const _n = (typeof $n === 'function') ? $n : function (v) {
        if (v === null || v === undefined) return 0;
        const num = parseFloat(String(v).replace(/,/g, ''));
        return isNaN(num) ? 0 : num;
    };
    const _esc = (typeof esc === 'function') ? esc : function (s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m] || m);
    };

    // ---------- الحالة ----------
    const S = {
        opened: false, bound: false, live: true, attachId: 0,
        usersRef: null, usersFn: null, storeRef: null, storeFn: null,
        usersRaw: null, storeRaw: null, gotUsers: false, gotStore: false,
        // بيانات مُشتقّة
        list: [], byId: {}, byPhone: {}, opsCache: {},
        totals: { amount: 0, cards: 0, users: 0, buyers: 0 }, unmatched: 0, undated: 0,
        lastUpdate: null, rebuildTimer: null, tick: null,
        // الواجهة
        view: 'list', search: '', sort: 'total-desc', visible: PAGE_SIZE,
        selected: null, period: 'month', chartType: 'area', zoom: 1,
        showCur: true, showPrev: true, showAvg: true, showPeak: true,
        dataset: null, ttKey: null, resetScroll: true
    };
    let ttTimer = null;

    /* ---------- أدوات ---------- */
    const el = id => document.getElementById(id);
    const qa = s => [].slice.call(document.querySelectorAll('#usersAnalysisInterface ' + s));
    const pad = n => String(n).padStart(2, '0');
    const midnight = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const sum = a => a.reduce((x, y) => x + y, 0);
    const fmt = n => isFinite(n) ? Math.round(n).toLocaleString('en-US') : '0';
    const shortMoney = n => {
        if (!isFinite(n) || n === 0) return '0';
        if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
        if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
        if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
        return String(Math.round(n));
    };
    const fmtDay = d => d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    const fmtShort = d => pad(d.getDate()) + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    const fmtFull = d => fmtDay(d) + ' - ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    const modeAr = m => m === 'hour' ? 'بالساعة' : m === 'day' ? 'يومي' : m === 'week' ? 'أسبوعي' : m === 'month' ? 'شهري' : 'سنوي';
    const growthOf = (cur, prev) => prev > 0 ? ((cur - prev) / prev) * 100 : 0;
    const say = (msg, ok) => { if (typeof showAlert === 'function') showAlert(msg, ok !== false); };
    const maskCode = c => c ? (c.length <= 4 ? '••••' : '••••' + c.slice(-4)) : '—';

    function colorOf(key) {
        let h = 0;
        for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
        return AV_COLORS[h % AV_COLORS.length];
    }
    function initialOf(name) { return (String(name || '').trim().charAt(0) || '؟'); }

    // timestamp → ms (يقبل ثوانٍ / مللي ثانية / نص تاريخ). 0 = غير معروف
    function toMs(v) {
        if (v === null || v === undefined || v === '') return 0;
        let n = Number(v);
        if (!isFinite(n) || n <= 0) n = Date.parse(v);
        if (!isFinite(n) || n <= 0) return 0;
        if (n < 1e12) n *= 1000;
        return n < 946684800000 ? 0 : n; // قبل عام 2000 = قيمة غير صالحة
    }
    // صيغة العدد العربية: [مفرد, مثنى, 3–10, 11+]
    function arNum(n, f) {
        if (n === 1) return f[0];
        if (n === 2) return f[1];
        return n + ' ' + (n >= 3 && n <= 10 ? f[2] : f[3]);
    }
    function ago(ms) {
        if (!ms) return '—';
        const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
        if (s < 60) return 'الآن';
        const m = Math.floor(s / 60); if (m < 60) return 'منذ ' + arNum(m, ['دقيقة', 'دقيقتين', 'دقائق', 'دقيقة']);
        const h = Math.floor(m / 60); if (h < 24) return 'منذ ' + arNum(h, ['ساعة', 'ساعتين', 'ساعات', 'ساعة']);
        const d = Math.floor(h / 24); if (d < 30) return 'منذ ' + arNum(d, ['يوم', 'يومين', 'أيام', 'يوماً']);
        const mo = Math.floor(d / 30); if (mo < 12) return 'منذ ' + arNum(mo, ['شهر', 'شهرين', 'أشهر', 'شهراً']);
        const y = Math.floor(d / 365); return 'منذ ' + arNum(Math.max(1, y), ['سنة', 'سنتين', 'سنوات', 'سنة']);
    }
    function safeImg(v) {
        if (typeof v !== 'string') return '';
        return (/^data:image\//i.test(v) || /^https?:\/\//i.test(v)) ? v : '';
    }

    function setStatus(kind, title, sub) {
        const b = el('uaStatus'); if (!b) return;
        if (!kind) { b.style.display = 'none'; return; }
        b.style.display = 'flex';
        b.className = 'sa-status' + (kind === 'error' ? ' error' : kind === 'warn' ? ' warn' : '');
        el('uaStatusTitle').textContent = title || '';
        el('uaStatusSub').textContent = sub || '';
    }

    /* =====================================================================
       بناء البيانات من Firebase
       ===================================================================== */
    function rebuild() {
        const raw = S.usersRaw || {};
        const users = {}, byLast9 = {}, byAcc = {};

        Object.keys(raw).forEach(k => {
            if (SKIP_USERS.indexOf(k) !== -1) return;
            const u = raw[k];
            if (!u || typeof u !== 'object') return;
            users[k] = {
                phone: k,
                name: String(u.fullName || u.name || 'بدون اسم'),
                account: (u.accountNumber !== undefined && u.accountNumber !== null) ? String(u.accountNumber) : '',
                balance: _n(u.balance),
                online: u.isOnline === true,
                lastSeen: toMs(u.lastSeen),
                createdAt: toMs(u.createdAt),
                avatar: safeImg(u.avatar)
            };
            const dg = k.replace(/\D/g, '');
            if (dg.length >= 7 && !byLast9[dg.slice(-9)]) byLast9[dg.slice(-9)] = k;
            if (users[k].account && !byAcc[users[k].account]) byAcc[users[k].account] = k;
        });

        // ربط قيمة "المشتري" بمستخدم موجود (مفتاح مباشر ← أرقام فقط ← آخر 9 أرقام ← رقم الحساب)
        function resolve(v) {
            if (v === null || v === undefined) return null;
            const s = String(v).trim();
            if (!s) return null;
            if (users[s]) return s;
            const dg = s.replace(/\D/g, '');
            if (dg && users[dg]) return dg;
            if (dg.length >= 7 && byLast9[dg.slice(-9)]) return byLast9[dg.slice(-9)];
            if (byAcc[s]) return byAcc[s];
            return null;
        }
        function resolveBuyer(it) {
            for (let i = 0; i < BUYER_FIELDS.length; i++) {
                const p = resolve(it[BUYER_FIELDS[i]]);
                if (p) return p;
            }
            return null;
        }

        const store = S.storeRaw || {};
        const byPhone = {}, stats = {};
        let unmatched = 0, undated = 0;

        Object.keys(store).forEach(catId => {
            if (catId === 'gift_cards') return;
            const cat = store[catId];
            if (!cat || typeof cat !== 'object' || !cat.sold || typeof cat.sold !== 'object') return;
            const price = _n(cat.sellPrice), catName = String(cat.name || catId);
            Object.keys(cat.sold).forEach(id => {
                const it = cat.sold[id];
                if (!it || typeof it !== 'object') return;
                const phone = resolveBuyer(it);
                if (!phone) { unmatched++; return; }
                const ms = toMs(it.soldAt || it.timestamp || it.addedAt);
                if (!ms) undated++;
                const r = { phone: phone, ms: ms, amount: price, catId: catId, catName: catName, code: String(it.code || ''), id: id };
                (byPhone[phone] || (byPhone[phone] = [])).push(r);
                const st = stats[phone] || (stats[phone] = { amount: 0, cards: 0, lastMs: 0 });
                st.amount += price; st.cards++;
                if (ms > st.lastMs) st.lastMs = ms;
            });
        });

        const list = Object.keys(users).map(k => {
            const st = stats[k] || { amount: 0, cards: 0, lastMs: 0 };
            return Object.assign({}, users[k], { amount: st.amount, cards: st.cards, lastMs: st.lastMs, rank: 0, vip: false });
        });
        list.sort((a, b) => b.amount - a.amount || b.cards - a.cards || a.name.localeCompare(b.name, 'ar'));

        const buyers = list.filter(u => u.cards > 0);
        const vipCut = buyers.length ? Math.max(1, Math.ceil(buyers.length * VIP_TOP_PCT)) : 0;
        buyers.forEach((u, i) => { u.rank = i + 1; u.vip = u.amount > 0 && u.rank <= vipCut; });

        const byId = {};
        list.forEach(u => { byId[u.phone] = u; });

        S.list = list; S.byId = byId; S.byPhone = byPhone; S.opsCache = {};
        S.unmatched = unmatched; S.undated = undated;
        S.totals = {
            amount: sum(list.map(u => u.amount)),
            cards: sum(list.map(u => u.cards)),
            users: list.length, buyers: buyers.length
        };
    }

    // العمليات = تجميع كروت نفس الفئة المتقاربة زمنياً (طلب شراء واحد)
    function opsOf(phone) {
        if (S.opsCache[phone]) return S.opsCache[phone];
        const recs = (S.byPhone[phone] || []).slice().sort((a, b) => a.ms - b.ms);
        const ops = [], open = {};
        recs.forEach(r => {
            const cur = r.ms ? open[r.catId] : null;
            if (cur && r.ms - cur.lastMs <= OP_GAP_MS) {
                cur.cards++; cur.amount += r.amount; cur.lastMs = r.ms;
                if (r.code) cur.codes.push(r.code);
                return;
            }
            const op = { ms: r.ms, lastMs: r.ms, catId: r.catId, catName: r.catName, cards: 1, amount: r.amount, codes: r.code ? [r.code] : [] };
            ops.push(op);
            if (r.ms) open[r.catId] = op;
        });
        return (S.opsCache[phone] = ops); // تصاعدياً (غير المؤرَّخة أولاً)
    }

    function isActive(u) { return !!u.lastMs && (Date.now() - u.lastMs) <= ACTIVE_DAYS * DAY; }
    function tierOf(u) { return u.vip ? 'vip' : isActive(u) ? 'act' : 'off'; }
    function badgeHTML(u) {
        const t = tierOf(u);
        if (t === 'vip') return '<span class="ua-badge vip"><i class="fas fa-crown"></i> VIP</span>';
        if (t === 'act') return '<span class="ua-badge act">● نشط</span>';
        return '<span class="ua-badge off">○ غير نشط</span>';
    }

    /* =====================================================================
       Firebase (اشتراك لحظي)
       ===================================================================== */
    function scheduleRebuild() {
        clearTimeout(S.rebuildTimer);
        S.rebuildTimer = setTimeout(function () {
            if (!S.opened || !S.gotUsers || !S.gotStore) return;
            rebuild();
            S.lastUpdate = new Date();
            renderAll();
        }, 60);
    }

    function onFail(what, err) {
        console.error('[UsersAnalysis] ' + what + ' error:', err);
        setStatus('error', 'تعذّر قراءة ' + what, (err && err.message) || 'تحقق من صلاحيات قاعدة البيانات');
        const box = el('uaList');
        if (box && !S.list.length) box.innerHTML = '<div class="sa-none">تعذّر جلب البيانات</div>';
    }

    async function attach() {
        detach();
        const myId = ++S.attachId;
        if (typeof database === 'undefined') {
            setStatus('error', 'تعذّر الاتصال بقاعدة البيانات', 'أعد تحميل الصفحة');
            return;
        }
        try { if (typeof waitForFirebaseAuth === 'function') await waitForFirebaseAuth(); } catch (e) { }
        if (!S.opened || !S.live || myId !== S.attachId) return;

        S.usersRef = database.ref('users');
        S.usersFn = function (snap) { S.usersRaw = snap.val() || {}; S.gotUsers = true; scheduleRebuild(); };
        S.usersRef.on('value', S.usersFn, function (err) { onFail('المستخدمين', err); });

        S.storeRef = database.ref('kova_store');
        S.storeFn = function (snap) { S.storeRaw = snap.val() || {}; S.gotStore = true; scheduleRebuild(); };
        S.storeRef.on('value', S.storeFn, function (err) { onFail('الكروت المباعة', err); });
    }

    function detach() {
        S.attachId++;
        try { if (S.usersRef && S.usersFn) S.usersRef.off('value', S.usersFn); } catch (e) { }
        try { if (S.storeRef && S.storeFn) S.storeRef.off('value', S.storeFn); } catch (e) { }
        S.usersRef = S.usersFn = S.storeRef = S.storeFn = null;
        clearTimeout(S.rebuildTimer);
    }

    /* =====================================================================
       العرض 1 — القائمة
       ===================================================================== */
    function renderAll() {
        if (!S.opened) return;
        const ts = el('uaLastUpdate'); if (ts) ts.textContent = S.lastUpdate ? fmtFull(S.lastUpdate) : '—';
        renderStatus();
        if (S.view === 'detail') {
            if (!S.byId[S.selected]) { showList(); return; } // المستخدم حُذف
            renderDetail(false);
        } else {
            renderSummary();
            renderList();
        }
    }

    function renderStatus() {
        if (S.view === 'detail') { setStatus(null); return; }
        const notes = [];
        if (S.unmatched > 0) notes.push(fmt(S.unmatched) + ' كرت مباع لا يطابق أي مستخدم (لا يوجد رقم مشترٍ مطابق) ولم يُحتسب');
        if (S.undated > 0) notes.push(fmt(S.undated) + ' كرت بدون تاريخ بيع (يُحتسب في الإجمالي ولا يظهر في الرسم)');
        if (!S.list.length) setStatus('warn', 'لا يوجد مستخدمون في قاعدة البيانات', 'ستظهر التحليلات فور إضافة مستخدمين');
        else if (notes.length) setStatus('warn', 'ملاحظات على البيانات', notes.join(' · '));
        else setStatus(null);
    }

    function renderSummary() {
        const t = S.totals;
        const active = S.list.filter(isActive).length;
        el('uaLTotal').innerHTML = fmt(t.amount) + '<small>ريال</small>';
        el('uaLCardsPill').textContent = fmt(t.cards) + ' كرت مباع';
        el('uaLBuyersPill').textContent = fmt(t.buyers) + ' مشترٍ';
        el('uaLCards').textContent = fmt(t.cards);
        el('uaLActive').textContent = fmt(active);
        el('uaLUsers').textContent = fmt(t.users);
    }

    function sortedFiltered() {
        const q = S.search.trim().toLowerCase();
        const qd = q.replace(/\D/g, '');
        let arr = S.list;
        if (q) {
            arr = arr.filter(u =>
                u.name.toLowerCase().indexOf(q) !== -1 ||
                u.phone.toLowerCase().indexOf(q) !== -1 ||
                (u.account && u.account.toLowerCase().indexOf(q) !== -1) ||
                (qd.length >= 3 && u.phone.replace(/\D/g, '').indexOf(qd) !== -1));
        }
        arr = arr.slice(); // S.list مرتّبة أصلاً: الأعلى إجمالاً
        if (S.sort === 'total-asc') arr.reverse();
        else if (S.sort === 'recent') arr.sort((a, b) => b.lastMs - a.lastMs || b.lastSeen - a.lastSeen || b.amount - a.amount);
        return arr;
    }

    function rowHTML(u, maxAmt) {
        const rank = (u.rank > 0 && u.rank <= 3)
            ? '<span class="ua-rank m' + u.rank + '" title="المرتبة ' + u.rank + '"><i class="fas fa-medal"></i></span>'
            : '<span class="ua-rank">' + (u.rank > 0 ? u.rank : '—') + '</span>';
        const pct = maxAmt > 0 && u.amount > 0 ? Math.max(3, (u.amount / maxAmt) * 100) : 0;
        const last = u.lastMs ? 'آخر شراء ' + ago(u.lastMs) : 'لم يشترِ بعد';
        return '<div class="ua-row" role="button" tabindex="0" data-phone="' + _esc(u.phone) + '">' +
            rank +
            '<div class="ua-av" style="background:' + colorOf(u.phone) + '">' + _esc(initialOf(u.name)) + (u.online ? '<span class="ua-dot" title="متصل الآن"></span>' : '') + '</div>' +
            '<div class="ua-main">' +
            '<div class="ua-line"><span class="ua-name">' + _esc(u.name) + '</span>' + badgeHTML(u) + '</div>' +
            '<div class="ua-sub"><span><i class="fas fa-phone"></i><bdi dir="ltr">' + _esc(u.phone) + '</bdi></span>' +
            (u.account ? '<span><i class="fas fa-hashtag"></i>' + _esc(u.account) + '</span>' : '') + '</div>' +
            '<div class="ua-sub"><b>' + fmt(u.cards) + ' كرت</b><span>· ' + last + '</span></div>' +
            '<div class="ua-bar"><i style="width:' + pct.toFixed(1) + '%"></i></div>' +
            '</div>' +
            '<div class="ua-side"><div class="ua-amt">' + fmt(u.amount) + '</div><small>ريال</small><i class="fas fa-chevron-left"></i></div>' +
            '</div>';
    }

    function renderList() {
        const box = el('uaList');
        if (!S.gotUsers || !S.gotStore) return;
        const arr = sortedFiltered();
        const maxAmt = S.list.length ? S.list[0].amount : 0; // شريط التقدم = نسبة من الأعلى دائماً
        const shown = arr.slice(0, S.visible);

        el('uaCount').textContent = arr.length === S.list.length
            ? fmt(arr.length) + ' مستخدم'
            : fmt(arr.length) + ' من ' + fmt(S.list.length);

        if (!arr.length) {
            box.innerHTML = '<div class="sa-none">' + (S.search ? 'لا توجد نتائج مطابقة' : 'لا يوجد مستخدمون') + '</div>';
        } else {
            box.innerHTML = shown.map(u => rowHTML(u, maxAmt)).join('');
        }
        const more = el('uaMore');
        if (arr.length > shown.length) {
            more.style.display = '';
            more.textContent = 'عرض المزيد (' + fmt(arr.length - shown.length) + ' متبقٍّ)';
        } else more.style.display = 'none';
    }

    function renderLoading() {
        el('uaLTotal').innerHTML = '0<small>ريال</small>';
        ['uaLCardsPill', 'uaLBuyersPill'].forEach(i => { el(i).textContent = '—'; });
        ['uaLCards', 'uaLActive', 'uaLUsers'].forEach(i => { el(i).textContent = '—'; });
        el('uaCount').textContent = '—';
        el('uaMore').style.display = 'none';
        el('uaList').innerHTML = '<div class="sa-empty"><i class="fas fa-circle-notch fa-spin"></i><b>جاري جلب البيانات…</b><span>يتم الآن قراءة المستخدمين والكروت المباعة من قاعدة البيانات</span></div>';
    }

    /* =====================================================================
       التنقل بين العرضين
       ===================================================================== */
    function toTop() {
        try { window.scrollTo(0, 0); } catch (e) { }
        const root = el('usersAnalysisInterface'); if (root) root.scrollTop = 0;
    }
    function showList() {
        hideTip();
        S.view = 'list'; S.selected = null; S.dataset = null;
        el('uaListView').classList.add('on');
        el('uaDetailView').classList.remove('on');
        renderAll();
        toTop();
    }
    function openDetail(phone) {
        if (!S.byId[phone]) return;
        S.view = 'detail'; S.selected = phone;
        S.period = 'month'; S.zoom = 1; S.resetScroll = true;
        qa('#uaPeriods .sa-chip').forEach(c => c.classList.toggle('active', c.getAttribute('data-period') === S.period));
        el('uaListView').classList.remove('on');
        el('uaDetailView').classList.add('on');
        renderDetail(true);
        toTop();
    }

    /* =====================================================================
       العرض 2 — تفاصيل المستخدم
       ===================================================================== */
    // ---------- حدود الفترات (Edges) ----------
    function buildEdges(mode, start, count) {
        const y = start.getFullYear(), m = start.getMonth(), d = start.getDate(), e = [];
        for (let i = 0; i <= count; i++) {
            if (mode === 'hour') e.push(new Date(y, m, d, i).getTime());
            else if (mode === 'day') e.push(new Date(y, m, d + i).getTime());
            else if (mode === 'week') e.push(new Date(y, m, d + 7 * i).getTime());
            else if (mode === 'month') e.push(new Date(y, m + i, 1).getTime());
            else e.push(new Date(y + i, 0, 1).getTime());
        }
        return e;
    }
    function labelsFor(mode, edges) {
        const labels = [], full = [];
        for (let i = 0; i < edges.length - 1; i++) {
            const a = new Date(edges[i]);
            if (mode === 'hour') { labels.push(pad(a.getHours()) + ':00'); full.push(fmtDay(a) + ' ' + pad(a.getHours()) + ':00'); }
            else if (mode === 'day') { labels.push(pad(a.getDate()) + ' ' + MONTHS[a.getMonth()].slice(0, 3)); full.push(fmtDay(a)); }
            else if (mode === 'week') {
                const b = new Date(edges[i + 1] - 1);
                labels.push(pad(a.getDate()) + ' ' + MONTHS[a.getMonth()].slice(0, 3));
                full.push('أسبوع ' + a.getDate() + ' ' + MONTHS[a.getMonth()] + ' — ' + b.getDate() + ' ' + MONTHS[b.getMonth()] + ' ' + b.getFullYear());
            }
            else if (mode === 'month') { labels.push(MONTHS[a.getMonth()].slice(0, 4) + ' ' + String(a.getFullYear()).slice(2)); full.push(MONTHS[a.getMonth()] + ' ' + a.getFullYear()); }
            else { labels.push(String(a.getFullYear())); full.push(String(a.getFullYear())); }
        }
        return { labels: labels, full: full };
    }
    function binIndex(edges, t) {
        const n = edges.length - 1;
        if (t < edges[0] || t >= edges[n]) return -1;
        let lo = 0, hi = n - 1;
        while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (edges[mid] <= t) lo = mid; else hi = mid - 1; }
        return lo;
    }
    function aggregate(recs, ops, edges) {
        const n = edges.length - 1;
        const amt = new Array(n).fill(0), cards = new Array(n).fill(0), opn = new Array(n).fill(0);
        recs.forEach(r => { if (!r.ms) return; const i = binIndex(edges, r.ms); if (i >= 0) { amt[i] += r.amount; cards[i]++; } });
        ops.forEach(o => { if (!o.ms) return; const i = binIndex(edges, o.ms); if (i >= 0) opn[i]++; });
        return { amt: amt, cards: cards, ops: opn };
    }

    function periodSpec(period, recs) {
        const now = new Date(), today = midnight(now);
        const Y = today.getFullYear(), M = today.getMonth(), D = today.getDate();
        let mode, start, count, pstart = null, endDate = today, firstDay = null;
        if (period === 'day') { mode = 'hour'; start = today; count = now.getHours() + 1; pstart = new Date(Y, M, D - 1); }
        else if (period === 'week') { mode = 'day'; start = new Date(Y, M, D - 6); count = 7; pstart = new Date(Y, M, D - 13); }
        else if (period === 'month') { mode = 'day'; start = new Date(Y, M, D - 29); count = 30; pstart = new Date(Y, M, D - 59); }
        else if (period === '3months') { mode = 'week'; start = new Date(Y, M, D - 90); count = 13; pstart = new Date(Y, M, D - 181); }
        else if (period === 'year') { mode = 'month'; start = new Date(Y, M - 11, 1); count = 12; pstart = new Date(Y, M - 23, 1); }
        else {
            let first = 0, last = 0;
            recs.forEach(r => { if (!r.ms) return; if (!first || r.ms < first) first = r.ms; if (r.ms > last) last = r.ms; });
            if (!first) return { edges: null, mode: 'day' };
            const fd = midnight(new Date(first)), ld = midnight(new Date(Math.max(last, now.getTime())));
            endDate = ld; firstDay = fd;
            const span = Math.round((ld - fd) / DAY) + 1;
            if (span <= 62) { mode = 'day'; start = fd; count = span; }
            else {
                const months = (ld.getFullYear() - fd.getFullYear()) * 12 + (ld.getMonth() - fd.getMonth()) + 1;
                if (months <= 36) { mode = 'month'; start = new Date(fd.getFullYear(), fd.getMonth(), 1); count = months; }
                else { mode = 'year'; start = new Date(fd.getFullYear(), 0, 1); count = ld.getFullYear() - fd.getFullYear() + 1; }
            }
        }
        const spec = { mode: mode, edges: buildEdges(mode, start, count), pedges: pstart ? buildEdges(mode, pstart, count) : null };
        if (period === 'all') start = firstDay;
        spec.periodLabel = mode === 'hour' ? 'اليوم — ' + fmtShort(start) : fmtShort(start) + ' — ' + fmtShort(endDate);
        return spec;
    }

    function buildDataset(phone, period) {
        const recs = S.byPhone[phone] || [], ops = opsOf(phone);
        const spec = periodSpec(period, recs);
        const inRecs = [], inOps = [];
        const d = {
            period: period, mode: spec.mode, labels: [], full: [], values: [], cardsArr: [], opsArr: [],
            prev: [], prevTotal: 0, hasPrev: !!(spec.pedges), total: 0, cards: 0, ops: 0,
            periodLabel: spec.periodLabel || PERIOD_LONG[period], isTodayIncluded: true,
            inRecs: inRecs, inOps: inOps, undated: 0
        };
        if (period === 'all') {
            recs.forEach(r => inRecs.push(r)); ops.forEach(o => inOps.push(o));
            d.undated = recs.filter(r => !r.ms).length;
        } else if (spec.edges) {
            const t0 = spec.edges[0], t1 = spec.edges[spec.edges.length - 1];
            recs.forEach(r => { if (r.ms >= t0 && r.ms < t1) inRecs.push(r); });
            ops.forEach(o => { if (o.ms >= t0 && o.ms < t1) inOps.push(o); });
        }
        d.total = sum(inRecs.map(r => r.amount));
        d.cards = inRecs.length;
        d.ops = inOps.length;
        if (!spec.edges) return d;

        const lab = labelsFor(spec.mode, spec.edges), cur = aggregate(recs, ops, spec.edges);
        d.labels = lab.labels; d.full = lab.full; d.values = cur.amt; d.cardsArr = cur.cards; d.opsArr = cur.ops;
        if (spec.pedges) d.prev = aggregate(recs, ops, spec.pedges).amt;
        else d.prev = new Array(d.values.length).fill(0);
        d.prevTotal = sum(d.prev);
        return d;
    }

    function renderDetail(animate) {
        const u = S.byId[S.selected]; if (!u) return;
        renderIdentity(u);
        S.dataset = buildDataset(u.phone, S.period);
        renderKPIs();
        renderChart(!!animate);
        if (S.resetScroll) { const sc = el('uaScroll'); if (sc) sc.scrollLeft = sc.scrollWidth; S.resetScroll = false; }
        renderCategories();
        renderInsights(u);
        renderTx(u);
        const lv = el('uaDetailLive');
        lv.classList.toggle('off', !S.live);
        lv.textContent = S.live ? 'تحليل مباشر' : 'المتابعة متوقفة';
    }

    function renderIdentity(u) {
        const av = el('uaIdAv');
        av.innerHTML = '';
        if (u.avatar) {
            const img = document.createElement('img');
            img.alt = '';
            img.onerror = function () { av.innerHTML = fallbackAv(u); };
            img.src = u.avatar;
            av.appendChild(img);
            if (u.online) av.insertAdjacentHTML('beforeend', '<span class="ua-dot"></span>');
        } else av.innerHTML = fallbackAv(u);
        el('uaIdName').textContent = u.name;
        el('uaIdBadge').innerHTML = badgeHTML(u);
        const st = el('uaIdStatus');
        if (u.online) { st.textContent = '● متصل الآن'; st.className = 'ua-id-status on'; }
        else { st.textContent = u.lastSeen ? 'آخر ظهور: ' + ago(u.lastSeen) : 'آخر ظهور: غير مسجّل'; st.className = 'ua-id-status'; }
        el('uaIdPhone').textContent = u.phone;
        el('uaIdAcc').textContent = u.account || '—';
        el('uaIdBal').textContent = fmt(u.balance) + ' ريال';
        el('uaIdJoin').textContent = u.createdAt ? fmtDay(new Date(u.createdAt)) : '—';
    }
    function fallbackAv(u) {
        return '<div class="ua-av" style="background:' + colorOf(u.phone) + '">' + _esc(initialOf(u.name)) + '</div>' + (u.online ? '<span class="ua-dot"></span>' : '');
    }

    function renderSpark() {
        const d = S.dataset, svg = el('uaSpark');
        if (!d || !d.values.length || !d.total) { svg.innerHTML = ''; return; }
        const W = 400, H = 70, P = 4, v = d.values;
        const mn = Math.min.apply(null, v), mx = Math.max.apply(null, v), span = (mx - mn) || 1;
        const pts = v.map((x, i) => ({ x: P + (i / ((v.length - 1) || 1)) * (W - P * 2), y: H - P - ((x - mn) / span) * (H - P * 2) }));
        const line = smoothPath(pts);
        svg.innerHTML = '<defs><linearGradient id="uaHeroA" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff" stop-opacity=".5"/><stop offset="100%" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>' +
            '<path d="' + line + ' L ' + pts[pts.length - 1].x + ' ' + H + ' L ' + pts[0].x + ' ' + H + ' Z" fill="url(#uaHeroA)"/>' +
            '<path d="' + line + '" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2" stroke-linecap="round"/>';
    }

    function renderKPIs() {
        const d = S.dataset; if (!d) return;
        const g = growthOf(d.total, d.prevTotal);
        const noPrev = !d.hasPrev || d.prevTotal === 0;
        el('uaTotal').innerHTML = fmt(d.total) + '<small>ريال</small>';
        el('uaTotalSub').textContent = d.periodLabel;

        const pill = el('uaGrowthPill');
        if (noPrev) {
            pill.textContent = d.hasPrev ? 'لا توجد بيانات سابقة' : 'كل الفترات';
            pill.className = 'sa-pill';
            pill.style.background = 'rgba(148,163,184,.18)';
            pill.style.borderColor = 'rgba(148,163,184,.3)';
            pill.style.color = '#94a3b8';
        } else {
            pill.textContent = (g >= 0 ? '▲ +' : '▼ ') + g.toFixed(1) + '% عن السابق';
            pill.className = 'sa-pill ' + (g >= 0 ? 'up' : 'down');
            pill.style.background = pill.style.borderColor = pill.style.color = '';
        }
        el('uaCards').textContent = fmt(d.cards);
        el('uaOps').textContent = fmt(d.ops);
        el('uaAvg').textContent = fmt(d.ops > 0 ? d.total / d.ops : 0);

        el('uaChartTitle').textContent = 'اتجاه المشتريات — ' + modeAr(d.mode);
        let sub = d.periodLabel;
        if (d.undated > 0) sub += ' (' + fmt(d.undated) + ' كرت بدون تاريخ غير ظاهر بالرسم)';
        el('uaChartPeriod').textContent = sub;
        el('uaChartLive').style.display = S.live ? '' : 'none';
        const lg = qa('.sa-lg[data-legend="prev"]')[0];
        if (lg) lg.classList.toggle('disabled', !d.hasPrev);
        renderSpark();
    }

    /* ----- التلميح ----- */
    function hideTip() {
        clearTimeout(ttTimer);
        const t = el('uaTooltip'); if (!t) return;
        t.classList.remove('visible'); t.setAttribute('aria-hidden', 'true');
        const bar = el('uaTtFill'); if (bar) bar.classList.remove('run');
        S.ttKey = null;
        qa('.sa-pt.active').forEach(o => o.classList.remove('active'));
    }

    function showTip(node) {
        const tip = el('uaTooltip'), card = el('uaChartCard'), d = S.dataset;
        if (!tip || !card || !d) return;
        const val = parseFloat(node.getAttribute('data-val'));
        const label = node.getAttribute('data-label');
        const type = node.getAttribute('data-type');
        const idx = parseInt(node.getAttribute('data-idx'), 10);

        el('uaTtHead').innerHTML = (type === 'prev' ? '🔴 ' : '🟢 ') + _esc(label);
        el('uaTtHead').style.color = type === 'prev' ? '#f87171' : '#34d399';
        el('uaTtVal').innerHTML = fmt(val) + '<small>ريال</small>';

        const box = el('uaTtDelta'), grey = 'background:rgba(148,163,184,.16);color:#94a3b8';
        if (type !== 'prev' && d.prev[idx] !== undefined && d.hasPrev) {
            const p = d.prev[idx], diff = p > 0 ? ((val - p) / p) * 100 : 0, up = diff >= 0;
            box.innerHTML = (p === 0
                ? '<span class="sa-tt-delta" style="' + grey + '">لا توجد بيانات سابقة</span>'
                : '<span class="sa-tt-delta ' + (up ? 'up' : 'dn') + '">' + (up ? '▲' : '▼') + ' ' + Math.abs(diff).toFixed(1) + '% <small>مقارنة بالفترة السابقة</small></span>');
        } else if (type === 'prev') {
            box.innerHTML = '<span class="sa-tt-delta" style="' + grey + '">الفترة السابقة</span>';
        } else box.innerHTML = '';
        if (type !== 'prev' && d.cardsArr[idx] !== undefined) {
            box.insertAdjacentHTML('beforeend', '<span class="sa-tt-delta" style="' + grey + ';margin-inline-start:4px">' + fmt(d.cardsArr[idx]) + ' كرت · ' + fmt(d.opsArr[idx]) + ' عملية</span>');
        }

        tip.classList.add('visible'); tip.setAttribute('aria-hidden', 'false');
        qa('.sa-pt.active').forEach(o => o.classList.remove('active'));
        qa('[data-type="' + type + '"][data-idx="' + idx + '"]').forEach(o => o.classList.add('active'));

        const m = node.getBoundingClientRect(), c = card.getBoundingClientRect();
        let left = m.left - c.left + m.width / 2 - tip.offsetWidth / 2;
        left = Math.max(8, Math.min(left, card.clientWidth - tip.offsetWidth - 8));
        let top = m.top - c.top - tip.offsetHeight - 14;
        if (top < 8) top = m.bottom - c.top + 14;
        tip.style.left = left + 'px'; tip.style.top = top + 'px';

        const bar = el('uaTtFill');
        bar.classList.remove('run'); void bar.offsetWidth;
        bar.style.setProperty('--tt', TT_MS + 'ms'); bar.classList.add('run');
        clearTimeout(ttTimer); ttTimer = setTimeout(hideTip, TT_MS);
    }

    function bindTips() {
        qa('#uaViewport [data-label]').forEach(node => {
            node.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') showTip(node); });
            node.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') hideTip(); });
            node.addEventListener('click', e => {
                e.stopPropagation();
                const key = node.getAttribute('data-type') + '-' + node.getAttribute('data-idx');
                if (S.ttKey === key && el('uaTooltip').classList.contains('visible')) { hideTip(); return; }
                showTip(node); S.ttKey = key;
            });
        });
    }

    function smoothPath(pts) {
        if (!pts.length) return '';
        if (pts.length === 1) return 'M ' + pts[0].x + ' ' + pts[0].y;
        let d = 'M ' + pts[0].x + ' ' + pts[0].y;
        for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
            const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
            const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
            d += ' C ' + c1x.toFixed(2) + ' ' + c1y.toFixed(2) + ', ' + c2x.toFixed(2) + ' ' + c2y.toFixed(2) + ', ' + p2.x.toFixed(2) + ' ' + p2.y.toFixed(2);
        }
        return d;
    }

    /* ----- المخطط الرئيسي (مساحة / خط / أعمدة) ----- */
    function renderChart(animate) {
        const d = S.dataset, vp = el('uaViewport');
        hideTip();
        el('uaYAxis').innerHTML = '';
        if (!d || !d.values.length || (d.total === 0 && d.prevTotal === 0 && !sum(d.values))) {
            vp.style.width = '';
            vp.innerHTML = '<div class="sa-empty"><i class="fas fa-chart-line"></i><b>لا توجد مشتريات في هذه الفترة</b><span>جرّب اختيار فترة أطول أو "الكل"</span></div>';
            el('uaHighlight').style.display = 'none';
            ['uaStatPeak', 'uaStatAvg', 'uaStatLow', 'uaStatVol'].forEach(i => { el(i).textContent = '—'; });
            el('uaStatPeakLbl').textContent = '—';
            el('uaStatLowLbl').textContent = '—';
            return;
        }
        const showPrev = S.showPrev && d.hasPrev;
        const n = d.labels.length;
        const W = Math.max(300, n * 40) * S.zoom;
        vp.style.width = W + 'px';

        const all = d.values.concat(showPrev ? d.prev : []);
        let maxV = Math.max.apply(null, all.concat([1])), minV = Math.min.apply(null, all.concat([0]));
        const span = (maxV - minV) || 1;
        maxV += span * 0.2; minV = Math.max(0, minV - span * 0.18);

        const H = 180, PT = 22, PB = 22, usable = H - PT - PB;
        const yOf = v => H - PB - ((v - minV) / (maxV - minV)) * usable;
        const xOf = i => n > 1 ? (i / (n - 1)) * (W - 44) + 22 : W / 2;

        const div = maxV >= 1e9 ? 1e9 : maxV >= 1e6 ? 1e6 : maxV >= 1e4 ? 1e3 : 1;
        el('uaChartUnit').textContent = div === 1e9 ? 'بالمليار ريال' : div === 1e6 ? 'بالمليون ريال' : div === 1e3 ? 'بالألف ريال' : 'بالريال';
        const axisText = v => { const x = v / div; return x >= 100 || div === 1 ? String(Math.round(x)) : x >= 10 ? x.toFixed(1) : x.toFixed(2); };

        const avgV = sum(d.values) / n, avgY = yOf(Math.min(avgV, maxV));
        const grid = [0.08, 0.29, 0.5, 0.71, 0.92].map(r => { const v = minV + r * (maxV - minV); return { y: yOf(v), text: axisText(v) }; });
        let near = 0, best = Infinity;
        grid.forEach((g, i) => { const dd = Math.abs(g.y - avgY); if (dd < best) { best = dd; near = i; } });
        el('uaYAxis').innerHTML = grid.map((g, i) => '<span class="' + (i === near ? 'hl' : '') + '" style="top:' + g.y.toFixed(1) + 'px">' + g.text + '</span>').join('');

        const mk = (arr, lbl) => arr.map((v, i) => ({ x: xOf(i), y: yOf(v), val: v, label: lbl[i], idx: i }));
        const prevPts = mk(d.prev, d.full), curPts = mk(d.values, d.full);
        const peakVal = Math.max.apply(null, d.values), peakIdx = d.values.indexOf(peakVal), last = n - 1;
        const lineD = smoothPath(curPts), prevD = smoothPath(prevPts);
        const areaD = lineD + ' L ' + curPts[last].x + ' ' + (H - PB) + ' L ' + curPts[0].x + ' ' + (H - PB) + ' Z';
        const attrs = (p, type, i) => 'data-val="' + p.val + '" data-label="' + _esc(p.label) + '" data-type="' + type + '" data-idx="' + i + '"';

        let svg = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" style="display:block;overflow:visible"><defs>' +
            '<linearGradient id="uaLineG" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#3b82f6"/><stop offset="50%" stop-color="#22d3ee"/><stop offset="100%" stop-color="#10b981"/></linearGradient>' +
            '<linearGradient id="uaAreaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity=".4"/><stop offset="50%" stop-color="#3b82f6" stop-opacity=".14"/><stop offset="100%" stop-color="#3b82f6" stop-opacity=".01"/></linearGradient>' +
            '<linearGradient id="uaBarG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity=".95"/><stop offset="100%" stop-color="#10b981" stop-opacity=".55"/></linearGradient>' +
            '<linearGradient id="uaBarPk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fbbf24"/><stop offset="100%" stop-color="#f59e0b" stop-opacity=".5"/></linearGradient>' +
            '<filter id="uaGlow" x="-5%" y="-40%" width="110%" height="180%"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>' +
            '<filter id="uaPk" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>';

        grid.forEach((g, i) => {
            const isAvg = i === near && S.showAvg;
            svg += '<line x1="0" y1="' + g.y.toFixed(1) + '" x2="' + W + '" y2="' + g.y.toFixed(1) + '" stroke="' + (isAvg ? 'rgba(167,139,250,.28)' : 'rgba(255,255,255,.06)') + '" stroke-dasharray="3,5" stroke-width=".8"/>';
        });

        if (S.chartType === 'bars' && S.showCur) {
            const bw = Math.max(4, (W - 60) / n * 0.55);
            curPts.forEach((p, i) => {
                const pk = i === peakIdx && S.showPeak && peakVal > 0;
                svg += '<rect x="' + (p.x - bw / 2).toFixed(1) + '" y="' + p.y.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(0, H - PB - p.y).toFixed(1) + '" rx="3" fill="url(#' + (pk ? 'uaBarPk' : 'uaBarG') + ')" class="' + (animate ? 'sa-pt-in' : '') + '" style="' + (animate ? 'animation-delay:' + Math.min(i * 40, 720) + 'ms' : '') + '" ' + attrs(p, 'cur', i) + ' opacity="' + (pk ? 1 : .88) + '"/>';
            });
            svg += '<path d="' + lineD + '" fill="none" stroke="#22d3ee" stroke-width="1.2" opacity=".5"/>';
        }
        if (S.chartType === 'area' && S.showCur) svg += '<path d="' + areaD + '" fill="url(#uaAreaG)" opacity="0" class="sa-area"/>';
        if (showPrev) svg += '<path d="' + prevD + '" fill="none" stroke="#ef4444" stroke-width="1.9" stroke-dasharray="6,4" opacity=".72" stroke-linecap="round"/>';
        if (S.showCur && S.chartType !== 'bars') svg += '<path class="sa-chart-line" d="' + lineD + '" fill="none" stroke="url(#uaLineG)" stroke-width="2.9" stroke-linecap="round" stroke-linejoin="round" filter="url(#uaGlow)"/>';
        if (S.showAvg) svg += '<line x1="0" y1="' + avgY.toFixed(1) + '" x2="' + W + '" y2="' + avgY.toFixed(1) + '" stroke="#a78bfa" stroke-width="1.2" stroke-dasharray="2,4" opacity=".7"/><text x="' + (W - 4) + '" y="' + (avgY - 4).toFixed(1) + '" font-size="7.5" font-weight="900" fill="#a78bfa" text-anchor="end">AVG</text>';
        if (showPrev) {
            prevPts.forEach((p, i) => {
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="2.5" fill="#ef4444" stroke="' + SOLID + '" stroke-width="1.1" class="sa-pt" ' + attrs(p, 'prev', i) + '/>';
            });
        }
        if (S.showCur && S.chartType !== 'bars') {
            curPts.forEach((p, i) => {
                const isLast = i === last, pk = i === peakIdx && S.showPeak && peakVal > 0;
                const livePt = S.live && isLast;
                const color = pk ? '#fbbf24' : livePt ? '#10b981' : isLast ? '#22d3ee' : '#10b981';
                const r = livePt ? 7 : pk ? 6 : isLast ? 5.5 : 4;
                if (livePt) svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="14" fill="none" stroke="#10b981" stroke-width="2" class="sa-pulse" opacity=".6"/>';
                else if (isLast && !pk) svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="9" fill="none" stroke="#22d3ee" stroke-width="1.5" class="sa-pulse"/>';
                const t = isLast ? 'now' : 'cur';
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="' + r + '" fill="' + color + '" stroke="' + SOLID + '" stroke-width="1.7" class="sa-pt ' + (animate ? 'sa-pt-in' : '') + '" style="' + (animate ? 'animation-delay:' + Math.min(i * 28, 720) + 'ms' : '') + '"' + (pk ? ' filter="url(#uaPk)"' : '') + ' ' + attrs(p, t, i) + '/>';
                svg += '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="14" fill="transparent" class="sa-pt" ' + attrs(p, t, i) + '/>';
            });
        }
        if (S.showPeak && S.showCur && peakVal > 0 && peakIdx !== last && S.chartType !== 'bars') {
            const pk = curPts[peakIdx], fy = Math.max(8, pk.y - 20);
            svg += '<g><circle cx="' + pk.x.toFixed(1) + '" cy="' + fy.toFixed(1) + '" r="8" fill="url(#uaBarPk)" filter="url(#uaPk)"/><text x="' + pk.x.toFixed(1) + '" y="' + (fy + 3).toFixed(1) + '" font-size="9" text-anchor="middle" fill="#1a1207" font-weight="900">★</text></g>';
        }
        svg += '</svg>';

        // تخفيف ازدحام تسميات المحور
        const stepLbl = n > 24 ? Math.ceil(n / 24) : 1;
        let axis = '<div class="sa-axis" style="width:' + W + 'px">';
        d.labels.forEach((lbl, i) => {
            const isLast = i === last, pk = i === peakIdx && S.showPeak && peakVal > 0;
            if (i % stepLbl !== 0 && !isLast && !pk) return;
            const live = S.live && isLast;
            axis += '<span class="' + (live ? 'live-now' : isLast ? 'now' : pk ? 'peak-lbl' : '') + '" style="left:' + xOf(i).toFixed(1) + 'px">' + _esc(lbl) + '</span>';
        });
        vp.innerHTML = svg + axis + '</div>';

        const area = vp.querySelector('.sa-area');
        if (animate) {
            const ln = vp.querySelector('.sa-chart-line');
            if (ln) {
                try {
                    const len = ln.getTotalLength();
                    ln.style.strokeDasharray = len; ln.style.strokeDashoffset = len; ln.getBoundingClientRect();
                    requestAnimationFrame(() => { ln.style.strokeDashoffset = 0; });
                } catch (e) { }
            }
            if (area) { area.style.transition = 'opacity .9s ease .35s'; requestAnimationFrame(() => { area.style.opacity = '1'; }); }
        } else if (area) area.style.opacity = '1';

        bindTips();
        updateHighlight();
    }

    function updateHighlight() {
        const d = S.dataset; if (!d || !d.values.length) return;
        const n = d.values.length;
        const pk = Math.max.apply(null, d.values), pi = d.values.indexOf(pk);
        const lo = Math.min.apply(null, d.values), li = d.values.indexOf(lo);
        const avg = sum(d.values) / n;
        el('uaHighlight').style.display = 'flex';
        el('uaHlTitle').textContent = 'أعلى فترة: ' + d.full[pi];
        el('uaHlSub').textContent = (avg > 0 && pk > 0) ? '+' + (((pk - avg) / avg) * 100).toFixed(0) + '% فوق المتوسط' : 'لا توجد مشتريات';
        el('uaHlVal').textContent = shortMoney(pk);
        el('uaStatPeak').textContent = shortMoney(pk); el('uaStatPeakLbl').textContent = d.labels[pi];
        el('uaStatAvg').textContent = shortMoney(avg);
        el('uaStatLow').textContent = shortMoney(lo); el('uaStatLowLbl').textContent = d.labels[li];
        const variance = sum(d.values.map(v => Math.pow(v - avg, 2))) / n;
        const vol = avg > 0 ? (Math.sqrt(variance) / avg) * 100 : 0;
        const vv = el('uaStatVol');
        vv.textContent = vol.toFixed(1) + '%';
        vv.style.color = vol > 25 ? 'var(--red)' : vol > 15 ? 'var(--gold)' : 'var(--green)';
    }

    /* ----- التوزيع حسب الفئة ----- */
    function categoryStats(recs) {
        const map = {};
        recs.forEach(r => {
            const o = map[r.catId] || (map[r.catId] = { name: r.catName, count: 0, amount: 0 });
            o.count++; o.amount += r.amount;
        });
        const cats = Object.keys(map).map(k => map[k]).sort((a, b) => b.count - a.count || b.amount - a.amount);
        cats.forEach((c, i) => { c.color = PALETTE[i % PALETTE.length]; });
        return { cats: cats, total: sum(cats.map(c => c.count)) };
    }

    function renderCategories() {
        const d = S.dataset, svgEl = el('uaDonut');
        el('uaCatHint').textContent = PERIOD_LONG[S.period];
        const st = categoryStats(d ? d.inRecs : []);
        S.dataset.cats = st;
        if (!st.total) {
            svgEl.innerHTML = '<circle cx="70" cy="70" r="52" fill="none" stroke="#1e293b" stroke-width="15"/>';
            el('uaDonutTotal').textContent = '0';
            el('uaCatList').innerHTML = '<div class="sa-none">لا توجد كروت في هذه الفترة</div>';
            return;
        }
        const R = 52, C = 2 * Math.PI * R;
        let off = 0, svg = '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="#1e293b" stroke-width="15"/>';
        st.cats.forEach(c => {
            const dash = (c.count / st.total) * C;
            svg += '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="' + c.color + '" stroke-width="15" stroke-dasharray="' + dash.toFixed(2) + ' ' + (C - dash).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 70 70)"/>';
            off += dash;
        });
        svgEl.innerHTML = svg;
        el('uaDonutTotal').textContent = fmt(st.total);
        el('uaCatList').innerHTML = st.cats.slice(0, 6).map(c =>
            '<div class="sa-cat"><i style="background:' + c.color + '"></i><span class="sa-cat-name">' + _esc(c.name) + '</span><span class="sa-cat-val" style="color:' + c.color + '">' + fmt(c.count) + ' · ' + ((c.count / st.total) * 100).toFixed(0) + '%</span></div>').join('');
    }

    /* ----- التحليل الذكي (من سلوك الشراء الفعلي) ----- */
    function renderInsights(u) {
        const d = S.dataset, box = el('uaInsights');
        const list = [];
        const allOps = opsOf(u.phone).filter(o => o.ms);

        // 1) الخمول
        if (!u.cards) {
            list.push(['warn', 'fa-circle-exclamation', 'لم يُسجَّل لهذا المستخدم <b>أي شراء</b> حتى الآن.']);
        } else if (u.lastMs) {
            const days = Math.floor((Date.now() - u.lastMs) / DAY);
            if (days > ACTIVE_DAYS) list.push(['bad', 'fa-user-clock', 'لم يشترِ منذ <b>' + fmt(days) + ' يوماً</b> — يُنصح بالتواصل معه لإعادة تنشيطه.']);
            else if (days <= 1) list.push(['good', 'fa-user-check', 'مستخدم <b>نشط</b> — آخر شراء <b>' + ago(u.lastMs) + '</b>.']);
            else list.push(['info', 'fa-user-check', 'آخر شراء <b>' + ago(u.lastMs) + '</b>.']);
        }

        // 2) النمو
        if (d && d.total > 0) {
            if (d.hasPrev && d.prevTotal > 0) {
                const g = growthOf(d.total, d.prevTotal);
                if (g >= 20) list.push(['good', 'fa-rocket', 'مشترياته في ' + PERIOD_LONG[S.period] + ' <b>نمت بقوة +' + g.toFixed(1) + '%</b> عن الفترة السابقة.']);
                else if (g >= 5) list.push(['good', 'fa-arrow-trend-up', 'نمو <b>إيجابي</b> بنسبة +' + g.toFixed(1) + '% عن الفترة السابقة.']);
                else if (g >= 0) list.push(['info', 'fa-arrow-right', 'مشتريات <b>مستقرة</b> (+' + g.toFixed(1) + '% عن الفترة السابقة).']);
                else list.push(['bad', 'fa-arrow-trend-down', 'تراجع بنسبة <b>' + Math.abs(g).toFixed(1) + '%</b> عن الفترة السابقة.']);
            } else if (d.hasPrev) {
                list.push(['info', 'fa-circle-info', 'لا توجد مشتريات في الفترة السابقة للمقارنة بها.']);
            }
        } else if (u.cards) {
            list.push(['info', 'fa-circle-info', 'لا توجد مشتريات في ' + PERIOD_LONG[S.period] + ' — إجمالي مشترياته الكلي <b>' + fmt(u.amount) + ' ريال</b>.']);
        }

        // 3) الفئة المفضلة
        const cs = d && d.cats;
        if (cs && cs.total) {
            const top = cs.cats[0];
            list.push(['info', 'fa-heart', 'فئته المفضلة: <b style="color:' + top.color + '">' + _esc(top.name) + '</b> — ' + fmt(top.count) + ' كرت (' + ((top.count / cs.total) * 100).toFixed(0) + '% من مشترياته).']);
        }

        // 4) الذروة
        if (d && d.values.length && sum(d.values) > 0) {
            const pk = Math.max.apply(null, d.values), pi = d.values.indexOf(pk);
            list.push(['info', 'fa-medal', 'أنشط فترة: <b>' + _esc(d.full[pi]) + '</b> بإجمالي <b>' + fmt(pk) + ' ريال</b>.']);
        }

        // 5) وتيرة الشراء (كل العمليات المؤرَّخة)
        if (allOps.length >= 3) {
            const spanDays = (allOps[allOps.length - 1].ms - allOps[0].ms) / DAY;
            const every = spanDays / (allOps.length - 1);
            list.push(['info', 'fa-calendar-check', 'يشتري تقريباً <b>' + (every < 1 ? 'أكثر من مرة يومياً' : 'كل ' + String(Math.round(every * 10) / 10) + ' يوم') + '</b> (بناءً على ' + fmt(allOps.length) + ' عملية).']);
        }

        // 6) الحجم والترتيب
        if (u.cards && S.totals.amount > 0) {
            const share = (u.amount / S.totals.amount) * 100;
            list.push(['info', 'fa-ranking-star', 'المرتبة <b>' + u.rank + '</b> من ' + fmt(S.totals.buyers) + ' مشترٍ — يمثّل <b>' + share.toFixed(1) + '%</b> من إجمالي المبيعات.']);
        }
        if (d && d.ops > 0) {
            list.push(['info', 'fa-receipt', 'متوسط العملية <b>' + fmt(d.total / d.ops) + ' ريال</b> · <b>' + (d.cards / d.ops).toFixed(1) + '</b> كرت لكل عملية.']);
        }

        box.innerHTML = list.length
            ? list.map(i => '<div class="sa-ins ' + i[0] + '"><i class="fas ' + i[1] + '"></i><span>' + i[2] + '</span></div>').join('')
            : '<div class="sa-none">لا توجد بيانات كافية للتحليل</div>';
    }

    /* ----- آخر 10 عمليات ----- */
    function renderTx(u) {
        const ops = opsOf(u.phone).slice().sort((a, b) => b.ms - a.ms).slice(0, 10);
        const colors = {};
        categoryStats(S.byPhone[u.phone] || []).cats.forEach(c => { colors[c.name] = c.color; });
        el('uaTxCount').textContent = ops.length ? 'من أصل ' + fmt(opsOf(u.phone).length) + ' عملية' : '—';
        if (!ops.length) { el('uaTx').innerHTML = '<div class="sa-none">لا توجد عمليات شراء لهذا المستخدم</div>'; return; }
        el('uaTx').innerHTML = ops.map(o => {
            const c = colors[o.catName] || '#3b82f6';
            const when = o.ms ? fmtFull(new Date(o.ms)) + ' · ' + ago(o.ms) : 'بدون تاريخ';
            const code = o.codes.length ? '<span class="ua-tx-code">' + _esc(maskCode(o.codes[0])) + '</span>' + (o.codes.length > 1 ? ' <bdi dir="ltr">+' + (o.codes.length - 1) + '</bdi>' : '') : '';
            return '<div class="ua-tx">' +
                '<div class="ua-tx-ico" style="background:' + c + '22;border-color:' + c + '55;color:' + c + '"><i class="fas fa-ticket"></i></div>' +
                '<div class="ua-tx-info"><div class="ua-tx-name">' + _esc(o.catName) + ' · ' + fmt(o.cards) + ' كرت</div>' +
                '<div class="ua-tx-sub">' + when + (code ? ' · ' + code : '') + '</div></div>' +
                '<div class="ua-tx-amt">+' + fmt(o.amount) + '</div></div>';
        }).join('');
    }

    /* ----- تصدير CSV ----- */
    function csvCell(v) {
        if (typeof v === 'number') return String(v);
        let s = String(v === null || v === undefined ? '' : v);
        if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // حماية من حقن الصيغ في Excel
        return '"' + s.replace(/"/g, '""') + '"';
    }
    function exportCsv() {
        const u = S.byId[S.selected];
        if (!u || !S.dataset) return;
        const recs = S.dataset.inRecs.slice().sort((a, b) => a.ms - b.ms);
        if (!recs.length) { say('لا توجد مشتريات للتصدير في هذه الفترة', false); return; }
        const out = [['التاريخ', 'الوقت', 'الفئة', 'السعر (ريال)', 'كود الكرت', 'اسم المستخدم', 'الجوال', 'رقم الحساب']];
        recs.forEach(r => {
            const d = r.ms ? new Date(r.ms) : null;
            out.push([d ? d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) : 'بدون تاريخ', d ? pad(d.getHours()) + ':' + pad(d.getMinutes()) : '', r.catName, r.amount, r.code, u.name, u.phone, u.account]);
        });
        const csv = '\uFEFF' + out.map(r => r.map(csvCell).join(',')).join('\n');
        const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
        const a = document.createElement('a');
        a.href = url;
        a.download = 'user_' + u.phone.replace(/[^\w-]/g, '') + '_' + S.period + '.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        say('تم تصدير ' + recs.length + ' كرت', true);
    }

    /* =====================================================================
       المتابعة المباشرة
       ===================================================================== */
    function setLiveUI() {
        const on = S.live, sw = el('uaLiveToggle');
        el('uaLive').classList.toggle('off', !on);
        sw.classList.toggle('on', on);
        sw.setAttribute('aria-checked', on ? 'true' : 'false');
        el('uaLiveBadge').textContent = on ? 'LIVE' : 'MANUAL';
        el('uaLiveBadge').classList.toggle('off', !on);
    }
    function setLive(on, silent) {
        S.live = on;
        setLiveUI();
        if (on) {
            S.gotUsers = S.gotStore = false;
            attach();
            if (!silent) say('المتابعة المباشرة مُفعّلة', true);
        } else {
            detach();
            if (!silent) say('تم إيقاف المتابعة المباشرة — البيانات المعروضة ثابتة', false);
        }
        if (S.view === 'detail') renderDetail(false);
    }

    /* =====================================================================
       الربط (مرة واحدة)
       ===================================================================== */
    function bind() {
        if (S.bound) return;
        S.bound = true;

        let st = null;
        el('uaSearch').addEventListener('input', e => {
            clearTimeout(st);
            st = setTimeout(() => { S.search = e.target.value; S.visible = PAGE_SIZE; renderList(); }, 120);
        });

        qa('#uaSort button').forEach(b => b.addEventListener('click', () => {
            S.sort = b.getAttribute('data-sort'); S.visible = PAGE_SIZE;
            qa('#uaSort button').forEach(x => x.classList.toggle('active', x === b));
            renderList();
        }));

        el('uaMore').addEventListener('click', () => { S.visible += PAGE_SIZE; renderList(); });

        const listBox = el('uaList');
        listBox.addEventListener('click', e => {
            const row = e.target.closest && e.target.closest('.ua-row');
            if (row) openDetail(row.getAttribute('data-phone'));
        });
        listBox.addEventListener('keydown', e => {
            if (e.key !== 'Enter' && e.key !== ' ') return;
            const row = e.target.closest && e.target.closest('.ua-row');
            if (row) { e.preventDefault(); openDetail(row.getAttribute('data-phone')); }
        });

        el('uaBack').addEventListener('click', showList);

        qa('#uaPeriods .sa-chip').forEach(chip => chip.addEventListener('click', () => {
            S.period = chip.getAttribute('data-period'); S.zoom = 1; S.resetScroll = true;
            qa('#uaPeriods .sa-chip').forEach(c => c.classList.toggle('active', c === chip));
            renderDetail(true);
        }));

        const sw = el('uaLiveToggle');
        sw.addEventListener('click', () => setLive(!S.live));
        sw.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setLive(!S.live); } });

        el('uaZoomIn').addEventListener('click', () => { S.zoom = Math.min(3.2, +(S.zoom + 0.3).toFixed(2)); renderChart(false); });
        el('uaZoomOut').addEventListener('click', () => { S.zoom = Math.max(0.75, +(S.zoom - 0.3).toFixed(2)); renderChart(false); });
        el('uaZoomReset').addEventListener('click', () => { S.zoom = 1; renderChart(false); });

        qa('.sa-ctype').forEach(b => b.addEventListener('click', () => {
            qa('.sa-ctype').forEach(x => x.classList.remove('active'));
            b.classList.add('active');
            S.chartType = b.getAttribute('data-chart');
            renderChart(true);
        }));

        qa('.sa-lg').forEach(item => item.addEventListener('click', () => {
            const k = item.getAttribute('data-legend');
            if (k === 'cur') S.showCur = !S.showCur;
            if (k === 'prev') S.showPrev = !S.showPrev;
            if (k === 'avg') S.showAvg = !S.showAvg;
            if (k === 'peak') S.showPeak = !S.showPeak;
            item.classList.toggle('off');
            renderChart(false);
        }));

        el('uaExport').addEventListener('click', exportCsv);
        el('uaChat').addEventListener('click', () => {
            if (!S.selected) return;
            if (typeof openChatWithUser === 'function') openChatWithUser(S.selected);
            else say('ميزة المراسلة غير متاحة حالياً', false);
        });

        document.addEventListener('click', e => {
            if (!S.opened) return;
            if (e.target.closest && (e.target.closest('#uaViewport [data-label]') || e.target.closest('#uaTooltip'))) return;
            const t = el('uaTooltip');
            if (t && t.classList.contains('visible')) hideTip();
        });
        document.addEventListener('keydown', e => { if (e.key === 'Escape' && S.opened) hideTip(); });

        let rt = null;
        window.addEventListener('resize', () => {
            clearTimeout(rt);
            rt = setTimeout(() => { if (S.opened && S.view === 'detail' && S.dataset) renderChart(false); }, 180);
        });
    }

    /* =====================================================================
       الواجهة العامة
       ===================================================================== */
    window.UsersAnalysis = {
        open: function () {
            if (S.opened) return;
            S.opened = true;
            bind();
            S.live = true;
            S.gotUsers = S.gotStore = false;
            S.view = 'list'; S.selected = null; S.dataset = null; S.visible = PAGE_SIZE;
            el('uaListView').classList.add('on');
            el('uaDetailView').classList.remove('on');
            setLiveUI();
            setStatus(null);
            renderLoading();
            attach();
            clearInterval(S.tick);
            // تحديث الأزمنة النسبية ("منذ 3 دقائق") وحدود الفترات كل دقيقة
            S.tick = setInterval(() => { if (S.opened && S.gotUsers && S.gotStore) renderAll(); }, 60000);
        },
        close: function () {
            if (!S.opened) return;
            S.opened = false;
            detach();
            clearInterval(S.tick); S.tick = null;
            hideTip();
            // تحرير الذاكرة
            S.usersRaw = S.storeRaw = null; S.gotUsers = S.gotStore = false;
            S.list = []; S.byId = {}; S.byPhone = {}; S.opsCache = {};
            S.dataset = null; S.selected = null; S.view = 'list';
        },
        // يعيد true إذا عالج الرجوع داخلياً (من التفاصيل إلى القائمة) — يستخدمه router عند زر الرجوع
        back: function () {
            if (S.opened && S.view === 'detail') { showList(); return true; }
            return false;
        }
    };
})();
