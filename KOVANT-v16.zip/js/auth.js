// ============================================================
// AUTH: LOGIN, SIGNUP + BIOMETRIC + NOTIFICATIONS
// ============================================================

if (typeof APP === 'undefined') {
    var APP = {
        user: null,
        notifications: [],
        storeData: {},
        adminUsers: [],
        adminCurrentSection: 'system',
        selectedCategoryId: null,
        selectedCategory: null,
        hiddenBalance: false,
        soundEnabled: false,
        html5Qr: null,
        revenueChart: null,
        currentTicketId: null,
        selectedMessage: null,
        toastTimeout: null,
        longPressTimer: null,
        typingTimeout: null,
        _adminUsersListener: null,
        _adminDevicesListener: null,
        _notifListenerPhone: null,
        adminPassword: null
    };
}

// ✅ دوال مساعدة
if (typeof isValidYemeniPhone === 'undefined') {
    function isValidYemeniPhone(p) { return /^7\d{8}$/.test(p); }
}
if (typeof generateDeviceId === 'undefined') {
    function generateDeviceId() {
        let d = localStorage.getItem('deviceId');
        if (!d) {
            d = 'dev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15);
            localStorage.setItem('deviceId', d);
        }
        return d;
    }
}
if (typeof hashPassword === 'undefined') {
    async function hashPassword(password) {
        const enc = new TextEncoder().encode(password);
        const buf = await crypto.subtle.digest('SHA-256', enc);
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
}
if (typeof getDeviceName === 'undefined') {
    function getDeviceName() {
        const ua = navigator.userAgent;
        if (/Android/i.test(ua)) return 'Android';
        if (/iPhone|iPad|iPod/i.test(ua)) return 'iOS';
        if (/Windows/i.test(ua)) return 'Windows';
        if (/Mac/i.test(ua)) return 'Mac';
        return 'جهاز غير معروف';
    }
}
if (typeof getDeviceFingerprint === 'undefined') {
    function getDeviceFingerprint() {
        const raw = [generateDeviceId(), navigator.userAgent || 'unknown', navigator.language || 'en', window.screen.width + 'x' + window.screen.height].join('###');
        return CryptoJS.SHA256(raw).toString(CryptoJS.enc.Hex);
    }
}
if (typeof getDeviceAnalytics === 'undefined') {
    async function getDeviceAnalytics() {
        return {
            os: navigator.userAgent.includes('Android') ? 'Android' : 'Unknown',
            browser: navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Unknown',
            deviceType: /Mobile/i.test(navigator.userAgent) ? 'mobile' : 'desktop'
        };
    }
}
if (typeof getUniqueAccountNumber === 'undefined') {
    async function getUniqueAccountNumber() {
        for (let i = 0; i < 20; i++) {
            const c = '40' + Math.floor(10000000 + Math.random() * 90000000).toString();
            const snap = await database.ref('users').orderByChild('accountNumber').equalTo(c).once('value');
            if (!snap.exists()) return c;
        }
        throw new Error('تعذر توليد رقم حساب فريد');
    }
}
if (typeof isDeviceLinkedToOtherAccount === 'undefined') {
    async function isDeviceLinkedToOtherAccount(deviceId, excludePhone) {
        const snap = await database.ref('users').once('value');
        if (!snap.val()) return false;
        for (const k in snap.val()) {
            const d = snap.val()[k];
            if (d.phone === excludePhone) continue;
            if (d.devices && d.devices[deviceId]) return true;
        }
        return false;
    }
}

// ============================================================
// 📅 قوائم تاريخ الميلاد
// ============================================================
function populateDateSelects() {
    const daySelect = document.getElementById('birthDay');
    const monthSelect = document.getElementById('birthMonth');
    const yearSelect = document.getElementById('birthYear');
    if (!daySelect || !monthSelect || !yearSelect) return;
    if (daySelect.options.length > 1) return;

    for (let i = 1; i <= 31; i++) {
        const o = document.createElement('option'); o.value = i; o.textContent = i; daySelect.appendChild(o);
    }
    for (let i = 1; i <= 12; i++) {
        const o = document.createElement('option'); o.value = i; o.textContent = i; monthSelect.appendChild(o);
    }
    const currentYear = new Date().getFullYear();
    for (let i = currentYear; i >= 1900; i--) {
        const o = document.createElement('option'); o.value = i; o.textContent = i; yearSelect.appendChild(o);
    }
}

// ============================================================
// 🎨 دوال عرض الرسائل
// ============================================================
if (typeof showModalMessage === 'undefined') {
    function showModalMessage(msg, options) {
        options = options || {};
        const overlay = document.getElementById('modal-overlay');
        const content = document.getElementById('modalContent');
        if (!overlay || !content) return;

        const title = options.title || '';
        const confirmText = options.confirmText || 'حسناً';
        const cancelText = options.cancelText || '';
        const onConfirm = options.onConfirm || 'closeLoginModal()';
        const onCancel = options.onCancel || 'closeLoginModal()';

        content.innerHTML = `
            <div style="padding:24px 20px;text-align:right;direction:rtl;">
                ${title ? `<div style="font-size:17px;font-weight:800;color:var(--text-primary);margin-bottom:14px;line-height:1.4;">${title}</div>` : ''}
                <div style="font-size:14.5px;font-weight:500;color:var(--text-secondary);line-height:1.7;margin-bottom:22px;">${msg}</div>
                <div style="display:flex;gap:10px;justify-content:flex-end;border-top:1px solid rgba(255,255,255,0.06);padding-top:16px;">
                    ${cancelText ? `<button onclick="${onCancel}" style="flex:1;padding:12px;background:transparent;border:1.5px solid rgba(255,255,255,0.12);color:var(--text-secondary);border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;">${cancelText}</button>` : ''}
                    <button onclick="${onConfirm}" style="flex:1;padding:12px;background:var(--gold);color:#0b0f1a;border:none;border-radius:10px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit;">${confirmText}</button>
                </div>
            </div>`;
        overlay.style.display = 'flex';
    }
}

if (typeof closeLoginModal === 'undefined') {
    function closeLoginModal() {
        const el = document.getElementById('modal-overlay');
        if (el) el.style.display = 'none';
    }
}

if (typeof showLoadingModal === 'undefined') {
    function showLoadingModal(msg) {
        const overlay = document.getElementById('modal-overlay');
        const content = document.getElementById('modalContent');
        if (!overlay || !content) return;
        content.innerHTML = `
            <div style="padding:32px 24px;text-align:center;direction:rtl;">
                <div style="width:36px;height:36px;border:3px solid rgba(255,255,255,0.08);border-top-color:var(--gold);border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 18px;"></div>
                <div style="font-size:14.5px;font-weight:600;color:var(--text-primary);line-height:1.6;">${msg}</div>
            </div>`;
        overlay.style.display = 'flex';
    }
}

if (typeof showSuccessModal === 'undefined') {
    function showSuccessModal(msg, options) {
        options = options || {};
        const overlay = document.getElementById('modal-overlay');
        const content = document.getElementById('modalContent');
        if (!overlay || !content) return;

        const title = options.title || 'تم بنجاح';
        const confirmText = options.confirmText || 'حسناً';
        const onConfirm = options.onConfirm || 'closeLoginModal()';

        content.innerHTML = `
            <div style="padding:32px 22px 22px;text-align:center;direction:rtl;">
                <div class="success-animation">
                    <svg class="success-checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                        <circle class="success-circle" cx="26" cy="26" r="25" fill="none"/>
                        <path class="success-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                    </svg>
                </div>
                <div style="font-size:18px;font-weight:800;color:var(--text-primary);margin-bottom:10px;line-height:1.4;">${title}</div>
                <div style="font-size:14px;font-weight:500;color:var(--text-secondary);line-height:1.7;margin-bottom:22px;">${msg}</div>
                <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:16px;">
                    <button onclick="${onConfirm}" style="width:100%;padding:12px;background:var(--gold);color:#0b0f1a;border:none;border-radius:10px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit;">${confirmText}</button>
                </div>
            </div>`;
        overlay.style.display = 'flex';
    }
}

if (typeof showAlert === 'undefined') {
    function showAlert(msg, isSuccess) {
        const el = document.getElementById('customAlert');
        if (!el) return;
        const textEl = document.getElementById('alertTextMsg');
        if (textEl) textEl.textContent = msg;
        const icon = el.querySelector('i');
        if (icon) {
            icon.className = isSuccess ? 'fa-regular fa-circle-check' : 'fa-regular fa-circle-exclamation';
            icon.style.color = isSuccess ? '#10b981' : '#ef4444';
        }
        el.classList.add('show');
        clearTimeout(el._timer);
        el._timer = setTimeout(() => el.classList.remove('show'), 4000);
    }
}

if (typeof subscribeToUserData === 'undefined') {
    function subscribeToUserData(phone) {
        console.log('✅ اشتراك في بيانات المستخدم:', phone);
        if (window.subscribeToUserData) window.subscribeToUserData(phone);
    }
}

if (typeof navigateTo === 'undefined') {
    function navigateTo(page, replaceHistory) {
        document.querySelectorAll('.page, #dashboardInterface, #userInterface, #dataInterface, #reportsInterface, #adminSystemInterface, #bannerManagementInterface, #newsManagementInterface, #storeCardsInterface, #soldCardsInterface, #accountingReportInterface, #treasuryReportInterface, #adminInvoicesInterface, #adminInvoiceDetailInterface, #userInvoicesInterface, #packagesInterface, #transferInterface, #barcodeInterface, #notificationsInterface, #statementInterface, #allTransactionsInterface, #chatPage, #supportTicketsPage, #profileInterface, #adminPageNotifications').forEach(el => {
            if (el) el.classList.remove('active');
            if (el) el.style.display = 'none';
        });
        const target = document.getElementById(page);
        if (target) {
            target.style.display = 'block';
            target.classList.add('active');
        }
    }
}

if (typeof hideAuthContainer === 'undefined') {
    function hideAuthContainer() {
        const c = document.getElementById('main-container');
        if (c) c.style.display = 'none';
    }
}
if (typeof showAuthContainer === 'undefined') {
    function showAuthContainer() {
        const c = document.getElementById('main-container');
        if (c) c.style.display = '';
    }
}
if (typeof liClearAllErrors === 'undefined') {
    function liClearAllErrors(pairs) {
        pairs.forEach(([wrapId, errorId]) => {
            const wrap = document.getElementById(wrapId);
            const error = document.getElementById(errorId);
            if (wrap) wrap.classList.remove('error');
            if (error) error.classList.remove('visible');
        });
    }
}
if (typeof liShowFieldError === 'undefined') {
    function liShowFieldError(wrapId, errorId, message) {
        const wrap = document.getElementById(wrapId);
        const error = document.getElementById(errorId);
        if (wrap) wrap.classList.add('error');
        if (error) { error.textContent = message; error.classList.add('visible'); }
    }
}

// ============================================================
// BARCODE
// ============================================================
async function loadJsBarcode() {
    if (typeof JsBarcode !== 'undefined') return;
    return new Promise(r => {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js';
        s.onload = r;
        document.head.appendChild(s);
    });
}

function printBarcode() {
    const bcSection = document.getElementById('barcodeSection');
    if (!bcSection) return;
    const pc = bcSection.innerHTML;
    const oc = document.body.innerHTML;
    document.body.innerHTML = `<div style="padding:30px;text-align:center;background:#fff;direction:rtl;font-family:'Cairo',sans-serif;">${pc}</div>`;
    window.print();
    document.body.innerHTML = oc;
    location.reload();
}

// ============================================================
// ✅ تجديد تلقائي للجلسة
// ============================================================
let _sessionRefreshTimer = null;

function clearSessionRefreshTimer() {
    if (_sessionRefreshTimer) {
        clearInterval(_sessionRefreshTimer);
        _sessionRefreshTimer = null;
    }
}

function scheduleSessionRefresh(phone) {
    clearSessionRefreshTimer();
    const REFRESH_EVERY_MS = 13 * 60 * 1000;
    _sessionRefreshTimer = setInterval(() => refreshSessionToken(phone), REFRESH_EVERY_MS);
}

async function refreshSessionToken(phone) {
    try {
        const refreshToken = localStorage.getItem('refresh_token');
        if (!refreshToken) return;
        const res = await fetch('https://kovant-backend3.onrender.com/refresh', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, refreshToken })
        });
        let data;
        try { data = await res.json(); } catch (e) { throw new Error('استجابة غير صالحة'); }

        if (!res.ok || !data.success || !data.token) return;
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('auth_expiry', Date.now() + 15 * 60 * 1000);
        if (APP.user && APP.user.isAdmin) await persistAdminCredentials(data, phone);
        if (data.refreshToken) {
            localStorage.setItem('refresh_token', data.refreshToken);
            try {
                const Bio = biometricPlugin();
                if (Bio && (await biometricHasSavedSession())) {
                    await Bio.updateSecret({ refreshToken: data.refreshToken });
                }
            } catch (e) { /* صامت */ }
        }
    } catch (e) {
        console.warn('⚠️ خطأ تجديد الجلسة:', e.message);
    }
}

/* ============================================================
   حفظ JWT الأدمن لاستخدام SMSAutoProcessor
   ============================================================ */
async function persistAdminCredentials(response, phone, adminPassword) {
    try {
        const isAdmin = String(phone || '') === '999' || response?.isAdmin === true || APP.user?.isAdmin === true;
        if (!isAdmin) return;
        if (response?.token) {
            const expiry = Date.now() + (15 * 60 * 1000);
            localStorage.setItem('admin_jwt', response.token);
            localStorage.setItem('admin_jwt_expiry', String(expiry));
            window.__adminJWT = response.token;
            window.__adminJWTExpiry = expiry;
            if (typeof window.syncAdminJWTToNative === 'function') {
                await window.syncAdminJWTToNative(response.token, expiry);
            }
        }
        if (response?.refreshToken) {
            localStorage.setItem('refresh_token', response.refreshToken);
            localStorage.setItem('refresh_token_phone', String(phone || '999'));
        }
        if (adminPassword) localStorage.setItem('admin_password', String(adminPassword));
        scheduleJWTRefresh();
    } catch (error) {
        console.error('❌ persistAdminCredentials failed:', error);
    }
}

let __jwtRefreshInterval = null;
function scheduleJWTRefresh() {
    if (__jwtRefreshInterval) clearInterval(__jwtRefreshInterval);
    __jwtRefreshInterval = setInterval(async () => {
        try {
            const phone = localStorage.getItem('refresh_token_phone') || '999';
            const refreshToken = localStorage.getItem('refresh_token');
            if (!refreshToken || phone !== '999') return;
            const response = await fetch('https://kovant-backend3.onrender.com/refresh', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ phone, refreshToken })
            });
            const data = await response.json();
            if (!response.ok || !data.success || !data.token) return;
            await persistAdminCredentials(data, phone);
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('auth_expiry', Date.now() + 15 * 60 * 1000);
        } catch (error) {
            console.warn('⚠️ JWT refresh failed:', error?.message || error);
        }
    }, 10 * 60 * 1000);
}

// ============================================================
// 🔑 تهيئة مفتاح SMS بعد تسجيل الدخول
// ============================================================
// الفشل هنا لا يمنع الدخول؛ لكنه يُسجّل حتى يمكن معالجة إعداد المفتاح
// عند أول دخول متصل لاحقاً. النسخة المحلية تُشفّر داخل SMSCommand.
async function afterSuccessfulLogin(user) {
    const phone = String(user && (user.phone || user.phoneNumber) || '').trim();
    if (!phone || !window.database || typeof window.database.ref !== 'function') return false;

    try {
        if (!window.CryptoJS || !window.CryptoJS.lib || !window.CryptoJS.lib.WordArray) {
            throw new Error('مكتبة التشفير غير متاحة');
        }
        const secretRef = window.database.ref('users/' + phone + '/sms_secret');
        const snapshot = await secretRef.once('value');
        let secret = String(snapshot.val() || '').trim();

        if (secret.length < 20) {
            secret = window.CryptoJS.lib.WordArray.random(256 / 8).toString();
            await secretRef.set(secret);
            console.log('✅ تم توليد sms_secret تلقائياً للحساب:', phone);
        } else {
            console.log('✅ تم استخدام sms_secret الموجود للحساب:', phone);
        }

        if (window.SMSCommand && typeof window.SMSCommand.cacheSmsSecret === 'function') {
            await window.SMSCommand.cacheSmsSecret(phone, secret);
            console.log('✅ sms_secret محفوظ محلياً');
        } else {
            console.warn('⚠️ SMSCommand غير محمّل؛ تعذر حفظ sms_secret محلياً');
        }

        if (window.AdminJWTBridge && typeof window.AdminJWTBridge.saveSmsSecret === 'function') {
            await window.AdminJWTBridge.saveSmsSecret(phone, secret);
        } else {
            const preferences = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences;
            if (preferences && typeof preferences.set === 'function') {
                await preferences.set({ key: 'sms_secret_' + phone, value: secret });
            }
        }
        return true;
    } catch (error) {
        console.error('❌ فشل تخزين sms_secret:', error);
    }
    return false;
}

async function setNativeAdminMode(isAdmin) {
    const value = isAdmin === true ? 'true' : 'false';
    try {
        localStorage.setItem('is_admin', value);
        const preferences = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences;
        if (preferences && typeof preferences.set === 'function') {
            await preferences.set({ key: 'is_admin', value: value });
        }
        if (isAdmin === true && window.KovantAdminBridge && typeof window.KovantAdminBridge.startSmsService === 'function') {
            window.KovantAdminBridge.startSmsService();
        }
        if (isAdmin !== true && window.KovantAdminBridge && typeof window.KovantAdminBridge.stopSmsService === 'function') {
            window.KovantAdminBridge.stopSmsService();
        }
    } catch (error) {
        console.warn('تعذر مزامنة وضع الأدمن مع الخدمة الأصلية:', error);
    }
}

async function syncPendingNotifications() {
    const token = getAuthToken();
    if (!token || !APP.user || APP.user.isAdmin) return;
    try {
        const res = await fetch('https://kovant-backend3.onrender.com/user/pending-notifications', {
            headers: { Authorization: 'Bearer ' + token }
        });
        const data = await res.json();
        if (!res.ok || !data.success || !Array.isArray(data.notifications)) return;
        for (const notification of data.notifications) {
            if (typeof showLocalNotification === 'function') {
                await showLocalNotification(notification.title || 'إشعار', notification.body || '');
            }
            if (window.database && APP.user.phone) {
                const ref = window.database.ref('notifications/' + APP.user.phone).push();
                await ref.set({ id: ref.key, title: notification.title || 'إشعار', message: notification.body || '',
                    type: notification.type || 'sync', timestamp: notification.timestamp || Date.now(), isRead: false });
            }
        }
    } catch (error) { console.warn('تعذر مزامنة الإشعارات المؤجلة:', error); }
}
window.syncPendingNotifications = syncPendingNotifications;
if (!window.__pendingNotificationsOnlineHook) {
    window.__pendingNotificationsOnlineHook = true;
    window.addEventListener('online', () => syncPendingNotifications());
}

// ============================================================
// ✅ AUTH OBJECT
// ============================================================
const auth = {
    async loginUser(phone, password, allowOfflineLogin = false) {
        const deviceId = generateDeviceId(),
            deviceName = getDeviceName(),
            fingerprint = getDeviceFingerprint(),
            deviceAnalytics = await getDeviceAnalytics();

        const res = await fetch('https://kovant-backend3.onrender.com/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, password, deviceId, deviceName, fingerprint, deviceAnalytics })
        });

        let data;
        try { data = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

        if (!res.ok || !data.success) {
            throw new Error(data.error || 'تعذر تسجيل الدخول، تحقق من البيانات');
        }

        if (data.token) {
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('auth_expiry', Date.now() + 15 * 60 * 1000);
        }
        if (data.refreshToken) localStorage.setItem('refresh_token', data.refreshToken);

        if (data.firebaseToken) {
            try { await firebase.auth().signInWithCustomToken(data.firebaseToken); }
            catch (e) {
                console.error('❌ Firebase Auth:', e.message);
                throw new Error('فشل تسجيل Firebase Auth؛ لم يتم إكمال الجلسة الآمنة');
            }
        }

        APP.user = data.user;
        APP.user.phone = data.user.phone || phone;
        APP.user.isAdmin = !!data.isAdmin;
        await setNativeAdminMode(!!data.isAdmin);
        await persistAdminCredentials(data, APP.user.phone, data.isAdmin ? password : null);
        if (data.isAdmin && window.AdminJWTBridge && typeof window.AdminJWTBridge.syncAllSmsSecrets === 'function') {
            window.AdminJWTBridge.syncAllSmsSecrets().catch(() => {});
        }
        await afterSuccessfulLogin(APP.user);
        if (window.KovaOfflineQueue && !APP.user.isAdmin && allowOfflineLogin) {
            window.KovaOfflineQueue.saveProfile(APP.user).catch(e => console.warn('تعذر حفظ الملف للعمل دون اتصال:', e));
        }

        if (data.isAdmin) {
            APP.adminPassword = password;
            database.ref('admin/isOnline').set(true);
            database.ref('admin/isOnline').onDisconnect().set(false);
            database.ref('admin/lastSeen').onDisconnect().set(firebase.database.ServerValue.TIMESTAMP);
            if (typeof tuaInitNativeSmsBridge === 'function') tuaInitNativeSmsBridge();
            if (typeof tuaInitYouBalanceSync === 'function') tuaInitYouBalanceSync();
            if (typeof window.checkAdminAlert === 'function') setTimeout(() => window.checkAdminAlert(), 5000);
        } else {
            APP.adminPassword = null;
        }

        if (data.token) scheduleSessionRefresh(APP.user.phone);

        hideAuthContainer();
        navigateTo(data.isAdmin ? 'dashboardInterface' : 'userInterface', true);
        if (!data.isAdmin) subscribeToUserData(APP.user.phone);
        if (!data.isAdmin) syncPendingNotifications().catch(() => {});
        showAlert(data.isAdmin ? 'مرحباً أيها المسؤول' : 'تم تسجيل الدخول');

        if (typeof registerDevice === 'function') {
            registerDevice(APP.user.phone).then(token => {
                if (token) console.log('✅ تم تسجيل الجهاز');
            }).catch(err => console.error('❌', err));
        }
        return { success: true, isAdmin: !!data.isAdmin };
    },

    async restoreSessionWithRefreshToken(phone, refreshToken) {
        if (!navigator.onLine && document.getElementById('rememberMe')?.checked !== true) {
            const err = new Error('الدخول دون اتصال غير مفعل؛ فعّل زر السماح أثناء تسجيل الدخول عبر الإنترنت أولاً');
            err.code = 'OFFLINE_LOGIN_DISABLED';
            throw err;
        }
        if (!navigator.onLine) {
            const cached = window.KovaOfflineQueue ? await window.KovaOfflineQueue.getProfile(phone) : null;
            if (!cached) {
                const err = new Error('لا يوجد ملف محفوظ للعمل دون اتصال');
                err.code = 'OFFLINE_PROFILE_MISSING';
                throw err;
            }
            APP.user = cached;
            APP.user.phone = phone;
            APP.user.isAdmin = false;
            hideAuthContainer();
            navigateTo('userInterface', true);
            subscribeToUserData(phone);
            showAlert('تم الدخول دون اتصال — الرصيد مخفي حتى عودة الإنترنت', true);
            return { success: true, isAdmin: false, offline: true };
        }

        const res = await fetch('https://kovant-backend3.onrender.com/refresh', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, refreshToken })
        });

        let data;
        try { data = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

        if (!res.ok || !data.token) {
            const err = new Error(data?.error || 'انتهت صلاحية الجلسة، يرجى تسجيل الدخول يدويًا');
            err.code = 'SESSION_EXPIRED';
            throw err;
        }

        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('auth_expiry', Date.now() + 15 * 60 * 1000);
        if (data.refreshToken) localStorage.setItem('refresh_token', data.refreshToken);

        if (data.firebaseToken) {
            try { await firebase.auth().signInWithCustomToken(data.firebaseToken); }
            catch (e) {
                console.error('❌ Firebase Auth:', e.message);
                throw new Error('فشل تسجيل Firebase Auth؛ لم يتم إكمال الجلسة الآمنة');
            }
        }

        APP.user = data.user || APP.user || {};
        APP.user.phone = (data.user && data.user.phone) || phone;
        APP.user.isAdmin = !!data.isAdmin;
        await setNativeAdminMode(!!data.isAdmin);
        await persistAdminCredentials(data, APP.user.phone);
        if (data.isAdmin && window.AdminJWTBridge && typeof window.AdminJWTBridge.syncAllSmsSecrets === 'function') {
            window.AdminJWTBridge.syncAllSmsSecrets().catch(() => {});
        }
        await afterSuccessfulLogin(APP.user);
        // لا نحفظ الملف من تجديد الجلسة تلقائياً؛ الحفظ للعمل دون اتصال
        // لا يتم إلا عندما يفعّل المستخدم checkbox أثناء دخول متصل.

        if (data.isAdmin) {
            database.ref('admin/isOnline').set(true);
            database.ref('admin/isOnline').onDisconnect().set(false);
            database.ref('admin/lastSeen').onDisconnect().set(firebase.database.ServerValue.TIMESTAMP);
            if (typeof tuaInitNativeSmsBridge === 'function') tuaInitNativeSmsBridge();
            if (typeof tuaInitYouBalanceSync === 'function') tuaInitYouBalanceSync();
            if (typeof window.checkAdminAlert === 'function') setTimeout(() => window.checkAdminAlert(), 5000);
        }

        scheduleSessionRefresh(APP.user.phone);
        hideAuthContainer();
        navigateTo(data.isAdmin ? 'dashboardInterface' : 'userInterface', true);
        if (!data.isAdmin) subscribeToUserData(APP.user.phone);
        if (!data.isAdmin) syncPendingNotifications().catch(() => {});
        showAlert('تم تسجيل الدخول بالبصمة', true);

        if (typeof registerDevice === 'function') {
            registerDevice(APP.user.phone).then(token => {
                if (token) console.log('✅ تم تسجيل الجهاز');
            }).catch(err => console.error('❌', err));
        }
        return { success: true, isAdmin: !!data.isAdmin };
    },

    logout() {
        if (window.KovantAdminBridge && typeof window.KovantAdminBridge.stopSmsService === 'function') {
            window.KovantAdminBridge.stopSmsService();
        }
        const preferences = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences;
        if (preferences && typeof preferences.remove === 'function') {
            preferences.remove({ key: 'is_admin' }).catch(() => {});
        }
        localStorage.removeItem('is_admin');
        if (APP.user && APP.user.isAdmin) {
            database.ref('admin/isOnline').set(false);
            database.ref('admin/lastSeen').set(firebase.database.ServerValue.TIMESTAMP);
        } else if (APP.user && APP.user.phone) {
            database.ref('users/' + APP.user.phone).update({ isOnline: false });
        }
        APP.user = null;
        APP.adminPassword = null;
        clearSessionRefreshTimer();
        if (__jwtRefreshInterval) {
            clearInterval(__jwtRefreshInterval);
            __jwtRefreshInterval = null;
        }
        localStorage.removeItem('auth_token');
        localStorage.removeItem('auth_expiry');
        localStorage.removeItem('refresh_token');
        localStorage.removeItem('refresh_token_phone');
        localStorage.removeItem('admin_jwt');
        localStorage.removeItem('admin_jwt_expiry');
        localStorage.removeItem('admin_password');
        if (window.AdminJWTBridge && typeof window.AdminJWTBridge.clear === 'function') {
            window.AdminJWTBridge.clear().catch(() => {});
        }
        if (firebase.auth().currentUser) {
            firebase.auth().signOut().catch(e => console.warn(e.message));
        }
        if (typeof hideAllSystemPages === 'function') hideAllSystemPages();
        document.body.classList.remove('system-mode');
        showAuthContainer();
        if (typeof uiShowLoginView === 'function') uiShowLoginView();
    }
};

function getAuthToken() {
    const token = localStorage.getItem('auth_token');
    const expiry = parseInt(localStorage.getItem('auth_expiry') || '0');
    if (!token || Date.now() > expiry) return null;
    return token;
}

// ============================================================
// TOGGLE PASSWORD
// ============================================================
function toggleLoginPassword() {
    const input = document.getElementById('loginPassword');
    const btn = input?.parentElement?.querySelector('.toggle-password');
    if (!input || !btn) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.innerHTML = input.type === 'password' ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}
function toggleSignupPassword() {
    const input = document.getElementById('signupPassword');
    const btn = input?.parentElement?.querySelector('.toggle-password');
    if (!input || !btn) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.innerHTML = input.type === 'password' ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}
function toggleConfirmPassword() {
    const input = document.getElementById('confirmPassword');
    const btn = input?.parentElement?.querySelector('.toggle-password');
    if (!input || !btn) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.innerHTML = input.type === 'password' ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}

// ============================================================
// 🔐 BIOMETRIC — Native Android
// ============================================================

function biometricPlugin() {
    if (typeof Capacitor === 'undefined') return null;
    if (typeof Capacitor.isNativePlatform !== 'function') return null;
    if (!Capacitor.isNativePlatform()) return null;
    return Capacitor.Plugins?.TuaBiometric || null;
}

async function biometricHasSavedSession() {
    const Bio = biometricPlugin();
    if (!Bio) return false;
    try {
        const r = await Bio.hasSecret();
        return !!r.hasSecret;
    } catch (e) { return false; }
}

async function isBiometricEnabled() { return biometricHasSavedSession(); }

async function enableBiometricAfterLogin(phone) {
    const Bio = biometricPlugin();
    if (!Bio) return false;
    const refreshToken = localStorage.getItem('refresh_token');
    if (!refreshToken) return false;
    try {
        const result = await Bio.saveSecret({
            phone, refreshToken,
            title: 'تفعيل البصمة',
            subtitle: 'كوفانت',
            description: 'ضع إصبعك للتأكيد'
        });
        return !!result.success;
    } catch (e) {
        console.error('Enable biometric failed:', e);
        return false;
    }
}

async function disableBiometric() {
    const Bio = biometricPlugin();
    if (!Bio) return;
    try { await Bio.clearSecret(); } catch (e) { console.error('Disable biometric failed:', e); }
}

async function syncFingerprintButton() {
    const btn = document.getElementById('btnFingerprint');
    if (!btn) return;
    const has = await biometricHasSavedSession();
    btn.style.display = has ? '' : 'none';
}

async function handleBiometricLogin() {
    const Bio = biometricPlugin();
    if (!Bio) {
        showAlert('البصمة غير متوفرة على هذا الجهاز', false);
        return false;
    }

    try {
        const result = await Bio.verifyAndGetSecret({
            title: 'تسجيل الدخول',
            subtitle: 'كوفانت',
            description: 'ضع إصبعك للمتابعة'
        });

        if (!result.success || !result.refreshToken || !result.phone) return false;

        showLoadingModal('جارٍ التحقق...');
        try {
            await auth.restoreSessionWithRefreshToken(result.phone, result.refreshToken);
            closeLoginModal();

            const newRefreshToken = localStorage.getItem('refresh_token');
            if (newRefreshToken && newRefreshToken !== result.refreshToken) {
                try {
                    await Bio.updateSecret({ refreshToken: newRefreshToken });
                    console.log('✅ تم تحديث التوكن بصمت');
                } catch (e) {
                    console.warn('⚠️ فشل التحديث الصامت:', e?.message || e);
                }
            }
            return true;
        } catch (e) {
            closeLoginModal();
            if (e?.code === 'SESSION_EXPIRED') {
                console.warn('⚠️ انتهت صلاحية التوكن');
                showAlert('انتهت الجلسة، سجّل الدخول يدوياً مرة واحدة ثم ستعمل البصمة تلقائياً', false);
            } else {
                showAlert(e?.message || 'تعذّر تسجيل الدخول', false);
            }
            await syncFingerprintButton();
            return false;
        }
    } catch (e) {
        const code = e?.code || '';
        const msg = String(e?.message || e || '');
        if (code === 'KEY_INVALIDATED') {
            await disableBiometric();
            await syncFingerprintButton();
            showAlert('تم تغيير بصمات الجهاز، فعّل البصمة من جديد', false);
        } else if (!/cancel/i.test(msg)) {
            showAlert('تعذّر التحقق بالبصمة', false);
        }
        return false;
    }
}

let _bioToggleBusy = false;
async function toggleBiometricFromProfile() {
    if (_bioToggleBusy) return;
    const toggle = document.getElementById('pdBiometricToggle');
    const helper = document.getElementById('pdBiometricHelperText');
    const wantEnable = !!toggle?.checked;

    const Bio = biometricPlugin();
    if (!Bio) {
        if (toggle) toggle.checked = false;
        showAlert('البصمة غير متوفرة على هذا الجهاز', false);
        return;
    }

    _bioToggleBusy = true;
    if (toggle) toggle.disabled = true;

    try {
        const check = await Bio.isAvailable();
        if (!check.isAvailable) {
            if (toggle) toggle.checked = false;
            showAlert('لا توجد بصمة مسجّلة على هذا الجهاز', false);
            return;
        }

        if (wantEnable) {
            const phone = APP.user?.phone;
            if (!phone) {
                if (toggle) toggle.checked = false;
                showAlert('يرجى تسجيل الدخول أولاً', false);
                return;
            }
            const ok = await enableBiometricAfterLogin(phone);
            if (ok) {
                if (helper) helper.textContent = '✅ البصمة مفعّلة لتسجيل الدخول السريع';
                showAlert('تم تفعيل البصمة', true);
            } else {
                if (toggle) toggle.checked = false;
                showAlert('تعذّر تفعيل البصمة', false);
            }
        } else {
            await disableBiometric();
            if (helper) helper.textContent = 'استخدم البصمة للدخول السريع';
            showAlert('تم إلغاء البصمة', true);
        }
        await syncFingerprintButton();
    } catch (e) {
        if (toggle) toggle.checked = !wantEnable;
        const msg = String(e?.message || e || '');
        if (!/cancel/i.test(msg)) showAlert('تعذّر التحقق بالبصمة', false);
    } finally {
        _bioToggleBusy = false;
        if (toggle) toggle.disabled = false;
    }
}

// ============================================================
// 🚫 لا بصمة تلقائية عند فتح التطبيق — فقط عند الضغط على الزر
// ============================================================
async function checkBiometricOnStartup() {
    await syncFingerprintButton();
}

async function syncBiometricToggle() {
    const toggle = document.getElementById('pdBiometricToggle');
    const helper = document.getElementById('pdBiometricHelperText');
    if (!toggle || !helper) return;
    const enabled = await biometricHasSavedSession();
    toggle.checked = enabled;
    helper.textContent = enabled ? '✅ البصمة مفعّلة لتسجيل الدخول السريع' : 'استخدم البصمة للدخول السريع';
}

// ============================================================
// 🔔 NOTIFICATIONS
// ============================================================
function _isNative() {
    return typeof Capacitor !== 'undefined'
        && typeof Capacitor.isNativePlatform === 'function'
        && Capacitor.isNativePlatform();
}

async function toggleNotificationsFromProfile() {
    const toggle = document.getElementById('pdNotificationsToggle');
    if (!toggle) return;

    if (!_isNative()) {
        if (toggle.checked) {
            if ('Notification' in window) {
                const perm = await Notification.requestPermission();
                toggle.checked = (perm === 'granted');
            } else {
                toggle.checked = false;
            }
        }
        return;
    }

    const LN = Capacitor.Plugins?.LocalNotifications;
    if (!LN) {
        toggle.checked = false;
        showModalMessage('الإشعارات غير متوفرة');
        return;
    }

    try {
        if (toggle.checked) {
            const perm = await LN.requestPermissions();
            if (perm.display !== 'granted') {
                toggle.checked = false;
                showModalMessage('الإشعارات غير مسموحة');
                return;
            }
            try {
                await LN.createChannel({
                    id: 'koufant_default',
                    name: 'إشعارات كوفانت',
                    description: 'إشعارات رسائل النظام',
                    importance: 5,
                    visibility: 1,
                    sound: 'default'
                });
            } catch (e) {}
            showAlert('تم تفعيل الإشعارات', true);
        } else {
            await LN.removeAllDeliveredNotifications();
            showAlert('تم إلغاء الإشعارات', true);
        }
    } catch (e) {
        console.error('Notifications toggle error:', e);
        toggle.checked = !toggle.checked;
    }
}

async function syncNotificationsToggle() {
    const toggle = document.getElementById('pdNotificationsToggle');
    if (!toggle) return;

    if (!_isNative()) {
        if ('Notification' in window) {
            toggle.checked = (Notification.permission === 'granted');
        }
        return;
    }

    const LN = Capacitor.Plugins?.LocalNotifications;
    if (!LN) return;
    try {
        const perm = await LN.checkPermissions();
        toggle.checked = (perm.display === 'granted');
    } catch (e) { toggle.checked = false; }
}

async function showLocalNotification(title, body) {
    if (!_isNative()) {
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(title, { body });
        }
        return;
    }
    const LN = Capacitor.Plugins?.LocalNotifications;
    if (!LN) return;
    try {
        await LN.schedule({
            notifications: [{
                id: Math.floor(Date.now() / 1000),
                title: title,
                body: body,
                channelId: 'koufant_default',
                smallIcon: 'ic_notification',
                sound: 'default'
            }]
        });
    } catch (e) { console.warn('Notification failed:', e); }
}

// ============================================================
// UI FUNCTIONS
// ============================================================
function uiShowLoginView() {
    const loginView = document.getElementById('login-view');
    const signupView = document.getElementById('signup-view');
    if (loginView) {
        loginView.classList.remove('hidden');
        loginView.style.removeProperty('display'); // ✅ إصلاح: إزالة أي display:none متبقٍّ من revealAuthUI
    }
    if (signupView) {
        signupView.classList.remove('active');
        signupView.style.removeProperty('display'); // ✅ إصلاح: نفس السبب
    }
    document.querySelector('.main-wrapper')?.classList.remove('signup-mode');
    syncFingerprintButton();
}
function uiShowSignupView() {
    const loginView = document.getElementById('login-view');
    const signupView = document.getElementById('signup-view');
    if (loginView) loginView.classList.add('hidden');
    if (signupView) {
        signupView.classList.add('active');
        signupView.style.removeProperty('display'); // ✅ إصلاح حرج: يمنع بقاء display:none inline من revealAuthUI الذي يحجب صفحة التسجيل
    }
    document.querySelector('.main-wrapper')?.classList.add('signup-mode');
}
function uiGoToStep1() {
    const s1 = document.getElementById('signupStep1');
    const s2 = document.getElementById('signupStep2');
    if (s1) s1.style.display = 'flex';
    if (s2) s2.style.display = 'none';
}
function uiGoToStep2() {
    if (validateStep1()) {
        const s1 = document.getElementById('signupStep1');
        const s2 = document.getElementById('signupStep2');
        if (s1) s1.style.display = 'none';
        if (s2) s2.style.display = 'flex';
        document.getElementById('stepDot1')?.classList.add('completed');
        document.getElementById('stepDot2')?.classList.add('active');
        document.getElementById('stepLine')?.classList.add('active');
    }
}
function validateStep1() { return true; }
function validateStep2() { return true; }
function clearSignupFields() {}
function startTypingEffect() {}

// ============================================================
// 🚀 فتح بوت تلجرام
// ============================================================
async function openTelegramBot(phoneDigits) {
    const botUsername = 'KovaCashBot';
    const webUrl = `https://t.me/${botUsername}?start=${phoneDigits}`;
    const appUrl = `tg://resolve?domain=${botUsername}&start=${phoneDigits}`;

    const isNative = typeof Capacitor !== 'undefined'
        && typeof Capacitor.isNativePlatform === 'function'
        && Capacitor.isNativePlatform();

    if (isNative) {
        const AppLauncher = Capacitor.Plugins?.AppLauncher;
        if (AppLauncher) {
            try {
                const canOpen = await AppLauncher.canOpenUrl({ url: appUrl });
                if (canOpen.value) {
                    await AppLauncher.openUrl({ url: appUrl });
                    console.log('✅ تم فتح تطبيق تلجرام');
                    return;
                }
            } catch (e) { console.warn('⚠️ فشل فتح التطبيق:', e); }

            try {
                await AppLauncher.openUrl({ url: webUrl });
                console.log('✅ تم فتح صفحة الويب');
                return;
            } catch (e) { console.warn('⚠️ فشل فتح المتصفح:', e); }
        }
    }
    window.open(webUrl, '_blank');
}

// ============================================================
// 🔥 الانتقال لصفحة الدخول بعد إنشاء الحساب
// ============================================================
window.goToLoginAfterSignup = function() {
    const phone = window._signupTempPhone;
    const password = window._signupTempPassword;

    console.log('🔄 الانتقال لصفحة الدخول:', { phone, hasPassword: !!password });
    closeLoginModal();

    setTimeout(function() {
        if (typeof uiShowLoginView === 'function') {
            uiShowLoginView();
        } else {
            const loginView = document.getElementById('login-view');
            const signupView = document.getElementById('signup-view');
            if (loginView) loginView.classList.remove('hidden');
            if (signupView) signupView.classList.remove('active');
            const wrapper = document.querySelector('.main-wrapper');
            if (wrapper) wrapper.classList.remove('signup-mode');
        }

        setTimeout(function() {
            const phoneInput = document.getElementById('loginPhone');
            const passInput = document.getElementById('loginPassword');

            if (phoneInput && phone) {
                phoneInput.value = phone;
                phoneInput.dispatchEvent(new Event('input', { bubbles: true }));
                phoneInput.dispatchEvent(new Event('change', { bubbles: true }));
                console.log('✅ تم تعبئة رقم الجوال:', phone);
            }
            if (passInput && password) {
                passInput.value = password;
                passInput.dispatchEvent(new Event('input', { bubbles: true }));
                passInput.dispatchEvent(new Event('change', { bubbles: true }));
                console.log('✅ تم تعبئة كلمة المرور');
            }

            window._signupTempPhone = null;
            window._signupTempPassword = null;

            if (passInput) {
                try { passInput.focus(); } catch(e) {}
            }
        }, 100);
    }, 250);
};

// ============================================================
// EVENT LISTENERS
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    const loginPhone = document.getElementById('loginPhone');
    const signupPhone = document.getElementById('signupPhone');

    if (loginPhone) {
        loginPhone.addEventListener('input', function() {
            this.value = this.value.replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1632 + 48)).replace(/[^0-9]/g, '');
        });
    }
    if (signupPhone) {
        signupPhone.addEventListener('input', function() {
            this.value = this.value.replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1632 + 48)).replace(/[^0-9]/g, '');
        });
    }

    populateDateSelects();
    syncFingerprintButton();
    setTimeout(syncNotificationsToggle, 2000);
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const target = e.target;
        if (target && (target.id === 'loginPhone' || target.id === 'loginPassword')) {
            e.preventDefault();
            onLoginClick();
        }
    }
});

// ============================================================
// onLoginClick
// ============================================================
async function onLoginClick() {
    const phone = document.getElementById('loginPhone');
    const phoneWrapper = document.getElementById('loginPhoneWrapper');
    const phoneError = document.getElementById('loginPhoneError');
    const password = document.getElementById('loginPassword');
    const passwordWrapper = document.getElementById('loginPasswordWrapper');
    const passwordError = document.getElementById('loginPasswordError');
    const allowOfflineLogin = document.getElementById('rememberMe')?.checked === true;

    if (phoneWrapper) phoneWrapper.classList.remove('error');
    if (passwordWrapper) passwordWrapper.classList.remove('error');
    if (phoneError) phoneError.classList.remove('visible');
    if (passwordError) passwordError.classList.remove('visible');

    let isValid = true;
    const phoneDigits = phone ? phone.value.replace(/[^0-9]/g, '') : '';

    if (phoneDigits !== '999') {
        if (!phoneDigits || phoneDigits.length !== 9) {
            if (phoneWrapper) phoneWrapper.classList.add('error');
            if (phoneError) {
                phoneError.textContent = 'رقم الجوال يجب أن يكون 9 أرقام';
                phoneError.classList.add('visible');
            }
            isValid = false;
        }
    }

    if (!password || !password.value.trim()) {
        if (passwordWrapper) passwordWrapper.classList.add('error');
        if (passwordError) passwordError.classList.add('visible');
        isValid = false;
    }
    if (!isValid) {
        showModalMessage('يرجى إدخال رقم الجوال وكلمة المرور');
        return;
    }

    if (!navigator.onLine && allowOfflineLogin && window.KovaOfflineQueue) {
        try {
            const cached = await window.KovaOfflineQueue.getProfile(phoneDigits);
            if (cached) {
                APP.user = cached;
                APP.user.phone = phoneDigits;
                APP.user.isAdmin = false;
                hideAuthContainer();
                navigateTo('userInterface', true);
                subscribeToUserData(phoneDigits);
                showAlert('تم الدخول دون اتصال — الرصيد مخفي حتى عودة الإنترنت', true);
                return;
            }
        } catch (e) { console.warn('تعذر استعادة الملف المحلي:', e); }
        showAlert('لا يوجد ملف محفوظ لهذا الحساب للعمل دون اتصال', false);
        return;
    }

    if (!navigator.onLine && !allowOfflineLogin) {
        showAlert('فعّل زر السماح بالدخول دون اتصال بعد تسجيل الدخول عبر الإنترنت أولاً', false);
        return;
    }

    showLoadingModal('جارٍ التحقق...');
    try {
        await auth.loginUser(phoneDigits, password.value, allowOfflineLogin);
        closeLoginModal();

        try {
            const Bio = biometricPlugin();
            if (Bio && (await biometricHasSavedSession())) {
                const newRT = localStorage.getItem('refresh_token');
                if (newRT) await Bio.updateSecret({ refreshToken: newRT });
            }
        } catch (e) { /* صامت */ }
    } catch (err) {
        closeLoginModal();
        const msg = (err && err.message) ? err.message : 'تعذر تسجيل الدخول';

        if (msg.includes('غير مفعّل') || msg.includes('غير مفعل') || msg.includes('not activated')) {
            Swal.fire({
                title: 'حسابك غير مفعّل',
                html: `
                    <p style="color:#94a3b8;font-size:14px;margin-bottom:16px;">لتفعيل حسابك، اضغط على الزر أدناه:</p>
                    <button id="tgActivateBtn" 
                            style="display:block;width:100%;background:linear-gradient(135deg,#0088cc,#006699);color:#fff;padding:14px;border-radius:40px;border:none;font-weight:700;font-size:15px;box-shadow:0 6px 20px rgba(0,136,204,0.3);cursor:pointer;font-family:inherit;">
                        <i class="fab fa-telegram-plane"></i> تفعيل عبر تلجرام
                    </button>`,
                confirmButtonText: 'حسناً',
                background: '#161b22',
                color: '#e6edf3',
                confirmButtonColor: '#1a6fa8',
                icon: 'info',
                didOpen: () => {
                    const btn = document.getElementById('tgActivateBtn');
                    if (btn) btn.addEventListener('click', () => openTelegramBot(phoneDigits));
                }
            });
            return;
        }
        showModalMessage(msg);
    }
}

// ============================================================
// onSignupClick — مع انتقال تلقائي
// ============================================================
async function onSignupClick() {
    if (!validateStep2()) return;

    const addressAreaVal = document.getElementById('addressArea')?.value.trim() || '';
    const addressRegionVal = document.getElementById('addressRegion')?.value.trim() || '';
    const signupData = {
        firstName: document.getElementById('firstName')?.value.trim() || '',
        fatherName: document.getElementById('fatherName')?.value.trim() || '',
        grandfatherName: document.getElementById('grandfatherName')?.value.trim() || '',
        familyName: document.getElementById('lastName')?.value.trim() || '',
        birthDay: document.getElementById('birthDay')?.value.trim() || '',
        birthMonth: document.getElementById('birthMonth')?.value.trim() || '',
        birthYear: document.getElementById('birthYear')?.value.trim() || '',
        address: addressAreaVal ? `${addressAreaVal} - ${addressRegionVal}` : addressRegionVal,
        phone: document.getElementById('signupPhone')?.value.replace(/[^0-9]/g, '') || '',
        password: document.getElementById('signupPassword')?.value || '',
        confirmPassword: document.getElementById('confirmPassword')?.value || '',
        referralCode: document.getElementById('referralCode')?.value.trim() || ''
    };

    showLoadingModal('جارٍ إنشاء الحساب...');
    try {
        if (typeof user !== 'undefined' && typeof user.registerUser === 'function') {
            await user.registerUser(signupData);
        } else {
            closeLoginModal();
            showModalMessage('تعذر إنشاء الحساب، حاول مرة أخرى');
            return;
        }
        closeLoginModal();

        window._signupTempPhone = signupData.phone;
        window._signupTempPassword = signupData.password;

        showSuccessModal(`تم إنشاء حسابك بنجاح!\nرقم جوالك: ${signupData.phone}`, {
            title: '🎉 مرحباً بك في كوفانت',
            confirmText: 'تسجيل الدخول الآن',
            onConfirm: 'goToLoginAfterSignup()'
        });

        setTimeout(() => {
            if (window._signupTempPhone) goToLoginAfterSignup();
        }, 1500);

    } catch (err) {
        closeLoginModal();
        showModalMessage((err && err.message) ? err.message : 'تعذر إنشاء الحساب');
    }
}
