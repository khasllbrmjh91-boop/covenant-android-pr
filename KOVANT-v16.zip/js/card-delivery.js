/* ============================================================
 * COVANT — CARD DELIVERY
 * تسليم كروت الإنترنت بعد الشراء
 *
 * يعتمد هذا الملف على:
 *   - Firebase Realtime Database الموجود في firebase-config.js
 *   - APP و getAuthToken الموجودين في التطبيق
 *   - SweetAlert2 إن كانت متاحة
 *   - نافذة successModal الحالية في index.html
 *
 * لا ينفذ خصم الرصيد من المتصفح مباشرة. تتم عملية الشراء عبر
 * نقطة API الآمنة الحالية، ثم يسجل هذا الملف طلب SMS ويعرض الأكواد.
 * ============================================================ */
(function (window, document) {
    'use strict';

    if (window.CardDelivery) return;

    const CONFIG = {
        apiUrl: 'https://kovant-backend3.onrender.com/api/purchase-package',
        smsQueuePath: 'sms_queue',
        maxCards: 100,
        maxSmsLength: 480,
        qrSize: 220
    };

    const state = {
        selected: null,
        cards: [],
        index: 0,
        busy: false,
        smsStatus: {}
    };

    function number(value) {
        const n = Number(String(value == null ? '' : value).replace(/,/g, ''));
        return Number.isFinite(n) ? n : 0;
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
        });
    }

    function formatMoney(value) {
        const fn = window.$fmt;
        return typeof fn === 'function' ? fn(value) : number(value).toLocaleString('ar-YE');
    }

    function phoneOf(value) {
        return String(value || '').replace(/[^0-9+]/g, '');
    }

    function currentUserPhone() {
        return phoneOf(window.APP && window.APP.user && window.APP.user.phone);
    }

    function createId(prefix) {
        const random = Math.random().toString(36).slice(2, 10).toUpperCase();
        return prefix + '-' + Date.now().toString(36).toUpperCase() + '-' + random;
    }

    function notify(title, text, icon) {
        if (window.Swal && typeof window.Swal.fire === 'function') {
            return window.Swal.fire({ title: title, text: text, icon: icon || 'info', background: '#111b2d', color: '#e6edf3', confirmButtonColor: '#02a3fe' });
        }
        if (typeof window.showAlert === 'function') window.showAlert(text || title, icon !== 'error');
        return Promise.resolve();
    }

    function loading(message) {
        if (window.Swal && typeof window.Swal.fire === 'function') {
            window.Swal.fire({ title: message || 'جارٍ التنفيذ...', allowOutsideClick: false, background: '#111b2d', color: '#e6edf3', didOpen: function () { window.Swal.showLoading(); } });
        }
    }

    function closeLoading() {
        if (window.Swal && typeof window.Swal.close === 'function') window.Swal.close();
    }

    function selectedCategory(categoryId) {
        const store = window.APP && window.APP.storeData ? window.APP.storeData : {};
        return store[categoryId] || null;
    }

    function availableCodes(category) {
        const cards = category && category.cards ? category.cards : {};
        return Object.keys(cards).map(function (key) {
            const raw = cards[key];
            return { id: key, code: typeof raw === 'string' ? raw : (raw && (raw.code || raw.cardCode || raw.value)) || key, raw: raw };
        }).filter(function (item) { return item.code; });
    }

    function getCustomerPhone() {
        const self = document.getElementById('selfCardToggle');
        if (!self || self.checked) return currentUserPhone();
        return phoneOf(document.getElementById('customerId') && document.getElementById('customerId').value);
    }

    function validateRequest() {
        const categoryId = window.APP && window.APP.selectedCategoryId;
        const category = selectedCategory(categoryId) || (window.APP && window.APP.selectedCategory);
        const countEl = document.getElementById('cardsCount');
        const count = Math.max(1, Math.min(CONFIG.maxCards, parseInt(countEl && countEl.textContent, 10) || 1));
        const customerPhone = getCustomerPhone();

        if (!categoryId || !category) throw new Error('الباقة غير موجودة أو انتهت صلاحيتها');
        if (!customerPhone || !/^\+?[0-9]{7,15}$/.test(customerPhone)) throw new Error('رقم الهاتف غير صالح');
        if (!number(category.sellPrice || category.price)) throw new Error('سعر الباقة غير صحيح');
        if (availableCodes(category).length < count) throw new Error('عدد الكروت المطلوب غير متوفر حالياً');
        return { categoryId: categoryId, category: category, count: count, customerPhone: customerPhone };
    }

    function authHeaders() {
        const token = typeof window.getAuthToken === 'function' ? window.getAuthToken() : '';
        if (!token) throw new Error('انتهت جلسة الدخول، الرجاء تسجيل الدخول مجدداً');
        return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token };
    }

    async function purchase(request) {
        const response = await window.fetch(CONFIG.apiUrl, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({
                packageId: request.categoryId,
                count: request.count,
                customerId: request.customerPhone,
                targetPhone: request.customerPhone,
                operationId: createId('PUR')
            })
        });
        let data = {};
        try { data = await response.json(); } catch (e) { /* يعالج الخطأ بالرسالة العامة أدناه */ }
        if (!response.ok || !data.success) throw new Error(data.error || 'فشلت عملية شراء الكروت');
        return data;
    }

    function smsText(card, request, txId) {
        const name = request.category.name || request.categoryId;
        return [
            'كوفانت — بطاقة إنترنت',
            '━━━━━━━━━━━━━━━━━━',
            'الباقة: ' + name,
            'السعر: ' + formatMoney(request.category.sellPrice || request.category.price) + ' ريال',
            '',
            'كود البطاقة:',
            card.code,
            '',
            'رقم العملية: ' + txId,
            '━━━━━━━━━━━━━━━━━━',
            'شكراً لاستخدامك كوفانت'
        ].join('\n').slice(0, CONFIG.maxSmsLength);
    }

    async function queueSms(phone, message, metadata) {
        const payload = Object.assign({
            to: phone,
            message: message,
            from: 'COVANT',
            status: 'pending',
            attempts: 0,
            createdAt: Date.now()
        }, metadata || {});

        if (!window.database || typeof window.database.ref !== 'function') {
            return { queued: false, reason: 'database-unavailable' };
        }
        const ref = window.database.ref(CONFIG.smsQueuePath).push();
        payload.messageId = ref.key;
        await ref.set(payload);
        return { queued: true, id: ref.key };
    }

    async function sendSmsForCards(request, cards, txId) {
        // أصبح الخادم ينشئ رسالة واحدة موحّدة تحتوي كل الأكواد بعد نجاح الخصم.
        // لا نضيف سجلات لكل كرت هنا حتى لا تصل للعميل رسائل مكررة.
        cards.forEach(function (card) { state.smsStatus[card.code] = 'queued-by-server'; });
        return cards.map(function () {
            return { queued: true, serverQueued: true, reason: 'authoritative-server-queue', txId: txId };
        });
    }

    function makeQrUrl(code) {
        return 'https://api.qrserver.com/v1/create-qr-code/?size=' + CONFIG.qrSize + 'x' + CONFIG.qrSize + '&data=' + encodeURIComponent(String(code));
    }

    function cardForDisplay(code, request, index, txId) {
        return {
            id: code.id || null,
            code: String(code.code),
            packageId: request.categoryId,
            packageName: request.category.name || request.categoryId,
            price: number(request.category.sellPrice || request.category.price),
            customerPhone: request.customerPhone,
            txId: txId + '-' + String(index + 1).padStart(3, '0'),
            qrUrl: makeQrUrl(code.code),
            sentVia: 'app'
        };
    }

    function showExistingVoucher(request, cards, txId) {
        const codes = cards.map(function (card) { return card.code; });
        if (typeof window.openVoucherSuccess === 'function') {
            window.openVoucherSuccess(request.category, codes, cards.length, request.customerPhone, request.customerPhone === currentUserPhone());
            return true;
        }
        return false;
    }

    function ensureDeliveryPanel() {
        let panel = document.getElementById('cardDeliveryQrPanel');
        if (panel) return panel;
        panel = document.createElement('div');
        panel.id = 'cardDeliveryQrPanel';
        panel.setAttribute('aria-live', 'polite');
        panel.style.cssText = 'display:none;margin:14px 0;padding:14px;border:1px solid rgba(2,163,254,.22);border-radius:16px;background:#0a1527;color:#e6edf3;direction:rtl;text-align:right;';
        const target = document.getElementById('successModal') || document.body;
        target.appendChild(panel);
        return panel;
    }

    function renderFallback(request, cards, txId) {
        const panel = ensureDeliveryPanel();
        panel.style.display = 'block';
        panel.innerHTML = '<div style="font-weight:800;color:#02a3fe;margin-bottom:10px;">أكواد البطاقات</div>' + cards.map(function (card, index) {
            return '<article style="display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.08);">' +
                '<img src="' + card.qrUrl + '" width="72" height="72" alt="QR Code" style="border-radius:8px;background:#fff;padding:4px;">' +
                '<div style="min-width:0;flex:1;"><div style="font-size:11px;color:#8fa5c0;">البطاقة ' + (index + 1) + '</div><strong dir="ltr" style="font-size:18px;letter-spacing:1px;">' + escapeHtml(card.code) + '</strong><div style="font-size:11px;color:#8fa5c0;">SMS: ' + escapeHtml(state.smsStatus[card.code] || 'pending') + '</div></div>' +
                '<button type="button" data-copy-card="' + escapeHtml(card.code) + '" style="border:0;border-radius:8px;padding:8px;background:#02a3fe;color:#fff;cursor:pointer;">نسخ</button>' +
                '</article>';
        }).join('') + '<div style="font-size:11px;color:#8fa5c0;margin-top:10px;">رقم العملية: <span dir="ltr">' + escapeHtml(txId) + '</span></div>';
        panel.querySelectorAll('[data-copy-card]').forEach(function (button) {
            button.addEventListener('click', function () { copyCode(button.getAttribute('data-copy-card')); });
        });
    }

    async function copyCode(code) {
        try {
            await navigator.clipboard.writeText(String(code));
            await notify('تم النسخ', 'تم نسخ كود البطاقة بنجاح', 'success');
        } catch (e) {
            await notify('تعذر النسخ', 'يمكنك تحديد الكود ونسخه يدوياً', 'warning');
        }
    }

    async function deliver(options) {
        if (state.busy) return;
        state.busy = true;
        try {
            const request = options && options.request ? options.request : validateRequest();
            loading('جاري التحقق من الرصيد والكروت...');
            const data = await purchase(request);
            const txId = data.txId || data.operationId || createId('KWT');
            const responseCodes = Array.isArray(data.codes) ? data.codes : [];
            const cards = responseCodes.map(function (code, index) {
                return cardForDisplay(typeof code === 'object' ? code : { code: code }, request, index, txId);
            });
            state.cards = cards;
            state.index = 0;
            state.selected = request;
            if (window.APP && window.APP.user && data.newBalance != null) window.APP.user.balance = data.newBalance;
            if (typeof window.updateUserUI === 'function' && window.APP && window.APP.user) window.updateUserUI(window.APP.user, window.APP.user.phone);
            closeLoading();
            if (typeof window.closeModal === 'function') window.closeModal();
            await sendSmsForCards(request, cards, txId);
            const displayed = showExistingVoucher(request, cards, txId);
            if (!displayed) renderFallback(request, cards, txId);
            if (typeof window.playSystemSuccessSound === 'function') window.playSystemSuccessSound();
            return { success: true, txId: txId, cards: cards, newBalance: data.newBalance };
        } catch (error) {
            closeLoading();
            await notify('تعذر إتمام الشراء', error.message || 'حدث خطأ أثناء تسليم الكروت', 'error');
            return { success: false, error: error };
        } finally {
            state.busy = false;
        }
    }

    function init() {
        const modal = document.getElementById('subscribeModal');
        if (modal) modal.addEventListener('click', function (event) { if (event.target === modal && typeof window.closeModal === 'function') window.closeModal(); });
    }

    window.CardDelivery = {
        config: CONFIG,
        state: state,
        validateRequest: validateRequest,
        deliver: deliver,
        queueSms: queueSms,
        sendSmsForCards: sendSmsForCards,
        copyCode: copyCode,
        getCards: function () { return state.cards.slice(); }
    };

    window.confirmCardDelivery = function () { return deliver(); };
    window.CardDelivery.init = init;
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
}(window, document));
