/* ============================================================
 * COVANT — SMS PARSER
 * تحليل أوامر CVT والتحقق من HMAC ومنع إعادة الاستخدام
 * ============================================================ */
(function (window) {
    'use strict';

    if (window.SMSParser) return;

    const PREFIX = 'CVT';
    const MAX_AGE_MS = 5 * 60 * 1000;
    const USED_KEY = 'covant_sms_used_sessions_v1';

    // عدد العناصر المتبقية بعد إزالة CVT واسم النوع:
    // sessionId + الحقول + timestamp + signature.
    // الصيغ هنا تحتوي فقط على بيانات العملية والطابع الزمني والتوقيع.
    const SHAPES = { TR: 6, CR: 7, TP: 6, BQ: 4 };
    const TYPES = { TR: 'transfer', CR: 'card_purchase', TP: 'topup', BQ: 'balance_query' };

    function text(value) { return String(value == null ? '' : value).trim(); }

    function classifyType(prefix) { return TYPES[text(prefix).toUpperCase()] || null; }

    function usedSessions() {
        try {
            const value = JSON.parse(window.localStorage.getItem(USED_KEY) || '{}');
            return value && typeof value === 'object' ? value : {};
        } catch (error) { return {}; }
    }

    function rememberSession(sessionId) {
        const used = usedSessions();
        used[sessionId] = Date.now();
        const cutoff = Date.now() - 24 * 60 * 60 * 1000;
        Object.keys(used).forEach(function (key) { if (Number(used[key]) < cutoff) delete used[key]; });
        try { window.localStorage.setItem(USED_KEY, JSON.stringify(used)); } catch (error) {}
    }

    function hasUsedSession(sessionId) { return !!usedSessions()[sessionId]; }

    function parseIncomingSMS(smsBody) {
        const raw = text(smsBody);
        if (!raw.startsWith(PREFIX + ':')) return null;
        const parts = raw.split(':');
        const prefix = parts.shift();
        const code = text(parts.shift()).toUpperCase();
        if (prefix !== PREFIX || !SHAPES[code]) return null;
        if (parts.length !== SHAPES[code]) return null;

        const sessionId = text(parts.shift());
        const signature = text(parts.pop());
        const timestamp = Number(parts.pop());
        const fields = parts.map(text);
        const command = {
            isValid: false,
            prefix: PREFIX,
            code: code,
            type: classifyType(code),
            sessionId: sessionId,
            ts: timestamp,
            sig: signature,
            raw: raw,
            data: [code, sessionId].concat(fields).concat([String(timestamp)]).join(':'),
            fields: fields
        };

        if (code === 'TR') Object.assign(command, { from: fields[0], to: fields[1], amount: Number(fields[2]) });
        if (code === 'CR') Object.assign(command, { buyer: fields[0], pkgId: fields[1], count: Number(fields[2]), recipient: fields[3], from: fields[0] });
        if (code === 'TP') Object.assign(command, { phone: fields[0], amount: Number(fields[1]), bankRef: fields[2], from: fields[0] });
        if (code === 'BQ') Object.assign(command, { phone: fields[0], from: fields[0] });
        return command;
    }

    function constantTimeEqual(left, right) {
        left = text(left).toLowerCase(); right = text(right).toLowerCase();
        if (!left || left.length !== right.length) return false;
        let result = 0;
        for (let i = 0; i < left.length; i += 1) result |= left.charCodeAt(i) ^ right.charCodeAt(i);
        return result === 0;
    }

    async function verifySignature(command, userSecret) {
        if (!command || !userSecret || !window.CryptoJS || !window.CryptoJS.HmacSHA256) return false;
        const expected = window.CryptoJS.HmacSHA256(command.data, String(userSecret)).toString(window.CryptoJS.enc.Hex);
        return constantTimeEqual(expected, command.sig);
    }

    function validPhone(phone) { return /^\+?[0-9]{7,15}$/.test(text(phone)); }

    function validateCommand(command, options) {
        options = options || {};
        if (!command || !command.type || !command.sessionId || !command.sig) return { valid: false, reason: 'malformed' };
        if (hasUsedSession(command.sessionId)) return { valid: false, reason: 'duplicate_session' };
        if (!Number.isFinite(command.ts) || Math.abs(Date.now() - command.ts) > (options.maxAgeMs || MAX_AGE_MS)) return { valid: false, reason: 'expired' };
        if (!validPhone(command.from || command.phone || command.buyer)) return { valid: false, reason: 'invalid_phone' };

        if (command.code === 'TR' && (!validPhone(command.to) || !Number.isFinite(command.amount) || command.amount < 100)) return { valid: false, reason: 'invalid_transfer' };
        if (command.code === 'CR' && (!text(command.pkgId) || !Number.isInteger(command.count) || command.count < 1 || command.count > 100 || !validPhone(command.recipient))) return { valid: false, reason: 'invalid_card_purchase' };
        if (command.code === 'TP' && (!Number.isFinite(command.amount) || command.amount <= 0 || !text(command.bankRef))) return { valid: false, reason: 'invalid_topup' };
        if (command.code === 'BQ' && !validPhone(command.phone)) return { valid: false, reason: 'invalid_balance_query' };
        return { valid: true, reason: null };
    }

    function markProcessed(sessionId) { if (sessionId) rememberSession(sessionId); }

    window.SMSParser = {
        MAX_AGE_MS: MAX_AGE_MS,
        parseIncomingSMS: parseIncomingSMS,
        verifySignature: verifySignature,
        classifyType: classifyType,
        validateCommand: validateCommand,
        markProcessed: markProcessed,
        hasUsedSession: hasUsedSession
    };
}(window));
