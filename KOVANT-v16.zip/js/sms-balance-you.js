/* ============================================================
   رصيد الرسائل الحقيقي من المرسل (Sender ID) = YOU
   ============================================================
   المشكلة: SmsStore كان يبدأ من رقم ثابت (100) ويخصم منه محلياً
   عند كل إرسال، يعني الرصيد المعروض وهمي ولا علاقة له برصيد الباقة
   الفعلي عند شركة الاتصالات.

   الحل: قراءة رسائل الجهاز الواردة من المرسل "YOU"، واستخراج عدد
   الرسائل المتبقي منها، وتحديث SmsStore به:
     1) عند فتح شاشة إدارة SMS وعند زر "تحديث من YOU" → قراءة الصندوق.
     2) لحظياً عند وصول رسالة جديدة من YOU أثناء عمل التطبيق.
     3) بعد كل إرسال فعلي → خصم تقديري مؤقت، ثم إعادة قراءة لالتقاط
        رسالة الرصيد الجديدة من YOU.

   يعمل فقط داخل تطبيق Capacitor أندرويد (يحتاج TuaSmsInboxPlugin.kt).
   في المتصفح/PWA لا توجد إمكانية قراءة رسائل الجهاز.
============================================================ */

const SmsYou = {
    SENDER_IDS: ['YOU'],   // يمكن إضافة صيغ أخرى لو ظهر المرسل بشكل مختلف
    SCAN_LIMIT: 40,        // عدد رسائل YOU الأحدث التي نفحصها
    _listening: false,
    _syncing: false,
    _lastApplied: 0        // تاريخ (ms) آخر رسالة طُبّقت — لمنع تطبيق رسالة أقدم فوق أحدث
};

/* ------------------------------------------------------------
   تحويل الأرقام العربية/الفارسية إلى لاتينية وإزالة فواصل الآلاف
------------------------------------------------------------ */
function smsYouNormalize(text) {
    return String(text || '')
        .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))
        .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0))
        .replace(/[\u066B\u066C]/g, ',')          // فواصل عربية
        .replace(/(\d)[,\u060C](?=\d{3}(\D|$))/g, '$1') // 1,250 → 1250
        .replace(/\u200f|\u200e|\u202a|\u202b|\u202c/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

/* ------------------------------------------------------------
   استخراج عدد الرسائل المتبقي من نص رسالة YOU.
   يرجع رقماً، أو null لو الرسالة لا تتحدث عن رصيد الرسائل.
   الأنماط أدناه مرنة (عربي/إنجليزي)؛ لو صيغة رسالة YOU الفعلية
   مختلفة يكفي إضافة نمط جديد إلى مصفوفة PATTERNS.
------------------------------------------------------------ */
const SMS_YOU_KW_SMS = '(?:رسالة|رسائل|رساله|الرسائل|الرسالة|sms|messages?|msgs?|texts?)';
const SMS_YOU_KW_REM = '(?:متبقي(?:ة)?|المتبقي(?:ة)?|باقي(?:ة)?|الباقي(?:ة)?|remaining|remain|left|balance|رصيد(?:ك)?)';

const SMS_YOU_PATTERNS = [
    // صيغة YOU الفعلية: "لديك129 رسالة" (قد تأتي بدون مسافة بعد لديك)
    new RegExp('(?:لديك|لدیك|عندك|لك)\\s*(\\d{1,9})\\s*' + SMS_YOU_KW_SMS, 'i'),
    // "رسائل ... متبقي: 45"  /  "SMS remaining: 45"
    new RegExp(SMS_YOU_KW_SMS + '[^\\d\\n]{0,25}?' + SMS_YOU_KW_REM + '[^\\d\\n]{0,15}?(\\d{1,9})', 'i'),
    // "متبقي لديك 45 رسالة"  /  "remaining 45 SMS"  /  "balance: 45 messages"
    new RegExp(SMS_YOU_KW_REM + '[^\\d\\n]{0,30}?(\\d{1,9})\\s*' + SMS_YOU_KW_SMS, 'i'),
    // "45 رسالة متبقية"  /  "45 SMS left"
    new RegExp('(\\d{1,9})\\s*' + SMS_YOU_KW_SMS + '[^\\d\\n]{0,15}?' + SMS_YOU_KW_REM, 'i'),
    // "رصيد الرسائل 45"
    new RegExp('رصيد\\s*(?:ال)?رسائل[^\\d\\n]{0,15}?(\\d{1,9})', 'i'),
    // "SMS balance: 45"
    new RegExp('sms\\s*(?:balance|bundle|remaining|left)[^\\d\\n]{0,15}?(\\d{1,9})', 'i')
];

function smsYouParseBalance(body) {
    const text = smsYouNormalize(body);
    if (!text) return null;
    // لازم تذكر الرسالة الرسائل النصية أصلاً (نتجنب رسائل رصيد المكالمات/الإنترنت)
    if (!new RegExp(SMS_YOU_KW_SMS, 'i').test(text)) return null;

    for (const re of SMS_YOU_PATTERNS) {
        const m = text.match(re);
        if (m) {
            const n = parseInt(m[1], 10);
            if (Number.isFinite(n) && n >= 0 && n <= 10000000) return n;
        }
    }
    return null;
}

function smsYouIsSender(from) {
    const f = String(from || '').trim().toLowerCase();
    return SmsYou.SENDER_IDS.some(s => s.toLowerCase() === f);
}

function smsYouPlugin() {
    if (typeof Capacitor === 'undefined' || !Capacitor.isNativePlatform || !Capacitor.isNativePlatform()) return null;
    return (Capacitor.Plugins || {}).TuaSmsInbox || null;
}

/* ------------------------------------------------------------
   تطبيق الرصيد الحقيقي على SmsStore
------------------------------------------------------------ */
function smsYouApplyBalance(remaining, msgDate, body) {
    const d = SmsStore.data;
    const when = Number(msgDate) || Date.now();
    if (when < SmsYou._lastApplied) return false; // رسالة أقدم من المطبّقة

    SmsYou._lastApplied = when;
    d.smsBalance = remaining;
    d.balanceSource = 'YOU';
    d.balanceSyncedAt = new Date().toISOString();
    d.balanceMsgDate = new Date(when).toISOString();
    d.balanceMsgBody = String(body || '').slice(0, 300);
    // الإجمالي غير معروف من رسالة YOU → نعتمد أعلى رصيد شوهد كإجمالي مرجعي
    d.balancePeak = Math.max(Number(d.balancePeak) || 0, remaining);
    d.totalSmsPurchased = d.balancePeak;
    SmsStore.save();
    return true;
}

/* ------------------------------------------------------------
   قراءة الصندوق وتحديث الرصيد
   interactive=true → يظهر Toast بالنتيجة (عند ضغط الزر)
------------------------------------------------------------ */
async function smsYouSync(interactive) {
    const say = (m, t) => { if (interactive && typeof smsToast === 'function') smsToast(m, t); };
    const plugin = smsYouPlugin();

    if (!plugin) {
        const isNative = typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform();
        say(isNative
            ? '⚠️ مكوّن TuaSmsInbox غير مثبت — شغّل setup-native-plugins.py ثم npx cap sync'
            : 'ℹ️ قراءة رسائل YOU تعمل داخل تطبيق الأندرويد فقط (ليس المتصفح)', 'warn');
        smsYouRenderStatus();
        return false;
    }
    if (SmsYou._syncing) return false;
    SmsYou._syncing = true;

    try {
        const perm = await plugin.requestAccess();
        if (perm.sms !== 'granted') {
            say('🚫 صلاحية قراءة الرسائل مرفوضة — فعّلها من إعدادات التطبيق', 'error');
            return false;
        }
        smsYouStartListening();

        const res = await plugin.readInbox({ sender: SmsYou.SENDER_IDS[0], limit: SmsYou.SCAN_LIMIT });
        const messages = (res && res.messages) || [];

        if (messages.length === 0) {
            say('لا توجد رسائل واردة من المرسل YOU على هذا الجهاز', 'warn');
            SmsStore.data.lastYouCheck = { at: new Date().toISOString(), found: 0 };
            SmsStore.save();
            return false;
        }

        // الأحدث أولاً → أول رسالة يمكن استخراج رصيد منها هي الأحدث فعلياً
        for (const m of messages) {
            const remaining = smsYouParseBalance(m.body);
            if (remaining !== null) {
                smsYouApplyBalance(remaining, m.date, m.body);
                SmsStore.data.lastYouCheck = { at: new Date().toISOString(), found: messages.length, parsed: true };
                SmsStore.save();
                say(`✅ الرصيد من YOU: ${remaining} رسالة متبقية`, 'success');
                return true;
            }
        }

        // وجدنا رسائل من YOU لكن لا شيء منها فُهم كرصيد رسائل
        SmsStore.data.lastYouCheck = {
            at: new Date().toISOString(), found: messages.length, parsed: false,
            sample: String(messages[0].body || '').slice(0, 200)
        };
        SmsStore.save();
        console.warn('⚠️ رسائل YOU لم تُفهم كرصيد رسائل. أحدث رسالة:', messages[0].body);
        say('وجدت رسائل من YOU لكن لم أتعرّف على صيغة رصيد الرسائل فيها', 'warn');
        return false;
    } catch (e) {
        console.error('❌ فشل قراءة رصيد YOU:', e);
        say('❌ فشل قراءة الرسائل: ' + (e && e.message ? e.message : ''), 'error');
        return false;
    } finally {
        SmsYou._syncing = false;
        if (typeof smsUpdateBalanceDisplay === 'function') smsUpdateBalanceDisplay();
    }
}

/* ------------------------------------------------------------
   استماع لحظي لرسائل YOU الجديدة
------------------------------------------------------------ */
async function smsYouStartListening() {
    const plugin = smsYouPlugin();
    if (!plugin || SmsYou._listening) return;
    SmsYou._listening = true;
    try {
        await plugin.addListener('smsReceived', (msg) => {
            if (!msg || !smsYouIsSender(msg.from)) return;
            const remaining = smsYouParseBalance(msg.body);
            if (remaining === null) return;
            if (smsYouApplyBalance(remaining, msg.date, msg.body)) {
                if (typeof smsToast === 'function') smsToast(`📩 تحديث من YOU: متبقي ${remaining} رسالة`, 'info');
                if (typeof smsUpdateBalanceDisplay === 'function') smsUpdateBalanceDisplay();
            }
        });
        await plugin.startListening();
    } catch (e) {
        SmsYou._listening = false;
        console.warn('⚠️ تعذر بدء الاستماع اللحظي لرسائل YOU:', e);
    }
}

/* ------------------------------------------------------------
   عرض مصدر الرصيد تحت الرقم (حقيقي / تقديري / غير متزامن)
------------------------------------------------------------ */
function smsYouRenderStatus() {
    const isNative = !!smsYouPlugin() || (typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
    const d = (typeof SmsStore !== 'undefined') ? SmsStore.data : null;
    if (!d) return;

    const srcEl = document.getElementById('smsBalanceSource');
    const numEl = document.getElementById('smsMainRemaining');
    const synced = d.balanceSource === 'YOU' || d.balanceSource === 'estimate';

    if (!isNative) {
        if (srcEl) srcEl.textContent = '⚠️ معاينة فقط — رقم تجريبي، الرصيد الحقيقي يُقرأ داخل تطبيق الأندرويد';
        return;
    }

    if (!synced) {
        // لم يُقرأ رصيد حقيقي بعد: لا نعرض الرقم الوهمي
        if (numEl) { numEl.textContent = '—'; numEl.style.color = 'var(--text-secondary)'; }
        ['smsBalanceWarning', 'smsBalanceDanger'].forEach(id => {
            const el = document.getElementById(id); if (el) el.classList.remove('show');
        });
        const last = d.lastYouCheck;
        if (srcEl) {
            srcEl.textContent = last && last.parsed === false
                ? '⚠️ وُجدت رسائل من YOU لكن صيغة الرصيد غير مفهومة'
                : 'لم يُقرأ رصيد من YOU بعد — اضغط "تحديث من YOU"';
        }
        return;
    }

    if (srcEl) {
        const t = d.balanceMsgDate ? new Date(d.balanceMsgDate) : null;
        const when = t ? t.toLocaleString('ar-EG', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
        srcEl.textContent = d.balanceSource === 'YOU'
            ? `✅ من رسالة YOU — ${when}`
            : '⏳ تقديري بعد الإرسال — بانتظار رسالة YOU';
    }
}

/* ------------------------------------------------------------
   ربط مع SmsStore: بعد كل إرسال فعلي → خصم تقديري ثم إعادة قراءة
------------------------------------------------------------ */
(function hookSmsStore() {
    if (typeof SmsStore === 'undefined' || SmsStore._youHooked) return;
    SmsStore._youHooked = true;
    const orig = SmsStore.consumeSms.bind(SmsStore);
    SmsStore.consumeSms = function (phone, body) {
        const entry = orig(phone, body);
        if (smsYouPlugin() && this.data.balanceSource === 'YOU') {
            this.data.balanceSource = 'estimate';
            this.save();
            setTimeout(() => smsYouSync(false), 8000);
            setTimeout(() => smsYouSync(false), 30000);
        }
        return entry;
    };
})();

/* نقطة التشغيل — تُستدعى بعد دخول الأدمن (auth.js) */
async function tuaInitYouBalanceSync() {
    if (!smsYouPlugin()) return;
    if (typeof APP !== 'undefined' && APP.user && !APP.user.isAdmin) return;
    if (typeof SmsStore !== 'undefined' && !SmsStore.data.deviceId) SmsStore.load();
    await smsYouSync(false);
}
