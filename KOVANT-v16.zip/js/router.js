// ============================================================
// router.js — التنقل بين الصفحات وإدارة الحالة
// ============================================================

// ============================================================
// UI HELPERS
// ============================================================
function toggleBalance() {
    const el = document.getElementById('amount');
    APP.hiddenBalance = !APP.hiddenBalance;
    if (APP.hiddenBalance) {
        el.textContent = '•••••••';
        document.getElementById('eyeIcon').className = 'fa-regular fa-eye-slash';
    } else {
        el.textContent = el.dataset.realValue || '0.00';
        document.getElementById('eyeIcon').className = 'fa-regular fa-eye';
    }
}

function toggleSidebar() {
    const ov = document.getElementById('sidebarOverlay');
    ov.classList.toggle('active');
    document.body.style.overflow = ov.classList.contains('active') ? 'hidden' : '';
}

function logout() {
    if (APP.user?.phone) {
        database.ref('notifications/' + APP.user.phone).off();
        database.ref('chats/' + getChatId(APP.user.phone)).off();
        database.ref('users/' + APP.user.phone).update({ isOnline: false });
    }
    APP.user = null;
    APP._notifListenerPhone = null;
    hideAllSystemPages();
    showAlert('تم تسجيل الخروج بنجاح');
}

function logoutUser() {
    document.getElementById('sidebarOverlay').classList.remove('active');
    document.body.style.overflow = '';
    logout();
}

// ============================================================
// NAVIGATION
// ============================================================
const PASSWORD_FIELDS_BY_PAGE = {
    loginInterface: ['loginPass', 'signupPass', 'signupConfirmPass'],
    profileInterface: ['profileOldPass', 'profileNewPass', 'profileOldPin', 'profileNewPin']
};

function syncPasswordFieldTypes(activePageId) {
    Object.entries(PASSWORD_FIELDS_BY_PAGE).forEach(([page, ids]) => {
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            el.type = (page === activePageId) ? 'password' : 'text';
        });
    });
}

// ✅ قائمة كل الصفحات المعروفة
const ALL_SYSTEM_PAGES = [
    'dashboardInterface', 'userInterface',
    'barcodeInterface', 'transferInterface', 'adminSystemInterface',
    'notificationsInterface', 'statementInterface', 'packagesInterface', 'sadaqInterface',
    'supportTicketsPage', 'chatPage', 'chatDetailPage', 'dataInterface', 'reportsInterface', 'salesAnalysisInterface', 'usersAnalysisInterface', 'agentsAnalysisInterface',
    'mapsMenuInterface', 'usersMapInterface', 'agentsMapInterface', 'coverageMapInterface', 'allMapsInterface', 'nearbyAgentsMapInterface', 'adminNotificationsInterface',
    'storeCardsInterface', 'soldCardsInterface', 'allTransactionsInterface',
    'accountingReportInterface', 'treasuryReportInterface',
    'adminInvoicesInterface', 'adminInvoiceDetailInterface', 'userInvoicesInterface',
    'bannerManagementInterface', 'loginBannerManagementInterface', 'newsManagementInterface', 'profileInterface',
    'topupInterface', 'smsManagementInterface', 'walletsManagementInterface', 'topupApprovalInterface',
    'appSystemInterface', 'networkSystemInterface',
    'countersMapInterface',
    'adminWifiMonitorInterface'
];

function hideAllSystemPages() {
    ALL_SYSTEM_PAGES.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = 'none';
            el.classList.remove('active');
        }
    });
}

function navigateTo(pageId, isMain) {
    const body = document.body;
    const hideBgPages = [
        'dashboardInterface', 'userInterface', 'adminSystemInterface',
        'appSystemInterface', 'networkSystemInterface',
        'dataInterface', 'reportsInterface', 'salesAnalysisInterface', 'usersAnalysisInterface', 'agentsAnalysisInterface', 'mapsMenuInterface', 'usersMapInterface', 'agentsMapInterface', 'coverageMapInterface', 'allMapsInterface', 'nearbyAgentsMapInterface', 'adminNotificationsInterface',
        'adminInvoicesInterface', 'adminInvoiceDetailInterface',
        'storeCardsInterface', 'soldCardsInterface', 'accountingReportInterface',
        'treasuryReportInterface', 'bannerManagementInterface', 'loginBannerManagementInterface', 'newsManagementInterface',
        'profileInterface', 'transferInterface', 'notificationsInterface',
        'statementInterface', 'packagesInterface', 'sadaqInterface', 'allTransactionsInterface',
        'supportTicketsPage', 'chatDetailPage', 'userInvoicesInterface',
        'topupInterface', 'smsManagementInterface', 'walletsManagementInterface', 'topupApprovalInterface',
        'countersMapInterface',
        'adminWifiMonitorInterface'
    ];

    if (hideBgPages.includes(pageId)) {
        body.classList.add('system-mode');
    } else {
        body.classList.remove('system-mode');
    }

    syncPasswordFieldTypes(pageId);

    // الصفحات الداخلية يجب ألا تتشارك العرض مع واجهات المصادقة أو شاشة البداية.
    // نستخدم style + class معاً لأن login/signup لهما قواعد CSS مختلفة.
    const loginView = document.getElementById('login-view');
    const signupView = document.getElementById('signup-view');
    const splashScreen = document.getElementById('splash-screen');
    if (loginView) {
        loginView.classList.add('hidden');
        loginView.style.display = 'none';
    }
    if (signupView) {
        signupView.classList.remove('active');
        signupView.style.display = 'none';
    }
    if (splashScreen) {
        splashScreen.classList.add('hidden');
        splashScreen.style.display = 'none';
    }
    document.getElementById('main-container') && (document.getElementById('main-container').style.display = 'none');

    const pages = [
        'dashboardInterface', 'userInterface',
        'barcodeInterface', 'transferInterface', 'adminSystemInterface',
        'appSystemInterface', 'networkSystemInterface',
        'notificationsInterface', 'statementInterface', 'packagesInterface', 'sadaqInterface',
        'supportTicketsPage', 'chatDetailPage', 'dataInterface', 'reportsInterface', 'salesAnalysisInterface', 'usersAnalysisInterface', 'agentsAnalysisInterface',
        'mapsMenuInterface', 'usersMapInterface', 'agentsMapInterface', 'coverageMapInterface', 'allMapsInterface', 'nearbyAgentsMapInterface', 'adminNotificationsInterface',
        'storeCardsInterface', 'soldCardsInterface', 'allTransactionsInterface', 'sadaqInterface',
        'accountingReportInterface', 'treasuryReportInterface',
        'adminInvoicesInterface', 'adminInvoiceDetailInterface', 'userInvoicesInterface',
        'bannerManagementInterface', 'loginBannerManagementInterface', 'newsManagementInterface', 'profileInterface',
        'topupInterface', 'smsManagementInterface', 'walletsManagementInterface', 'topupApprovalInterface',
        'countersMapInterface',
        'adminWifiMonitorInterface'
    ];

    pages.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = 'none';
            el.classList.remove('active');
        }
    });

    const target = document.getElementById(pageId);
    if (!target) return;

    if (pageId === 'supportTicketsPage' || pageId === 'chatDetailPage') {
        target.style.display = 'flex';
    } else {
        target.style.display = 'block';
    }

    const activePages = [
        'loginInterface', 'dashboardInterface', 'userInterface',
        'adminSystemInterface', 'appSystemInterface', 'networkSystemInterface',
        'packagesInterface', 'supportTicketsPage',
        'chatDetailPage', 'dataInterface', 'reportsInterface', 'salesAnalysisInterface', 'usersAnalysisInterface', 'agentsAnalysisInterface', 'mapsMenuInterface', 'usersMapInterface', 'agentsMapInterface', 'coverageMapInterface', 'allMapsInterface', 'nearbyAgentsMapInterface', 'adminNotificationsInterface', 'storeCardsInterface',
        'soldCardsInterface', 'allTransactionsInterface', 'sadaqInterface',
        'accountingReportInterface', 'statementInterface',
        'treasuryReportInterface', 'adminInvoicesInterface',
        'adminInvoiceDetailInterface', 'userInvoicesInterface', 'profileInterface',
        'topupInterface', 'smsManagementInterface', 'walletsManagementInterface', 'topupApprovalInterface',
        'countersMapInterface',
        'adminWifiMonitorInterface'
    ];

    if (activePages.includes(pageId)) target.classList.add('active');

    APP.isMain = isMain;
    if (!isMain) history.pushState({ page: pageId }, '');
    else history.replaceState({ page: 'main' }, '');

    const dNav = document.getElementById('dashboardBottomNav');
    const adminPages = [
        'dashboardInterface', 'dataInterface', 'storeCardsInterface',
        'soldCardsInterface', 'accountingReportInterface',
        'treasuryReportInterface', 'adminSystemInterface',
        'adminInvoicesInterface', 'adminInvoiceDetailInterface'
    ];
    dNav.classList.toggle('active', adminPages.includes(pageId));

    const navBtns = dNav.querySelectorAll('.nav-btn');
    navBtns.forEach(btn => btn.classList.remove('active'));
    if (pageId === 'dashboardInterface') {
        if (navBtns[0]) navBtns[0].classList.add('active');
    } else if (['dataInterface', 'storeCardsInterface', 'soldCardsInterface',
            'accountingReportInterface', 'treasuryReportInterface',
            'adminInvoicesInterface', 'adminInvoiceDetailInterface'
        ].includes(pageId)) {
        if (navBtns[1]) navBtns[1].classList.add('active');
    }

    // تحميل البيانات حسب الصفحة
    if (pageId === 'dashboardInterface') loadDashboardData();

    if (pageId === 'adminSystemInterface') {
        const pending = window._pendingAdminSection || 'system';
        window._pendingAdminSection = null;
        _applyAdminSection(pending);
        loadAdminUsers();
        loadAdminStore();
    }

    if (pageId === 'barcodeInterface' && APP.user) updateBarcodePage();

    if (pageId === 'transferInterface' && APP.user) {
        document.getElementById('transfer-current-balance').innerText = $fmt(APP.user.balance);
    }

    if (pageId === 'statementInterface' && APP.user) {
        setDefaultStatementDates();
        loadStatementData();
    }

    if (pageId === 'profileInterface' && APP.user) {
        loadProfilePage();
    }

    if (pageId === 'accountingReportInterface') {
        setTimeout(() => {
            setupPickerAcc('col-year-acc', [], false);
            setupPickerAcc('col-month-acc', ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"], true);
            setupPickerAcc('col-day-acc', Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0')), false);
            setTodayDateAcc();
        }, 100);
    }

    if (pageId === 'treasuryReportInterface') {
        setTimeout(() => {
            setupPickerTreasury('col-year-treasury', [], false);
            setupPickerTreasury('col-month-treasury', ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"], true);
            setupPickerTreasury('col-day-treasury', Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0')), false);
            setTodayDateTreasury();
        }, 100);
    }

    if (pageId === 'userInterface' && APP.user) {
        updateUserUI(APP.user, APP.user.phone);
        renderLastTransactions();
    }

    if (pageId === 'notificationsInterface') {
        renderNotifications();
        markAllNotificationsAsRead();
    }

    if (pageId === 'storeCardsInterface') StoreManager.load();
    if (pageId === 'soldCardsInterface') SoldManager.load();
    if (pageId === 'allTransactionsInterface' && APP.user) renderAllTransactions();
    if (pageId === 'packagesInterface') loadPackagesFromStore();
    if (pageId === 'sadaqInterface' && typeof window.sadaqLoad === 'function') window.sadaqLoad();
    if (pageId === 'adminInvoicesInterface') loadAdminInvoicesOverview();
    if (pageId === 'userInvoicesInterface') loadUserInvoices();
    if (pageId === 'bannerManagementInterface') loadBannerManagementAdmin();
    if (pageId === 'loginBannerManagementInterface' && typeof loadLoginBannerAdmin === 'function') loadLoginBannerAdmin();
    if (pageId === 'newsManagementInterface') loadNewsManagementAdmin();
    if (pageId === 'smsManagementInterface') loadSmsManagementAdmin();
    if (pageId === 'walletsManagementInterface') loadWalletsManagementAdmin();
    if (pageId === 'topupApprovalInterface') loadTopupApprovalAdmin();

    if (window.SalesAnalysis) {
        if (pageId === 'salesAnalysisInterface') SalesAnalysis.open();
        else SalesAnalysis.close();
    }

    if (window.UsersAnalysis) {
        if (pageId === 'usersAnalysisInterface') UsersAnalysis.open();
        else UsersAnalysis.close();
    }

    if (window.AgentsAnalysis) {
        if (pageId === 'agentsAnalysisInterface') AgentsAnalysis.open();
        else AgentsAnalysis.close();
    }

    // ✅ عدادات خريطة الشبكة
    if (window.CountersMap) {
        if (pageId === 'countersMapInterface') CountersMap.open();
        else CountersMap.close();
    }

    // ✅ مراقبة شبكات WiFi (أدمن)
    if (pageId === 'adminWifiMonitorInterface') {
        if (typeof loadWifiMonitorData === 'function') {
            setTimeout(loadWifiMonitorData, 200);
        }
    }

    APP.selectedMessage = null;
}

// ============================================================
// ADMIN NAVIGATION
// ============================================================
function navigateAdmin(section) {
    const adminSys = document.getElementById('adminSystemInterface');
    const isActive = adminSys && adminSys.classList.contains('active');

    if (!isActive) {
        window._pendingAdminSection = section;
        navigateTo('adminSystemInterface', true);
        return;
    }

    _applyAdminSection(section);
}

function _applyAdminSection(section) {
    const sections = ['adminSystemHome', 'adminPageUsers', 'adminPageCards', 'adminDevicesInterface', 'adminPageNotifications', 'adminVisitorsInterface', 'adminPageSettings', 'adminKeyGenInterface'];
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });

    const titles = {
        system: 'إدارة النظام والتواصل',
        users: 'إدارة الحسابات',
        cards: 'مخزن الكروت',
        devices: 'إدارة الأجهزة',
        notifications: 'إدارة الإشعارات',
        visitors: 'زوّار الموقع',
        settings: 'إعدادات النظام',
        keygen: 'توليد مفاتيح QR'
    };

    if (section === 'system') {
        document.getElementById('adminSystemHome').style.display = 'block';
    } else if (section === 'users') {
        document.getElementById('adminPageUsers').style.display = 'block';
        loadAdminUsers();
    } else if (section === 'cards') {
        document.getElementById('adminPageCards').style.display = 'block';
        loadAdminStore();
    } else if (section === 'devices') {
        document.getElementById('adminDevicesInterface').style.display = 'block';
        loadAdminDevices();
    } else if (section === 'notifications') {
        document.getElementById('adminPageNotifications').style.display = 'block';
        loadAdminNotificationLog();
        loadUsersForNotificationSelect();
    } else if (section === 'visitors') {
        document.getElementById('adminVisitorsInterface').style.display = 'block';
        loadAdminVisitors();
    } else if (section === 'settings') {
        document.getElementById('adminPageSettings').style.display = 'block';
        if (typeof loadAdminSettingsPage === 'function') loadAdminSettingsPage();
    } else if (section === 'keygen') {
        document.getElementById('adminKeyGenInterface').style.display = 'block';
        if (typeof loadUsersForKeyGen === 'function') loadUsersForKeyGen();
    }

    document.getElementById('adminSystemTitle').innerText = titles[section] || 'إدارة النظام';
    APP.adminCurrentSection = section;

    const btn = document.getElementById('adminSystemBackBtn');
    if (section === 'system') {
        btn.innerHTML = '<i class="fas fa-arrow-right"></i> رجوع';
        btn.onclick = function() { navigateTo('dashboardInterface', true); };
    } else {
        btn.innerHTML = '<i class="fas fa-arrow-right"></i> رجوع';
        btn.onclick = function() { navigateAdmin('system'); };
    }

    document.querySelectorAll('.admin-bottom-nav .nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.admin-bottom-nav .nav-btn')?.classList.add('active');
}

function navigateAdminBack() {
    if (APP.adminCurrentSection === 'system') navigateTo('dashboardInterface', true);
    else navigateAdmin('system');
}

function toNumber(v) {
    if (typeof v === 'number') return v;
    let c = String(v).replace(/,/g, '').trim();
    let n = parseFloat(c);
    return isNaN(n) ? 0 : n;
}

// ============================================================
// STATEMENT
// ============================================================
let activeTargetIdStmt = '';

function setupPickerStmt(id, list, isMonth) {
    let col = document.getElementById(id);
    if (!col) return;
    col.innerHTML = '<div class="spacer"></div>';
    if (isMonth) {
        const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
        monthNames.forEach((name, idx) => {
            let monthNumber = String(idx + 1).padStart(2, '0');
            col.innerHTML += `<div class="picker-item" data-val="${monthNumber}">${name}</div>`;
        });
    } else {
        const currentYear = new Date().getFullYear();
        const startYear = currentYear - 10;
        const endYear = currentYear + 5;
        for (let y = startYear; y <= endYear; y++) {
            col.innerHTML += `<div class="picker-item" data-val="${y}">${y}</div>`;
        }
    }
    col.innerHTML += '<div class="spacer"></div>';
    col.addEventListener('scroll', function() { updateSelectedItemStmt(this); });
    col.addEventListener('click', function(e) {
        const item = e.target.closest('.picker-item');
        if (item) {
            const colEl = item.closest('.picker-col');
            const offset = item.offsetTop - 88;
            colEl.scrollTo({ top: offset, behavior: 'smooth' });
        }
    });
}

function updateSelectedItemStmt(col) {
    const items = col.querySelectorAll('.picker-item');
    let selectedVal = null;
    items.forEach(el => {
        const rect = el.getBoundingClientRect();
        const colRect = col.getBoundingClientRect();
        const middle = colRect.top + colRect.height / 2;
        const elMiddle = rect.top + rect.height / 2;
        if (Math.abs(elMiddle - middle) < 30) {
            el.classList.add('selected');
            selectedVal = el.dataset.val;
        } else {
            el.classList.remove('selected');
        }
    });
    if (selectedVal) {
        let year = document.querySelector('#col-year-stmt .selected')?.dataset.val;
        let month = document.querySelector('#col-month-stmt .selected')?.dataset.val;
        let day = document.querySelector('#col-day-stmt .selected')?.dataset.val;
        if (year && month && day && activeTargetIdStmt) {
            document.getElementById(activeTargetIdStmt).innerText = `${year}-${month}-${day}`;
        }
    }
}

function openPickerStmt(id) {
    activeTargetIdStmt = id;
    document.getElementById('sheetStmt').classList.add('active');
    document.getElementById('overlayStmt').style.display = 'block';
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
    const currentDay = String(now.getDate()).padStart(2, '0');

    if (id === 'to-text-stmt' || id === 'from-text-stmt') {
        const colDay = document.getElementById('col-day-stmt');
        colDay.innerHTML = '<div class="spacer"></div>';
        for (let d = 1; d <= now.getDate(); d++) {
            let dayStr = String(d).padStart(2, '0');
            colDay.innerHTML += `<div class="picker-item" data-val="${dayStr}">${dayStr}</div>`;
        }
        colDay.innerHTML += '<div class="spacer"></div>';
        colDay.addEventListener('scroll', function() { updateSelectedItemStmt(this); });
        colDay.addEventListener('click', function(e) {
            const item = e.target.closest('.picker-item');
            if (item) {
                const colEl = item.closest('.picker-col');
                const offset = item.offsetTop - 88;
                colEl.scrollTo({ top: offset, behavior: 'smooth' });
            }
        });
    }

    setTimeout(() => {
        scrollToValStmt('col-year-stmt', currentYear);
        scrollToValStmt('col-month-stmt', currentMonth);
        scrollToValStmt('col-day-stmt', currentDay);
    }, 150);
}

function scrollToValStmt(id, val) {
    let col = document.getElementById(id);
    if (!col) return;
    let items = Array.from(col.querySelectorAll('.picker-item'));
    let targetVal = String(val);
    if (id === 'col-day-stmt' && (activeTargetIdStmt === 'to-text-stmt' || activeTargetIdStmt === 'from-text-stmt')) {
        const today = new Date();
        const maxDay = today.getDate();
        if (parseInt(targetVal) > maxDay) targetVal = String(maxDay).padStart(2, '0');
    }
    let target = items.find(el => el.dataset.val == targetVal);
    if (target) col.scrollTo({ top: target.offsetTop - 88, behavior: 'smooth' });
}

function closePickerStmt() {
    document.getElementById('sheetStmt').classList.remove('active');
    document.getElementById('overlayStmt').style.display = 'none';
    if (activeTargetIdStmt === 'to-text-stmt' || activeTargetIdStmt === 'from-text-stmt') {
        const today = new Date();
        const selectedDateStr = document.getElementById(activeTargetIdStmt).innerText;
        if (selectedDateStr) {
            const parts = selectedDateStr.split('-');
            const selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
            if (selectedDate > today) {
                const year = today.getFullYear();
                const month = String(today.getMonth() + 1).padStart(2, '0');
                const day = String(today.getDate()).padStart(2, '0');
                document.getElementById(activeTargetIdStmt).innerText = `${year}-${month}-${day}`;
                showAlert('لا يمكن اختيار تاريخ مستقبلي، تم ضبطه على اليوم الحالي.');
            }
        }
    }
}

function setDefaultStatementDates() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const todayStr = `${year}-${month}-${day}`;
    document.getElementById('from-text-stmt').innerText = todayStr;
    document.getElementById('to-text-stmt').innerText = todayStr;
}

function setTodayStatement() {
    const today = new Date();
    const str = today.toISOString().split('T')[0];
    document.getElementById('from-text-stmt').innerText = str;
    document.getElementById('to-text-stmt').innerText = str;
    loadStatementData();
}

function loadStatementData() {
    if (!APP.user) {
        showAlert('الرجاء تسجيل الدخول أولاً');
        return;
    }
    document.getElementById('loaderStmt').style.display = 'block';
    document.getElementById('report-content-stmt').style.display = 'none';

    setTimeout(() => {
        document.getElementById('loaderStmt').style.display = 'none';
        document.getElementById('report-content-stmt').style.display = 'block';
        renderStatement();
    }, 300);
}

function renderStatement() {
    const fromStr = document.getElementById('from-text-stmt').innerText;
    const toStr = document.getElementById('to-text-stmt').innerText;
    let fromDate = null,
        toDate = null;
    if (fromStr) { fromDate = new Date(fromStr);
        fromDate.setHours(0, 0, 0, 0); }
    if (toStr) { toDate = new Date(toStr);
        toDate.setHours(23, 59, 59, 999); }

    const history = APP.user.history || {};
    const historyArray = Object.values(history);
    let filtered = historyArray.filter(item => {
        let itemDate = null;
        if (item.timestamp) itemDate = new Date(item.timestamp);
        else if (item.date) itemDate = new Date(item.date);
        if (!itemDate) return false;
        if (fromDate && itemDate < fromDate) return false;
        if (toDate && itemDate > toDate) return false;
        return true;
    });
    filtered.sort((a, b) => (a.timestamp || new Date(a.date).getTime()) - (b.timestamp || new Date(b.date).getTime()));

    let runningCash = 0,
        runningDebt = 0;
    let totalDebit = 0,
        totalCredit = 0;
    let rows = '';

    if (!filtered.length) {
        rows =
            '<tr><td colspan="5" style="text-align:center;color:var(--text-secondary);padding:30px 0;">لا توجد معاملات في هذه الفترة</td></tr>';
    } else {
        filtered.forEach(item => {
            let amount = $n(item.amount);
            let isDebit = (item.type === 'out' || item.type === 'withdraw');
            let isCredit = (item.type === 'in' || item.type === 'deposit' || item.type === 'transfer_in');
            let debit = isDebit ? amount : 0;
            let credit = isCredit ? amount : 0;

            let isDebtInvoice = item.title && (item.title.includes('فاتورة آجلة') || item.title.includes('إنشاء فاتورة'));
            if (isCredit) {
                if (isDebtInvoice) runningDebt += amount;
                else runningCash += amount;
            } else if (isDebit) {
                let isDebtPayment = item.title && item.title.includes('سداد فاتورة');
                if (isDebtPayment) runningDebt -= amount;
                else runningCash -= amount;
            }

            totalDebit += debit;
            totalCredit += credit;

            let displayDate = item.dateStr || item.date || '';
            if (item.timestamp) {
                const d = new Date(item.timestamp);
                displayDate = d.toLocaleString('en-US', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });
            }
            let runningTotal = runningCash + runningDebt;
            rows += `
                <tr>
                    <td style="font-size:10px;">${esc(displayDate)}</td>
                    <td class="col-desc" style="font-size:10px;">${esc(item.title || item.description || 'معاملة')}</td>
                    <td class="debit" style="font-size:10px;">${debit > 0 ? $fmt(debit) : '-'}</td>
                    <td class="credit" style="font-size:10px;">${credit > 0 ? $fmt(credit) : '-'}</td>
                    <td class="balance" style="font-size:10px;">${$fmt(runningTotal)}</td>
                </tr>
            `;
        });
    }

    const finalBalance = runningCash + runningDebt;
    document.getElementById('table-body-stmt').innerHTML = rows;
    document.getElementById('totalDebitStmt').innerText = $fmt(totalDebit);
    document.getElementById('totalCreditStmt').innerText = $fmt(totalCredit);
    document.getElementById('totalNetStmt').innerText = $fmt(totalCredit - totalDebit);

    const summaryRow = document.getElementById('summaryRowStmt');
    if (summaryRow) {
        summaryRow.style.display = 'table-row';
        document.getElementById('summaryCashStmt').innerText = `رصيد نقدي ${$fmt(runningCash)}`;
        document.getElementById('summaryDebtStmt').innerText = `رصيد الفاتورة المتبقي عليكم ${$fmt(runningDebt)}`;
        document.getElementById('summaryTotalStmt').innerText = `اجمالي الرصيد ${$fmt(finalBalance)}`;
    }

    document.getElementById('rep-from-stmt').innerText = fromStr || 'البداية';
    document.getElementById('rep-to-stmt').innerText = toStr || 'الحاضر';
    const userName = APP.user?.fullName || 'مستخدم';
    document.getElementById('repUserNameStmt').innerText = userName;
    document.getElementById('reportUserNameStmtBar').innerText = userName;

    document.getElementById('loaderStmt').style.display = 'none';
    document.getElementById('emptyReportMsgStmt').style.display = 'none';
    document.getElementById('report-content-stmt').style.display = 'block';
}

function printStatement() {
    let content = document.getElementById('printable-area-stmt').innerHTML;
    let iframe = document.getElementById('print-frame-stmt');
    let pri = iframe.contentWindow;
    pri.document.open();
    pri.document.write(`
        <html dir="rtl">
        <head>
            <style>
                body{font-family:'Cairo',sans-serif;padding:20px;background:#fff;}
                .account-table{width:100%;border-collapse:collapse;}
                .account-table th,.account-table td{border:1px solid #000;padding:8px;text-align:center;font-size:12px;}
                .col-desc{text-align:right!important;}
                .footer-row{background:#f2f2f2;font-weight:bold;}
                .debit{color:#c62828;font-weight:bold;}
                .credit{color:#2e7d32;font-weight:bold;}
                .balance{background:#fff9c4;font-weight:bold;}
                .summary-row td{font-size:11px!important;}
                .separator{opacity:0.3;padding:0 4px;}
            </style>
        </head>
        <body>${content}</body>
        </html>
    `);
    pri.document.close();
    setTimeout(() => { pri.focus(); pri.print(); }, 500);
}

// ============================================================
// SCANNER
// ============================================================
function startScanner() {
    stopScanner();
    document.getElementById('scanner-overlay').style.display = 'flex';
}

function stopScanner() {
    if (APP.html5Qr) {
        try { APP.html5Qr.stop().catch(e => {}); } catch (e) {}
    }
    APP.html5Qr = null;
    document.getElementById('scanner-overlay').style.display = 'none';
    document.getElementById('scanner-area').innerHTML = '';
}

async function startCameraScanner() {
    const sa = document.getElementById('scanner-area');
    if (!sa) return;
    sa.innerHTML = '';
    try {
        APP.html5Qr = new Html5Qrcode("scanner-area");
        await APP.html5Qr.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } },
            onScanSuccess, onScanError);
    } catch (e) {
        Swal.fire('خطأ', 'تعذر تشغيل الكاميرا.', 'error');
    }
}

function selectImageFromGallery() {
    const fi = document.getElementById('qr-file-input');
    if (!fi) return;
    fi.value = '';
    fi.click();
    fi.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        Swal.fire({
            title: 'جاري المسح',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });
        try {
            const temp = new Html5Qrcode("scanner-area");
            const decoded = await temp.scanFile(file, true);
            Swal.close();
            await onScanSuccess(decoded);
        } catch (err) {
            Swal.close();
            Swal.fire('خطأ', 'لم يتم العثور على رمز QR', 'error');
        }
    };
}

async function onScanSuccess(decodedText) {
    stopScanner();
    try {
        let acc = decodedText;
        try { const qd = JSON.parse(decodedText); if (qd.account) acc = qd.account; } catch (e) {}
        if (!/^(40|41)\d{8}$/.test(acc)) {
            Swal.fire('تنبيه', 'رمز QR غير صالح', 'warning');
            return;
        }
        document.getElementById('recipient-account').value = acc;
        Swal.fire({ title: 'تم المسح', icon: 'success', timer: 1500, showConfirmButton: false });
    } catch (e) {
        Swal.fire('خطأ', 'حدث خطأ', 'error');
    }
}

function onScanError(err) {
    if (err && !err.includes('NotFoundException')) console.error(err);
}

// ============================================================
// INIT & EVENT LISTENERS
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    hideAllSystemPages();

    document.getElementById('scan-qr-btn')?.addEventListener('click', startScanner);
    document.getElementById('startCameraBtn')?.addEventListener('click', startCameraScanner);
    document.getElementById('uploadGalleryBtn')?.addEventListener('click', selectImageFromGallery);
    document.getElementById('closeScannerBtn')?.addEventListener('click', stopScanner);

    document.getElementById('confirm-transfer-btn')?.addEventListener('click', showTransferConfirmation);

    document.getElementById('shareQrBtn')?.addEventListener('click', shareQrCode);
    document.getElementById('downloadQrBtn')?.addEventListener('click', downloadQrCode);

    document.getElementById('soundToggleBtnNotif')?.addEventListener('click', toggleSound);

    document.querySelectorAll('input[name="notifTarget"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const singleInput = document.getElementById('singleUserContainer');
            if (!singleInput) return;
            if (this.value === 'single') singleInput.style.display = 'block';
            else singleInput.style.display = 'none';
        });
    });

    const titleTypeSelect = document.getElementById('notifTitleType');
    const titleInput = document.getElementById('notifAdminTitle');
    const bodyInput = document.getElementById('notifAdminBody');

    if (titleTypeSelect && titleInput && bodyInput) {
        titleTypeSelect.addEventListener('change', function() {
            const selected = this.value;
            if (selected === 'custom') {
                titleInput.value = '';
                bodyInput.value = '';
                titleInput.placeholder = 'أدخل عنوان الإشعار...';
                bodyInput.placeholder = 'اكتب رسالة الإشعار هنا...';
            } else {
                const template = NOTIFICATION_TEMPLATES[selected];
                if (template) {
                    titleInput.value = template.title;
                    bodyInput.value = template.body;
                    titleInput.placeholder = '';
                    bodyInput.placeholder = '';
                }
            }
        });
        titleTypeSelect.value = 'custom';
        titleTypeSelect.dispatchEvent(new Event('change'));
    }

    loadUserBanners();
    loadNewsTicker();

    document.getElementById('subscribeModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });
    document.getElementById('successModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeSuccessModal();
    });

    document.getElementById('userChatInput')?.addEventListener('input', function(e) {
        if (this.value.trim().length > 0) handleTypingStart('user');
        else if (APP.user) database.ref('chats/' + getChatId(APP.user.phone) + '/typing').remove();
    });
    document.getElementById('userChatInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') { e.preventDefault();
            sendMessage('user'); }
    });
    document.getElementById('chatMsgInput')?.addEventListener('input', function(e) {
        if (this.value.trim().length > 0) handleTypingStart('admin');
        else if (APP.currentTicketId) database.ref('chats/' + getChatId(APP.currentTicketId) + '/typing').remove();
    });
    document.getElementById('chatMsgInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') { e.preventDefault();
            sendMessage('admin'); }
    });

    document.getElementById('adminSearchUsers')?.addEventListener('input', renderAdminUsers);

    try {
        if (localStorage.getItem('notif_sound') === 'true') {
            APP.soundEnabled = true;
            updateSoundUI();
        }
    } catch (e) {}

    loadPackagesFromStore();
    initProfileCollapsibles();

    window.addEventListener('popstate', function(event) {
        if (APP.isMain) {
            if (document.getElementById('userInterface').classList.contains('active') ||
                document.getElementById('dashboardInterface').classList.contains('active')) {
                history.pushState({ page: 'main' }, '');
                showAlert('أنت في الصفحة الرئيسية');
            }
            return;
        }

        if (document.getElementById('barcodeInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('transferInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('notificationsInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('adminSystemInterface').classList.contains('active')) navigateTo('dashboardInterface', true);
        else if (document.getElementById('appSystemInterface').classList.contains('active')) navigateTo('dashboardInterface', true);
        else if (document.getElementById('networkSystemInterface').classList.contains('active')) navigateTo('dashboardInterface', true);
        else if (document.getElementById('statementInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('packagesInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('supportTicketsPage').classList.contains('active')) navigateTo('adminSystemInterface', true);
        else if (document.getElementById('chatDetailPage').classList.contains('active')) closeChatDetail();
        else if (document.getElementById('chatPage').classList.contains('active')) closeChatPage();
        else if (document.getElementById('dataInterface').classList.contains('active')) navigateTo('dashboardInterface', true);
        else if (document.getElementById('reportsInterface').classList.contains('active')) navigateTo('dashboardInterface', true);
        else if (document.getElementById('salesAnalysisInterface').classList.contains('active')) navigateTo('reportsInterface', true);
        else if (document.getElementById('usersAnalysisInterface').classList.contains('active')) {
            if (!(window.UsersAnalysis && UsersAnalysis.back())) navigateTo('reportsInterface', true);
        }
        else if (document.getElementById('agentsAnalysisInterface').classList.contains('active')) {
            if (!(window.AgentsAnalysis && AgentsAnalysis.back())) navigateTo('reportsInterface', true);
        }
        else if (document.getElementById('storeCardsInterface').classList.contains('active')) navigateTo('dataInterface', true);
        else if (document.getElementById('soldCardsInterface').classList.contains('active')) navigateTo('dataInterface', true);
        else if (document.getElementById('accountingReportInterface').classList.contains('active')) navigateTo('dataInterface', true);
        else if (document.getElementById('treasuryReportInterface').classList.contains('active')) navigateTo('dataInterface', true);
        else if (document.getElementById('allTransactionsInterface').classList.contains('active')) navigateTo('userInterface', true);
        else if (document.getElementById('adminInvoicesInterface').classList.contains('active')) navigateTo('dataInterface', true);
        else if (document.getElementById('adminInvoiceDetailInterface').classList.contains('active')) navigateTo('adminInvoicesInterface', true);
        else if (document.getElementById('userInvoicesInterface').classList.contains('active')) navigateTo('userInterface', true);
        else if (document.getElementById('countersMapInterface').classList.contains('active')) {
            if (window.CountersMap) CountersMap.close();
            navigateTo('networkSystemInterface', true);
        }
        else if (document.getElementById('adminWifiMonitorInterface').classList.contains('active')) {
            navigateTo('appSystemInterface', true);
        }
        else {
            if (APP.user) navigateTo('userInterface', true);
            else {
                hideAllSystemPages();
                showAuthContainer();
                if (typeof uiShowLoginView === 'function') uiShowLoginView();
            }
        }
        APP.selectedMessage = null;
    });

    if (document.getElementById('dashboardInterface').classList.contains('active')) {
        navigateTo('dashboardInterface', true);
    } else if (document.getElementById('userInterface').classList.contains('active')) {
        navigateTo('userInterface', true);
    }
});

// ============================================================
// 🧹 تنظيف احتياطي — حذف الأزرار المكررة
// ============================================================
(function() {
    function cleanupOldButtons() {
        const home = document.getElementById('adminSystemHome');
        if (!home) return;

        const grid = home.querySelector('.grid-container');
        if (!grid) return;

        const ALLOWED_TEXT = [
            'زوّار الموقع',
            'إدارة العمولة',
            'سجل الإضافات',
            'الحماية',
            'تسجيل الخروج'
        ];

        const cards = grid.querySelectorAll('.admin-card');
        cards.forEach(card => {
            const text = (card.textContent || '').trim();
            const isAllowed = ALLOWED_TEXT.some(t => text.includes(t));
            if (!isAllowed) {
                card.remove();
            }
        });
    }

    setInterval(cleanupOldButtons, 1000);
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', cleanupOldButtons);
    } else {
        cleanupOldButtons();
    }
})();

console.log('🚀 تطبيق كوفانت جاهز مع جميع التعديلات النهائية');

// ============================================================
// SPLASH SCREEN, CAROUSEL, MODAL
// ============================================================
(function() {
    const splash = document.getElementById('splash-screen');
    if (splash) {
        splash.addEventListener('click', function() {
            if (typeof window.revealAuthUI === 'function') window.revealAuthUI();
            else {
                splash.classList.add('hidden');
                setTimeout(function() { splash.style.display = 'none'; }, 700);
            }
        });
        setTimeout(function() {
            if (typeof window.revealAuthUI === 'function') window.revealAuthUI();
            else {
                splash.classList.add('hidden');
                setTimeout(function() { splash.style.display = 'none'; }, 700);
            }
        }, 2500);
    }
})();

// ============================================================
// ✅ طلب إذن الإشعارات
// ============================================================
(function() {
    if (typeof Notification === 'undefined') return;
    let asked = false;
    function askOnce() {
        if (asked || Notification.permission !== 'default') return;
        asked = true;
        Notification.requestPermission().then(p => {
            console.log('🔔 إذن الإشعارات:', p);
        }).catch(() => {});
    }
    document.addEventListener('click', askOnce, { once: true, capture: true });
    document.addEventListener('touchstart', askOnce, { once: true, capture: true });
    setTimeout(askOnce, 2600);
})();

// ============================================================
// LOGIN BANNER (editable from: نظام التطبيق > إدارة إعلانات الدخول)
// Firebase node: loginBanners = [{icon,title,desc,duration,image,active}]
// ============================================================
const LOGIN_BANNER_CACHE_KEY = 'cn_login_banners_v1';
const LOGIN_BANNER_DEFAULT_SEC = 5;
let currentSlide = 0;
let totalSlides = 3;
let bannerInterval;          // setTimeout handle (per-slide duration)
let loginBannerData = null;  // null => static slides from index.html

function _lbEsc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function _lbSafeIcon(c) {
    c = String(c || '').trim();
    return /^[a-z0-9\- ]{2,60}$/i.test(c) ? c : 'fa-solid fa-bullhorn';
}
function _lbSafeUrl(u) {
    u = String(u || '').trim();
    return /^(https?:\/\/|data:image\/)/i.test(u) ? u : '';
}

function updateBanner() {
    const track = document.getElementById('bannerTrack');
    if (!track) return;
    track.style.transform = 'translateX(' + currentSlide * 100 + '%)';
    const dots = document.querySelectorAll('#bannerDots .banner-dot');
    dots.forEach(function(dot, index) { dot.classList.toggle('active', index === currentSlide); });
}

function goToSlide(index) {
    currentSlide = index;
    updateBanner();
    resetBannerInterval();
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    updateBanner();
    resetBannerInterval();
}

function _currentSlideMs() {
    const d = loginBannerData && loginBannerData[currentSlide];
    const s = d && Number(d.duration) > 0 ? Number(d.duration) : LOGIN_BANNER_DEFAULT_SEC;
    return s * 1000;
}

function stopBannerInterval() { clearTimeout(bannerInterval); }

function resetBannerInterval() {
    clearTimeout(bannerInterval);
    if (totalSlides < 2) return;
    bannerInterval = setTimeout(nextSlide, _currentSlideMs());
}

function renderLoginBanner(list) {
    const track = document.getElementById('bannerTrack');
    const dots = document.getElementById('bannerDots');
    if (!track || !dots) return;
    list = (Array.isArray(list) ? list : []).filter(function (c) { return c && c.active !== false; });
    if (!list.length) return;   // keep the static slides
    loginBannerData = list;
    track.innerHTML = list.map(function (c) {
        const img = _lbSafeUrl(c.image);
        if (img) {
            return '<div class="banner-slide banner-slide-img"><img class="banner-bg" src="' + _lbEsc(img) + '" alt="" aria-hidden="true">' +
                '<img class="banner-img" src="' + _lbEsc(img) + '" alt="' + _lbEsc(c.title || 'إعلان') + '" draggable="false"></div>';
        }
        return '<div class="banner-slide"><div class="banner-icon"><i class="' + _lbEsc(_lbSafeIcon(c.icon)) + '"></i></div>' +
            '<div class="banner-text"><div class="banner-title">' + _lbEsc(c.title) + '</div><div class="banner-desc">' + _lbEsc(c.desc) + '</div></div></div>';
    }).join('');
    dots.innerHTML = list.map(function (_, i) {
        return '<button class="banner-dot' + (i === 0 ? ' active' : '') + '" data-index="' + i + '" onclick="goToSlide(' + i + ')" aria-label="الشريحة ' + (i + 1) + '"></button>';
    }).join('');
    dots.style.display = list.length > 1 ? '' : 'none';
    totalSlides = list.length;
    currentSlide = 0;
    updateBanner();
    resetBannerInterval();
}

function _lbApply(list, fromServer) {
    list = (Array.isArray(list) ? list : []).filter(Boolean);
    try {
        if (list.length) localStorage.setItem(LOGIN_BANNER_CACHE_KEY, JSON.stringify(list));
        else if (fromServer) localStorage.removeItem(LOGIN_BANNER_CACHE_KEY);
    } catch (e) {}
    renderLoginBanner(list);
}

function loadLoginBannerImages() {
    // 1) النسخة المحفوظة (ظهور فوري)
    try {
        const cached = JSON.parse(localStorage.getItem(LOGIN_BANNER_CACHE_KEY) || 'null');
        if (cached) renderLoginBanner(cached);
    } catch (e) {}
    // 2) السيرفر (يعمل قبل تسجيل الدخول)  3) Firebase مباشرة كاحتياط
    const viaFirebase = function () {
        if (typeof database === 'undefined') return;
        try {
            database.ref('loginBanners').once('value').then(function (snap) {
                if (!snap.exists()) return;
                const d = snap.val();
                _lbApply(Array.isArray(d) ? d : Object.values(d), false);
            }).catch(function () {});
        } catch (e) {}
    };
    fetch('https://kovant-backend3.onrender.com/api/public/login-banners', { cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error('http'); return r.json(); })
        .then(function (j) { if (!j || !Array.isArray(j.banners)) throw new Error('bad'); _lbApply(j.banners, true); })
        .catch(viaFirebase);
}

const bannerContainer = document.getElementById('bannerCarousel');
if (bannerContainer) {
    loadLoginBannerImages();
    resetBannerInterval();
    document.addEventListener('visibilitychange', function () { if (!document.hidden) loadLoginBannerImages(); });
    bannerContainer.addEventListener('mouseenter', stopBannerInterval);
    bannerContainer.addEventListener('mouseleave', resetBannerInterval);

    let touchStartX = 0;
    bannerContainer.addEventListener('touchstart', (e) => { stopBannerInterval(); touchStartX = e.changedTouches[0].screenX; }, { passive: true });
    bannerContainer.addEventListener('touchend', (e) => {
        const diff = touchStartX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) currentSlide = (currentSlide + 1) % totalSlides;
            else currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            updateBanner();
        }
        resetBannerInterval();
    }, { passive: true });
}

function showLoadingModal(text) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div class="modal-spinner"></div>
        <div class="modal-title">يرجى الانتظار</div>
        <div class="modal-subtitle">${text}</div>
    `;
    overlay.classList.add('visible');
}

function showModalMessage(text) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div style="font-size: 48px; color: var(--brand-accent); margin: 10px 0;">
            <i class="fa-solid fa-circle-info"></i>
        </div>
        <div class="modal-title" style="font-size:1.2rem;">${text}</div>
        <div class="modal-subtitle">اضغط أي مكان للإغلاق</div>
    `;
    overlay.classList.add('visible');
    setTimeout(() => closeLoginModal(), 3000);
}

function showSuccessModal(text) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div style="font-size: 48px; color: #10b981; margin: 10px 0;">
            <i class="fa-solid fa-circle-check"></i>
        </div>
        <div class="modal-title" style="font-size:1.2rem;">${text}</div>
        <div class="modal-subtitle">سيتم تحويلك تلقائياً...</div>
    `;
    overlay.classList.add('visible');
    setTimeout(() => closeLoginModal(), 2000);
}

function showMenuModal() {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div class="modal-title" style="font-size:1.2rem;">تم تسجيل الدخول بنجاح</div>
        <div class="modal-subtitle">مرحباً بك في كوفانت! اختر وجهتك:</div>
        <div class="modal-menu-list">
            <button class="modal-menu-item" onclick="closeLoginModal(); showModalMessage('لوحة التحكم - قيد التطوير')">
                <span class="menu-icon"><i class="fa-solid fa-chart-pie"></i></span> لوحة التحكم
            </button>
            <button class="modal-menu-item" onclick="closeLoginModal(); showModalMessage('إدارة الباقات - قيد التطوير')">
                <span class="menu-icon"><i class="fa-solid fa-box"></i></span> إدارة الباقات
            </button>
            <button class="modal-menu-item" onclick="closeLoginModal(); showModalMessage('الإعدادات - قيد التطوير')">
                <span class="menu-icon"><i class="fa-solid fa-gear"></i></span> الإعدادات
            </button>
        </div>
    `;
    overlay.classList.add('visible');
}

function closeLoginModal() {
    document.getElementById('modal-overlay').classList.remove('visible');
}

document.getElementById('modal-overlay')?.addEventListener('click', function(e) {
    if (e.target === this) closeLoginModal();
});

document.addEventListener('DOMContentLoaded', function() {
    if (typeof populateDateSelects === 'function') populateDateSelects();
    if (typeof uiGoToStep1 === 'function') uiGoToStep1();
});

document.getElementById('referralCode')?.addEventListener('input', function(e) {
    this.value = this.value.replace(/[^A-Za-z0-9\u0621-\u064A]/g, '').toUpperCase();
});
