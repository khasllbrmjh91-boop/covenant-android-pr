/* ============================================================
 * COVANT — ADMIN SMS GATEWAY
 * بوابة SMS المركزية على جهاز الأدمن
 * ============================================================
 * البوابة تراقب /sms_queue وتنفذ الرسائل pending على جهاز الأدمن
 * فقط. الحجز يتم بمعاملة Firebase ذرية حتى لا ترسل أجهزة متعددة
 * الرسالة نفسها. الإرسال الفعلي يتم عبر SMSNativeBridge إن توفر،
 * ثم عبر tuaSendRealSms (الجسر الحالي) كبديل.
 * ============================================================ */
(function (window, document) {
    'use strict';

    if (window.AdminSmsGateway) return;

    const CONFIG = {
        queuePath: 'sms_queue',
        gatewaysPath: 'sms_gateways',
        logPath: 'sms_log',
        maxPerMinute: 30,
        maxAttempts: 3,
        lockTimeoutMs: 5 * 60 * 1000,
        pollIntervalMs: 15000,
        heartbeatMs: 30000,
        retryDelayMs: 2500,
        pageSize: 100
    };

    const state = {
        running: false,
        listenerAttached: false,
        processing: false,
        deviceId: null,
        timer: null,
        heartbeatTimer: null,
        sentTimestamps: [],
        currentQueueSize: 0,
        lastError: null,
        sentToday: 0
    };

    function now() { return Date.now(); }

    function safeString(value) { return String(value == null ? '' : value).trim(); }

    function getDatabase() {
        return window.database && typeof window.database.ref === 'function' ? window.database : null;
    }

    function makeDeviceId() {
        // الأولوية للمعرّف الأصلي (ANDROID_ID) القادم من SharedPreferences
        const bridge = window.SmsSettingsBridge;
        if (bridge && bridge.cache && bridge.cache.deviceId) return safeString(bridge.cache.deviceId);
        const store = window.SmsStore;
        if (store && store.data && store.data.deviceId) return safeString(store.data.deviceId);
        try {
            const key = 'covant_sms_gateway_device_id';
            const saved = window.localStorage.getItem(key);
            if (saved) return saved;
            const created = 'GW-' + now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 9).toUpperCase();
            window.localStorage.setItem(key, created);
            return created;
        } catch (error) {
            return 'GW-' + now().toString(36).toUpperCase();
        }
    }

    function deviceName() {
        return (window.SmsStore && window.SmsStore.data && window.SmsStore.data.deviceId) || 'COVANT SMS Gateway';
    }

    function isAdmin() {
        return !!(window.APP && window.APP.user && (
            window.APP.user.isAdmin === true ||
            window.APP.user.role === 'admin' ||
            safeString(window.APP.user.phone || window.APP.user.phoneNumber) === '999'
        ));
    }

    function nativeAvailable() {
        return !!(
            window.SMSNativeBridge && typeof window.SMSNativeBridge.send === 'function' ||
            typeof window.tuaSendRealSms === 'function'
        );
    }

    // شريحة الإرسال: subscriptionId الصريح في العنصر أولاً، وإلا إعداد sendSim، وإلا الافتراضي
    async function resolveSubscriptionId(item) {
        if (item && item.subscriptionId != null && item.subscriptionId !== '') return Number(item.subscriptionId);
        if (window.SmsSettingsBridge) {
            try { const id = await window.SmsSettingsBridge.getSendSubscriptionId(); if (id != null) return id; } catch (e) {}
        }
        return undefined;
    }

    async function sendNative(to, message, item) {
        const subscriptionId = await resolveSubscriptionId(item);
        if (window.SMSNativeBridge && typeof window.SMSNativeBridge.send === 'function') {
            return window.SMSNativeBridge.send({
                number: to,
                to: to,
                text: message,
                message: message,
                subscriptionId: subscriptionId
            });
        }
        if (typeof window.tuaSendRealSms === 'function') {
            return window.tuaSendRealSms(to, message, subscriptionId);
        }
        throw new Error('SMS_NATIVE_BRIDGE_UNAVAILABLE');
    }

    function pruneRateWindow() {
        const cutoff = now() - 60000;
        state.sentTimestamps = state.sentTimestamps.filter(function (time) { return time > cutoff; });
    }

    function canSendNow() {
        pruneRateWindow();
        return state.sentTimestamps.length < CONFIG.maxPerMinute;
    }

    function waitForRateSlot() {
        pruneRateWindow();
        if (canSendNow()) return Promise.resolve();
        const delay = Math.max(250, 60000 - (now() - state.sentTimestamps[0]) + 50);
        return new Promise(function (resolve) { setTimeout(resolve, delay); });
    }

    function lockIsStale(item) {
        return item && item.status === 'sending' && (!item.lockedAt || now() - Number(item.lockedAt) > CONFIG.lockTimeoutMs);
    }

    async function claim(messageId, item) {
        const database = getDatabase();
        if (!database || !messageId || !item) return false;
        const ref = database.ref(CONFIG.queuePath + '/' + messageId);
        const result = await ref.transaction(function (current) {
            if (!current) return;
            if (current.status === 'sent' || current.status === 'failed') return;
            if (current.status === 'sending' && !lockIsStale(current) && current.lockedBy !== state.deviceId) return;
            const attempts = Number(current.attempts || 0);
            if (attempts >= CONFIG.maxAttempts && !lockIsStale(current)) return;
            return Object.assign({}, current, {
                status: 'sending',
                attempts: attempts + 1,
                lockedBy: state.deviceId,
                lockedAt: now(),
                gatewayDeviceId: state.deviceId,
                updatedAt: now()
            });
        });
        return !!(result && result.committed && result.snapshot && result.snapshot.val() && result.snapshot.val().lockedBy === state.deviceId);
    }

    async function markFailed(messageId, item, error) {
        const database = getDatabase();
        if (!database) return;
        const message = safeString(error && error.message) || 'unknown-error';
        const ref = database.ref(CONFIG.queuePath + '/' + messageId);
        await ref.transaction(function (current) {
            if (!current || current.lockedBy !== state.deviceId) return;
            const attempts = Number(current.attempts || 0);
            return Object.assign({}, current, {
                status: attempts >= CONFIG.maxAttempts ? 'failed' : 'pending',
                lastError: message,
                lastFailedAt: now(),
                lockedBy: null,
                lockedAt: null,
                updatedAt: now()
            });
        });
    }

    async function writeLog(messageId, item, sentAt) {
        const database = getDatabase();
        if (!database) return;
        const logData = Object.assign({}, item, {
            messageId: messageId,
            status: 'sent',
            sentAt: sentAt,
            sentBy: state.deviceId,
            gatewayDeviceId: state.deviceId
        });
        await database.ref(CONFIG.logPath + '/' + messageId).set(logData);
    }

    async function markSent(messageId, item) {
        const database = getDatabase();
        if (!database) return;
        const sentAt = now();
        await database.ref(CONFIG.queuePath + '/' + messageId).transaction(function (current) {
            if (!current || current.lockedBy !== state.deviceId) return;
            return Object.assign({}, current, {
                status: 'sent',
                sentAt: sentAt,
                sentBy: state.deviceId,
                lockedBy: null,
                lockedAt: null,
                updatedAt: sentAt
            });
        });
        await writeLog(messageId, item, sentAt);
        state.sentToday += 1;
        state.sentTimestamps.push(sentAt);
    }

    async function processItem(messageId, item) {
        if (!item || !safeString(item.to) || !safeString(item.message)) return { skipped: true };
        if (item.status === 'sent' || item.status === 'failed') return { skipped: true };
        if (!isAdmin()) return { skipped: true, reason: 'not-admin' };
        if (!nativeAvailable()) return { skipped: true, reason: 'native-unavailable' };
        if (!await claim(messageId, item)) return { skipped: true, reason: 'locked' };

        try {
            await waitForRateSlot();
            await sendNative(safeString(item.to), safeString(item.message), item);
            await markSent(messageId, item);
            return { sent: true, id: messageId };
        } catch (error) {
            state.lastError = error;
            await markFailed(messageId, item, error);
            return { sent: false, id: messageId, error: error };
        }
    }

    async function processSnapshot(snapshot) {
        if (!snapshot || !snapshot.val()) return;
        const entries = [];
        snapshot.forEach(function (child) {
            const item = child.val();
            if (item && (item.status === 'pending' || lockIsStale(item))) entries.push({ id: child.key, item: item });
        });
        entries.sort(function (a, b) { return Number(a.item.createdAt || 0) - Number(b.item.createdAt || 0); });
        state.currentQueueSize = entries.length;
        if (state.processing || !state.running) return;
        state.processing = true;
        try {
            for (let i = 0; i < entries.length && state.running; i += 1) {
                await processItem(entries[i].id, entries[i].item);
            }
        } finally {
            state.processing = false;
        }
    }

    async function updateGateway(status) {
        const database = getDatabase();
        if (!database || !state.deviceId) return;
        try {
            await database.ref(CONFIG.gatewaysPath + '/' + state.deviceId).update({
                lastSeen: now(),
                status: status || (state.running ? 'online' : 'offline'),
                deviceName: deviceName(),
                sentToday: state.sentToday,
                queueSize: state.currentQueueSize,
                updatedAt: now()
            });
        } catch (error) { state.lastError = error; }
    }

    function attachListener() {
        const database = getDatabase();
        if (!database || state.listenerAttached) return false;
        state.listenerAttached = true;
        database.ref(CONFIG.queuePath).limitToFirst(CONFIG.pageSize).on('value', processSnapshot, function (error) {
            state.lastError = error;
            updateGateway('error');
        });
        return true;
    }

    function detachListener() {
        const database = getDatabase();
        if (database && state.listenerAttached) database.ref(CONFIG.queuePath).off('value', processSnapshot);
        state.listenerAttached = false;
    }

    function scheduleHeartbeat() {
        clearInterval(state.heartbeatTimer);
        state.heartbeatTimer = setInterval(function () { updateGateway(state.running ? 'online' : 'offline'); }, CONFIG.heartbeatMs);
    }

    async function start(options) {
        options = options || {};
        if (!isAdmin()) return { started: false, reason: 'not-admin' };
        if (!getDatabase()) return { started: false, reason: 'database-unavailable' };
        if (window.SmsSettingsBridge) {
            // انتظر قراءة الإعدادات الأصلية (بحد أقصى 3 ثوانٍ) كي يُستخدم ANDROID_ID كمعرّف للبوابة
            await Promise.race([window.SmsSettingsBridge.ready, new Promise(function (r) { setTimeout(r, 3000); })]);
        }
        state.deviceId = state.deviceId || makeDeviceId();
        state.running = true;
        attachListener();
        scheduleHeartbeat();
        await updateGateway('online');
        if (options.processNow !== false) {
            try { const snapshot = await getDatabase().ref(CONFIG.queuePath).limitToFirst(CONFIG.pageSize).once('value'); await processSnapshot(snapshot); } catch (error) { state.lastError = error; }
        }
        return { started: true, deviceId: state.deviceId };
    }

    async function stop() {
        state.running = false;
        clearInterval(state.heartbeatTimer);
        state.heartbeatTimer = null;
        detachListener();
        await updateGateway('offline');
        return { stopped: true };
    }

    function status() {
        pruneRateWindow();
        return {
            running: state.running,
            deviceId: state.deviceId,
            queueSize: state.currentQueueSize,
            sentLastMinute: state.sentTimestamps.length,
            sentToday: state.sentToday,
            nativeAvailable: nativeAvailable(),
            lastError: state.lastError ? safeString(state.lastError.message || state.lastError) : null
        };
    }

    window.AdminSmsGateway = {
        config: CONFIG,
        state: state,
        start: start,
        stop: stop,
        processNow: async function () {
            if (!getDatabase()) throw new Error('database-unavailable');
            const snapshot = await getDatabase().ref(CONFIG.queuePath).limitToFirst(CONFIG.pageSize).once('value');
            return processSnapshot(snapshot);
        },
        status: status,
        updateGateway: updateGateway
    };

    // بدء تلقائي متين: ينتظر APP.user وFirebase والجسر الأصلي، ثم يعيد المحاولة.
    var autoStartTimer = null;
    var autoStartAttempts = 0;
    var autoStartMaxAttempts = 40;

    function autoStartAttempt() {
        if (state.running) {
            if (autoStartTimer) { clearInterval(autoStartTimer); autoStartTimer = null; }
            return;
        }
        autoStartAttempts += 1;
        if (!isAdmin()) {
            if (autoStartAttempts >= autoStartMaxAttempts && autoStartTimer) {
                clearInterval(autoStartTimer);
                autoStartTimer = null;
            }
            return;
        }
        if (!getDatabase()) return;
        start().then(function (result) {
            if (result && result.started && autoStartTimer) {
                clearInterval(autoStartTimer);
                autoStartTimer = null;
                console.log('✅ Admin SMS Gateway started');
            }
        }).catch(function (error) {
            state.lastError = error;
        });
    }

    function scheduleAutoStart() {
        if (state.running || autoStartTimer) return;
        autoStartAttempts = 0;
        autoStartAttempt();
        autoStartTimer = setInterval(autoStartAttempt, 1500);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scheduleAutoStart);
    else scheduleAutoStart();
    window.addEventListener('userLoggedIn', scheduleAutoStart);
    window.addEventListener('adminModeEnabled', scheduleAutoStart);
}(window, document));
