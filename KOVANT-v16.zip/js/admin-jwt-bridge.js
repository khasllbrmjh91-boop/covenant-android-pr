/* ============================================================
   COVANT — ADMIN JWT NATIVE BRIDGE
   يحفظ JWT الأدمن في Capacitor Preferences ليكون متاحاً
   للوحدة الأصلية بعد إنشاء مشروع Android وتشغيل cap sync.
   ============================================================ */
(function (window) {
    'use strict';

    if (window.AdminJWTBridge) return;

    function preferences() {
        return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences;
    }

    async function save(jwt, expiry) {
        if (!jwt) return false;
        const plugin = preferences();
        try {
            if (plugin && typeof plugin.set === 'function') {
                await plugin.set({ key: 'admin_jwt', value: String(jwt) });
                await plugin.set({ key: 'admin_jwt_expiry', value: String(expiry || 0) });
                return true;
            }
            localStorage.setItem('admin_jwt_native_pending', String(jwt));
            localStorage.setItem('admin_jwt_native_expiry', String(expiry || 0));
            return false;
        } catch (error) {
            console.error('❌ فشل حفظ JWT في التخزين الأصلي:', error);
            return false;
        }
    }

    async function get() {
        const plugin = preferences();
        try {
            if (plugin && typeof plugin.get === 'function') {
                const jwt = await plugin.get({ key: 'admin_jwt' });
                const expiry = await plugin.get({ key: 'admin_jwt_expiry' });
                return { jwt: jwt && jwt.value || null, expiry: Number(expiry && expiry.value || 0) };
            }
        } catch (error) {
            console.warn('⚠️ تعذر قراءة JWT الأصلي:', error);
        }
        return {
            jwt: localStorage.getItem('admin_jwt_native_pending'),
            expiry: Number(localStorage.getItem('admin_jwt_native_expiry') || 0)
        };
    }

    async function clear() {
        const plugin = preferences();
        try {
            if (plugin && typeof plugin.remove === 'function') {
                await plugin.remove({ key: 'admin_jwt' });
                await plugin.remove({ key: 'admin_jwt_expiry' });
            }
        } catch (error) {
            console.warn('⚠️ تعذر حذف JWT الأصلي:', error);
        }
        localStorage.removeItem('admin_jwt_native_pending');
        localStorage.removeItem('admin_jwt_native_expiry');
    }

    async function saveSmsSecret(phone, secret) {
        const normalizedPhone = String(phone || '').trim();
        const normalizedSecret = String(secret || '').trim();
        if (!normalizedPhone || normalizedSecret.length < 20) return false;
        const plugin = preferences();
        try {
            if (plugin && typeof plugin.set === 'function') {
                await plugin.set({ key: 'sms_secret_' + normalizedPhone, value: normalizedSecret });
                return true;
            }
            localStorage.setItem('sms_secret_native_pending_' + normalizedPhone, normalizedSecret);
            return false;
        } catch (error) {
            console.error('❌ فشل حفظ sms_secret في التخزين الأصلي:', error);
            return false;
        }
    }

    async function syncAllSmsSecrets() {
        if (!window.database || typeof window.database.ref !== 'function') return false;
        const plugin = preferences();
        if (!plugin || typeof plugin.set !== 'function') return false;
        try {
            const snapshot = await window.database.ref('users').once('value');
            const users = snapshot.val() || {};
            const tasks = Object.keys(users).map(function (phone) {
                const secret = users[phone] && users[phone].sms_secret;
                return secret ? plugin.set({ key: 'sms_secret_' + phone, value: String(secret) }) : Promise.resolve();
            });
            await Promise.all(tasks);
            return true;
        } catch (error) {
            console.warn('تعذر مزامنة مفاتيح SMS للأدمن:', error);
            return false;
        }
    }

    window.AdminJWTBridge = { save: save, get: get, clear: clear, saveSmsSecret: saveSmsSecret, syncAllSmsSecrets: syncAllSmsSecrets };
    window.syncAdminJWTToNative = save;
}(window));
