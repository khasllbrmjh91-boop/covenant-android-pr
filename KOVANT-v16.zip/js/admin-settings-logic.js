/* ============================================================
   admin-settings-logic.js — منطق صفحة "إعدادات النظام"
   ============================================================ */

const ADMIN_SETTINGS_KEY = 'kovant_admin_settings';
const ADMIN_DEFAULT_SOUND_URL = 'sounds/success-default.mp3';

function _adminSettingsDefaults() {
    return {
        security: { fingerprintTransfer: false },
        sounds: { master: true, volume: 70, customSoundDataUrl: null, customFileName: null },
        notifications: { transfers: true, deposits: true, purchases: true }
    };
}

function loadAdminSettingsState() {
    try {
        const raw = localStorage.getItem(ADMIN_SETTINGS_KEY);
        if (!raw) return _adminSettingsDefaults();
        const saved = JSON.parse(raw);
        const d = _adminSettingsDefaults();
        return {
            security: { ...d.security, ...(saved.security || {}) },
            sounds: { ...d.sounds, ...(saved.sounds || {}) },
            notifications: { ...d.notifications, ...(saved.notifications || {}) }
        };
    } catch (e) { return _adminSettingsDefaults(); }
}

function saveAdminSettingsState(state) {
    try { localStorage.setItem(ADMIN_SETTINGS_KEY, JSON.stringify(state)); } catch (e) {}
}

let _adminSettingsState = loadAdminSettingsState();

/* ============================================================
   تحميل الصفحة عند فتحها (يُستدعى من navigateAdmin → 'settings')
   ============================================================ */
async function loadAdminSettingsPage() {
    const s = _adminSettingsState = loadAdminSettingsState();

    // الأمان — بصمة الدخول للوحة التحكم (نفس آلية بصمة الملف الشخصي)
    const fpToggle = document.getElementById('adminFpToggle');
    if (fpToggle && typeof biometricHasSavedSession === 'function') {
        try { fpToggle.checked = await biometricHasSavedSession(); }
        catch (e) { fpToggle.checked = false; }
    }
    const fpTransferToggle = document.getElementById('adminFpTransferToggle');
    if (fpTransferToggle) fpTransferToggle.checked = !!s.security.fingerprintTransfer;

    // الأصوات
    const soundMaster = document.getElementById('adminSoundMaster');
    if (soundMaster) soundMaster.checked = !!s.sounds.master;

    const volSlider = document.getElementById('adminVolume');
    if (volSlider) { volSlider.value = s.sounds.volume ?? 70; _updateAdminVolumeUI(); }

    _refreshAdminSoundChip();

    // الإشعارات
    const nT = document.getElementById('adminNotifTransfers');
    const nD = document.getElementById('adminNotifDeposits');
    const nP = document.getElementById('adminNotifPurchases');
    if (nT) nT.checked = !!s.notifications.transfers;
    if (nD) nD.checked = !!s.notifications.deposits;
    if (nP) nP.checked = !!s.notifications.purchases;
}

function _refreshAdminSoundChip() {
    const box = document.getElementById('adminSoundUploader');
    const chip = document.getElementById('adminFileChip');
    const nameEl = document.getElementById('adminSoundFileName');
    const clearBtn = document.getElementById('adminClearSoundBtn');
    if (!box || !chip || !nameEl) return;

    if (_adminSettingsState.sounds.customFileName) {
        nameEl.textContent = _adminSettingsState.sounds.customFileName;
        box.classList.add('has-file');
        chip.classList.add('active');
        if (clearBtn) clearBtn.style.display = 'inline-flex';
    } else {
        nameEl.textContent = 'نغمة النظام الافتراضية';
        box.classList.remove('has-file');
        chip.classList.remove('active');
        if (clearBtn) clearBtn.style.display = 'none';
    }
}

/* ============================================================
   تشغيل صوت نجاح العملية (يمكن استدعاؤها من أي مكان في النظام)
   ============================================================ */
let _adminCurrentAudio = null;

function _playFallbackBeep(vol) {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [880, 1174.66, 1567.98].forEach((freq, i) => {
            const osc = ctx.createOscillator(), gain = ctx.createGain();
            osc.type = 'sine'; osc.frequency.value = freq;
            osc.connect(gain); gain.connect(ctx.destination);
            const t = ctx.currentTime + i * 0.09;
            gain.gain.setValueAtTime(0.0001, t);
            gain.gain.linearRampToValueAtTime(Math.max(0.001, vol * 0.28), t + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
            osc.start(t); osc.stop(t + 0.38);
        });
    } catch (e) {}
}

function playSystemSuccessSound(forcePreview) {
    const s = _adminSettingsState;
    if (!forcePreview && !s.sounds.master) return;

    if (_adminCurrentAudio) { try { _adminCurrentAudio.pause(); } catch (e) {} _adminCurrentAudio = null; }

    const src = s.sounds.customSoundDataUrl || ADMIN_DEFAULT_SOUND_URL;
    const vol = (s.sounds.volume ?? 70) / 100;
    try {
        _adminCurrentAudio = new Audio(src);
        _adminCurrentAudio.volume = vol;
        _adminCurrentAudio.play().catch(() => _playFallbackBeep(vol));
    } catch (e) { _playFallbackBeep(vol); }

    if (navigator.vibrate) navigator.vibrate(12);
}

/* ============================================================
   هل الإشعار من نوع معيّن مفعّل؟ (تُستخدم قبل إرسال إشعارات المستخدمين)
   ============================================================ */
function isAdminNotificationEnabled(kind) {
    // kind: 'transfers' | 'deposits' | 'purchases'
    const n = _adminSettingsState.notifications || {};
    return n[kind] !== false; // افتراضياً مفعّل ما لم يُعطَّل صراحةً
}

/* ============================================================
   بوابة تأكيد البصمة للعمليات المالية الحسّاسة التي ينفّذها الأدمن
   (تُستخدم فقط عندما يكون مفتاح "البصمة عند تأكيد التحويلات" مفعّلاً
   على نفس الجهاز/الجلسة التي يعمل منها الأدمن)
   يعيد true للسماح بالمتابعة، و false لإلغاء العملية
   ============================================================ */
async function requireFingerprintConfirmIfEnabled() {
    const s = _adminSettingsState;
    if (!s.security.fingerprintTransfer) return true; // الخاصية غير مفعّلة

    const Bio = (typeof biometricPlugin === 'function') ? biometricPlugin() : null;
    if (!Bio) return true; // لا يوجد دعم بصمة على هذا الجهاز (متصفح ويب مثلاً) — لا نمنع العمل

    try {
        const has = (typeof biometricHasSavedSession === 'function') ? await biometricHasSavedSession() : false;
        if (!has) return true; // البصمة غير مُفعّلة أصلاً على الجهاز — لا يمكن التحقق، نسمح بالمتابعة

        const result = await Bio.verifyAndGetSecret({
            title: 'تأكيد العملية المالية',
            subtitle: 'كوفانت',
            description: 'ضع إصبعك لتأكيد تنفيذ العملية'
        });
        if (!result || !result.success) {
            showAlert('لم يتم تأكيد البصمة، تم إلغاء العملية', false);
            return false;
        }
        return true;
    } catch (e) {
        showAlert('تعذّر التحقق بالبصمة، تم إلغاء العملية', false);
        return false;
    }
}

/* ============================================================
   ربط الأحداث — مرة واحدة عند تحميل السكربت
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

    // ----- بصمة الدخول للوحة التحكم -----
    const fpToggle = document.getElementById('adminFpToggle');
    if (fpToggle) {
        fpToggle.addEventListener('change', async () => {
            const Bio = (typeof biometricPlugin === 'function') ? biometricPlugin() : null;
            if (!Bio) {
                fpToggle.checked = false;
                showAlert('البصمة غير متوفرة على هذا الجهاز', false);
                return;
            }
            fpToggle.disabled = true;
            try {
                if (fpToggle.checked) {
                    const phone = (typeof APP !== 'undefined' && APP.user) ? APP.user.phone : null;
                    if (!phone) { fpToggle.checked = false; showAlert('يرجى تسجيل الدخول أولاً', false); return; }
                    const ok = await enableBiometricAfterLogin(phone);
                    if (ok) showAlert('تم تفعيل الدخول بالبصمة ✅', true);
                    else { fpToggle.checked = false; showAlert('تعذّر تفعيل البصمة', false); }
                } else {
                    await disableBiometric();
                    showAlert('تم إيقاف الدخول بالبصمة', true);
                }
            } catch (e) {
                fpToggle.checked = !fpToggle.checked;
                showAlert('تعذّر التحقق بالبصمة', false);
            } finally {
                fpToggle.disabled = false;
            }
        });
    }

    const fpTransferToggle = document.getElementById('adminFpTransferToggle');
    if (fpTransferToggle) {
        fpTransferToggle.addEventListener('change', () => {
            _adminSettingsState.security.fingerprintTransfer = fpTransferToggle.checked;
            saveAdminSettingsState(_adminSettingsState);
            showAlert(fpTransferToggle.checked ? 'تم تفعيل تأكيد التحويلات بالبصمة' : 'تم إيقاف تأكيد التحويلات بالبصمة', true);
        });
    }

    // ----- تفعيل صوت النظام -----
    const soundMaster = document.getElementById('adminSoundMaster');
    if (soundMaster) {
        soundMaster.addEventListener('change', () => {
            _adminSettingsState.sounds.master = soundMaster.checked;
            saveAdminSettingsState(_adminSettingsState);
            showAlert(soundMaster.checked ? 'تم تفعيل صوت النظام' : 'تم إيقاف صوت النظام', true);
            if (soundMaster.checked) playSystemSuccessSound(true);
        });
    }

    // ----- مستوى الصوت -----
    const volSlider = document.getElementById('adminVolume');
    if (volSlider) {
        volSlider.addEventListener('input', _updateAdminVolumeUI);
        volSlider.addEventListener('change', () => {
            _adminSettingsState.sounds.volume = +volSlider.value;
            saveAdminSettingsState(_adminSettingsState);
            playSystemSuccessSound();
        });
    }

    // ----- رفع/تجربة/حذف ملف الصوت -----
    const pickBtn = document.getElementById('adminPickSoundBtn');
    const fileInput = document.getElementById('adminSoundFileInput');
    const previewBtn = document.getElementById('adminPreviewSoundBtn');
    const clearBtn = document.getElementById('adminClearSoundBtn');

    if (pickBtn && fileInput) pickBtn.addEventListener('click', () => fileInput.click());

    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            const f = e.target.files[0];
            if (!f) return;
            if (!f.type.startsWith('audio/')) {
                showAlert('الرجاء اختيار ملف صوتي صالح', false);
                return;
            }
            if (f.size > 2 * 1024 * 1024) {
                showAlert('حجم الملف كبير جداً، الرجاء اختيار ملف أصغر من 2MB', false);
                return;
            }
            const reader = new FileReader();
            reader.onload = () => {
                _adminSettingsState.sounds.customSoundDataUrl = reader.result;
                _adminSettingsState.sounds.customFileName = f.name;
                saveAdminSettingsState(_adminSettingsState);
                _refreshAdminSoundChip();
                showAlert('تم إرفاق: ' + f.name, true);
                if (navigator.vibrate) navigator.vibrate(15);
            };
            reader.readAsDataURL(f);
        });
    }

    if (previewBtn) {
        previewBtn.addEventListener('click', () => {
            playSystemSuccessSound(true);
            previewBtn.classList.add('playing');
            setTimeout(() => previewBtn.classList.remove('playing'), 700);
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            _adminSettingsState.sounds.customSoundDataUrl = null;
            _adminSettingsState.sounds.customFileName = null;
            saveAdminSettingsState(_adminSettingsState);
            if (fileInput) fileInput.value = '';
            _refreshAdminSoundChip();
            showAlert('تم الحذف — سيُستخدم صوت النظام الافتراضي', true);
        });
    }

    // ----- الإشعارات -----
    [['adminNotifTransfers', 'transfers'], ['adminNotifDeposits', 'deposits'], ['adminNotifPurchases', 'purchases']]
        .forEach(([id, key]) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.addEventListener('change', () => {
                _adminSettingsState.notifications[key] = el.checked;
                saveAdminSettingsState(_adminSettingsState);
            });
        });
});

function _updateAdminVolumeUI() {
    const slider = document.getElementById('adminVolume');
    const val = document.getElementById('adminVolVal');
    if (!slider || !val) return;
    val.textContent = slider.value + '%';
    slider.style.setProperty('--p', slider.value + '%');
}
