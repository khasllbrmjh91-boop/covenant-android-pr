/* ============================================================
   موافقة طلبات التغذية — تحقق تلقائي من رسائل SMS المستقبلة
   مدمجة ضمن لوحة الأدمن (كوفانت)
   جميع الأسماء مسبوقة بـ Tua/tua لتفادي أي تعارض مع باقي النظام
   ------------------------------------------------------------
   الفكرة:
   1) الرسائل الواردة من شريحة الاتصال (إيداعات البنوك) تُسجَّل مركزياً
      في قاعدة البيانات تحت sms_inbox/ (عبر tuaReceiveIncomingSms، والتي
      يستدعيها لاحقاً مكوّن Capacitor يقرأ SMS من الجهاز الفعلي — غير
      موجود في هذا المستودع بعد، لذلك أضفنا أيضاً زر "إضافة رسالة يدوياً"
      للأدمن يستخدم نفس الدالة، لحين ربط قارئ SMS الحقيقي).
   2) كل طلب تغذية معلّق (topup_requests/status=pending) يُقارَن تلقائياً
      مع الرسائل غير المُستهلكة عبر 4 نقاط تحقق:
        - معرف المرسل (Sender ID) لرسالة SMS = معرف المرسل المسجّل في المحفظة
        - الاسم الأول + الاسم الثاني في "كوفانت" = نفس الاسم في نص الرسالة
        - المبلغ في الرسالة = المبلغ الذي أدخله المستخدم في الطلب
        - الرسالة لم تُستخدم من قبل لأي طلب آخر (منع التكرار) ضمن نافذة
          زمنية معقولة حول وقت تقديم الطلب
   3) عند تحقق كل الشروط (تلقائياً إن كان الإعداد autoProcess مفعّلاً) أو
      عند ضغط الأدمن "قبول": يُضاف المبلغ لرصيد المستخدم، يُخصم من
      الخزينة، تُسجَّل الحركة في كشف الخزينة/كشف حساب المستخدم، ويُسجَّل
      قيد مطابقة في سجل "إدارة الرسائل" بالصيغة المطلوبة.
============================================================ */

/* ============================================================
   حارس صلاحيات: كل عمليات موافقة/رفض التغذية وصندوق الرسائل
   الواردة يجب أن تعمل للأدمن فقط. هذا الفحص طبقة حماية إضافية
   على مستوى الواجهة (Front-end) — الحماية الفعلية والملزمة تبقى
   في قواعد أمان Firebase (Realtime Database Rules) على المسارات:
   sms_inbox, topup_requests, topup_processed_log
   (راجع الشرح المرفق في الرد لإضافتها إن لم تكن موجودة).
============================================================ */
function tuaRequireAdmin(showMsg) {
    if (APP.user && APP.user.isAdmin) return true;
    console.warn('⛔ محاولة استخدام نظام موافقة التغذية بدون صلاحية أدمن');
    if (showMsg !== false) tuaToast('🚫 هذه الميزة متاحة للأدمن فقط', 'error');
    return false;
}

const TuaStore = {
    requests: [],       // topup_requests/*
    inbox: [],           // sms_inbox/* (رسائل واردة)
    processedLog: [],    // topup_processed_log/* (سجل المطابقات المؤكدة)
    _attached: false,

    load() {
        if (this._attached) return;
        this._attached = true;

        database.ref('topup_requests').on('value', snap => {
            const val = snap.val() || {};
            this.requests = Object.keys(val).map(id => ({ id, ...val[id] }))
                .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            tuaRenderList();
            tuaAutoMatchPending();
        }, err => console.error('❌ فشل تحميل طلبات التغذية:', err));

        database.ref('sms_inbox').on('value', snap => {
            const val = snap.val() || {};
            this.inbox = Object.keys(val).map(id => ({ id, ...val[id] }))
                .sort((a, b) => (b.receivedAt || 0) - (a.receivedAt || 0));
            tuaRenderInbox();
            tuaAutoMatchPending();
        }, err => console.error('❌ فشل تحميل صندوق الرسائل الواردة:', err));

        database.ref('topup_processed_log').limitToLast(200).on('value', snap => {
            const val = snap.val() || {};
            this.processedLog = Object.keys(val).map(id => ({ id, ...val[id] }))
                .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
            tuaRenderProcessedLog();
        }, err => console.error('❌ فشل تحميل سجل المطابقات:', err));
    }
};

let tuaFilter = 'pending';
let tuaBusyIds = {}; // منع الضغط المزدوج على "قبول/رفض" لنفس الطلب

function tuaToast(message, type) {
    type = type || 'success';
    const colors = { success: '#3b82f6', error: '#ef4444', warn: '#f59e0b', info: '#94a3b8' };
    const toast = document.createElement('div');
    toast.textContent = message;
    Object.assign(toast.style, {
        position: 'fixed', bottom: '100px', left: '50%', transform: 'translateX(-50%)',
        background: colors[type] || colors.success, color: '#fff',
        padding: '12px 24px', borderRadius: '12px', fontSize: '13px', fontWeight: '700',
        fontFamily: 'Cairo, sans-serif', zIndex: '9999', boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
        maxWidth: '85%', textAlign: 'center', whiteSpace: 'pre-line', opacity: '0', transition: 'opacity .3s'
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.style.opacity = '1');
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3000);
}

/* ============================================================
   التنقل الداخلي
============================================================ */
function tuaGoTo(view) {
    document.querySelectorAll('#topupApprovalInterface .tua-subpage').forEach(el => el.classList.remove('active'));
    const target = document.getElementById('tuaSub-' + view);
    if (target) target.classList.add('active');
    const titles = { list: 'موافقة طلبات التغذية', inbox: 'الرسائل الواردة', log: 'سجل المطابقات المؤكدة' };
    const titleEl = document.getElementById('tuaPageTitle');
    if (titleEl) titleEl.textContent = titles[view] || 'موافقة طلبات التغذية';
    if (view === 'inbox') tuaRenderInbox();
    if (view === 'log') tuaRenderProcessedLog();

    document.querySelectorAll('#topupApprovalInterface .tua-bottom-nav .nav-btn').forEach(b => b.classList.remove('active'));
    const navMap = { list: 0, inbox: 1, log: 2 };
    if (view in navMap) document.querySelectorAll('#topupApprovalInterface .tua-bottom-nav .nav-btn')[navMap[view]]?.classList.add('active');

    const content = document.querySelector('#topupApprovalInterface .page-content');
    if (content) content.scrollTop = 0;
}

function tuaSetFilter(btn) {
    document.querySelectorAll('#topupApprovalInterface .tua-filter-chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    tuaFilter = btn.dataset.filter;
    tuaRenderList();
}

/* ============================================================
   أدوات مطابقة الأسماء والمبالغ وتحليل نص رسالة الإيداع
============================================================ */

// تطبيع الاسم العربي: إزالة التشكيل، توحيد أشكال الألف والهمزات، إزالة المسافات الزائدة
function tuaNormalizeArabicName(str) {
    if (!str) return '';
    return String(str)
        .replace(/[\u064B-\u0652\u0670\u0640]/g, '')           // تشكيل + تطويل
        .replace(/[إأآا]/g, 'ا')
        .replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه')
        .replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
}

// يأخذ أول كلمتين فقط (الاسم الأول + الاسم الثاني) حسب طلب المستخدم
function tuaFirstTwoTokens(name) {
    const parts = tuaNormalizeArabicName(name).split(' ').filter(Boolean);
    return parts.slice(0, 2).join(' ');
}

function tuaNamesMatch(appFullName, smsName) {
    const a = tuaFirstTwoTokens(appFullName);
    const b = tuaFirstTwoTokens(smsName);
    if (!a || !b) return false;
    return a === b;
}

// تحويل مبلغ نصي (يحتمل فواصل الآلاف) إلى رقم
function tuaParseAmount(raw) {
    if (!raw) return null;
    const n = parseFloat(String(raw).replace(/,/g, '').trim());
    return isNaN(n) ? null : n;
}

// تحليل نص رسالة إيداع الكريمي (وصيغ مشابهة):
// "أودع/عباس فهيم لحسابك7,000.00 YERرصيدك8,170.53YER"
// يُرجع {name, amount, balanceAfter, isCredit, refNumber}
function tuaParseDepositSms(body) {
    if (!body) return null;
    const text = String(body).trim();

    // اسم المودع: بعد "أودع/" وقبل "لحسابك"
    const nameMatch = text.match(/أودع\s*\/\s*(.+?)\s*لحسابك/);
    // المبلغ: بعد "لحسابك" وقبل أول "YER"
    const amountMatch = text.match(/لحسابك\s*([\d,.\s]+?)\s*YER/i);
    // الرصيد بعد العملية: بعد "رصيدك" وقبل "YER" الثانية
    const balanceMatch = text.match(/رصيدك\s*([\d,.\s]+?)\s*YER/i);
    // رقم مرجع اختياري إن وُجد بصيغة "المرجع:" أو "Ref:" (قد لا يكون موجوداً في كل الصيغ)
    const refMatch = text.match(/(?:المرجع|رقم المرجع|Ref(?:erence)?)\s*[:\-]?\s*([A-Za-z0-9]+)/i);

    const isCredit = /أودع|رصيدك/.test(text); // يؤكد أنها رسالة "زيادة رصيد" وليست سحب/خصم

    if (!nameMatch || !amountMatch) return null;

    return {
        name: nameMatch[1].trim(),
        amount: tuaParseAmount(amountMatch[1]),
        balanceAfter: balanceMatch ? tuaParseAmount(balanceMatch[1]) : null,
        refNumber: refMatch ? refMatch[1].trim() : null,
        isCredit,
        rawText: text
    };
}

/* ============================================================
   محرك التحقق — 4 نقاط تحقق حسب المطلوب
============================================================ */

// يبحث عن أفضل رسالة غير مُستهلكة تطابق طلباً معيناً
function tuaFindCandidateSms(request) {
    const wallet = (typeof WltStore !== 'undefined') ? WltStore.getWallet(request.walletId) : null;
    const senderId = (wallet && wallet.senderId) || request.senderId || '';
    const windowMs = 72 * 60 * 60 * 1000; // نافذة ٧٢ ساعة حول وقت تقديم الطلب

    let best = null;
    for (const sms of TuaStore.inbox) {
        if (sms.consumed) continue;
        if (!senderId || (sms.sender || '').trim().toLowerCase() !== senderId.trim().toLowerCase()) continue;
        if (Math.abs((sms.receivedAt || 0) - (request.createdAt || 0)) > windowMs) continue;

        const parsed = sms.parsed || tuaParseDepositSms(sms.body);
        if (!parsed || !parsed.isCredit) continue;
        if (parsed.amount === null || Math.abs(parsed.amount - $n(request.amount)) > 0.01) continue;
        if (!tuaNamesMatch(request.fullName, parsed.name)) continue;

        // الأقرب زمنياً لوقت تقديم الطلب هو المرشّح الأفضل
        if (!best || Math.abs((sms.receivedAt || 0) - (request.createdAt || 0)) < Math.abs((best.receivedAt || 0) - (request.createdAt || 0))) {
            best = sms;
        }
    }
    return best;
}

// يبني قائمة الشروط الأربعة مع حالتها (نجاح/فشل) لعرضها وللتنفيذ
function tuaVerifyRequest(request) {
    const wallet = (typeof WltStore !== 'undefined') ? WltStore.getWallet(request.walletId) : null;
    const senderId = (wallet && wallet.senderId) || request.senderId || '';
    const sms = tuaFindCandidateSms(request);
    const parsed = sms ? (sms.parsed || tuaParseDepositSms(sms.body)) : null;

    const checks = [
        {
            key: 'sender',
            label: `معرف المرسل يطابق المحفظة (${senderId || '—'})`,
            pass: !!sms && !!senderId && (sms.sender || '').trim().toLowerCase() === senderId.trim().toLowerCase()
        },
        {
            key: 'name',
            label: 'اسم المستخدم في كوفانت يطابق الاسم في الرسالة (أول + ثاني)',
            pass: !!parsed && tuaNamesMatch(request.fullName, parsed.name)
        },
        {
            key: 'amount',
            label: `المبلغ في الرسالة يطابق المبلغ المُدخل (${$fmt(request.amount)} YER)`,
            pass: !!parsed && parsed.amount !== null && Math.abs(parsed.amount - $n(request.amount)) <= 0.01
        },
        {
            key: 'dedupe',
            label: 'الرسالة غير مستخدمة من قبل ولم تُعالج مسبقاً (منع التكرار)',
            pass: !!sms && !sms.consumed
        }
    ];

    return { sms, parsed, checks, allPassed: checks.every(c => c.pass) };
}

function tuaAutoMatchPending() {
    if (!TuaStore.requests.length || !TuaStore.inbox.length) return;
    const autoOn = (typeof SmsStore !== 'undefined') && SmsStore.data && SmsStore.data.settings && SmsStore.data.settings.autoProcess !== false;
    if (!autoOn) return;

    TuaStore.requests
        .filter(r => r.status === 'pending' && !tuaBusyIds[r.id])
        .forEach(r => {
            const v = tuaVerifyRequest(r);
            if (v.allPassed) {
                tuaApproveRequest(r.id, { auto: true });
            }
        });
}

/* ============================================================
   تنفيذ القبول / الرفض
============================================================ */
async function tuaApproveRequest(requestId, opts) {
    if (!tuaRequireAdmin()) return;
    opts = opts || {};
    if (tuaBusyIds[requestId]) return;

    // بصمة تأكيد العملية — فقط للقبول اليدوي (ليس التحقق التلقائي)
    if (!opts.auto && typeof requireFingerprintConfirmIfEnabled === 'function') {
        const okFp = await requireFingerprintConfirmIfEnabled();
        if (!okFp) return;
    }

    tuaBusyIds[requestId] = true;

    try {
        const request = TuaStore.requests.find(r => r.id === requestId);
        if (!request) throw new Error('الطلب غير موجود');
        if (request.status !== 'pending') throw new Error('تمت معالجة هذا الطلب مسبقاً');

        const verification = tuaVerifyRequest(request);
        if (!opts.force && !verification.allPassed) {
            throw new Error('لم تكتمل كل شروط التحقق بعد — راجع القائمة أو استخدم "قبول يدوي"');
        }

        const wallet = (typeof WltStore !== 'undefined') ? WltStore.getWallet(request.walletId) : null;
        const sms = verification.sms;

        await waitForFirebaseAuth();

        // 1) قفل الرسالة المستخدمة أولاً (transaction) لمنع استخدامها في طلب آخر بنفس اللحظة
        if (sms) {
            const smsRef = database.ref('sms_inbox/' + sms.id);
            const txResult = await smsRef.transaction(cur => {
                if (!cur) return cur;
                if (cur.consumed) return; // إلغاء — مُستخدمة بالفعل
                cur.consumed = true;
                cur.consumedByRequestId = requestId;
                cur.consumedAt = Date.now();
                return cur;
            });
            if (!txResult.committed) {
                throw new Error('هذه الرسالة استُخدمت للتو من طلب آخر — أعد المحاولة');
            }
        }

        // 2) إضافة المبلغ لرصيد المستخدم + تسجيله في كشف حسابه
        const newBalance = await updateUserBalance(
            request.phone,
            request.amount,
            'in',
            `تغذية رصيد - ${request.walletName || (wallet && wallet.name) || ''}`,
            `تغذية عبر ${request.walletName || ''} - مرجع: ${request.reference || '—'}`,
            {
                reference: request.reference || null,
                walletId: request.walletId || null,
                walletName: request.walletName || null,
                topupRequestId: requestId,
                matchedSmsId: sms ? sms.id : null
            }
        );

        // 3) خصم القيمة من الخزينة (تمويل رصيد المستخدم من الخزينة)
        await logTreasuryTransaction(
            'deposit',
            -Math.abs($n(request.amount)),
            `تغذية رصيد المستخدم ${request.fullName || request.phone} عبر ${request.walletName || ''} - مرجع: ${request.reference || '—'}`,
            request.fullName || null,
            request.reference || null
        );

        // 4) تحديث حالة الطلب
        await database.ref('topup_requests/' + requestId).update({
            status: 'approved',
            reviewedAt: Date.now(),
            reviewedBy: (opts.auto ? 'نظام (تحقق تلقائي)' : ((APP.user && (APP.user.fullName || APP.user.phone)) || 'أدمن')),
            matchedSmsId: sms ? sms.id : null,
            verifyChecks: verification.checks.map(c => ({ key: c.key, pass: c.pass })),
            manualOverride: !!opts.force,
            balanceAfter: newBalance
        });

        // 5) تسجيل القيد في "إدارة الرسائل" بالصيغة المطلوبة:
        //    اسم المستخدم (أول+ثاني) + رقم حساب كوفانت + رقم حساب الكريمي (المستفيد) + المبلغ + رقم المرجع + وقت العملية
        await database.ref('topup_processed_log').push().set({
            appUserFirstSecondName: tuaFirstTwoTokens(request.fullName) ? tuaDisplayFirstTwo(request.fullName) : (request.fullName || ''),
            kawanetAccountNumber: request.userAccountNumber || (request.phone || ''),
            beneficiaryBankAccount: (wallet && wallet.beneficiaryAccount) || '',
            walletName: request.walletName || (wallet && wallet.name) || '',
            amount: $n(request.amount),
            reference: request.reference || '',
            operationTime: Date.now(),
            operationTimeStr: new Date().toLocaleString('ar-YE'),
            requestId: requestId,
            matchedSmsId: sms ? sms.id : null,
            auto: !!opts.auto
        });

        // 6) إشعار المستخدم (اختياري — يعتمد على وجود توكن)
        const depositNotifOn = (typeof isAdminNotificationEnabled === 'function') ? isAdminNotificationEnabled('deposits') : true;
        if (depositNotifOn && typeof sendViaMyServer === 'function') {
            sendViaMyServer(request.phone, 'تم تغذية رصيدك ✅',
                `تمت إضافة ${$fmt(request.amount)} YER إلى رصيدك عبر ${request.walletName || ''}`);
        }

        if (typeof playSystemSuccessSound === 'function') playSystemSuccessSound();
        tuaToast(`✅ تمت الموافقة وإضافة ${$fmt(request.amount)} YER لرصيد ${request.fullName || request.phone}`, 'success');
    } catch (e) {
        console.error('❌ فشل قبول طلب التغذية:', e);
        tuaToast('❌ ' + (e.message || 'حدث خطأ أثناء المعالجة'), 'error');
    } finally {
        delete tuaBusyIds[requestId];
    }
}

async function tuaRejectRequest(requestId) {
    if (!tuaRequireAdmin()) return;
    if (tuaBusyIds[requestId]) return;
    const reason = prompt('سبب الرفض (سيظهر للمستخدم إن أمكن):', 'لم يتم العثور على رسالة إيداع مطابقة');
    if (reason === null) return;

    tuaBusyIds[requestId] = true;
    try {
        await waitForFirebaseAuth();
        await database.ref('topup_requests/' + requestId).update({
            status: 'rejected',
            reviewedAt: Date.now(),
            reviewedBy: (APP.user && (APP.user.fullName || APP.user.phone)) || 'أدمن',
            rejectReason: reason || ''
        });
        tuaToast('⭕ تم رفض الطلب', 'warn');
    } catch (e) {
        console.error('❌ فشل رفض الطلب:', e);
        tuaToast('❌ فشل رفض الطلب', 'error');
    } finally {
        delete tuaBusyIds[requestId];
    }
}

// قبول يدوي (تجاوز) — لحالات نادرة يقتنع فيها الأدمن رغم عدم اكتمال كل الشروط تلقائياً
function tuaManualApprove(requestId) {
    if (!tuaRequireAdmin()) return;
    if (!confirm('⚠️ سيتم قبول الطلب وإضافة الرصيد رغم عدم اكتمال كل شروط التحقق تلقائياً. هل أنت متأكد؟')) return;
    tuaApproveRequest(requestId, { force: true });
}

/* ============================================================
   استقبال رسالة SMS جديدة (تُستدعى من قارئ SMS الفعلي على الجهاز
   لاحقاً عبر إضافة Capacitor Plugin، أو يدوياً من الأدمن الآن)
============================================================ */
async function tuaReceiveIncomingSms(sender, body, deviceId) {
    if (!tuaRequireAdmin(false)) return; // صامت: قد يُستدعى تلقائياً من قارئ SMS، لا داعي لإزعاج المستخدم برسالة
    if (!sender || !body) return;
    await waitForFirebaseAuth();
    const parsed = tuaParseDepositSms(body);
    const ref = database.ref('sms_inbox').push();
    await ref.set({
        sender: String(sender).trim(),
        body: String(body).trim(),
        deviceId: deviceId || (typeof SmsStore !== 'undefined' ? SmsStore.data.deviceId : null) || null,
        receivedAt: Date.now(),
        receivedAtStr: new Date().toLocaleString('ar-YE'),
        consumed: false,
        parsed: parsed || null
    });
    return ref.key;
}

function tuaAddIncomingManually() {
    if (!tuaRequireAdmin()) return;
    const sender = prompt('معرف المرسل (Sender ID):', 'KuraimiIMB');
    if (!sender) return;
    const body = prompt('نص الرسالة الكامل:', 'أودع/عباس فهيم لحسابك7,000.00 YERرصيدك8,170.53YER');
    if (!body) return;
    tuaReceiveIncomingSms(sender, body).then(() => {
        tuaToast('✅ تمت إضافة الرسالة — جارٍ التحقق التلقائي...', 'success');
    }).catch(e => {
        console.error(e);
        tuaToast('❌ فشل إضافة الرسالة', 'error');
    });
}

/* ============================================================
   عرض الاسم (أول + ثاني فقط) بشكل أصلي غير مُطبَّع للعرض
============================================================ */
function tuaDisplayFirstTwo(fullName) {
    if (!fullName) return '';
    const parts = String(fullName).trim().split(/\s+/).filter(Boolean);
    return parts.slice(0, 2).join(' ');
}

/* ============================================================
   العرض — قائمة الطلبات
============================================================ */
function tuaRenderList() {
    const list = document.getElementById('tua-list');
    if (!list) return;

    let items = [...TuaStore.requests];
    if (tuaFilter !== 'all') items = items.filter(r => (r.status || 'pending') === tuaFilter);

    const pendingCount = TuaStore.requests.filter(r => (r.status || 'pending') === 'pending').length;
    const approvedCount = TuaStore.requests.filter(r => r.status === 'approved').length;
    const rejectedCount = TuaStore.requests.filter(r => r.status === 'rejected').length;
    const pc = document.getElementById('tuaPendingCount'); if (pc) pc.textContent = pendingCount;
    const ac = document.getElementById('tuaApprovedCount'); if (ac) ac.textContent = approvedCount;
    const rc = document.getElementById('tuaRejectedCount'); if (rc) rc.textContent = rejectedCount;

    if (items.length === 0) {
        list.innerHTML = `<div class="empty-state"><i class="fa-solid fa-inbox"></i><p>لا توجد طلبات</p></div>`;
        return;
    }

    list.innerHTML = items.map(r => tuaRenderCard(r)).join('');
}

function tuaRenderCard(r) {
    const status = r.status || 'pending';
    const statusMeta = {
        pending: { text: 'قيد المراجعة', cls: 'tua-pending', icon: 'fa-clock' },
        approved: { text: 'مقبول', cls: 'tua-approved', icon: 'fa-circle-check' },
        rejected: { text: 'مرفوض', cls: 'tua-rejected', icon: 'fa-circle-xmark' }
    }[status];

    let checksHtml = '';
    let allPassed = false;
    if (status === 'pending') {
        const v = tuaVerifyRequest(r);
        allPassed = v.allPassed;
        checksHtml = `<div class="tua-checks">` + v.checks.map(c => `
            <div class="tua-check-row ${c.pass ? 'ok' : 'fail'}">
                <i class="fa-solid ${c.pass ? 'fa-circle-check' : 'fa-circle-xmark'}"></i>
                <span>${esc(c.label)}</span>
            </div>`).join('') + `</div>`;
    } else if (Array.isArray(r.verifyChecks)) {
        checksHtml = `<div class="tua-checks">` + r.verifyChecks.map(c => `
            <div class="tua-check-row ${c.pass ? 'ok' : 'fail'}">
                <i class="fa-solid ${c.pass ? 'fa-circle-check' : 'fa-circle-xmark'}"></i>
                <span>${esc(c.key)}</span>
            </div>`).join('') + `</div>`;
    }

    return `
        <div class="tua-card ${statusMeta.cls}">
            <div class="tua-card-top">
                <div class="tua-card-user">
                    <div class="tua-card-name">${esc(r.fullName || '—')}</div>
                    <div class="tua-card-phone"><i class="fa-solid fa-phone"></i> ${esc(r.phone || '—')}</div>
                </div>
                <div class="tua-status-badge ${statusMeta.cls}"><i class="fa-solid ${statusMeta.icon}"></i> ${statusMeta.text}</div>
            </div>

            <div class="tua-card-meta">
                <div class="tua-meta-item"><span class="tua-meta-label">المحفظة</span><span class="tua-meta-value">${esc(r.walletName || '—')}</span></div>
                <div class="tua-meta-item"><span class="tua-meta-label">المبلغ</span><span class="tua-meta-value">${$fmt(r.amount)} YER</span></div>
                <div class="tua-meta-item"><span class="tua-meta-label">رقم المرجع</span><span class="tua-meta-value">${esc(r.reference || '—')}</span></div>
                <div class="tua-meta-item"><span class="tua-meta-label">رقم الحساب في كوفانت</span><span class="tua-meta-value">${esc(r.userAccountNumber || '—')}</span></div>
                <div class="tua-meta-item"><span class="tua-meta-label">وقت الطلب</span><span class="tua-meta-value">${esc(r.dateStr || (r.createdAt ? new Date(r.createdAt).toLocaleString('ar-YE') : '—'))}</span></div>
            </div>

            ${checksHtml}

            ${status === 'pending' ? `
                <div class="tua-card-actions">
                    <button class="tua-btn tua-btn-approve" ${allPassed ? '' : 'disabled'} onclick="tuaApproveRequest('${r.id}')"><i class="fa-solid fa-check"></i> قبول</button>
                    ${!allPassed ? `<button class="tua-btn tua-btn-manual" onclick="tuaManualApprove('${r.id}')"><i class="fa-solid fa-triangle-exclamation"></i> قبول يدوي</button>` : ''}
                    <button class="tua-btn tua-btn-reject" onclick="tuaRejectRequest('${r.id}')"><i class="fa-solid fa-xmark"></i> رفض</button>
                </div>` : (status === 'rejected' && r.rejectReason ? `<div class="tua-reject-reason"><i class="fa-solid fa-circle-info"></i> ${esc(r.rejectReason)}</div>` : '')}
        </div>`;
}

/* ============================================================
   العرض — صندوق الرسائل الواردة
============================================================ */
function tuaRenderInbox() {
    const list = document.getElementById('tua-inbox-list');
    if (!list) return;

    if (TuaStore.inbox.length === 0) {
        list.innerHTML = `<div class="empty-state"><i class="fa-solid fa-comment-slash"></i><p>لا توجد رسائل واردة بعد</p></div>`;
        return;
    }

    list.innerHTML = TuaStore.inbox.map(sms => {
        const parsed = sms.parsed || tuaParseDepositSms(sms.body);
        const dt = new Date(sms.receivedAt || 0);
        return `
            <div class="tua-sms-item ${sms.consumed ? 'consumed' : ''}">
                <div class="tua-sms-top">
                    <span class="tua-sms-sender"><i class="fa-solid fa-tower-broadcast"></i> ${esc(sms.sender || '—')}</span>
                    <span class="tua-sms-time">${dt.toLocaleString('ar-YE')}</span>
                </div>
                <div class="tua-sms-body">${esc(sms.body || '—')}</div>
                ${parsed ? `<div class="tua-sms-parsed">
                    <span>👤 ${esc(parsed.name || '—')}</span>
                    <span>💰 ${parsed.amount !== null ? $fmt(parsed.amount) : '—'} YER</span>
                    ${parsed.balanceAfter !== null ? `<span>🏦 ${$fmt(parsed.balanceAfter)} YER</span>` : ''}
                </div>` : `<div class="tua-sms-parsed tua-sms-unparsed">⚠️ تعذّر تحليل نص الرسالة تلقائياً</div>`}
                <div class="tua-sms-footer">${sms.consumed ? `<span class="tua-used"><i class="fa-solid fa-link"></i> مستخدمة لطلب سابق</span>` : `<span class="tua-free"><i class="fa-solid fa-circle-check"></i> متاحة للمطابقة</span>`}</div>
            </div>`;
    }).join('');
}

/* ============================================================
   العرض — سجل المطابقات المؤكدة (لإدارة الرسائل)
============================================================ */
function tuaRenderProcessedLog() {
    const list = document.getElementById('tua-log-list');
    if (!list) return;

    if (TuaStore.processedLog.length === 0) {
        list.innerHTML = `<div class="empty-state"><i class="fa-solid fa-clock-rotate-left"></i><p>لا توجد عمليات مؤكدة بعد</p></div>`;
        return;
    }

    list.innerHTML = TuaStore.processedLog.map(l => `
        <div class="tua-log-item">
            <div class="tua-log-row"><span class="tua-log-label">الاسم</span><span class="tua-log-value">${esc(l.appUserFirstSecondName || '—')}</span></div>
            <div class="tua-log-row"><span class="tua-log-label">رقم الحساب (كوفانت)</span><span class="tua-log-value">${esc(l.kawanetAccountNumber || '—')}</span></div>
            <div class="tua-log-row"><span class="tua-log-label">حساب الاستلام (${esc(l.walletName || '')})</span><span class="tua-log-value">${esc(l.beneficiaryBankAccount || '—')}</span></div>
            <div class="tua-log-row"><span class="tua-log-label">المبلغ</span><span class="tua-log-value">${$fmt(l.amount)} YER</span></div>
            <div class="tua-log-row"><span class="tua-log-label">رقم المرجع</span><span class="tua-log-value">${esc(l.reference || '—')}</span></div>
            <div class="tua-log-row"><span class="tua-log-label">وقت العملية</span><span class="tua-log-value">${esc(l.operationTimeStr || (l.operationTime ? new Date(l.operationTime).toLocaleString('ar-YE') : '—'))}</span></div>
        </div>`).join('');
}

/* ============================================================
   نقطة الدخول — تُستدعى من navigateTo() في router.js
============================================================ */
function loadTopupApprovalAdmin() {
    if (!tuaRequireAdmin()) {
        navigateTo('dashboardInterface', true);
        return;
    }
    if (typeof WltStore !== 'undefined') WltStore.load();
    TuaStore.load();
    tuaGoTo('list');
}
