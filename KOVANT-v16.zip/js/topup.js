// ============================================================
// تغذية الحساب (Topup) — منطق واجهة #topupInterface
// كل الدوال هنا مسبوقة بـ topup لتفادي أي تعارض مع بقية التطبيق
//
// ملاحظة مهمة: هذه الواجهة أصبحت متصلة بالكامل بالمحافظ الحقيقية
// المُدارة من "إدارة المحافظ البنكية" (js/wallets-logic.js / WltStore)
// وتُخزَّن طلبات التغذية في قاعدة بيانات Firebase تحت topup_requests/
// ============================================================
let topupSelectedWalletId = null;

function topupShowSubPage(id) {
    document.querySelectorAll('#topupInterface .tu-page').forEach(p => p.classList.remove('tu-active'));
    const target = document.getElementById(id);
    if (target) target.classList.add('tu-active');
    const iface = document.getElementById('topupInterface');
    if (iface) iface.scrollTop = 0;
}

// تُستدعى من زر "غذي حسابي" في الصفحة الرئيسية للمستخدم
function topupOpen() {
    navigateTo('topupInterface', true);
    topupRenderBankList();
    topupShowSubPage('tu-topup-page');
}

// عرض قائمة البنوك/المحافظ المفعّلة فقط — مصدرها WltStore (قاعدة البيانات)
function topupRenderBankList() {
    const container = document.getElementById('tu-bank-list');
    if (!container) return;

    const wallets = (WltStore.data.wallets || []).filter(w => w.active);

    if (wallets.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;color:var(--text-secondary);padding:50px 15px;">
                <i class="fa-solid fa-building-columns" style="font-size:2.2rem;margin-bottom:12px;display:block;opacity:.5;"></i>
                لا توجد بنوك متاحة للتغذية حالياً
            </div>`;
        return;
    }

    container.innerHTML = wallets.map(w => `
        <div class="tu-topup-card" onclick="topupStartWizard('${w.id}')">
            <div class="tu-topup-card-icon">
                ${w.logo ? `<img src="${esc(w.logo)}" alt="${esc(w.name || '')}" onerror="this.style.display='none';">` : `<i class="fa-solid fa-building-columns"></i>`}
            </div>
            <div class="tu-topup-card-text">
                <div class="tu-topup-card-title">${esc(w.formTitle || w.name || '')}</div>
                <div class="tu-topup-card-desc">${esc(w.cardDesc || 'اتبع الخطوات المطلوبة خطوة بخطوة.')}</div>
            </div>
        </div>`).join('');
}

// بدء معالج التغذية لمحفظة محددة
function topupStartWizard(walletId) {
    const wallet = WltStore.getWallet(walletId);
    if (!wallet) { showAlert('تعذر تحميل بيانات هذه المحفظة، حاول مرة أخرى', false); return; }
    topupSelectedWalletId = walletId;

    // خطوات التغذية الخاصة بهذه المحفظة
    const stepsContainer = document.getElementById('tu-steps-container');
    if (stepsContainer) {
        const steps = wallet.steps || [];
        stepsContainer.innerHTML = steps.length
            ? steps.map((s, i) => `
                <div class="tu-step-item">
                    <div class="tu-step-num">${i + 1}</div>
                    <div class="tu-step-text">${esc(s)}</div>
                </div>`).join('')
            : `<div class="tu-step-text" style="text-align:center;padding:10px;">لا توجد خطوات مضافة لهذه المحفظة</div>`;
    }

    // الشروط والأحكام مع بيانات المستفيد الحقيقية لهذه المحفظة
    const termsList = document.getElementById('tu-terms-list');
    if (termsList) {
        termsList.innerHTML = `
            <li>تأكد من أن اسمك في تطبيق كوفانت مطابق تماماً للاسم المسجل لدى ${esc(wallet.name || 'الجهة')}.</li>
            <li>تأكد من أن رقم حساب المستلم: <strong>${esc(wallet.beneficiaryAccount || '—')}</strong> يعود للمستفيد <strong>${esc(wallet.beneficiaryName || '—')}</strong>.</li>
            <li>${esc((wallet.fields && wallet.fields.hint) || 'انسخ رقم المرجع من بيانات العملية بعد تنفيذ الإيداع.')}</li>
            <li>أي بيانات خاطئة أو تكرار خاطئ سيؤدي إلى حظر الخدمة، ولديك <strong>3 محاولات فقط</strong>.</li>
            <li>إخلاء المسؤولية: نحن غير مسؤولين عن أي أخطاء ناتجة عن إدخال بيانات خاطئة، والمستخدم يتحمل كامل المسؤولية.</li>`;
    }

    const check = document.getElementById('tu-agreeCheck');
    const btn = document.getElementById('tu-step2NextBtn');
    if (check) check.checked = false;
    if (btn) btn.disabled = true;

    topupShowSubPage('tu-wizard-step1');
}

function topupGoToStep2() { topupShowSubPage('tu-wizard-step2'); }

function topupGoToStep3() {
    const input = document.getElementById('tu-yreInput');
    if (input) input.value = (APP.user && APP.user.accountNumber) ? APP.user.accountNumber : '';
    topupShowSubPage('tu-wizard-step3');
}

function topupBackToMain() { topupShowSubPage('tu-topup-page'); }
function topupBackToStep1() { topupShowSubPage('tu-wizard-step1'); }
function topupBackToStep2() { topupShowSubPage('tu-wizard-step2'); }

function topupToggleStep2Btn() {
    const check = document.getElementById('tu-agreeCheck');
    const btn = document.getElementById('tu-step2NextBtn');
    if (btn) btn.disabled = !check.checked;
}

// تجهيز نموذج الإيداع النهائي حسب حقول المحفظة المخصّصة من الأدمن
function topupFinishWizard() {
    const yreInput = document.getElementById('tu-yreInput');
    const yre = yreInput ? yreInput.value.trim() : '';

    if (!yre) {
        showAlert('الرجاء إدخال رقم الحساب!', false);
        return;
    }

    const wallet = WltStore.getWallet(topupSelectedWalletId);
    if (!wallet) { showAlert('تعذر تحميل بيانات هذه المحفظة', false); return; }

    const logoImg = document.getElementById('tu-form-logo-img');
    const iconFallback = document.getElementById('tu-form-icon-fallback');
    if (wallet.logo) {
        logoImg.src = wallet.logo;
        logoImg.style.display = 'block';
        iconFallback.style.display = 'none';
    } else {
        logoImg.style.display = 'none';
        iconFallback.style.display = 'flex';
    }

    document.getElementById('tu-form-title-text').textContent = wallet.formTitle || `غذي حسابك عبر ${wallet.name || ''}`;
    document.getElementById('tu-form-header').style.background = wallet.color
        ? `linear-gradient(135deg, ${wallet.color}33, #0d1231)`
        : 'linear-gradient(135deg,#0d1231,#1a237e)';

    const amountInput = document.getElementById('tu-amountInput');
    const refInput = document.getElementById('tu-refInput');
    amountInput.value = '';
    refInput.value = '';
    amountInput.placeholder = (wallet.fields && wallet.fields.amountLabel) || 'المبلغ';
    refInput.placeholder = (wallet.fields && wallet.fields.refLabel) || 'رقم المرجع';

    const hintWrap = document.getElementById('tu-hint-wrap');
    const hintText = document.getElementById('tu-hintText');
    const hint = wallet.fields && wallet.fields.hint;
    if (hint) { hintText.textContent = hint; hintWrap.style.display = 'flex'; }
    else { hintWrap.style.display = 'none'; }

    const submitBtn = document.getElementById('tu-submitBtn');
    submitBtn.textContent = (wallet.fields && wallet.fields.submitLabel) || 'تأكيد';
    submitBtn.style.background = wallet.color
        ? `linear-gradient(135deg, ${wallet.color}, #0f5a8e)`
        : 'linear-gradient(135deg,var(--blue),#1a6fa8)';

    topupShowSubPage('tu-wallet-form-page');
}

// إرسال طلب التغذية — يُخزَّن فعلياً في قاعدة بيانات Firebase
async function topupSubmitRequest() {
    const wallet = WltStore.getWallet(topupSelectedWalletId);
    if (!wallet) { showAlert('تعذر تحميل بيانات هذه المحفظة', false); return; }

    const amountRaw = document.getElementById('tu-amountInput').value.trim();
    const reference = document.getElementById('tu-refInput').value.trim();
    const accountInput = document.getElementById('tu-yreInput') ? document.getElementById('tu-yreInput').value.trim() : '';
    const amount = $n(amountRaw);

    if (!amountRaw || amount <= 0) {
        showAlert(`الرجاء إدخال ${(wallet.fields && wallet.fields.amountLabel) || 'المبلغ'} بشكل صحيح`, false);
        return;
    }
    if (!reference) {
        showAlert(`الرجاء إدخال ${(wallet.fields && wallet.fields.refLabel) || 'رقم المرجع'}`, false);
        return;
    }

    if (!navigator.onLine) {
        if (!window.SMSCommand || typeof window.SMSCommand.sendTopupSMS !== 'function') {
            showAlert('خدمة SMS غير متاحة على هذا الجهاز', false);
            return;
        }
        try {
            await window.SMSCommand.sendTopupSMS((APP.user && APP.user.phone) || '', amount, reference);
            showAlert('✅ تم إرسال طلب التغذية عبر SMS — سيُنفَّذ بعد التحقق', true);
            topupBackToMain();
        } catch (error) {
            console.error('❌ فشل إرسال طلب التغذية عبر SMS:', error);
            showAlert(error.message || 'فشل إرسال طلب التغذية عبر SMS', false);
        }
        return;
    }

    const submitBtn = document.getElementById('tu-submitBtn');
    const originalLabel = submitBtn ? submitBtn.textContent : '';
    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'جاري الإرسال...'; }

    try {
        await waitForFirebaseAuth();
        const ref = database.ref('topup_requests').push();
        await ref.set({
            phone: (APP.user && APP.user.phone) || null,
            fullName: (APP.user && APP.user.fullName) || null,
            userAccountNumber: (APP.user && APP.user.accountNumber) || accountInput || null,
            walletId: wallet.id,
            walletName: wallet.name || null,
            senderId: wallet.senderId || null,
            amount: amount,
            reference: reference,
            status: 'pending',
            createdAt: Date.now(),
            dateStr: new Date().toLocaleString('ar-YE')
        });

        showAlert('تم إرسال طلب التغذية بنجاح! سيتم مراجعته من قبل الإدارة قريباً.', true);
        topupBackToMain();
    } catch (e) {
        console.error('❌ فشل إرسال طلب التغذية:', e);
        showAlert('حدث خطأ أثناء إرسال الطلب، تحقق من الاتصال وحاول مرة أخرى', false);
    } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = originalLabel; }
    }
}
