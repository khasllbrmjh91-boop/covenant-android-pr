# تحديث البصمة — كوفانت (Kova Cash)

## لماذا هذا التحديث؟

النظام القديم كان فيه ثلاث مشاكل جوهرية:

1. **كلمة المرور كانت تُخزَّن نصًا عاديًا محليًا** (`biometric_password` داخل
   `SecureStorage`) لاستخدامها لاحقًا في إعادة تسجيل الدخول بعد نجاح البصمة.
2. **نظامان متعارضان لنفس الميزة**: `auth.js` كان يستخدم إضافة `TuaBiometric`
   الأصلية، بينما `user-logic.js` كان فيه نظام WebAuthn قديم منفصل يكتب إلى
   `users/{phone}/biometric` في Firebase — وكلاهما كان يستمع لنفس عنصر
   `pdBiometricToggle` في نفس الوقت (مستمعان على حدث `change`)، ما يسبب طلبين
   متزامنين ونافذتي بصمة وحالة toggle غير متّسقة. هذا كان سبب عطل "أزرار
   التفعيل".
3. **تأخير صناعي ~3 ثوانٍ** قبل ظهور مستشعر البصمة عند فتح التطبيق
   (`setTimeout` بقيمتي 1800ms + 1200ms) دون أي سبب تقني حقيقي.

## ما الذي تغيّر؟

| | قبل | بعد |
|---|---|---|
| ما يُخزَّن | رقم الجوال + **كلمة المرور** (نص عادي) | رقم الجوال + **refresh_token** فقط (الموجود أصلاً بعد تسجيل الدخول) |
| مكان التخزين | `EncryptedSharedPreferences` عادي، بلا ربط حقيقي بالبصمة | مفتاح **Android Keystore** مربوط بـ `setUserAuthenticationRequired` + `BiometricPrompt.CryptoObject` — فك التشفير يفشل فعليًا بدون بصمة حقيقية |
| كتابة Firebase | نعم (`users/{phone}/biometric`) من النظام القديم في `user-logic.js` | **لا يوجد أي كتابة جديدة** |
| تسجيل الدخول بعد البصمة | إعادة إرسال `phone + password` إلى `/login` | استخدام `/refresh` الموجودة أصلاً مع `refresh_token` المُستَرجَع |
| ظهور زر البصمة | بعد ~3 ثوانٍ تأخير صناعي | فوري (فحص `hasSecret()` محلي لا يلمس Keystore) |
| النوافذ المنبثقة | نوافذ كاملة الشاشة (`showModalMessage` / `showSuccessModal`) لكل خطوة | تنبيهات خفيفة (toast عبر `showAlert`) — نافذة النظام نفسها (البصمة) هي التأكيد الوحيد |
| عدد الأنظمة | نظامان متعارضان (`auth.js` + WebAuthn في `user-logic.js`) | نظام واحد موحَّد |

## الملفات

- **`native-plugins/android/TuaBiometricPlugin.kt`** — إضافة واحدة تحل محل
  الإضافتين القديمتين معًا (`TuaBiometricPlugin.kt` + `SecureStoragePlugin.kt`
  القديمين). الدوال المتاحة للواجهة (`Capacitor.Plugins.TuaBiometric`):
  - `isAvailable()` — هل يوجد مستشعر بصمة مسجَّل على الجهاز؟
  - `hasSecret()` — فحص محلي فوري: هل توجد جلسة محفوظة؟ (بلا أي واجهة أو تأخير)
  - `saveSecret({ phone, refreshToken, title?, subtitle?, description? })` —
    يطلب بصمة حقيقية عبر `CryptoObject` ثم يشفّر ويخزّن `refreshToken` محليًا.
  - `verifyAndGetSecret({ title?, subtitle?, description? })` — يطلب بصمة
    ويعيد `{ success, phone, refreshToken }` بعد فك تشفير ناجح فعليًا.
  - `clearSecret()` — يمسح المفتاح من Keystore وكل البيانات المحلية.

- **`js/auth.js`** — قسم البصمة بالكامل مُعاد كتابته:
  `enableBiometricAfterLogin`, `disableBiometric`, `handleBiometricLogin`,
  `toggleBiometricFromProfile`, `checkBiometricOnStartup`,
  `syncBiometricToggle`, `syncFingerprintButton`, و`auth.restoreSessionWithRefreshToken`
  الجديدة (تستخدم `/refresh` بدل إعادة إرسال كلمة المرور).

- **`js/user-logic.js`** — حُذف منه بالكامل النظام القديم المكرر
  (WebAuthn + كتابة Firebase): `registerProfileBiometric`,
  `disableProfileBiometric`, `verifyProfileBiometric`,
  `updateBiometricHelperText`, `isBiometricSupported`، والمستمع المكرر على
  `pdBiometricToggle`. أصبح التحكم في الزر عبر `onchange` الموجود في
  `index.html` فقط (يستدعي `toggleBiometricFromProfile()` من `auth.js`).

- **`index.html`** — زر البصمة في شاشة الدخول أصبح له `id="btnFingerprint"`
  ومخفي افتراضيًا (`style="display:none"`)؛ يُظهره `auth.js` فورًا فقط عند
  وجود جلسة بصمة محفوظة فعلاً.

- **`setup-native-plugins.py`** — عُدِّل ليعكس دمج الإضافتين (لم يعد يبحث عن
  `SecureStoragePlugin.kt` أو يسجّله).

## خطوات التركيب (بعد فك ضغط هذا الملف داخل مجلد المشروع)

```bash
cd <مجلد المشروع>          # المجلد الذي يحوي capacitor.config.json
python3 setup-native-plugins.py
npx cap sync android
npx cap open android        # ثم Build من Android Studio، أو ./gradlew assembleDebug
```

السكربت يقوم تلقائيًا بـ:
1. نسخ `TuaBiometricPlugin.kt` (و`TuaSmsSenderPlugin.kt`) إلى
   `android/app/src/main/java/com/kova/cash/plugins/`.
2. تسجيل الإضافة في `MainActivity` قبل `super.onCreate()`.
3. إضافة تبعيتي Gradle المطلوبتين إن لم تكونا موجودتين:
   `androidx.biometric:biometric:1.1.0` و
   `androidx.security:security-crypto:1.1.0-alpha06`.

كل ملف يعدّله السكربت يُنسخ احتياطيًا أولًا بامتداد `.bak`، والسكربت آمن
لإعادة التشغيل (idempotent).

**تحقّق بعد التشغيل:** في console الخاص بالـ WebView تأكد أن
`Capacitor.Plugins.TuaBiometric` كائن حقيقي (وليس `undefined`).

## ملاحظة مهمة عن الترقية من النسخة القديمة

المستخدمون الذين فعّلوا البصمة على النسخة القديمة كانت بياناتهم مخزَّنة تحت
مفاتيح مختلفة (`biometric_password` في `SecureStorage` القديمة). النظام الجديد
لا يقرأ هذه المفاتيح القديمة، فسيحتاج هؤلاء المستخدمون فقط لإعادة تفعيل البصمة
مرة واحدة من الملف الشخصي بعد التحديث (تسجيل دخول عادي بكلمة المرور ثم تفعيل
البصمة من جديد) — لا حاجة لأي إجراء آخر من جهتك.

## عن نقطة `/refresh`

الكود الحالي يفترض أن `/refresh` (نفس النقطة المستخدمة أصلاً في تجديد الجلسة
كل 13 دقيقة) تُعيد على الأقل `{ token, refreshToken }`. إن كانت تُعيد أيضًا
`user` و`isAdmin` و`firebaseToken` (بنفس شكل استجابة `/login`) فسيستفيد
`restoreSessionWithRefreshToken()` منها تلقائيًا لاسترجاع كامل بيانات الحساب
فور نجاح البصمة؛ وإن لم تُعِدها، سيبقى التطبيق يعمل عبر `subscribeToUserData()`
التي تقرأ بيانات المستخدم مباشرة من Firebase بالاعتماد على رقم الجوال.
