module.exports = [
    {
        files: ['server.js'],
        languageOptions: {
            ecmaVersion: 2022,
            sourceType: 'commonjs',
            globals: {
                process: 'readonly', Buffer: 'readonly', console: 'readonly',
                module: 'readonly', require: 'readonly', __dirname: 'readonly'
            }
        },
        rules: {
            'no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],
            'no-undef': 'error',
            semi: ['error', 'always']
        }
    }
];
