# تحويل تطبيق كوفانت إلى تطبيق أصلي عبر Capacitor

تم تعديل الكود بحيث يكتشف تلقائياً إذا كان شغّال جوه تطبيق Capacitor (Android/iOS)
أو جوه متصفح عادي/PWA، ويستخدم نظام الإشعارات المناسب في كل حالة — بدون أي
تعديل في سيرفر الإشعارات الحالي (`kovant-backend3.onrender.com`).

## 1) تثبيت الأدوات

```bash
npm install
npx cap init   # لو عاوز تغيّر appId/appName اللي في capacitor.config.json
npx cap add android
npx cap add ios      # لو محتاج iOS (يتطلب Mac + Xcode)
```

## 2) ربط تطبيق أندرويد بمشروع Firebase الحالي (kova-cash)

✅ تم تسجيل تطبيق Android في مشروع `kova-cash` بالفعل، بباكدج نيم
**`com.kova.cash`** — وحدّثت `capacitor.config.json` عشان الـ `appId` يطابقه
بالظبط (لازم يكونوا متطابقين حرفياً وإلا Firebase مش هيتهيأ صح).

ملف `google-services.json` موجود بالفعل في جذر المشروع هنا. بعد ما تعمل:
```bash
npx cap add android
```
انقل الملف يدوياً إلى:
```
android/app/google-services.json
```
(مجلد `android/` مش موجود دلوقتي لأنه بيتولّد تلقائي من الأمر ده).

لو محتاج iOS كمان: روح [Firebase Console](https://console.firebase.google.com) → `kova-cash`
→ أضف تطبيق iOS بنفس الـ Bundle ID (`com.kova.cash`)، ونزّل
`GoogleService-Info.plist` وحطه في `ios/App/App/` عن طريق Xcode.

## 3) تثبيت مكتبة الإشعارات

```bash
npm i @capacitor-firebase/messaging
npx cap sync
```

اخترنا `@capacitor-firebase/messaging` (مش `@capacitor/push-notifications` الخام)
لأنها بترجع **توكن FCM حقيقي على Android وعلى iOS معاً**. البديل الخام بيرجع
على iOS توكن APNs بس، وده مش هيشتغل مع الباك إند الحالي اللي بيبعت عبر
Firebase Admin `messaging.send()` بتوكن FCM.

## 4) أذونات لازم تضيفها يدوياً

### Android — `android/app/src/main/AndroidManifest.xml`
```xml
<uses-permission android:name="android.permission.CAMERA" /> <!-- ماسح QR -->
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" /> <!-- الموقع -->
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

<!-- مطلوبة لتبويب الواي فاي (js/wifi-module.js + TuaWifiManagerPlugin) -->
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
<uses-feature android:name="android.hardware.wifi" android:required="true" />
```

> ⚠️ **ليه بطاقة "صلاحية الموقع مطلوبة" كانت مش بتشتغل صح:** مسح شبكات
> الواي فاي (قراءة SSID) على أندرويد 8+ يتطلب دايماً `ACCESS_FINE_LOCATION`
> (نفس صلاحية الموقع فوق — مفيش صلاحية منفصلة اسمها "wifi scan")، **بالإضافة**
> إلى تشغيل خدمة الموقع (GPS) على مستوى الجهاز نفسه، مش بس منح الصلاحية.
> الكود في `wifi-module.js` كان بيتوقع `Capacitor.Plugins.TuaWifiManager`،
> لكن الإضافة (plugin) دي مكانتش موجودة أصلاً في المشروع — تمت إضافتها الآن
> في `native-plugins/android/TuaWifiManagerPlugin.kt`. ركّبها بنفس طريقة
> `TuaBiometricPlugin`/`TuaSmsSenderPlugin` بالأسفل، أو ببساطة شغّل
> `python3 setup-native-plugins.py` بعد `npx cap add android` وهيركّبها
> تلقائياً مع الاتنين التانيين.

### iOS — `ios/App/App/Info.plist`
```xml
<key>NSCameraUsageDescription</key>
<string>نحتاج الكاميرا لمسح رمز QR</string>
<key>NSLocationWhenInUseUsageDescription</key>
<string>نحتاج موقعك لعرض أقرب الوكلاء وتغطية الإنترنت</string>
```

## 5) بناء التطبيق ومزامنته مع Capacitor

بما إن `webDir` في `capacitor.config.json` بيشاور على نفس المجلد ده مباشرة:

```bash
npx cap sync
npx cap open android   # أو: npx cap open ios
```

## ملاحظات مهمة

- **Service Worker / manifest.json (PWA)**: اتعطّلوا تلقائياً جوه Capacitor
  (الكود بيتحقق من `Capacitor.isNativePlatform()` قبل تسجيلهم)، ومفيش داعي
  تشيلهم — ما بيأثروش على التطبيق الأصلي.
- **الكاميرا (html5-qrcode) والموقع (`navigator.geolocation`)**: شغالين زي ما
  هما بدون تعديل كود، بس لازم الأذونات في الخطوة 4 فوق وإلا هيفشلوا بصمت.
- **المكتبات الخارجية** (Firebase SDK, Leaflet, SweetAlert2, html5-qrcode,
  crypto-js, pdf.js) لسه بتتحمّل من CDN خارجي، يعني التطبيق هيحتاج إنترنت أول
  ما يفتح. لو عاوز يشتغل حتى بإنترنت ضعيف/بطيء، الأفضل تنزّل نسخهم محلياً
  جوه مجلد `js/lib` أو `css/lib` وتغيّر الروابط في `index.html`.
- سيرفر الإشعارات (`kovant-backend3.onrender.com`) وقواعد قاعدة البيانات
  (`user_tokens/*`, `users/*/fcmToken`) **ما اتغيّروش** — يقرأ ويكتب بنفس
  الشكل بغض النظر عن مصدر التوكن (ويب أو تطبيق أصلي).

## 6) القراءة الفعلية لرسائل SMS (تلقائياً بالخلفية — بدون زر يدوي)

تم إضافة `js/sms-native-bridge.js` وربطه بتسجيل دخول الأدمن. بعد ما تعمل
`npx cap add android`، ثبّت هذه المكوّنات الثلاثة:

```bash
npm install capacitor-sms-inbox capacitor-sms-watcher-fork @capawesome-team/capacitor-android-battery-optimization
npx cap sync android
```

أضف هذه الصلاحيات في `android/app/src/main/AndroidManifest.xml` **قبل** وسم
`<application>`:

```xml
<uses-permission android:name="android.permission.READ_SMS" />
<uses-permission android:name="android.permission.RECEIVE_SMS" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" /> <!-- لتمييز الشريحة عند تعدد الشرائح -->
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
```

**ما الذي سيحصل عملياً بعد ذلك:**
1. عند دخول الأدمن، يطلب التطبيق صلاحية قراءة الرسائل (نفس مربع "منح
   الصلاحية" في الصورة اللي أرسلتها)، ثم يطلب الإعفاء من توفير البطارية
   (نفس مربع "هل تريد السماح بتشغيل التطبيق في الخلفية دائماً؟").
2. بعد الموافقتين، يبدأ استماع لحظي لأي رسالة واردة ويحفظها تلقائياً في
   `sms_inbox/` عبر نفس الدالة `tuaReceiveIncomingSms()` — **زر "إضافة رسالة
   يدوياً" يبقى موجود فقط كخطة بديلة لو رُفضت الصلاحية أو حصل عطل**.
3. المطابقة التلقائية مع طلبات التغذية (`tuaAutoMatchPending`) تشتغل زي ما
   هي بدون أي تعديل.

### ⚠️ تنبيه مهم قبل النشر على Google Play

جوجل تتعامل بحذر شديد مع تطبيقات تطلب `READ_SMS`/`RECEIVE_SMS` وتشتغل
بالخلفية دائماً — هذه الصلاحيات محصورة عادة بتطبيقات الرسائل الافتراضية
(Default SMS Handler) أو فئات معينة (البنوك المرخّصة)، وأي تطبيق آخر يطلبها
معرّض لرفض المراجعة أو الإزالة اللاحقة. الخيارات المتاحة:
- توزيع التطبيق مباشرة (APK) خارج المتجر لجهاز الأدمن فقط (أكثر الحلول أماناً وشيوعاً في هذه الحالة).
- أو التقديم لبرنامج "الوصول الحساس" الخاص بجوجل وتبرير الاستخدام كخدمة مالية.
- تفعيل هذا التطبيق فقط على جهاز/أجهزة الأدمن المحددة، وليس على تطبيق المستخدمين العاديين.

## 7) شاشة "إدارة SMS" الحقيقية (كشف الشرائح + الإرسال الفعلي)

شاشة "إعدادات شرائح الاتصال" و"إرسال SMS تجريبي" في لوحة الأدمن كانت
هيكل واجهة وهمي بالكامل (بيانات محلية في localStorage، بدون أي صلاحية
أو إرسال حقيقي). تم ربطها الآن ببيانات حقيقية — التفعيل يحتاج:

### أ) كشف الشرائح الحقيقي (READ_PHONE_STATE)

```bash
npm install @capgo/capacitor-sim
npx cap sync android
```

هذا المكوّن جاهز من npm ولا يحتاج أي تعديل يدوي — بيرجع `simSlotIndex`,
`subscriptionId`, `carrierName`, `phoneNumber` لكل شريحة فعلية على الجهاز.
بعد التركيب، زر "منح الصلاحية" في شاشة SMS هيطلب الصلاحية فعلياً، والقائمة
هتتبنى ديناميكياً حسب عدد الشرائح الحقيقية (مش نص ثابت "شريحة واحدة" كل مرة).

### ب) الإرسال الفعلي والصامت (SEND_SMS)

هذا الجزء **مفيهوش مكوّن npm جاهز** لأن جوجل تمنع أي مكوّن عام من إرسال
SMS صامتاً بدون فتح تطبيق الرسائل (`@byteowls/capacitor-sms` مثلاً بيفتح
تطبيق الرسائل ويطلب من المستخدم يضغط "إرسال" يدوياً، وده مش المطلوب هنا).
لذلك أضفنا كود مكوّن مخصص جاهز في:

```
native-plugins/android/TuaSmsSenderPlugin.kt
```

**خطوات تركيبه بعد `npx cap add android`:**
1. انسخ الملف إلى:
   ```
   android/app/src/main/java/com/kova/cash/plugins/TuaSmsSenderPlugin.kt
   ```
   (أنشئ مجلد `plugins` لو مش موجود — الـ package name `com.kova.cash.plugins`
   مطابق لـ appId الحالي `com.kova.cash`).
2. سجّله في `MainActivity` (عادة `android/app/src/main/java/com/kova/cash/MainActivity.java`)
   داخل `onCreate()` **قبل** `super.onCreate()`:
   ```java
   import com.kova.cash.plugins.TuaSmsSenderPlugin;
   // ...
   registerPlugin(TuaSmsSenderPlugin.class);
   ```
3. أضف صلاحية `SEND_SMS` في `AndroidManifest.xml`:
   ```xml
   <uses-permission android:name="android.permission.SEND_SMS" />
   ```
4. `npx cap sync android` ثم أعد البناء.

بعدها، زر "إرسال SMS تجريبي" في شاشة SMS هيرسل رسالة حقيقية فعلاً عبر
الشريحة المحفوظة في الإعدادات — وليست محاكاة. لو شغّلت التطبيق داخل
متصفح عادي (بدون Capacitor)، الزر يفضل يشتغل بوضع "معاينة" واضح
(موسوم صراحة بكلمة "معاينة" في التوست) بدون ما يوهمك إنه أرسل فعلياً.

⚠️ **تذكير:** إرسال SMS صامت (SEND_SMS) هو أيضاً من الصلاحيات المحظورة
على معظم التطبيقات في Google Play لغير تطبيقات الرسائل الافتراضية —
نفس قيد قراءة الرسائل بالضبط، ونفس الحل: توزيع خاص (APK يدوي) على جهاز
الأدمن، وليس نشر عام على المتجر.

### ج) البصمة والتخزين الآمن (TuaBiometricPlugin) — راجع أيضًا README-تحديث-البصمة.md

⚠️ **ملاحظة محدَّثة:** الإضافتان القديمتان (`TuaBiometricPlugin` +
`SecureStoragePlugin`) تم دمجهما في ملف واحد فقط: `TuaBiometricPlugin.kt`.
لم تعد `SecureStoragePlugin` موجودة ولا تحتاج تسجيلها. التفاصيل الكاملة
(لماذا الدمج، وكيف يعمل التخزين المحمي بالبصمة عبر Android Keystore
و`CryptoObject`) موثّقة في `README-تحديث-البصمة.md` في جذر المشروع.

الأسهل: شغّل `python3 setup-native-plugins.py` من جذر المشروع بعد
`npx cap add android` — يقوم تلقائيًا بالنسخ، والتسجيل في `MainActivity`
قبل `super.onCreate()`، وإضافة تبعيتي Gradle المطلوبتين. إن فضّلت
اليدوي:

1. انسخ الملف إلى:
   ```
   android/app/src/main/java/com/kova/cash/plugins/TuaBiometricPlugin.kt
   ```
2. سجّله في `MainActivity` (نفس الملف والمكان اللي سجّلت فيه `TuaSmsSenderPlugin`)
   داخل `onCreate()` **قبل** `super.onCreate()`:
   ```java
   import com.kova.cash.plugins.TuaBiometricPlugin;
   // ...
   registerPlugin(TuaBiometricPlugin.class);
   ```
3. أضف مكتبة البصمة في `android/app/build.gradle` (قسم `dependencies`):
   ```gradle
   implementation "androidx.biometric:biometric:1.1.0"
   implementation "androidx.security:security-crypto:1.1.0-alpha06"
   ```
4. `npx cap sync android` ثم أعد البناء.

تحقّق أن `Capacitor.Plugins.TuaBiometric` كائن حقيقي (وليس `undefined`)
في console الخاص بالـ WebView.

كمان تم تصحيح `js/user-logic.js`: كان فيه نظام بصمة قديم مكرر (WebAuthn +
كتابة إلى Firebase) يتصارع مع نظام `auth.js` على نفس زر التفعيل — تم حذفه
بالكامل وتوحيد كل شيء على `TuaBiometric` فقط. التفاصيل في
`README-تحديث-البصمة.md`.


## 8) رصيد الرسائل الحقيقي من المرسل YOU

الرصيد في شاشة "إدارة SMS" كان رقماً محلياً وهمياً (يبدأ من 100 ويُخصم داخل
التطبيق). الآن يُقرأ من رسائل شركة الاتصالات الواردة من المرسل `YOU`:

- `native-plugins/android/TuaSmsInboxPlugin.kt` — يقرأ الصندوق الوارد فعلياً ويستمع لحظياً للرسائل الجديدة.
- `js/sms-balance-you.js` — يستخرج عدد الرسائل المتبقي من نص رسالة YOU ويحدّث الرصيد.

**التثبيت:**
```bash
python3 setup-native-plugins.py    # ينسخ TuaSmsInboxPlugin.kt ويسجّله في MainActivity
npx cap sync android
```
تأكد من وجود `READ_SMS` و`RECEIVE_SMS` في `AndroidManifest.xml` (موجودتان في القسم 6).

**ملاحظات:**
- التحديث يحدث عند دخول الأدمن، وعند فتح شاشة إدارة SMS، وبزر "تحديث الرصيد من YOU"، ولحظياً عند وصول رسالة جديدة من YOU.
- إذا كانت صيغة رسالة YOU مختلفة عمّا يفهمه المحلل، عدّل مصفوفة `SMS_YOU_PATTERNS` في `js/sms-balance-you.js`.
- لو كتب المرسل بصيغة مختلفة (مثل `YOU-Info`) أضفها إلى `SmsYou.SENDER_IDS`.
