/* COVANT Sadaq / Taiztel API routes. Exported as a factory to reuse the server's existing Firebase and auth helpers. */
'use strict';

const express = require('express');
const crypto = require('crypto');

module.exports = function createSadaqRoutes({ db, fetch, verifyUserToken, transactionWithWarmValue, recordTreasuryMovement }) {
    const router = express.Router();
    const apiBase = String(process.env.TAIZTEL_API_URL || '').replace(/\/$/, '');
    const providerUser = String(process.env.TAIZTEL_USERNAME || '');
    // الوثيقة تفرّق بين Userid (رقم المستخدم) و Username (اسم الدخول). إن لم يُضبط TAIZTEL_USERID نستخدم اسم الدخول كما كان.
    const providerUserId = String(process.env.TAIZTEL_USERID || process.env.TAIZTEL_USERNAME || '');
    const password = String(process.env.TAIZTEL_PASSWORD || '');
    const timeoutMs = 25000;
    const MOBILE_RE = /^[0-9]{9}$/; // الوثيقة: رقم يمن موبايل 9 أرقام فقط

    // Express 4 لا يلتقط أخطاء async: نغلّف كل المسارات حتى لا يبقى الطلب معلقاً عند أي خطأ.
    ['get', 'post'].forEach(method => {
        const original = router[method].bind(router);
        router[method] = (path, ...handlers) => original(path, ...handlers.map(h => (req, res, next) => {
            try { return Promise.resolve(h(req, res, next)).catch(next); } catch (e) { return next(e); }
        }));
    });

    function auth(req, res, next) {
        const decoded = verifyUserToken(req);
        if (!decoded) return res.status(401).json({ success: false, error: 'مطلوب تسجيل الدخول' });
        req.sadaqUser = decoded;
        next();
    }

    function allowedPhone(req, phone) {
        return req.sadaqUser && (req.sadaqUser.phone === '999' || String(req.sadaqUser.phone) === String(phone));
    }

    function newTransId(prefix) {
        return `${prefix || 'SDQ'}${Date.now()}${crypto.randomBytes(4).toString('hex')}`.slice(0, 32);
    }

    function tokenFor(transid, mobile) {
        const hashPass = crypto.createHash('md5').update(password, 'utf8').digest('hex');
        return crypto.createHash('md5').update(hashPass + transid + providerUser + mobile, 'utf8').digest('hex');
    }

    function resultCode(data) {
        const value = data && (data.resultCode ?? data.result_code ?? data.code ?? data.result);
        return value === undefined || value === null ? '' : String(value);
    }

    function providerState(data) {
        const code = resultCode(data);
        if (code === '0') return 'success';
        if (code === '-2') return 'pending';
        return 'failed';
    }

    async function callProvider(action, params, path = 'yem') {
        if (!apiBase || !providerUser || !providerUserId || !password) throw new Error('إعدادات مزود تعز تل غير مكتملة');
        const url = new URL(`${apiBase}/${path}`);
        url.searchParams.set('action', action);
        url.searchParams.set('userid', providerUserId);
        Object.entries(params || {}).forEach(([key, value]) => {
            if (value !== undefined && value !== null && String(value) !== '') url.searchParams.set(key, String(value));
        });
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        try {
            let response; let raw;
            try {
                response = await fetch(url.toString(), { method: 'GET', signal: controller.signal, headers: { Accept: 'application/json' } });
                raw = await response.text();
            } catch (networkError) {
                // لا نعرف هل وصل الطلب للمزود أم لا (مهلة/انقطاع): نعلّم الخطأ "غير مؤكد" كي لا نسترد المبلغ آلياً
                const err = new Error(networkError && networkError.name === 'AbortError' ? 'انتهت مهلة الاتصال بتعز تل' : 'تعذر الاتصال بتعز تل');
                err.uncertain = true;
                throw err;
            }
            let data;
            try { data = JSON.parse(raw); } catch (_) { data = { raw }; }
            if (!response.ok) {
                const err = new Error(`مزود تعز تل أعاد HTTP ${response.status}`);
                err.uncertain = response.status >= 500;
                throw err;
            }
            return data;
        } finally { clearTimeout(timer); }
    }

    async function saveTransaction(transid, values) {
        await db.ref(`sadaq/transactions/${transid}`).set({
            ...values, timestamp: values.timestamp || Date.now(), updatedAt: Date.now()
        });
    }

    async function updateTransaction(transid, values) {
        await db.ref(`sadaq/transactions/${transid}`).update({ ...values, updatedAt: Date.now() });
    }

    async function getOffer(offerid) {
        const snap = await db.ref(`sadaq/pricing/offers/${offerid}`).once('value');
        const offer = snap.val();
        if (!offer || offer.active === false) throw Object.assign(new Error('الباقة غير موجودة أو غير مفعّلة'), { status: 400 });
        const cost = Number(offer.cost);
        const sell = Number(offer.sell);
        if (!Number.isFinite(cost) || cost < 0 || !Number.isFinite(sell) || sell < 0) throw new Error('سعر الباقة غير صالح');
        return { ...offer, cost, sell };
    }

    async function debit(phone, amount, transid) {
        const ref = db.ref(`users/${phone}/balance`);
        const tx = await transactionWithWarmValue(ref, current => {
            const balance = Number(current) || 0;
            return balance < amount ? undefined : balance - amount;
        }, `خصم سداد ${transid}`);
        if (!tx || !tx.committed) throw new Error('الرصيد غير كافٍ');
        const newBalance = Number(tx.snapshot.val()) || 0;
        await updateTransaction(transid, { balanceBefore: newBalance + amount, balanceAfter: newBalance });
        return newBalance;
    }

    async function rollback(phone, amount, transid) {
        try {
            await transactionWithWarmValue(db.ref(`users/${phone}/balance`), current => (Number(current) || 0) + amount, `استرداد سداد ${transid}`);
            await updateTransaction(transid, { rollback: true, rollbackAt: Date.now() });
        } catch (error) { console.error('Sadaq rollback failed:', transid, error); }
    }

    async function finishFinancial(transid, phone, sell, cost, offer) {
        if (recordTreasuryMovement && sell > 0) {
            await recordTreasuryMovement(sell, { type: 'sadaq_payment', details: `سداد ${offer?.name || offer?.offerid || transid}`, performedBy: phone });
        }
        const profit = Math.max(0, sell - cost);
        if (profit > 0) {
            await db.ref('sadaq/profits').push({ transid, offerid: offer?.offerid || null, offerName: offer?.name || null, sell, cost, profit, phone, timestamp: Date.now() });
        }
    }

    function responseFor(res, transid, data, extra = {}) {
        const state = providerState(data);
        const failMessage = state === 'failed' ? ((data && (data.resultDesc || data.message)) || `رفضت تعز تل العملية (رمز ${resultCode(data) || 'غير معروف'})`) : undefined;
        return res.status(state === 'failed' ? 502 : 200).json({ success: state !== 'failed', transid, status: state, resultCode: resultCode(data), result: data, ...(failMessage ? { error: failMessage } : {}), ...extra });
    }

    router.post('/query', auth, async (req, res) => {
        const mobile = String(req.body?.mobile || req.body?.phone || '').trim();
        if (!MOBILE_RE.test(mobile) || !allowedPhone(req, mobile)) return res.status(400).json({ success: false, error: 'رقم الجوال يجب أن يكون 9 أرقام ومصرحاً لك' });
        const transid = newTransId('Q');
        await saveTransaction(transid, { phone: mobile, type: 'query', status: 'pending', requestedBy: req.sadaqUser.phone });
        try {
            const data = await callProvider('query', { mobile, transid, token: tokenFor(transid, mobile) });
            const status = providerState(data);
            await updateTransaction(transid, { status, result: data });
            return responseFor(res, transid, data);
        } catch (error) {
            await updateTransaction(transid, { status: 'failed', result: { error: error.message } });
            return res.status(502).json({ success: false, transid, status: 'failed', error: error.message });
        }
    });

    router.post('/pay', auth, async (req, res) => {
        const mobile = String(req.body?.mobile || req.body?.phone || '').trim();
        const amount = Number(req.body?.amount);
        const type = String(req.body?.type || 'bill').trim();
        if (!MOBILE_RE.test(mobile) || !allowedPhone(req, mobile) || !Number.isFinite(amount) || amount <= 0) return res.status(400).json({ success: false, error: 'بيانات السداد غير صحيحة' });
        const transid = newTransId('B');
        await saveTransaction(transid, { phone: mobile, type, amount, status: 'pending', requestedBy: req.sadaqUser.phone });
        let debited = false; let providerSettled = false;
        try {
            const newBalance = await debit(mobile, amount, transid); debited = true;
            const data = await callProvider('bill', { mobile, amount, transid, token: tokenFor(transid, mobile) });
            const status = providerState(data);
            if (status === 'failed') { await rollback(mobile, amount, transid); return responseFor(res, transid, data, { newBalance: newBalance + amount }); }
            providerSettled = true;
            await finishFinancial(transid, mobile, amount, amount, null);
            await updateTransaction(transid, { status, result: data });
            return responseFor(res, transid, data, { newBalance });
        } catch (error) {
            const uncertain = !!error.uncertain && debited && !providerSettled;
            if (debited && !providerSettled && !uncertain) await rollback(mobile, amount, transid);
            const state = (providerSettled || uncertain) ? 'pending_reconciliation' : 'failed';
            await updateTransaction(transid, { status: state, result: { error: error.message } });
            if (uncertain) return res.status(202).json({ success: false, transid, status: state, error: 'العملية قيد التحقق من تعز تل. لا تكررها، وتأكد من حالتها لاحقاً.' });
            return res.status(providerSettled ? 202 : 502).json({ success: providerSettled, transid, status: state, error: error.message });
        }
    });

    router.post('/offer', auth, async (req, res) => {
        const mobile = String(req.body?.mobile || req.body?.phone || '').trim();
        const offerid = String(req.body?.offerid || '').trim();
        const method = String(req.body?.method || 'New');
        if (!MOBILE_RE.test(mobile) || !allowedPhone(req, mobile) || !offerid || !['New', 'Renew', 'Remove'].includes(method)) return res.status(400).json({ success: false, error: 'بيانات الباقة غير صحيحة' });
        const offer = await getOffer(offerid);
        if (method !== 'Remove' && !(offer.sell > 0)) return res.status(400).json({ success: false, error: 'لم يتم تسعير هذه الباقة بعد' });
        const charge = method === 'Remove' ? 0 : offer.sell;
        const transid = newTransId('O');
        await saveTransaction(transid, { phone: mobile, type: 'offer', amount: charge, offerid, method, status: 'pending', requestedBy: req.sadaqUser.phone });
        let debited = false; let providerSettled = false;
        try {
            const newBalance = charge ? await debit(mobile, charge, transid) : Number((await db.ref(`users/${mobile}/balance`).once('value')).val()) || 0;
            debited = charge > 0;
            const data = await callProvider('billoffer', { mobile, offerid, method, transid, token: tokenFor(transid, mobile) });
            const status = providerState(data);
            if (status === 'failed') { if (debited) await rollback(mobile, charge, transid); return responseFor(res, transid, data, { newBalance: debited ? newBalance + charge : newBalance }); }
            providerSettled = true;
            if (charge) await finishFinancial(transid, mobile, charge, offer.cost, { ...offer, offerid });
            await updateTransaction(transid, { status, result: data, cost: offer.cost, sell: offer.sell });
            return responseFor(res, transid, data, { newBalance, offer });
        } catch (error) {
            const uncertain = !!error.uncertain && debited && !providerSettled;
            if (debited && !providerSettled && !uncertain) await rollback(mobile, charge, transid);
            const state = (providerSettled || uncertain) ? 'pending_reconciliation' : 'failed';
            await updateTransaction(transid, { status: state, result: { error: error.message } });
            if (uncertain) return res.status(202).json({ success: false, transid, status: state, error: 'العملية قيد التحقق من تعز تل. لا تكررها، وتأكد من حالتها لاحقاً.' });
            return res.status(providerSettled ? 202 : 502).json({ success: providerSettled, transid, status: state, error: error.message });
        }
    });

    router.post('/offers-list', auth, async (req, res) => {
        try {
            const pricing = (await db.ref('sadaq/pricing/offers').once('value')).val() || {};
            return res.json({ success: true, status: 'success', offers: pricing });
        } catch (error) { return res.status(502).json({ success: false, error: error.message }); }
    });

    router.get('/status/:transid', auth, async (req, res) => {
        const snap = await db.ref(`sadaq/transactions/${req.params.transid}`).once('value');
        const transaction = snap.val();
        if (!transaction || (req.sadaqUser.phone !== '999' && String(transaction.phone) !== String(req.sadaqUser.phone))) return res.status(404).json({ success: false, error: 'العملية غير موجودة' });
        let provider = null;
        // ?refresh=1 (للأدمن فقط): يسأل تعز تل عن حالة العملية (info?action=status). لا يحرّك أي مبلغ؛ القرار يبقى بيد الأدمن.
        if (req.query.refresh === '1' && req.sadaqUser.phone === '999') {
            try {
                const mobile = String(transaction.phone || '');
                let data = null;
                // الوثيقة تكتب action=status في موضع و action=staus في موضع آخر، نجرّب الاثنين
                for (const action of ['status', 'staus']) {
                    data = await callProvider(action, { mobile, transid: req.params.transid, token: tokenFor(req.params.transid, mobile) }, 'info');
                    if (resultCode(data) === '0') break;
                }
                const ok = resultCode(data) === '0';
                provider = {
                    ok, resultCode: resultCode(data), resultDesc: data && data.resultDesc || null,
                    state: !ok ? 'unknown' : (String(data.isBan) === '1' ? 'banned' : (String(data.isDone) === '1' ? 'done' : 'in_progress')),
                    isDone: data && data.isDone, isBan: data && data.isBan, price: data && data.price, reason: data && data.reason, checkedAt: Date.now()
                };
                await updateTransaction(req.params.transid, { providerStatus: provider });
            } catch (error) { provider = { ok: false, error: error.message }; }
        }
        return res.json({ success: true, transaction, ...(provider ? { provider } : {}) });
    });

    // فحص آمن للإعدادات (قراءة فقط): يستعلم عن رصيد الوكيل ليتأكد من الرابط وuserid والتوكن دون أي عملية مالية. للأدمن فقط.
    router.get('/diagnose', auth, async (req, res) => {
        if (req.sadaqUser.phone !== '999') return res.status(403).json({ success: false, error: 'للأدمن فقط' });
        const transid = newTransId('D');
        const mobile = '777777777';
        try {
            const data = await callProvider('balance', { mobile, transid, token: tokenFor(transid, mobile) }, 'info');
            return res.json({ success: resultCode(data) === '0', resultCode: resultCode(data), resultDesc: data && data.resultDesc || null, agentBalance: data && data.balance, base: apiBase, useridIsSeparate: !!process.env.TAIZTEL_USERID });
        } catch (error) { return res.status(502).json({ success: false, error: error.message, base: apiBase }); }
    });

    router.use((err, req, res, next) => {
        console.error('Sadaq route error:', err);
        if (res.headersSent) return next(err);
        return res.status(err.status || 500).json({ success: false, error: err.message || 'خطأ في الخادم' });
    });

    return router;
};
