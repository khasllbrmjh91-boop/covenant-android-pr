# تقرير إصلاح صلاحيات SMS وخدمة الخلفية — V3

## النتيجة

تم جعل بوابة SMS وخدمة القراءة الخلفية خاصة بجهاز الأدمن فقط.

### المستخدم العادي

- لا يتم طلب `SEND_SMS` أو `READ_SMS` أو `RECEIVE_SMS` عند فتح التطبيق.
- لا يتم تشغيل `SMSForegroundService` عند فتح التطبيق أو بعد إعادة تشغيل الجهاز.
- عند تنفيذ عملية دون اتصال، يفتح التطبيق شاشة SMS النظامية عبر `sms:`، ويقوم المستخدم بإرسال الرسالة من تطبيق الرسائل. لا يحتاج التطبيق إلى صلاحية `SEND_SMS`.

### الأدمن

بعد نجاح تسجيل دخول حساب يحمل `isAdmin === true`:

1. يحفظ JavaScript القيمة `is_admin=true` في Capacitor Preferences.
2. يستدعي `KovantAdminBridge.startSmsService()`.
3. تطلب الواجهة صلاحيات SMS وإعفاء البطارية عند الحاجة فقط.
4. تبدأ `SMSForegroundService`.
5. عند الإقلاع، يبدأ `BootReceiver` الخدمة فقط إذا كانت `is_admin=true`.

عند تسجيل الخروج:

- يتم استدعاء `stopSmsService()`.
- تُحذف قيمة `is_admin` من Preferences و`localStorage`.
- تتوقف الخدمة.

## الأمان والتوافق

- لم يتغير تنسيق `CVT:`.
- لم يتغير HMAC-SHA256.
- يقرأ native service `sms_secret_{phone}` من Preferences أولاً، ثم يستخدم Firebase كاحتياطي مؤقت.
- تتم مزامنة مفاتيح المستخدمين إلى Preferences عند دخول الأدمن، إن كانت صلاحية Firebase تسمح بذلك.
- لا يحتوي Java أو Kotlin على رقم هاتف ثابت.
- الرقم الثابت المستخدم في JavaScript هو رقم وجهة SMS الموجود مسبقاً في النظام.

## ملاحظة Android مهمة

تبقى تعريفات صلاحيات SMS في `AndroidManifest.xml` لأن APK الأدمن يحتاجها، لكن Android لا يعرض طلب الصلاحية للمستخدم العادي إلا إذا استدعى التطبيق `requestPermissions`. في هذه النسخة، الاستدعاء يحدث من `AdminBridge.startSmsService()` فقط.

## التحقق

- تم فحص جميع ملفات `js/*.js` باستخدام `node --check`.
- تم فحص `server.js` باستخدام `node --check`.
- تمت مطابقة كود الخدمة المضمّن في Workflow مع ملف الخدمة المحلي.
- تم التحقق من أن `onCreate()` لا يستدعي صلاحيات SMS أو تشغيل الخدمة مباشرة.
- تم التحقق من وجود فحص `is_admin` في الخدمة و`BootReceiver`.
- تم التحقق من سلامة YAML تركيبياً.
