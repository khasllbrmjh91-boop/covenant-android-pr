package com.kova.cash;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Telephony;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public final class SMSWorker extends Worker {
    private static final long MAX_COMMAND_AGE_MS = 5 * 60 * 1000L;
    private static final String PREFS = "CapacitorStorage";
    private static final String CACHE = "CovantProcessedCache";

    public SMSWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!"true".equals(prefs.getString("is_admin", ""))) return Result.success();
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return Result.success();
        // المعالجة التلقائية متوقفة من الإعدادات: لا نقرأ الصندوق ولا نرفع شيئاً
        if (!SmsGatewaySettings.isAutoProcess(context)) return Result.success();
        try {
            if (FirebaseAuth.getInstance().getCurrentUser() == null) Tasks.await(FirebaseAuth.getInstance().signInAnonymously());
            processInbox(context);
            return Result.success();
        } catch (Exception error) {
            return Result.retry();
        }
    }

    private void processInbox(Context context) throws Exception {
        // العلاقة بين الإعدادين (مستقلان): autoProcess فُحص في doWork() — إن كان false لا نصل هنا.
        // processOld=false (الافتراضي) → 24 ساعة + حد عمر 5 دقائق (السلوك القديم، الرسائل الجديدة تمر دائماً)
        // processOld=true → 7 أيام وبدون حد الـ5 دقائق.
        final boolean processOld = SmsGatewaySettings.isProcessOld(context);
        long since = System.currentTimeMillis() - SmsGatewaySettings.inboxWindowMs(context);
        int readSim = SmsGatewaySettings.readSim(context);
        String selection = "date > ? AND body LIKE 'CVT:%'";
        String[] selectionArgs;
        if (readSim >= 0) {
            selection += " AND " + Telephony.Sms.SUBSCRIPTION_ID + " = ?";
            selectionArgs = new String[]{String.valueOf(since), String.valueOf(readSim)};
        } else {
            selectionArgs = new String[]{String.valueOf(since)};
        }
        Uri uri = Telephony.Sms.Inbox.CONTENT_URI;
        String[] projection = { Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE };
        try (Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, "date DESC LIMIT 100")) {
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                long date = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                if (body == null || !body.startsWith("CVT:") || (!processOld && System.currentTimeMillis() - date > MAX_COMMAND_AGE_MS)) continue;
                String sessionId = extractSessionId(body);
                if (sessionId == null || isLocallyProcessed(context, sessionId) || isAlreadyProcessedInFirebase(sessionId)) continue;
                String sender = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                SMSDatabase database = new SMSDatabase(context);
                if (database.insertPending(sessionId, sender, body, date)) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("sender", sender == null ? "" : sender);
                    data.put("body", body);
                    data.put("timestamp", date);
                    data.put("processed", false);
                    data.put("source", "work_manager");
                    try {
                        Tasks.await(FirebaseDatabase.getInstance().getReference("sms_raw_inbox").push().setValue(data), 20, TimeUnit.SECONDS);
                        database.markSent(sessionId);
                        markLocallyProcessed(context, sessionId);
                    } catch (Exception uploadError) {
                        database.markRetry(sessionId, uploadError.getMessage());
                    }
                }
                database.close();
            }
        }
    }

    static String extractSessionId(String body) {
        String[] parts = body.split(":");
        return parts.length >= 3 && !parts[2].trim().isEmpty() ? parts[2].trim() : null;
    }
    static boolean isLocallyProcessed(Context context, String sessionId) {
        return context.getSharedPreferences(CACHE, Context.MODE_PRIVATE).getBoolean(sessionId, false);
    }
    static void markLocallyProcessed(Context context, String sessionId) {
        SharedPreferences prefs = context.getSharedPreferences(CACHE, Context.MODE_PRIVATE);
        Map<String, ?> all = prefs.getAll();
        SharedPreferences.Editor editor = prefs.edit().putBoolean(sessionId, true);
        if (all.size() >= 500) editor.clear().putBoolean(sessionId, true);
        editor.apply();
    }
    static boolean isAlreadyProcessedInFirebase(String sessionId) throws Exception {
        return Tasks.await(FirebaseDatabase.getInstance().getReference("sms_processed/" + sessionId).get()).exists();
    }
}
