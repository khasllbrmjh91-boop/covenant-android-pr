package com.kova.cash;

public final class SMSRetryManager {
    private SMSRetryManager() {}
    private static final long[] BACKOFF_DELAYS = {
            30_000L, 2 * 60_000L, 10 * 60_000L, 60 * 60_000L,
            6 * 60 * 60_000L, 12 * 60 * 60_000L, 24 * 60 * 60_000L,
            48 * 60 * 60_000L, 72 * 60 * 60_000L
    };
    public static final int MAX_ATTEMPTS = 20;
    public static long getNextDelay(int attempts) {
        int index = Math.max(0, Math.min(attempts, BACKOFF_DELAYS.length - 1));
        return BACKOFF_DELAYS[index];
    }
    public static boolean shouldRetry(int attempts) { return attempts < MAX_ATTEMPTS; }
    public static boolean isReadyForRetry(int attempts, long lastAttemptAt) {
        return lastAttemptAt <= 0 || System.currentTimeMillis() - lastAttemptAt >= getNextDelay(attempts);
    }
}
