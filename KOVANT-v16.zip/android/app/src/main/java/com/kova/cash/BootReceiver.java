package com.kova.cash;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * يعيد تشغيل بوابة SMS بعد إعادة تشغيل الجهاز.
 * يجب تسجيله في AndroidManifest مع RECEIVE_BOOT_COMPLETED.
 */
public final class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "CovantBootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !"android.intent.action.QUICKBOOT_POWERON".equals(action)
                && !"com.htc.intent.action.QUICKBOOT_POWERON".equals(action)
                && !Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)) {
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE);
        if (!"true".equals(prefs.getString("is_admin", ""))) return;

        try {
            Intent serviceIntent = new Intent(context, SMSForegroundService.class);
            serviceIntent.setAction(SMSForegroundService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
            SMSWorkerScheduler.schedule(context);
            Log.d(TAG, "SMS foreground service started after boot");
        } catch (Exception error) {
            Log.e(TAG, "Unable to start SMS foreground service after boot", error);
        }
    }
}
