package com.kova.cash

import android.os.Bundle
import com.getcapacitor.BridgeActivity
import com.kova.cash.plugins.TuaBiometricPlugin
import com.kova.cash.plugins.TuaSmsSenderPlugin
import com.kova.cash.plugins.TuaWifiManagerPlugin
import com.kova.cash.plugins.TuaSmsInboxPlugin
import com.kova.cash.plugins.TuaSmsSettingsPlugin

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Capacitor يقرأ قائمة الإضافات داخل super.onCreate()، لذلك يجب التسجيل قبله.
        registerPlugin(TuaBiometricPlugin::class.java)
        registerPlugin(TuaSmsSenderPlugin::class.java)
        registerPlugin(TuaWifiManagerPlugin::class.java)
        registerPlugin(TuaSmsInboxPlugin::class.java)
        registerPlugin(TuaSmsSettingsPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
