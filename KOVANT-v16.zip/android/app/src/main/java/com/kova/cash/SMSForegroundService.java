package com.kova.cash;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.content.pm.PackageManager;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Query;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SMSForegroundService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";

    private static final String TAG = "SMSGateway";
    private static final String CHANNEL_ID = "covant_gateway";
    private static final int NOTIF_ID = 1;
    private static final String API_BASE = "https://kovant-backend3.onrender.com";
    private static final String PREFS = "CapacitorStorage";
    private static final String OFFLINE_QUEUE_PREFS = "CovantSmsOfflineQueue";
    private static final String OFFLINE_QUEUE_KEY = "pending_sms_v1";
    private static final long MAX_COMMAND_AGE_MS = 5 * 60 * 1000L;
    private static final long PROCESSING_LEASE_MS = 2 * 60 * 1000L;
    private static final long STUCK_CHECK_INTERVAL_MS = 30 * 1000L;

    private BroadcastReceiver smsReceiver;
    private PowerManager.WakeLock wakeLock;
    private FirebaseDatabase firebaseDB;
    private ExecutorService executor;
    private ScheduledExecutorService scheduler;
    private OkHttpClient httpClient;
    private SharedPreferences offlinePrefs;
    private SharedPreferences capPrefs;
    private SMSDatabase smsDatabase;
    private ContentObserver smsContentObserver;
    private volatile boolean isInboxProcessing = false;
    // مستمع تغيّر الإعدادات المشتركة — يجب الاحتفاظ بمرجع قوي لأن SharedPreferences تحتفظ بمرجع ضعيف فقط
    private SharedPreferences gatewayPrefs;
    private SharedPreferences.OnSharedPreferenceChangeListener gatewayPrefsListener;
    private static final String PROCESSED_CACHE_PREFS = "CovantProcessedCache";
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Object offlineQueueLock = new Object();
    private volatile boolean offlineSyncInProgress = false;
    private Query pendingCommandsQuery;
    private ChildEventListener pendingCommandsListener;
    private volatile boolean commandListenerStarted = false;
    private volatile boolean stuckCommandsCheckerStarted = false;
    private Query smsQueueQuery;
    private ChildEventListener smsQueueListener;
    private volatile boolean smsQueueListenerStarted = false;
    private static final int MAX_SMS_QUEUE_ATTEMPTS = 3;

    @Override
    public void onCreate() {
        super.onCreate();
        capPrefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!isAdminDevice()) {
            stopSelf();
            return;
        }
        executor = Executors.newFixedThreadPool(4);
        scheduler = Executors.newSingleThreadScheduledExecutor();
        httpClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .build();
        offlinePrefs = getSharedPreferences(OFFLINE_QUEUE_PREFS, MODE_PRIVATE);
        smsDatabase = new SMSDatabase(this);
        createChannel();
        acquireWakeLock();
        registerNetworkCallback();
        try {
            firebaseDB = FirebaseDatabase.getInstance();
            authenticateFirebase();
        } catch (Exception error) {
            Log.e(TAG, "Firebase init failed", error);
        }
        registerSMSReceiver();
        registerContentObserver();
        registerGatewaySettingsListener();
        processExistingInbox();
        syncOfflineSmsQueue();
        // مهم: يبدأ العامل حتى عند تشغيل الخدمة بدون فتح WebView.
        startCommandListener();
        startStuckCommandsChecker();
    }

    private void authenticateFirebase() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            startCommandListener();
            startStuckCommandsChecker();
            startSmsQueueListener();
            return;
        }
        auth.signInAnonymously().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Log.d(TAG, "Firebase auth OK");
                startCommandListener();
                startStuckCommandsChecker();
                startSmsQueueListener();
            } else {
                Log.e(TAG, "Firebase auth failed; retrying automatically", task.getException());
                if (scheduler != null && !scheduler.isShutdown()) {
                    scheduler.schedule(this::authenticateFirebase, 15, TimeUnit.SECONDS);
                }
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isAdminDevice()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIF_ID, buildNotification());
        startCommandListener();
        startStuckCommandsChecker();
        startSmsQueueListener();
        processExistingInbox();
        return START_STICKY;
    }

    private boolean isAdminDevice() {
        return capPrefs != null && "true".equals(capPrefs.getString("is_admin", ""));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "بوابة كوفانت", NotificationManager.IMPORTANCE_LOW);
            channel.setShowBadge(false);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("كوفانت — بوابة نشطة")
                .setContentText("يعالج أوامر SMS حتى عند إغلاق التطبيق")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void acquireWakeLock() {
        PowerManager manager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (manager != null) {
            wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Covant::SMSWakeLock");
            wakeLock.acquire();
        }
    }

    private void registerSMSReceiver() {
        smsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                try {
                    Bundle bundle = intent.getExtras();
                    if (bundle == null) return;
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    String format = bundle.getString("format");
                    if (pdus == null) return;
                    // فلترة شريحة القراءة: -1 = الكل. extra "subscription" يضيفه النظام لـ SMS_RECEIVED
                    int readSim = SmsGatewaySettings.readSim(SMSForegroundService.this);
                    int receivedSub = intent.getIntExtra("subscription", -1);
                    if (readSim >= 0 && receivedSub >= 0 && receivedSub != readSim) {
                        Log.d(TAG, "SMS ignored: received on subscription " + receivedSub + ", readSim=" + readSim);
                        return;
                    }
                    for (Object pdu : pdus) {
                        SmsMessage message = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                                ? SmsMessage.createFromPdu((byte[]) pdu, format)
                                : SmsMessage.createFromPdu((byte[]) pdu);
                        if (message == null) continue;
                        String sender = message.getOriginatingAddress();
                        String body = message.getMessageBody();
                        Log.d(TAG, "SMS from: " + sender);
                        saveSmsToFirebase(sender, body);
                    }
                } catch (Exception error) {
                    Log.e(TAG, "Error receiving SMS", error);
                }
            }
        };
        IntentFilter filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        filter.setPriority(999);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(smsReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(smsReceiver, filter);
        }
    }

    private void saveSmsToFirebase(String sender, String body) {
        if (body == null || !body.startsWith("CVT:")) return;
        try {
            // الاستقبال دائماً (حفظ محلي) — الرفع/المعالجة فقط عند تفعيل autoProcess
            enqueueOfflineSms(sender, body);
            if (SmsGatewaySettings.isAutoProcess(this)) syncOfflineSmsQueue();
            else Log.d(TAG, "autoProcess=false: SMS stored locally, not processed");
        } catch (Exception error) {
            Log.e(TAG, "Failed to persist SMS locally", error);
        }
    }

    private void registerContentObserver() {
        final Handler handler = new Handler(Looper.getMainLooper());
        smsContentObserver = new ContentObserver(handler) {
            private boolean scheduled;
            @Override public void onChange(boolean selfChange, Uri uri) {
                if (scheduled) return;
                scheduled = true;
                handler.postDelayed(() -> { scheduled = false; executor.execute(SMSForegroundService.this::processExistingInbox); }, 2000L);
            }
        };
        try { getContentResolver().registerContentObserver(Telephony.Sms.CONTENT_URI, true, smsContentObserver); }
        catch (Exception error) { Log.e(TAG, "SMS ContentObserver registration failed", error); }
    }

    private void processExistingInbox() {
        if (!isAdminDevice() || isInboxProcessing || smsDatabase == null) return;
        if (!SmsGatewaySettings.isAutoProcess(this)) return;
        isInboxProcessing = true;
        try {
            if (!isNetworkAvailable() || firebaseDB == null) return;
            syncSqliteQueue();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission("android.permission.READ_SMS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
            // العلاقة بين الإعدادين (مستقلان):
            //  • autoProcess: فُحص أعلى الدالة — إن كان false فلا يصل التنفيذ إلى هنا إطلاقاً.
            //  • processOld=false (الافتراضي): السلوك القديم كما هو — نافذة 24 ساعة + حد عمر 5 دقائق،
            //    أي أن الرسالة الجديدة تُعالَج دائماً ولا يتأثر الاستقبال الحي.
            //  • processOld=true: نافذة 7 أيام وبدون حد الـ5 دقائق (رسائل وصلت أثناء إغلاق التطبيق).
            final boolean processOld = SmsGatewaySettings.isProcessOld(this);
            long since = System.currentTimeMillis() - SmsGatewaySettings.inboxWindowMs(this);
            int readSim = SmsGatewaySettings.readSim(this);
            String selection = "date > ? AND body LIKE 'CVT:%'";
            String[] selectionArgs;
            if (readSim >= 0) {
                selection += " AND " + Telephony.Sms.SUBSCRIPTION_ID + " = ?";
                selectionArgs = new String[]{String.valueOf(since), String.valueOf(readSim)};
            } else {
                selectionArgs = new String[]{String.valueOf(since)};
            }
            String[] projection = { Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE };
            try (Cursor cursor = getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI, projection, selection, selectionArgs, "date DESC LIMIT 100")) {
                if (cursor == null) return;
                while (cursor.moveToNext()) {
                    String body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY));
                    long receivedAt = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE));
                    if (body == null || !body.startsWith("CVT:") || (!processOld && System.currentTimeMillis() - receivedAt > MAX_COMMAND_AGE_MS)) continue;
                    String sessionId = SMSWorker.extractSessionId(body);
                    if (sessionId == null || SMSWorker.isLocallyProcessed(this, sessionId)) continue;
                    if (isAlreadyProcessedInFirebase(sessionId)) continue;
                    String sender = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                    if (!smsDatabase.insertPending(sessionId, sender, body, receivedAt)) continue;
                    Map<String, Object> data = new HashMap<>();
                    data.put("sender", sender == null ? "" : sender);
                    data.put("body", body);
                    data.put("timestamp", receivedAt);
                    data.put("processed", false);
                    data.put("source", "foreground_service");
                    final String key = sessionId;
                    firebaseDB.getReference("sms_raw_inbox").push().setValue(data)
                            .addOnSuccessListener(v -> { smsDatabase.markSent(key); SMSWorker.markLocallyProcessed(this, key); })
                            .addOnFailureListener(e -> { if (SMSRetryManager.shouldRetry(0)) smsDatabase.markRetry(key, e.getMessage()); else smsDatabase.markFailed(key, e.getMessage()); });
                }
            }
        } catch (Exception error) { Log.e(TAG, "Existing SMS scan failed", error); }
        finally { isInboxProcessing = false; }
    }

    private void syncSqliteQueue() {
        if (smsDatabase == null || firebaseDB == null) return;
        for (SMSDatabase.PendingSms item : smsDatabase.getPendingToSend()) {
            if (!SMSRetryManager.isReadyForRetry(item.attempts, item.lastAttemptAt)) continue;
            Map<String, Object> data = new HashMap<>();
            data.put("sender", item.sender);
            data.put("body", item.body);
            data.put("timestamp", item.receivedAt);
            data.put("processed", false);
            data.put("source", "sqlite_retry_queue");
            try {
                Tasks.await(firebaseDB.getReference("sms_raw_inbox").push().setValue(data), 20, TimeUnit.SECONDS);
                smsDatabase.markSent(item.sessionId);
                SMSWorker.markLocallyProcessed(this, item.sessionId);
            } catch (Exception error) {
                if (SMSRetryManager.shouldRetry(item.attempts)) smsDatabase.markRetry(item.sessionId, error.getMessage());
                else smsDatabase.markFailed(item.sessionId, error.getMessage());
            }
        }
    }

    private boolean isAlreadyProcessedInFirebase(String sessionId) {
        try { return Tasks.await(firebaseDB.getReference("sms_processed/" + sessionId).get()).exists(); }
        catch (Exception error) { return false; }
    }

    private void enqueueOfflineSms(String sender, String body) throws Exception {
        synchronized (offlineQueueLock) {
            JSONArray queue = readOfflineQueue();
            JSONObject item = new JSONObject();
            item.put("id", "sms-" + System.currentTimeMillis() + "-" + Math.abs(body.hashCode()));
            item.put("sender", sender == null ? "" : sender);
            item.put("body", body);
            item.put("timestamp", System.currentTimeMillis());
            queue.put(item);
            while (queue.length() > 200) queue.remove(0);
            offlinePrefs.edit().putString(OFFLINE_QUEUE_KEY, queue.toString()).apply();
            Log.d(TAG, "SMS stored in local queue; size=" + queue.length());
        }
    }

    private JSONArray readOfflineQueue() {
        try { return new JSONArray(offlinePrefs.getString(OFFLINE_QUEUE_KEY, "[]")); }
        catch (Exception error) { return new JSONArray(); }
    }

    private void removeOfflineSms(String id) {
        synchronized (offlineQueueLock) {
            JSONArray source = readOfflineQueue();
            JSONArray remaining = new JSONArray();
            for (int i = 0; i < source.length(); i++) {
                JSONObject item = source.optJSONObject(i);
                if (item != null && !id.equals(item.optString("id"))) remaining.put(item);
            }
            offlinePrefs.edit().putString(OFFLINE_QUEUE_KEY, remaining.toString()).apply();
        }
    }

    private boolean isNetworkAvailable() {
        if (connectivityManager == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = connectivityManager.getActiveNetwork();
            return network != null && connectivityManager.getNetworkCapabilities(network) != null;
        }
        android.net.NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void registerNetworkCallback() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                Log.d(TAG, "Network available; syncing local SMS queue");
                executor.execute(SMSForegroundService.this::syncOfflineSmsQueue);
                scheduler.execute(SMSForegroundService.this::startCommandListener);
                scheduler.execute(SMSForegroundService.this::startSmsQueueListener);
                scheduler.execute(SMSForegroundService.this::recoverStuckCommands);
                executor.execute(SMSForegroundService.this::processExistingInbox);
            }
        };
        try { connectivityManager.registerDefaultNetworkCallback(networkCallback); }
        catch (Exception error) { Log.e(TAG, "Network callback registration failed", error); }
    }

    private void syncOfflineSmsQueue() {
        if (firebaseDB == null || !isNetworkAvailable() || offlineSyncInProgress) return;
        if (!SmsGatewaySettings.isAutoProcess(this)) return;
        synchronized (offlineQueueLock) {
            if (offlineSyncInProgress) return;
            offlineSyncInProgress = true;
        }
        try {
            JSONArray queue = readOfflineQueue();
            if (queue.length() == 0) { offlineSyncInProgress = false; return; }
            AtomicInteger remaining = new AtomicInteger(queue.length());
            for (int i = 0; i < queue.length(); i++) {
                JSONObject item = queue.optJSONObject(i);
                if (item == null) { if (remaining.decrementAndGet() == 0) offlineSyncInProgress = false; continue; }
                String id = item.optString("id");
                DatabaseReference ref = firebaseDB.getReference("sms_raw_inbox").push();
                Map<String, Object> data = new HashMap<>();
                data.put("sender", item.optString("sender"));
                data.put("body", item.optString("body"));
                data.put("timestamp", item.optLong("timestamp", System.currentTimeMillis()));
                data.put("processed", false);
                data.put("source", "android_service_local_queue");
                ref.setValue(data).addOnSuccessListener(v -> {
                    removeOfflineSms(id);
                    Log.d(TAG, "Queued SMS synced: " + ref.getKey());
                    startCommandListener();
                    if (remaining.decrementAndGet() == 0) offlineSyncInProgress = false;
                }).addOnFailureListener(error -> {
                    Log.e(TAG, "Queued SMS sync failed", error);
                    if (remaining.decrementAndGet() == 0) offlineSyncInProgress = false;
                });
            }
        } catch (Exception error) {
            offlineSyncInProgress = false;
            Log.e(TAG, "Local SMS queue sync failed", error);
        }
    }

    private synchronized void startSmsQueueListener() {
        if (firebaseDB == null || smsQueueListenerStarted || !isAdminDevice()) return;
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        smsQueueListenerStarted = true;
        smsQueueQuery = firebaseDB.getReference("sms_queue").orderByChild("status").equalTo("pending");
        smsQueueListener = new ChildEventListener() {
            @Override public void onChildAdded(DataSnapshot snapshot, String previousChildName) { executor.execute(() -> processSmsQueueItem(snapshot)); }
            @Override public void onChildChanged(DataSnapshot snapshot, String previousChildName) {
                if ("pending".equals(text(snapshot.child("status").getValue()))) executor.execute(() -> processSmsQueueItem(snapshot));
            }
            @Override public void onChildRemoved(DataSnapshot snapshot) {}
            @Override public void onChildMoved(DataSnapshot snapshot, String previousChildName) {}
            @Override public void onCancelled(DatabaseError error) {
                smsQueueListenerStarted = false;
                Log.e(TAG, "SMS queue listener cancelled: " + error.getMessage());
                if (scheduler != null && !scheduler.isShutdown()) scheduler.schedule(SMSForegroundService.this::startSmsQueueListener, 15, TimeUnit.SECONDS);
            }
        };
        smsQueueQuery.addChildEventListener(smsQueueListener);
        scheduler.scheduleWithFixedDelay(this::recoverStuckSmsQueue, 60, 60, TimeUnit.SECONDS);
        Log.d(TAG, "SMS queue listener started");
    }

    private void recoverStuckSmsQueue() {
        if (firebaseDB == null || !isNetworkAvailable()) return;
        firebaseDB.getReference("sms_queue").orderByChild("status").equalTo("processing")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot snapshot) {
                        long now = System.currentTimeMillis();
                        for (DataSnapshot item : snapshot.getChildren()) {
                            long processingAt = number(item.child("processingAt").getValue());
                            if (processingAt > 0 && now - processingAt >= PROCESSING_LEASE_MS) {
                                item.getRef().runTransaction(new Transaction.Handler() {
                                    @Override public Transaction.Result doTransaction(MutableData current) {
                                        long started = number(current.child("processingAt").getValue());
                                        if (!"processing".equals(text(current.child("status").getValue())) || started <= 0 || System.currentTimeMillis() - started < PROCESSING_LEASE_MS) return Transaction.abort();
                                        current.child("status").setValue("pending");
                                        current.child("processingAt").setValue(null);
                                        current.child("lastError").setValue("استرداد تلقائي لرسالة SMS عالقة");
                                        return Transaction.success(current);
                                    }
                                    @Override public void onComplete(DatabaseError error, boolean committed, DataSnapshot current) {
                                        if (error != null) Log.e(TAG, "SMS queue recovery failed", error.toException());
                                    }
                                });
                            }
                        }
                    }
                    @Override public void onCancelled(DatabaseError error) { Log.e(TAG, "SMS queue recovery scan failed", error.toException()); }
                });
    }

    private void processSmsQueueItem(DataSnapshot snapshot) {
        String itemId = snapshot.getKey();
        if (itemId == null || firebaseDB == null || Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission("android.permission.SEND_SMS") != PackageManager.PERMISSION_GRANTED) {
            if (itemId != null && firebaseDB != null) firebaseDB.getReference("sms_queue/" + itemId).updateChildren(singleMap("lastError", "SEND_SMS permission missing"));
            return;
        }
        DatabaseReference itemRef = firebaseDB.getReference("sms_queue/" + itemId);
        itemRef.runTransaction(new Transaction.Handler() {
            @Override public Transaction.Result doTransaction(MutableData current) {
                if (current.getValue() == null || !"pending".equals(text(current.child("status").getValue()))) return Transaction.abort();
                current.child("status").setValue("processing");
                current.child("processingAt").setValue(System.currentTimeMillis());
                return Transaction.success(current);
            }
            @Override public void onComplete(DatabaseError error, boolean committed, DataSnapshot current) {
                if (error != null || !committed) return;
                String to = text(current.child("to").getValue());
                String message = text(current.child("message").getValue());
                long attempts = number(current.child("attempts").getValue());
                if (to.isEmpty() || message.isEmpty()) {
                    itemRef.updateChildren(queueStatus("failed", "missing fields", attempts));
                    return;
                }
                try {
                    SmsManager manager = managerForQueueItem(current);
                    ArrayList<String> parts = manager.divideMessage(message);
                    manager.sendMultipartTextMessage(to, null, parts, null, null);
                    itemRef.updateChildren(queueStatus("sent", null, attempts));
                    Log.d(TAG, "SMS queue send initiated: " + itemId + " -> " + to);
                } catch (Exception sendError) {
                    long nextAttempts = attempts + 1;
                    String reason = sendError.getMessage() == null ? "SMS send failed" : sendError.getMessage();
                    itemRef.updateChildren(queueStatus(nextAttempts >= MAX_SMS_QUEUE_ATTEMPTS ? "failed" : "pending", reason, nextAttempts));
                    Log.e(TAG, "SMS queue send failed: " + itemId, sendError);
                }
            }
        });
    }

    private Map<String, Object> queueStatus(String status, String error, long attempts) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);
        update.put("attempts", attempts);
        update.put("lastAttemptAt", System.currentTimeMillis());
        update.put("processingAt", null);
        if ("sent".equals(status)) update.put("sentAt", System.currentTimeMillis());
        if (error != null) update.put("lastError", error);
        return update;
    }

    private Map<String, Object> singleMap(String key, Object value) {
        Map<String, Object> update = new HashMap<>();
        update.put(key, value);
        return update;
    }

    /** مراقبة مستمرة للأوامر التي أنشأها WebView أو الخدمة سابقاً. */
    private synchronized void startCommandListener() {
        if (firebaseDB == null || commandListenerStarted) return;
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            Log.d(TAG, "Waiting for Firebase authentication before starting command listener");
            return;
        }
        commandListenerStarted = true;
        pendingCommandsQuery = firebaseDB.getReference("sms_commands")
                .orderByChild("status").equalTo("pending");
        pendingCommandsListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot snapshot, String previousChildName) {
                executor.execute(() -> executeCommand(snapshot.getKey(), snapshot));
            }

            @Override
            public void onChildChanged(DataSnapshot snapshot, String previousChildName) {
                if ("pending".equals(text(snapshot.child("status").getValue()))) {
                    executor.execute(() -> executeCommand(snapshot.getKey(), snapshot));
                }
            }

            @Override public void onChildRemoved(DataSnapshot snapshot) {}
            @Override public void onChildMoved(DataSnapshot snapshot, String previousChildName) {}
            @Override public void onCancelled(DatabaseError error) {
                commandListenerStarted = false;
                Log.e(TAG, "Pending command listener cancelled: " + error.getMessage());
                scheduler.schedule(SMSForegroundService.this::startCommandListener, 15, TimeUnit.SECONDS);
            }
        };
        pendingCommandsQuery.addChildEventListener(pendingCommandsListener);
        Log.d(TAG, "Pending command listener started");
    }

    /** يفحص عقود المعالجة دورياً حتى لا يبقى الأمر في processing بعد توقف الخدمة. */
    private synchronized void startStuckCommandsChecker() {
        if (firebaseDB == null || stuckCommandsCheckerStarted || scheduler == null) return;
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        stuckCommandsCheckerStarted = true;
        scheduler.scheduleWithFixedDelay(this::recoverStuckCommands, 5, 30, TimeUnit.SECONDS);
        Log.d(TAG, "Stuck command checker started");
    }

    private void recoverStuckCommands() {
        if (firebaseDB == null || !isNetworkAvailable()) return;
        try {
            firebaseDB.getReference("sms_commands")
                    .orderByChild("status").equalTo("processing")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            long now = System.currentTimeMillis();
                            for (DataSnapshot command : snapshot.getChildren()) {
                                long processingAt = number(command.child("processingAt").getValue());
                                if (processingAt <= 0) {
                                    processingAt = number(command.child("updatedAt").getValue());
                                    if (processingAt <= 0) processingAt = number(command.child("receivedAt").getValue());
                                }
                                if (processingAt > 0 && now - processingAt >= PROCESSING_LEASE_MS) {
                                    recoverStuckCommand(command.getKey());
                                }
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            Log.e(TAG, "Stuck command scan failed: " + error.getMessage());
                        }
                    });
        } catch (Exception error) {
            Log.e(TAG, "Stuck command recovery failed", error);
        }
    }

    private void recoverStuckCommand(String commandId) {
        if (commandId == null || firebaseDB == null) return;
        DatabaseReference commandRef = firebaseDB.getReference("sms_commands/" + commandId);
        commandRef.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData currentData) {
                if (!"processing".equals(text(currentData.child("status").getValue()))) {
                    return Transaction.abort();
                }
                long processingAt = number(currentData.child("processingAt").getValue());
                if (processingAt <= 0) processingAt = number(currentData.child("updatedAt").getValue());
                if (processingAt <= 0) processingAt = number(currentData.child("receivedAt").getValue());
                if (processingAt <= 0 || System.currentTimeMillis() - processingAt < PROCESSING_LEASE_MS) {
                    return Transaction.abort();
                }
                currentData.child("status").setValue("pending");
                currentData.child("processingAt").setValue(null);
                currentData.child("recoveredAt").setValue(System.currentTimeMillis());
                currentData.child("lastError").setValue("استرداد تلقائي بعد توقف المعالجة");
                return Transaction.success(currentData);
            }

            @Override
            public void onComplete(DatabaseError error, boolean committed, DataSnapshot snapshot) {
                if (error != null) {
                    Log.e(TAG, "Stuck command recovery transaction failed: " + commandId, error.toException());
                } else if (committed) {
                    Log.w(TAG, "Recovered stuck command automatically: " + commandId);
                }
            }
        });
    }

    /** يقفل الأمر ذرياً ثم يبدأ المعالجة بعد نجاح المعاملة. */
    private void executeCommand(String commandId, DataSnapshot command) {
        if (commandId == null || firebaseDB == null) return;
        DatabaseReference commandRef = firebaseDB.getReference("sms_commands/" + commandId);
        commandRef.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData currentData) {
                if (currentData.getValue() == null) return Transaction.abort();
                if ("pending".equals(text(currentData.child("status").getValue()))) {
                    currentData.child("status").setValue("processing");
                    currentData.child("processingAt").setValue(System.currentTimeMillis());
                    return Transaction.success(currentData);
                }
                return Transaction.abort();
            }

            @Override
            public void onComplete(DatabaseError error, boolean committed, DataSnapshot snapshot) {
                if (error != null) {
                    Log.e(TAG, "Transaction error for command: " + commandId, error.toException());
                    return;
                }
                if (committed) {
                    processPendingCommand(command);
                } else {
                    Log.d(TAG, "Command already claimed or processed: " + commandId);
                }
            }
        });
    }

    private void processPendingCommand(DataSnapshot snapshot) {
        String commandId = snapshot.getKey();
        if (commandId == null) return;
        try {
            String code = text(snapshot.child("code").getValue());
            String sessionId = text(snapshot.child("sessionId").getValue());
            String from = text(snapshot.child("from").getValue());
            if (from.isEmpty()) from = text(snapshot.child("phone").getValue());
            if (from.isEmpty()) from = text(snapshot.child("buyer").getValue());
            long timestamp = number(snapshot.child("ts").getValue());
            String signature = text(snapshot.child("sig").getValue());
            String signedData = text(snapshot.child("data").getValue());

            if (sessionId.isEmpty() || from.isEmpty() || signedData.isEmpty() || signature.isEmpty()) {
                rejectCommand(commandId, from, "بيانات الأمر غير مكتملة");
                return;
            }
            if (timestamp <= 0 || Math.abs(System.currentTimeMillis() - timestamp) > MAX_COMMAND_AGE_MS) {
                rejectCommand(commandId, from, "انتهت صلاحية الطلب");
                return;
            }
            Boolean signatureValid = verifyCommandSignature(from, signedData, signature);
            if (signatureValid == null) {
                retryCommand(commandId, "تعذر قراءة مفتاح SMS مؤقتاً");
                return;
            }
            if (!signatureValid) {
                rejectCommand(commandId, from, "تعذر التحقق من توقيع الطلب");
                return;
            }

            String jwt = getAdminJwt();
            if (jwt.isEmpty()) {
                retryCommand(commandId, "JWT الأدمن غير متوفر");
                return;
            }

            JSONObject body = new JSONObject();
            String endpoint;
            if ("TR".equals(code)) {
                endpoint = "/sms/transfer";
                body.put("from", from);
                body.put("toAccount", text(snapshot.child("to").getValue()));
                body.put("amount", number(snapshot.child("amount").getValue()));
                body.put("note", "تحويل عبر SMS");
                body.put("sessionId", sessionId);
            } else if ("CR".equals(code)) {
                endpoint = "/sms/purchase-package";
                body.put("buyer", text(snapshot.child("buyer").getValue()));
                body.put("packageId", text(snapshot.child("pkgId").getValue()));
                body.put("count", (int) number(snapshot.child("count").getValue()));
                body.put("customerId", text(snapshot.child("recipient").getValue()));
                body.put("sessionId", sessionId);
            } else if ("TP".equals(code)) {
                endpoint = "/admin/deposit";
                body.put("phone", text(snapshot.child("phone").getValue()));
                body.put("amount", number(snapshot.child("amount").getValue()));
                body.put("bankRef", text(snapshot.child("bankRef").getValue()));
            } else if ("BQ".equals(code)) {
                processBalanceQuery(commandId, from, sessionId);
                return;
            } else {
                rejectCommand(commandId, from, "نوع أمر غير مدعوم");
                return;
            }

            String responseText = callAPI(endpoint, jwt, body.toString());
            JSONObject response = new JSONObject(responseText);
            if (!response.optBoolean("success", false)) {
                rejectCommand(commandId, from, response.optString("error", "فشلت العملية"));
                return;
            }
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("txId", response.optString("txId", sessionId));
            if (response.has("newBalance")) result.put("newBalance", response.opt("newBalance"));
            markExecuted(commandId, result);
            sendConfirmation(code, snapshot, response, sessionId);
        } catch (Exception error) {
            Log.e(TAG, "Pending command failed: " + commandId, error);
            retryCommand(commandId, error.getMessage() == null ? "خطأ مؤقت" : error.getMessage());
        }
    }

    /**
     * null = فشل مؤقت في القراءة/المصادقة، false = السر موجود لكن التوقيع خاطئ.
     */
    private Boolean verifyCommandSignature(String phone, String signedData, String suppliedSignature) {
        try {
            String secret = capPrefs == null ? "" : capPrefs.getString("sms_secret_" + phone, "");
            if (secret == null || secret.isEmpty()) {
                DataSnapshot secretSnapshot = Tasks.await(firebaseDB.getReference("users/" + phone + "/sms_secret").get());
                secret = secretSnapshot.getValue(String.class);
            }
            if (secret == null || secret.isEmpty()) return false;
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] expected = mac.doFinal(signedData.getBytes(StandardCharsets.UTF_8));
            byte[] supplied = hexToBytes(suppliedSignature);
            return supplied != null && MessageDigest.isEqual(expected, supplied);
        } catch (Exception error) {
            Log.e(TAG, "HMAC verification failed", error);
            return null;
        }
    }

    private void processBalanceQuery(String commandId, String phone, String sessionId) throws Exception {
        DataSnapshot user = Tasks.await(firebaseDB.getReference("users/" + phone).get());
        if (!user.exists()) {
            rejectCommand(commandId, phone, "الحساب غير موجود");
            return;
        }
        String balance = String.valueOf(number(user.child("balance").getValue()));
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("balance", number(user.child("balance").getValue()));
        result.put("txId", sessionId);
        markExecuted(commandId, result);
        sendSMS(phone, "كوفانت\nرصيدك الحالي: " + balance + " ريال\nالعملية: " + sessionId);
    }

    private void markExecuted(String commandId, Map<String, Object> result) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", "executed");
        update.put("executedAt", System.currentTimeMillis());
        update.put("processingAt", null);
        update.put("result", result);
        firebaseDB.getReference("sms_commands/" + commandId).updateChildren(update);
    }

    private void rejectCommand(String commandId, String phone, String reason) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", "rejected");
        update.put("rejectedAt", System.currentTimeMillis());
        update.put("processingAt", null);
        update.put("rejectReason", reason);
        firebaseDB.getReference("sms_commands/" + commandId).updateChildren(update);
        if (phone != null && !phone.isEmpty()) sendSMS(phone, "كوفانت: تعذر تنفيذ الطلب\n" + reason);
    }

    private void retryCommand(String commandId, String reason) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", "pending");
        update.put("processingAt", null);
        update.put("lastError", reason);
        update.put("retryAt", System.currentTimeMillis());
        firebaseDB.getReference("sms_commands/" + commandId).updateChildren(update);
        scheduler.schedule(this::startCommandListener, 15, TimeUnit.SECONDS);
    }

    private void sendConfirmation(String code, DataSnapshot command, JSONObject response, String sessionId) {
        try {
            if ("TR".equals(code)) {
                String from = text(command.child("from").getValue());
                String to = response.optJSONObject("recipient") == null ? text(command.child("to").getValue()) : response.optJSONObject("recipient").optString("phone", text(command.child("to").getValue()));
                String amount = text(command.child("amount").getValue());
                sendSMS(from, "كوفانت: تم خصم " + amount + " ريال\nالعملية: " + sessionId);
                sendSMS(to, "كوفانت: تم إيداع " + amount + " ريال\nالعملية: " + sessionId);
            } else if ("CR".equals(code)) {
                String buyer = text(command.child("buyer").getValue());
                String recipient = text(command.child("recipient").getValue());
                int count = (int) number(command.child("count").getValue());
                sendSMS(buyer, "كوفانت: تم شراء " + count + " كرت للعميل رقم " + recipient + "\nرصيدك بعد العملية: " + response.optString("newBalance", "غير متاح"));
                JSONArray codes = response.optJSONArray("codes");
                if (codes != null) {
                    StringBuilder message = new StringBuilder("كوفانت — أكواد الكروت\n");
                    for (int i = 0; i < codes.length(); i++) message.append("الكود: ").append(codes.optString(i)).append('\n');
                    sendSMS(recipient, message.toString());
                }
            } else if ("TP".equals(code)) {
                sendSMS(text(command.child("phone").getValue()), "كوفانت: تم تأكيد الإيداع بمبلغ " + text(command.child("amount").getValue()) + " ريال\nرصيدك: " + response.optString("newBalance", "غير متاح"));
            }
        } catch (Exception error) {
            Log.e(TAG, "Confirmation failed", error);
        }
    }

    private String getAdminJwt() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String jwt = prefs.getString("admin_jwt", "");
        if (jwt == null) return "";
        jwt = jwt.trim();
        if (jwt.startsWith("\"") && jwt.endsWith("\"")) jwt = jwt.substring(1, jwt.length() - 1);
        long expiry = 0;
        try { expiry = Long.parseLong(prefs.getString("admin_jwt_expiry", "0")); } catch (Exception ignored) {}
        return expiry > 0 && expiry <= System.currentTimeMillis() ? "" : jwt;
    }

    private String callAPI(String endpoint, String jwt, String jsonBody) {
        try {
            RequestBody requestBody = RequestBody.create(
                    jsonBody,
                    MediaType.parse("application/json; charset=utf-8")
            );
            Request request = new Request.Builder()
                    .url(API_BASE + endpoint)
                    .post(requestBody)
                    .header("Authorization", "Bearer " + jwt)
                    .build();
            try (Response response = httpClient.newCall(request).execute()) {
                if (response.body() == null) return "{\"success\":false,\"error\":\"network\"}";
                return response.body().string();
            }
        } catch (Exception error) {
            Log.e(TAG, "API call failed", error);
            return "{\"success\":false,\"error\":\"network\"}";
        }
    }

    /** شريحة الإرسال: subscriptionId الصريح في عنصر الطابور أولاً، ثم إعداد sendSim، ثم الافتراضي. */
    private SmsManager managerForQueueItem(DataSnapshot item) {
        long explicit = -1;
        Object raw = item.child("subscriptionId").getValue();
        if (raw != null) { try { explicit = Long.parseLong(text(raw)); } catch (Exception ignored) {} }
        if (explicit >= 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try { return SmsManager.getSmsManagerForSubscriptionId((int) explicit); } catch (Exception ignored) {}
        }
        return SmsGatewaySettings.smsManagerForSend(this);
    }

    private void registerGatewaySettingsListener() {
        gatewayPrefs = SmsGatewaySettings.prefs(this);
        gatewayPrefsListener = (prefs, key) -> {
            if (SmsGatewaySettings.KEY_AUTO_PROCESS.equals(key) && prefs.getBoolean(key, true)) {
                // أُعيد تفعيل المعالجة: أرسل ما اجتمع محلياً وافحص الصندوق فوراً
                if (executor != null && !executor.isShutdown()) {
                    executor.execute(this::syncOfflineSmsQueue);
                    executor.execute(this::processExistingInbox);
                }
            } else if (SmsGatewaySettings.KEY_PROCESS_OLD.equals(key) || SmsGatewaySettings.KEY_READ_SIM.equals(key)) {
                if (executor != null && !executor.isShutdown()) executor.execute(this::processExistingInbox);
            }
        };
        gatewayPrefs.registerOnSharedPreferenceChangeListener(gatewayPrefsListener);
    }

    private void sendSMS(String phone, String message) {
        if (phone == null || phone.trim().isEmpty()) return;
        try { SmsGatewaySettings.smsManagerForSend(this).sendTextMessage(phone, null, message, null, null); }
        catch (Exception error) { Log.e(TAG, "sendSMS failed", error); }
    }

    private static String text(Object value) { return value == null ? "" : String.valueOf(value).trim(); }
    private static long number(Object value) {
        try { return Math.round(Double.parseDouble(text(value))); } catch (Exception ignored) { return 0; }
    }
    private static byte[] hexToBytes(String value) {
        if (value == null || value.length() != 64 || !value.matches("[0-9a-fA-F]+")) return null;
        byte[] result = new byte[32];
        for (int i = 0; i < result.length; i++) result[i] = (byte) Integer.parseInt(value.substring(i * 2, i * 2 + 2), 16);
        return result;
    }

    @Override
    public void onDestroy() {
        if (gatewayPrefs != null && gatewayPrefsListener != null) {
            try { gatewayPrefs.unregisterOnSharedPreferenceChangeListener(gatewayPrefsListener); } catch (Exception ignored) {}
        }
        if (smsContentObserver != null) try { getContentResolver().unregisterContentObserver(smsContentObserver); } catch (Exception ignored) {}
        if (smsDatabase != null) { smsDatabase.cleanupOld(7); smsDatabase.close(); }
        if (pendingCommandsQuery != null && pendingCommandsListener != null) pendingCommandsQuery.removeEventListener(pendingCommandsListener);
        if (smsQueueQuery != null && smsQueueListener != null) smsQueueQuery.removeEventListener(smsQueueListener);
        smsQueueListener = null;
        smsQueueListenerStarted = false;
        if (smsReceiver != null) try { unregisterReceiver(smsReceiver); } catch (Exception ignored) {}
        if (connectivityManager != null && networkCallback != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) {}
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (executor != null) executor.shutdownNow();
        if (scheduler != null) scheduler.shutdownNow();
        if (httpClient != null) httpClient.dispatcher().executorService().shutdown();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
