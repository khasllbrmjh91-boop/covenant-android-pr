package com.kova.cash;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.util.Log;

import java.util.UUID;

/**
 * طبقة إعدادات موحّدة بين الواجهة (عبر TuaSmsSettingsPlugin) والكود الأصلي
 * (SMSForegroundService / SMSWorker). مصدر الحقيقة: SharedPreferences باسم sms_gateway_prefs.
 *
 * readSim / sendSim = subscriptionId (int)، والقيمة -1 تعني "الكل / الافتراضي".
 */
public final class SmsGatewaySettings {
    private static final String TAG = "SmsGatewaySettings";

    public static final String PREFS = "sms_gateway_prefs";
    public static final String KEY_INITIALIZED = "initialized";
    public static final String KEY_AUTO_PROCESS = "autoProcess";
    public static final String KEY_PROCESS_OLD = "processOld";
    public static final String KEY_READ_SIM = "readSim";
    public static final String KEY_SEND_SIM = "sendSim";
    public static final String KEY_DEVICE_ID = "deviceId";

    /*
     * العلاقة بين autoProcess و processOld (مستقلان تماماً):
     *
     *  - autoProcess  = «هل نعالج/نرفع الرسائل أصلاً؟». الافتراضي true.
     *      false → تُستقبل الرسائل وتُحفظ محلياً فقط، ولا يُرفع ولا يُفحص شيء
     *      (لا استقبال حي ولا مسح الصندوق ولا العامل الدوري).
     *  - processOld   = «ما مدى قِدم الرسائل المسموح بمعالجتها عند مسح الصندوق؟». الافتراضي false.
     *      false → السلوك القديم: نافذة 24 ساعة + حد عمر 5 دقائق (رسائل جديدة فقط عملياً).
     *      true  → نافذة 7 أيام وبدون حد الـ5 دقائق (رسائل وصلت أثناء إغلاق التطبيق).
     *
     *  processOld لا يعطّل الرسائل الجديدة أبداً: الرسالة الواصلة الآن تمر في الحالتين.
     *  وهو لا يعمل إلا إذا كان autoProcess = true (autoProcess=false يسبقه ويوقف كل شيء).
     */

    /** نافذة قراءة الصندوق: 24 ساعة (سلوك قديم) أو 7 أيام عند processOld. */
    public static final long WINDOW_DEFAULT_MS = 24L * 60L * 60L * 1000L;
    public static final long WINDOW_OLD_MS = 7L * 24L * 60L * 60L * 1000L;

    private SmsGatewaySettings() {}

    public static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isAutoProcess(Context context) {
        return prefs(context).getBoolean(KEY_AUTO_PROCESS, true);
    }

    public static boolean isProcessOld(Context context) {
        return prefs(context).getBoolean(KEY_PROCESS_OLD, false);
    }

    public static long inboxWindowMs(Context context) {
        return isProcessOld(context) ? WINDOW_OLD_MS : WINDOW_DEFAULT_MS;
    }

    public static int readSim(Context context) {
        return validSubscription(context, prefs(context).getInt(KEY_READ_SIM, -1));
    }

    public static int sendSim(Context context) {
        return validSubscription(context, prefs(context).getInt(KEY_SEND_SIM, -1));
    }

    /** إن لم تعد الشريحة موجودة (تغيّرت/أُزيلت) نرجع إلى -1 بدل أن نفلتر على شريحة ميتة. */
    private static int validSubscription(Context context, int subId) {
        if (subId < 0) return -1;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                SubscriptionManager sm = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                if (sm != null && sm.getActiveSubscriptionInfo(subId) == null) {
                    Log.w(TAG, "Saved subscription " + subId + " is not active; falling back to ALL");
                    return -1;
                }
            }
        } catch (SecurityException e) {
            // بدون READ_PHONE_STATE لا نستطيع التحقق: نحترم القيمة المحفوظة
        } catch (Exception e) {
            Log.w(TAG, "Subscription validation failed", e);
        }
        return subId;
    }

    /** SmsManager للشريحة المختارة للإرسال، أو الافتراضي عند -1. */
    @SuppressWarnings("deprecation")
    public static SmsManager smsManagerForSend(Context context) {
        int subId = sendSim(context);
        try {
            if (subId >= 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                return SmsManager.getSmsManagerForSubscriptionId(subId);
            }
        } catch (Exception e) {
            Log.w(TAG, "getSmsManagerForSubscriptionId failed; using default", e);
        }
        return SmsManager.getDefault();
    }

    /** معرّف الجهاز: ANDROID_ID يُحفظ مرة واحدة؛ احتياطياً UUID ثابت. */
    public static String deviceId(Context context) {
        SharedPreferences p = prefs(context);
        String saved = p.getString(KEY_DEVICE_ID, null);
        if (saved != null && !saved.trim().isEmpty()) return saved;

        String id = null;
        try {
            id = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) {}
        // 9774d56d682e549c قيمة معروفة مكرّرة في بعض الأجهزة القديمة/المحاكيات
        if (id == null || id.trim().isEmpty() || "9774d56d682e549c".equalsIgnoreCase(id)) {
            id = "GEN-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
        }
        p.edit().putString(KEY_DEVICE_ID, id).apply();
        return id;
    }
}
