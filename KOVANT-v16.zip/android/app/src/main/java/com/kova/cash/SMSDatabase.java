package com.kova.cash;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public final class SMSDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "covant_sms.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "pending_sms";

    public SMSDatabase(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "session_id TEXT UNIQUE NOT NULL," +
                "sender TEXT NOT NULL," +
                "body TEXT NOT NULL," +
                "received_at INTEGER NOT NULL," +
                "status TEXT DEFAULT 'pending'," +
                "attempts INTEGER DEFAULT 0," +
                "last_error TEXT," +
                "last_attempt_at INTEGER)");
        db.execSQL("CREATE INDEX idx_status ON " + TABLE + "(status)");
        db.execSQL("CREATE INDEX idx_attempt ON " + TABLE + "(last_attempt_at)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 1) onCreate(db);
    }

    public boolean insertPending(String sessionId, String sender, String body, long receivedAt) {
        if (sessionId == null || sessionId.trim().isEmpty() || body == null) return false;
        ContentValues values = new ContentValues();
        values.put("session_id", sessionId);
        values.put("sender", sender == null ? "" : sender);
        values.put("body", body);
        values.put("received_at", receivedAt);
        values.put("status", "pending");
        return getWritableDatabase().insertWithOnConflict(TABLE, null, values,
                SQLiteDatabase.CONFLICT_IGNORE) != -1;
    }

    public List<PendingSms> getPendingToSend() {
        List<PendingSms> result = new ArrayList<>();
        long now = System.currentTimeMillis();
        try (Cursor cursor = getReadableDatabase().query(TABLE, null,
                "status IN ('pending','retry') AND (last_attempt_at IS NULL OR last_attempt_at <= ?)",
                new String[]{String.valueOf(now)}, null, null, "received_at ASC", "100")) {
            while (cursor.moveToNext()) result.add(PendingSms.from(cursor));
        }
        return result;
    }

    public void markSent(String sessionId) { updateStatus(sessionId, "sent", null, false); }

    public void markRetry(String sessionId, String error) { updateStatus(sessionId, "retry", error, true); }

    public void markFailed(String sessionId, String error) { updateStatus(sessionId, "failed", error, true); }

    private void updateStatus(String sessionId, String status, String error, boolean incrementAttempts) {
        ContentValues values = new ContentValues();
        values.put("status", status);
        values.put("last_error", error == null ? "" : error);
        values.put("last_attempt_at", System.currentTimeMillis());
        if (incrementAttempts) getWritableDatabase().execSQL(
                "UPDATE " + TABLE + " SET status=?, last_error=?, last_attempt_at=?, attempts=attempts+1 WHERE session_id=?",
                new Object[]{status, error == null ? "" : error, System.currentTimeMillis(), sessionId});
        else getWritableDatabase().update(TABLE, values, "session_id=?", new String[]{sessionId});
    }

    public int getPendingCount() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + TABLE + " WHERE status IN ('pending','retry')", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public void cleanupOld(int daysOld) {
        long cutoff = System.currentTimeMillis() - Math.max(1, daysOld) * 24L * 60L * 60L * 1000L;
        getWritableDatabase().delete(TABLE, "status='sent' AND received_at < ?", new String[]{String.valueOf(cutoff)});
    }

    public static final class PendingSms {
        public final long id;
        public final String sessionId, sender, body, status, lastError;
        public final long receivedAt, lastAttemptAt;
        public final int attempts;
        private PendingSms(long id, String sessionId, String sender, String body, String status,
                           String lastError, long receivedAt, long lastAttemptAt, int attempts) {
            this.id = id; this.sessionId = sessionId; this.sender = sender; this.body = body;
            this.status = status; this.lastError = lastError; this.receivedAt = receivedAt;
            this.lastAttemptAt = lastAttemptAt; this.attempts = attempts;
        }
        static PendingSms from(Cursor c) {
            return new PendingSms(c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("session_id")),
                    c.getString(c.getColumnIndexOrThrow("sender")),
                    c.getString(c.getColumnIndexOrThrow("body")),
                    c.getString(c.getColumnIndexOrThrow("status")),
                    c.getString(c.getColumnIndexOrThrow("last_error")),
                    c.getLong(c.getColumnIndexOrThrow("received_at")),
                    c.isNull(c.getColumnIndexOrThrow("last_attempt_at")) ? 0 : c.getLong(c.getColumnIndexOrThrow("last_attempt_at")),
                    c.getInt(c.getColumnIndexOrThrow("attempts")));
        }
    }
}
