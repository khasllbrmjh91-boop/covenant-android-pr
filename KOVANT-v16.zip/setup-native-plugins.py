#!/usr/bin/env python3
"""
setup-native-plugins.py — كوفانت (Kova Cash)

Fixes the "البصمة غير مثبتة" (TuaBiometric undefined) issue described in
CAPACITOR-README.md, section (ج). Run this AFTER `npx cap add android`
and BEFORE `npx cap sync android`.

What it does, idempotently:
  1. Copies TuaBiometricPlugin.kt (biometric + secure local storage of the
     refresh_token, merged into one plugin) and TuaSmsSenderPlugin.kt from
     native-plugins/android/ into android/app/src/main/java/com/kova/cash/plugins/
  2. Patches MainActivity (.java or .kt) so the three plugins are
     registered with registerPlugin(...) BEFORE super.onCreate() runs
     (Capacitor requires this ordering — the Bridge that reads the
     plugin list is created inside super.onCreate()). Handles both:
       - a MainActivity that already overrides onCreate()
       - the default Capacitor 6 template, which has NO onCreate()
         override at all — in that case it adds one.
  3. Adds the two missing Gradle dependencies
     (androidx.biometric, androidx.security:security-crypto)
     to android/app/build.gradle if they're not already there.

Every file this script modifies is backed up first as <file>.bak.
Safe to re-run — it will not duplicate imports/registrations/deps.

Usage:
    cd <project root>          # the folder with capacitor.config.json
    python3 setup-native-plugins.py
"""

import re
import shutil
import sys
from pathlib import Path

PACKAGE = "com.kova.cash"
PLUGINS_PACKAGE = f"{PACKAGE}.plugins"
PLUGIN_FILES = ["TuaBiometricPlugin.kt", "TuaSmsSenderPlugin.kt", "TuaWifiManagerPlugin.kt", "TuaSmsInboxPlugin.kt", "TuaSmsSettingsPlugin.kt"]
PLUGIN_CLASSES = ["TuaBiometricPlugin", "TuaSmsSenderPlugin", "TuaWifiManagerPlugin", "TuaSmsInboxPlugin", "TuaSmsSettingsPlugin"]

GRADLE_DEPS = [
    ('androidx.biometric:biometric', '    implementation "androidx.biometric:biometric:1.1.0"'),
    ('androidx.security:security-crypto', '    implementation "androidx.security:security-crypto:1.1.0-alpha06"'),
]


def fail(msg):
    print(f"❌ {msg}")
    sys.exit(1)


def backup(path: Path):
    bak = path.with_suffix(path.suffix + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)
        print(f"   🗄  backup: {bak}")


def step1_copy_plugins(root: Path):
    src_dir = root / "native-plugins" / "android"
    android_main = root / "android" / "app" / "src" / "main" / "java" / Path(*PACKAGE.split("."))
    dest_dir = android_main / "plugins"

    if not (root / "android").is_dir():
        fail("android/ not found. Run `npx cap add android` first, then re-run this script.")

    dest_dir.mkdir(parents=True, exist_ok=True)
    print(f"📁 plugins package: {dest_dir}")

    for fname in PLUGIN_FILES:
        src = src_dir / fname
        if not src.is_file():
            print(f"   ⚠️  {fname} not found in native-plugins/android/, skipping")
            continue
        dest = dest_dir / fname
        shutil.copy2(src, dest)
        print(f"   ✅ copied {fname}")

    return android_main


def find_main_activity(android_main: Path):
    java = android_main / "MainActivity.java"
    kt = android_main / "MainActivity.kt"
    if java.is_file():
        return java, "java"
    if kt.is_file():
        return kt, "kotlin"
    fail(f"Could not find MainActivity.java or MainActivity.kt under {android_main}")


def patch_java(text: str) -> str:
    # 1) imports, right after the package line — only the ones missing
    missing_imports = [c for c in PLUGIN_CLASSES if f"import {PLUGINS_PACKAGE}.{c};" not in text]
    if missing_imports:
        imports = "\n".join(f"import {PLUGINS_PACKAGE}.{c};" for c in missing_imports)
        text = re.sub(r"(^package [^\n]+;\n)", r"\1\n" + imports + "\n", text, count=1, flags=re.M)

    # 2) registerPlugin(...) calls — only the ones missing (a plugin may already
    #    be registered from an earlier README step, e.g. TuaSmsSenderPlugin)
    missing_classes = [c for c in PLUGIN_CLASSES if f"registerPlugin({c}.class);" not in text]
    if not missing_classes:
        return text  # everything already registered

    registers = "\n".join(f"        registerPlugin({c}.class);" for c in missing_classes)

    if re.search(r"super\.onCreate\(", text):
        # Existing onCreate() — insert registrations right before super.onCreate(
        text = re.sub(
            r"([ \t]*)(super\.onCreate\()",
            registers + r"\n\1\2",
            text,
            count=1,
        )
    else:
        # Default Capacitor 6 template has no onCreate() override at all — add one.
        # Matches: `public class MainActivity extends BridgeActivity {` ... `}`
        m = re.search(r"(public class MainActivity extends BridgeActivity\s*\{)", text)
        if not m:
            fail("Couldn't locate 'public class MainActivity extends BridgeActivity {' to patch — edit MainActivity.java by hand using the snippet in CAPACITOR-README.md.")
        onCreate_block = (
            "\n"
            "    @Override\n"
            "    public void onCreate(android.os.Bundle savedInstanceState) {\n"
            f"{registers}\n"
            "        super.onCreate(savedInstanceState);\n"
            "    }\n"
        )
        text = text[: m.end()] + onCreate_block + text[m.end():]
        if "import android.os.Bundle;" not in text and "import android.os.*;" not in text:
            pass  # we used the fully-qualified android.os.Bundle above, so no import needed

    return text


def patch_kotlin(text: str) -> str:
    missing_imports = [c for c in PLUGIN_CLASSES if f"import {PLUGINS_PACKAGE}.{c}" not in text]
    if missing_imports:
        imports = "\n".join(f"import {PLUGINS_PACKAGE}.{c}" for c in missing_imports)
        text = re.sub(r"(^package [^\n]+\n)", r"\1\n" + imports + "\n", text, count=1, flags=re.M)

    missing_classes = [c for c in PLUGIN_CLASSES if f"registerPlugin({c}::class.java)" not in text]
    if not missing_classes:
        return text

    registers = "\n".join(f"        registerPlugin({c}::class.java)" for c in missing_classes)

    if re.search(r"super\.onCreate\(", text):
        text = re.sub(
            r"([ \t]*)(super\.onCreate\()",
            registers + r"\n\1\2",
            text,
            count=1,
        )
    else:
        m = re.search(r"(class MainActivity\s*:\s*BridgeActivity\(\)\s*\{)", text)
        if not m:
            fail("Couldn't locate 'class MainActivity : BridgeActivity() {' to patch — edit MainActivity.kt by hand using the snippet in CAPACITOR-README.md.")
        onCreate_block = (
            "\n"
            "    override fun onCreate(savedInstanceState: android.os.Bundle?) {\n"
            f"{registers}\n"
            "        super.onCreate(savedInstanceState)\n"
            "    }\n"
        )
        text = text[: m.end()] + onCreate_block + text[m.end():]

    return text


def step2_patch_main_activity(android_main: Path):
    path, lang = find_main_activity(android_main)
    print(f"🛠  patching {path} ({lang})")
    original = path.read_text(encoding="utf-8")
    patched = patch_java(original) if lang == "java" else patch_kotlin(original)

    if patched == original:
        print("   ✅ already patched, nothing to do")
        return

    backup(path)
    path.write_text(patched, encoding="utf-8")
    print("   ✅ registerPlugin(...) calls added before super.onCreate()")


def step3_patch_gradle(root: Path):
    gradle_path = root / "android" / "app" / "build.gradle"
    if not gradle_path.is_file():
        print(f"⚠️  {gradle_path} not found — add these two lines to its `dependencies {{ }}` block by hand:")
        for _, line in GRADLE_DEPS:
            print(f"   {line.strip()}")
        return

    text = gradle_path.read_text(encoding="utf-8")
    missing = [line for marker, line in GRADLE_DEPS if marker not in text]

    if not missing:
        print(f"✅ {gradle_path} already has the required dependencies")
        return

    m = re.search(r"dependencies\s*\{", text)
    if not m:
        print(f"⚠️  Couldn't find a `dependencies {{` block in {gradle_path} — add by hand:")
        for line in missing:
            print(f"   {line.strip()}")
        return

    backup(gradle_path)
    insert_at = m.end()
    addition = "\n" + "\n".join(missing)
    text = text[:insert_at] + addition + text[insert_at:]
    gradle_path.write_text(text, encoding="utf-8")
    print(f"✅ added {len(missing)} missing dependency line(s) to {gradle_path}")


def step4_patch_manifest_cleartext(root: Path):
    """السماح بـ HTTP (صفحة الراوتر http://www.c.com/status.html) — أندرويد 9+ يمنعه افتراضياً."""
    mf = root / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
    if not mf.is_file():
        print(f"⚠️  {mf} not found — add android:usesCleartextTraffic=\"true\" to <application> by hand.")
        return
    text = mf.read_text(encoding="utf-8")
    if "usesCleartextTraffic" in text:
        print("✓ usesCleartextTraffic already present")
        return
    backup(mf)
    text = text.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
    mf.write_text(text, encoding="utf-8")
    print("✓ added android:usesCleartextTraffic=\"true\"")


def main():
    root = Path.cwd()
    if not (root / "capacitor.config.json").is_file():
        fail("Run this from the project root (the folder with capacitor.config.json).")

    print("=== Step 1/3: copy plugin .kt files ===")
    android_main = step1_copy_plugins(root)

    print("\n=== Step 2/3: register plugins in MainActivity ===")
    step2_patch_main_activity(android_main)

    print("\n=== Step 3/3: Gradle dependencies ===")
    step3_patch_gradle(root)

    print("\n=== Step 4: allow cleartext HTTP (router page) ===")
    step4_patch_manifest_cleartext(root)

    print(
        "\n🎉 Done. Next steps:\n"
        "   npx cap sync android\n"
        "   npx cap open android   # rebuild from Android Studio (or ./gradlew assembleDebug)\n\n"
        "Verify by checking, after launch, that Capacitor.Plugins.TuaBiometric is an object\n"
        "(not undefined) in the WebView console. TuaBiometric now also handles secure local\n"
        "storage of the refresh_token itself — the old separate SecureStorage plugin no longer\n"
        "exists and does not need to be registered."
    )


if __name__ == "__main__":
    main()
