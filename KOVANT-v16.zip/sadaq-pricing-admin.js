'use strict';
const express = require('express');
const crypto = require('crypto');

module.exports = function createSadaqPricingAdmin({ db, fetch, verifyAdmin }) {
    const router = express.Router();
    const apiBase = String(process.env.TAIZTEL_API_URL || '').replace(/\/$/, '');
    const providerUser = String(process.env.TAIZTEL_USERNAME || '');
    const providerUserId = String(process.env.TAIZTEL_USERID || process.env.TAIZTEL_USERNAME || '');
    const password = String(process.env.TAIZTEL_PASSWORD || '');

    ['get', 'post', 'delete'].forEach(method => {
        const original = router[method].bind(router);
        router[method] = (path, ...handlers) => original(path, ...handlers.map(h => (req, res, next) => {
            try { return Promise.resolve(h(req, res, next)).catch(next); } catch (e) { return next(e); }
        }));
    });

    async function admin(req, res, next) {
        const check = await verifyAdmin(req);
        if (!check.isAdmin) return res.status(401).json({ success: false, error: 'غير مصرح' });
        req.sadaqAdmin = check; next();
    }
    function validMode(mode) { return ['percent', 'fixed', 'manual', 'none'].includes(mode); }
    function calculate(cost, mode, percent, fixed, manual) {
        const c = Number(cost) || 0;
        let sell = c;
        if (mode === 'percent') sell = c * (1 + (Number(percent) || 0) / 100);
        if (mode === 'fixed') sell = c + (Number(fixed) || 0);
        if (mode === 'manual') sell = Number(manual);
        if (!Number.isFinite(sell) || sell < 0) throw new Error('سعر البيع غير صالح');
        return { sell: Number(sell.toFixed(2)), profit: Number(Math.max(0, sell - c).toFixed(2)) };
    }
    function normalizedOffer(offerid, input, updatedBy, syncedFrom) {
        const cost = Number(input.cost ?? input.price ?? input.amount ?? 0);
        const mode = validMode(input.mode) ? input.mode : 'percent';
        const values = calculate(cost, mode, input.percent, input.fixed, input.manual);
        return {
            offerid: String(offerid), name: String(input.name || input.title || offerid), cost,
            sell: values.sell, profit: values.profit, mode,
            percent: Number(input.percent) || 0, fixed: Number(input.fixed) || 0,
            manual: Number(input.manual) || values.sell, active: input.active !== false,
            updatedAt: Date.now(), updatedBy: updatedBy || '999', syncedFrom: syncedFrom || input.syncedFrom || null
        };
    }
    async function providerOffers(mobile) {
        if (!apiBase || !providerUser || !providerUserId || !password) throw new Error('إعدادات تعز تل غير مكتملة');
        if (!/^[0-9]{9}$/.test(String(mobile || ''))) throw new Error('أدخل رقم يمن موبايل من 9 أرقام للمزامنة');
        const transid = `L${Date.now()}${crypto.randomBytes(3).toString('hex')}`;
        const hashPass = crypto.createHash('md5').update(password).digest('hex');
        const token = crypto.createHash('md5').update(hashPass + transid + providerUser + String(mobile || '')).digest('hex');
        const url = new URL(`${apiBase}/yem`);
        [['action', 'queryoffer'], ['userid', providerUserId], ['mobile', mobile || ''], ['transid', transid], ['token', token]].forEach(([k, v]) => url.searchParams.set(k, v));
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 25000);
        let response; let raw;
        try { response = await fetch(url.toString(), { headers: { Accept: 'application/json' }, signal: controller.signal }); raw = await response.text(); }
        catch (e) { throw new Error(e && e.name === 'AbortError' ? 'انتهت مهلة الاتصال بتعز تل' : 'تعذر الاتصال بتعز تل'); }
        finally { clearTimeout(timer); }
        let data; try { data = JSON.parse(raw); } catch (_) { data = { raw }; }
        if (!response.ok) throw new Error(`تعز تل HTTP ${response.status}`);
        const code = data && (data.resultCode ?? data.result_code);
        if (String(code) !== '0') throw new Error((data && data.resultDesc) || `رفضت تعز تل الطلب (رمز ${code === undefined ? 'غير معروف' : code})`);
        return data;
    }
    function extractOffers(data) {
        let raw = data && (data.offers || data.offer || data.data || data.result || data);
        if (raw && !Array.isArray(raw) && typeof raw === 'object') {
            raw = Object.entries(raw).map(([id, v]) =>
                (v && typeof v === 'object') ? { offerid: v.offerid || v.offerId || v.id || id, ...v } : null);
        }
        if (!Array.isArray(raw)) return [];
        const BAD = ['resultcode', 'resultdesc', 'transid', 'token', 'userid', 'status', 'message'];
        return raw
            .filter(o => o && typeof o === 'object')
            .map(o => ({ ...o,
                offerid: String(o.offerid || o.offerId || o.id || o.code || '').trim(),
                name: String(o.name || o.offerName || o.offername || '').replace(/\s+/g, ' ').trim() || undefined }))
            .filter(o => o.offerid && !BAD.includes(o.offerid.toLowerCase()));
    }

    router.get('/settings', admin, async (req, res) => {
        const snap = await db.ref('sadaq/pricing/settings').once('value');
        return res.json({ success: true, settings: snap.val() || { defaultMode: 'percent', defaultPercent: 10, defaultFixed: 150 } });
    });
    router.post('/settings', admin, async (req, res) => {
        try {
            const mode = String(req.body?.defaultMode || 'percent');
            if (!validMode(mode)) return res.status(400).json({ success: false, error: 'طريقة تسعير غير صحيحة' });
            const settings = { defaultMode: mode, defaultPercent: Number(req.body?.defaultPercent) || 0, defaultFixed: Number(req.body?.defaultFixed) || 0, updatedAt: Date.now(), updatedBy: req.sadaqAdmin.phone };
            await db.ref('sadaq/pricing/settings').update(settings);
            return res.json({ success: true, settings });
        } catch (error) { return res.status(400).json({ success: false, error: error.message }); }
    });
    router.get('/', admin, async (req, res) => {
        const snap = await db.ref('sadaq/pricing/offers').once('value');
        return res.json({ success: true, offers: snap.val() || {} });
    });
    router.post('/', admin, async (req, res) => {
        try {
            const offerid = String(req.body?.offerid || '').trim();
            if (!offerid) return res.status(400).json({ success: false, error: 'offerid مطلوب' });
            const offer = normalizedOffer(offerid, req.body, req.sadaqAdmin.phone);
            await db.ref(`sadaq/pricing/offers/${offerid}`).set(offer);
            return res.json({ success: true, offer });
        } catch (error) { return res.status(400).json({ success: false, error: error.message }); }
    });
    router.post('/bulk', admin, async (req, res) => {
        try {
            const offers = req.body?.offers;
            if (!offers || typeof offers !== 'object') return res.status(400).json({ success: false, error: 'offers غير صحيحة' });
            const updates = {};
            Object.entries(offers).forEach(([id, value]) => { updates[`sadaq/pricing/offers/${id}`] = normalizedOffer(id, value || {}, req.sadaqAdmin.phone); });
            await db.ref().update(updates);
            return res.json({ success: true, updated: Object.keys(updates).length });
        } catch (error) { return res.status(400).json({ success: false, error: error.message }); }
    });
    router.post('/apply-all', admin, async (req, res) => {
        try {
            const settings = (await db.ref('sadaq/pricing/settings').once('value')).val() || {};
            const mode = String(req.body?.mode || settings.defaultMode || 'percent');
            const percent = req.body?.percent ?? settings.defaultPercent;
            const fixed = req.body?.fixed ?? settings.defaultFixed;
            if (!validMode(mode)) return res.status(400).json({ success: false, error: 'طريقة تسعير غير صحيحة' });
            const current = (await db.ref('sadaq/pricing/offers').once('value')).val() || {};
            const updates = {};
            Object.entries(current).forEach(([id, offer]) => { updates[`sadaq/pricing/offers/${id}`] = normalizedOffer(id, { ...offer, mode, percent, fixed }, req.sadaqAdmin.phone, offer.syncedFrom); });
            if (Object.keys(updates).length) await db.ref().update(updates);
            return res.json({ success: true, updated: Object.keys(updates).length });
        } catch (error) { return res.status(400).json({ success: false, error: error.message }); }
    });
    router.delete('/:offerid', admin, async (req, res) => {
        await db.ref(`sadaq/pricing/offers/${req.params.offerid}`).remove();
        return res.json({ success: true });
    });
    router.post('/sync', admin, async (req, res) => {
        try {
            const data = await providerOffers(String(req.body?.mobile || ''));
            const rawOffers = extractOffers(data);
            const settings = (await db.ref('sadaq/pricing/settings').once('value')).val() || { defaultMode: 'percent', defaultPercent: 10, defaultFixed: 150 };
            const existing = (await db.ref('sadaq/pricing/offers').once('value')).val() || {};
            const updates = {};
            let added = 0;
            rawOffers.forEach(raw => {
                const id = String(raw.offerid || raw.id || raw.code || '').trim();
                if (!id) return;
                if (existing[id]) {
                    // باقة موجودة: لا نمس تسعيرها (التكلفة/النسبة/التفعيل). نحدّث وقت المزامنة فقط.
                    updates[`sadaq/pricing/offers/${id}/syncedAt`] = Date.now();
                    return;
                }
                // الوثيقة لا ترسل أسعاراً، فالباقة الجديدة تُنشأ بتكلفة 0 وغير مفعّلة حتى يسعّرها الأدمن ويفعّلها.
                const offer = normalizedOffer(id, { ...raw, cost: 0, active: false, mode: settings.defaultMode, percent: settings.defaultPercent, fixed: settings.defaultFixed }, req.sadaqAdmin.phone, 'taiztel');
                updates[`sadaq/pricing/offers/${id}`] = offer;
                added++;
            });
            if (Object.keys(updates).length) await db.ref().update(updates);
            await db.ref('sadaq/pricing/settings').update({ lastSync: Date.now(), lastSyncCount: rawOffers.length });
            return res.json({ success: true, count: rawOffers.length, added, result: data });
        } catch (error) { return res.status(502).json({ success: false, error: error.message }); }
    });
    return router;
};
