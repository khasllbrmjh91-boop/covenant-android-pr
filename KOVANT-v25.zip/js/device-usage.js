/* ═══════════════════════════════════════════════════════════════
   استهلاك الإنترنت — جدول يومي (جوال / واي فاي / المجموع)
   ───────────────────────────────────────────────────────────────
   • مستقل تماماً عن الراوتر: المصدر عدّادات نظام أندرويد للجهاز كله.
   • السجل يُكتب في الخلفية من خدمة الإشعار الدائم (سرعة الإنترنت في الإشعارات)
     حتى والتطبيق مغلق، ويُقرأ هنا عبر CovaTrafficStats.getUsageLog.
   • إن كان التطبيق قديماً (بدون getUsageLog) يعمل احتياطياً بسجل محلي تقريبي
     يُحدَّث أثناء فتح التطبيق، ويعرض المجموع فقط.
   ═══════════════════════════════════════════════════════════════ */
(function () {
    'use strict';
    if (window.__DEVICE_USAGE_LOADED__) return;
    window.__DEVICE_USAGE_LOADED__ = true;

    const LEGACY_KEY = 'kovant_device_usage_v1';
    const SHOW_DAYS = 30;

    const trafficPlugin = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CovaTrafficStats) || null;
    const notifPlugin = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TuaNotification) || null;
    const hasNative = () => { const p = trafficPlugin(); return !!(p && p.getUsageLog); };

    /* ── تنسيق الأرقام والتواريخ (حسب التصميم المعتمد) ── */
    function fmtBytes(b) {
        b = Math.max(0, b || 0);
        const trim = (n, d) => String(parseFloat(n.toFixed(d)));
        if (b >= 1073741824) return trim(b / 1073741824, 2) + ' ج ب';
        const mb = b / 1048576;
        return (mb >= 10 ? String(Math.round(mb)) : (mb >= 0.05 ? trim(mb, 1) : '0')) + ' م ب';
    }
    const pad = n => String(n).padStart(2, '0');
    const keyOf = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
    const labelOf = k => k.replace(/-/g, '/');

    /* ── مصدر البيانات ── */
    async function ensureService() {
        const n = notifPlugin();
        if (!n || !n.checkPermissions || !n.startForegroundService) return;
        try {
            let perm = await n.checkPermissions();
            if (perm.notifications !== 'granted' && n.requestPermissions) perm = await n.requestPermissions();
            if (perm.notifications === 'granted') await n.startForegroundService();
        } catch (_) {}
    }

    /* سجل احتياطي (تطبيق قديم): مجموع فقط */
    function legacyLoad() { try { const s = JSON.parse(localStorage.getItem(LEGACY_KEY) || 'null'); if (s && s.days) return s; } catch (_) {} return { days: {}, last: null }; }
    let legacy = legacyLoad();
    async function legacyTick() {
        const p = trafficPlugin(); if (!p || !p.getDeviceTraffic) return;
        try {
            const t = await p.getDeviceTraffic(), cur = t.rxBytes + t.txBytes;
            if (legacy.last != null) {
                const k = keyOf(new Date());
                legacy.days[k] = (legacy.days[k] || 0) + (cur >= legacy.last ? cur - legacy.last : cur);
            }
            legacy.last = cur;
            localStorage.setItem(LEGACY_KEY, JSON.stringify(legacy));
        } catch (_) {}
    }

    async function loadDays() {
        const p = trafficPlugin();
        const map = {};
        if (p && p.getUsageLog) {
            try {
                const r = await p.getUsageLog();
                (r.days || []).forEach(d => { map[d.date] = { mobile: d.mobile || 0, wifi: d.wifi || 0, kova: d.kova || 0 }; });
                return { map, split: true };
            } catch (_) {}
        }
        await legacyTick();
        Object.keys(legacy.days).forEach(k => { map[k] = { total: legacy.days[k] }; });
        return { map, split: false };
    }

    /* ── الواجهة (تصميم معتمد: شريط أزرق متدرج + جدول بخمسة أعمدة) ── */
    const CSS = `
    #deviceUsageInterface{position:fixed;inset:0;z-index:99997;display:none;flex-direction:column;background:#f1f5f9;color:#334155;direction:rtl;font-family:'Readex Pro','Cairo','Tajawal',sans-serif;-webkit-user-select:none;user-select:none}
    #deviceUsageInterface.active{display:flex}
    .du-bar{display:flex;align-items:center;gap:6px;padding:calc(10px + env(safe-area-inset-top)) 12px 10px;color:#fff;background:linear-gradient(90deg,#1d4ed8,#2563eb 50%,#4338ca);box-shadow:0 6px 16px rgba(30,64,175,.35);position:relative;z-index:10;flex-shrink:0}
    .du-bar h2{flex:1;margin:0;font-size:16px;font-weight:600}
    .du-btn{width:38px;height:38px;border-radius:50%;border:none;background:transparent;color:#fff;font-size:17px;cursor:pointer;display:flex;align-items:center;justify-content:center}
    .du-btn:active{background:rgba(255,255,255,.18)}
    .du-menu{position:absolute;top:calc(52px + env(safe-area-inset-top));left:10px;background:#fff;border:1px solid #cbd5e1;border-radius:12px;padding:6px;display:none;z-index:20;box-shadow:0 8px 24px rgba(15,23,42,.25)}
    .du-menu.open{display:block}
    .du-menu button{display:block;width:100%;text-align:right;background:none;border:none;color:#1e293b;font-family:inherit;font-size:13px;padding:10px 16px;border-radius:8px;cursor:pointer;white-space:nowrap}
    .du-menu button:active{background:#e2e8f0}
    .du-scroll{flex:1;overflow-y:auto;background:#f1f5f9;-webkit-overflow-scrolling:touch}
    .du-scroll::-webkit-scrollbar{width:4px}.du-scroll::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:4px}
    table.du-t{width:100%;border-collapse:collapse;text-align:center;font-size:12px}
    .du-t thead th{position:sticky;top:0;z-index:5;background:#2563eb;color:#fff;font-weight:600;font-size:12px;padding:12px 4px;border-bottom:1px solid #3b82f6;border-left:1px solid #60a5fa;box-shadow:0 1px 2px rgba(0,0,0,.08)}
    .du-t thead th:last-child{border-left:none}
    .du-t thead th.k{background:rgba(29,78,216,.75)}
    .du-t td{padding:10px 4px;border-left:1px solid #e2e8f0;border-bottom:1px solid rgba(219,234,254,.7);font-weight:400;color:#334155;white-space:nowrap}
    .du-t td:last-child{border-left:none;font-weight:500;color:#1e293b}
    .du-t td.d{font-weight:500;color:#0f172a}
    .du-t td.z{color:#64748b}
    .du-t td.k{color:#1d4ed8;font-weight:500;background:rgba(239,246,255,.5)}
    .du-t tr.w{background:#fff}
    .du-t tr.b{background:rgba(239,246,255,.5)}
    .du-t tr.b td.k{background:rgba(219,234,254,.3)}
    .du-t tr.today{background:rgba(219,234,254,.9);color:#172554}
    .du-t tr.today td{font-weight:500;color:#172554;border-left-color:#bfdbfe}
    .du-t tr.today td.d{font-weight:700;color:#1e40af;background:rgba(191,219,254,.4)}
    .du-t tr.today td.k{background:rgba(191,219,254,.3);color:#1e3a8a;font-weight:600}
    .du-t tfoot td{position:sticky;bottom:0;z-index:5;background:#bfdbfe;color:#172554;font-weight:700;font-size:12px;padding:12px 4px;border-top:1px solid #93c5fd;border-left:1px solid #93c5fd}
    .du-t tfoot td:last-child{border-left:none;color:#1d4ed8}
    .du-t tfoot td.d{color:#1e3a8a}
    .du-t tfoot td.k{color:#1e40af;background:#93c5fd}
    .du-empty{margin:60px auto;text-align:center;color:#64748b;padding:30px;line-height:1.9;font-size:13px}
    .du-note{font-size:11px;color:#64748b;padding:10px 14px;line-height:1.7;text-align:center}
    `;
    const HTML = `
    <div id="deviceUsageInterface">
        <div class="du-bar">
            <button class="du-btn" onclick="closeDeviceUsagePage()" aria-label="رجوع"><i class="fa-solid fa-arrow-right"></i></button>
            <h2>استهلاك الإنترنت</h2>
            <button class="du-btn" onclick="document.getElementById('duMenu').classList.toggle('open')" aria-label="المزيد"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        </div>
        <div class="du-menu" id="duMenu">
            <button onclick="refreshDeviceUsage()"><i class="fa-solid fa-rotate" style="margin-left:8px"></i>تحديث</button>
            <button onclick="resetDeviceUsage()"><i class="fa-solid fa-trash-can" style="margin-left:8px"></i>تصفير السجل</button>
        </div>
        <div class="du-scroll" id="duScroll"></div>
    </div>`;

    function inject() {
        if (document.getElementById('deviceUsageInterface')) return;
        const st = document.createElement('style'); st.id = 'device-usage-styles'; st.textContent = CSS; document.head.appendChild(st);
        const t = document.createElement('div'); t.innerHTML = HTML.trim(); document.body.appendChild(t.firstElementChild);
    }

    function rowCells(v, split, cls) {
        const z = x => (x ? '' : ' z');
        if (!split) return '<td class="z">—</td><td class="z">—</td><td class="k z">—</td><td>' + fmtBytes(v.t) + '</td>';
        return '<td class="' + (v.m ? '' : 'z') + '">' + fmtBytes(v.m) + '</td>' +
               '<td>' + fmtBytes(v.w) + '</td>' +
               '<td class="k">' + fmtBytes(v.k) + '</td>' +
               '<td>' + fmtBytes(v.t) + '</td>';
    }

    async function render() {
        const { map, split } = await loadDays();
        const box = document.getElementById('duScroll');
        if (!box) return;

        const now = new Date(), days = [];
        for (let i = 0; i < SHOW_DAYS; i++) { const d = new Date(now); d.setDate(d.getDate() - i); days.push(keyOf(d)); }
        const val = k => {
            const r = map[k] || {}, m = r.mobile || 0, w = r.wifi || 0, kk = r.kova || 0;
            return { m, w, k: kk, t: split ? m + w + kk : (r.total || 0) };
        };

        let body = '';
        days.forEach((k, i) => {
            const cls = i === 0 ? 'today' : (i % 2 === 1 ? 'w' : 'b');
            body += '<tr class="' + cls + '"><td class="d">' + (i === 0 ? 'اليوم' : labelOf(k)) + '</td>' + rowCells(val(k), split) + '</tr>';
        });

        const pre = keyOf(now).slice(0, 8);
        const tot = { m: 0, w: 0, k: 0, t: 0 };
        Object.keys(map).forEach(k => { if (k.startsWith(pre)) { const v = val(k); tot.m += v.m; tot.w += v.w; tot.k += v.k; tot.t += v.t; } });

        box.innerHTML = '<table class="du-t"><thead><tr><th>تاريخ</th><th>جوال</th><th>واي فاي</th><th class="k">كوفا نت</th><th>المجموع</th></tr></thead>' +
            '<tbody>' + body + '</tbody>' +
            '<tfoot><tr><td class="d">هذا الشهر</td>' + rowCells(tot, split).replace(/<td class="z">/g, '<td>').replace(/<td class="k z">/g, '<td class="k">') + '</tr></tfoot></table>' +
            (split ? '' : '<div class="du-note">هذا الإصدار من التطبيق لا يفصل الجوال والواي فاي وكوفا نت — حدّث التطبيق لتفعيل التسجيل في الخلفية والفصل بينها.</div>');
    }

    /* ── الفتح/الإغلاق ── */
    let pageOpen = false, timer = null;
    window.openDeviceUsagePage = async function () {
        inject();
        document.getElementById('deviceUsageInterface').classList.add('active');
        document.getElementById('duMenu').classList.remove('open');
        pageOpen = true;
        if (!trafficPlugin()) {
            document.getElementById('duScroll').innerHTML = '<div class="du-empty"><i class="fa-solid fa-mobile-screen" style="font-size:42px;color:#94a3b8;display:block;margin-bottom:12px"></i>قياس الاستهلاك متاح داخل تطبيق أندرويد فقط.</div>';
            return;
        }
        ensureService();
        await render();
        if (timer) clearInterval(timer);
        timer = setInterval(() => { if (pageOpen && !document.hidden) render(); }, 5000);
    };
    window.closeDeviceUsagePage = function () {
        pageOpen = false;
        if (timer) { clearInterval(timer); timer = null; }
        const p = document.getElementById('deviceUsageInterface'); if (p) p.classList.remove('active');
    };
    window.refreshDeviceUsage = function () { document.getElementById('duMenu').classList.remove('open'); render(); };
    window.resetDeviceUsage = function () {
        document.getElementById('duMenu').classList.remove('open');
        const doReset = async () => {
            const p = trafficPlugin();
            if (p && p.resetUsageLog) { try { await p.resetUsageLog(); } catch (_) {} }
            legacy = { days: {}, last: legacy.last }; try { localStorage.setItem(LEGACY_KEY, JSON.stringify(legacy)); } catch (_) {}
            render();
        };
        if (window.Swal) {
            Swal.fire({ title: 'تصفير السجل؟', text: 'سيُحذف سجل الاستهلاك المحفوظ على هذا الجهاز.', icon: 'warning', showCancelButton: true,
                confirmButtonText: 'تصفير', cancelButtonText: 'إلغاء', background: '#161b22', color: '#e6edf3', confirmButtonColor: '#c0392b', cancelButtonColor: '#2a3340'
            }).then(r => { if (r.isConfirmed) doReset(); });
        } else if (confirm('تصفير سجل الاستهلاك؟')) doReset();
    };

    /* ── تشغيل التسجيل: خدمة الإشعار الدائمة تسجّل في الخلفية؛ والاحتياطي المحلي يعمل أثناء فتح التطبيق فقط ── */
    function boot() {
        setTimeout(async () => {
            const n = notifPlugin();
            if (n && n.checkPermissions && n.startForegroundService) {
                try { const perm = await n.checkPermissions(); if (perm.notifications === 'granted') await n.startForegroundService(); } catch (_) {}
            }
            if (!hasNative()) { legacyTick(); setInterval(() => { if (!document.hidden) legacyTick(); }, 30000); }
        }, 3000);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
