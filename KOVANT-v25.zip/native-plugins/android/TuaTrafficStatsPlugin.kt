package com.kova.cash.plugins

import android.content.Context
import android.net.wifi.WifiManager
import android.net.TrafficStats
import android.os.Process
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CovaUsageLog — سجل الاستهلاك اليومي (جوال / واي فاي) المحفوظ على الجهاز.
 * يُستدعى من خدمة الإشعار الدائم (CovaForegroundService) كل بضع ثوانٍ، ومن getUsageLog.
 * العدّادات تراكمية منذ إقلاع الجهاز: نحفظ آخر قراءة ونضيف الفرق إلى سجل اليوم،
 * وإذا صارت القراءة أصغر من السابقة (إعادة تشغيل) يُحتسب الجديد كله.
 */
object CovaUsageLog {
    private const val PREFS = "cova_usage_log"
    private val lock = Any()


    /**
     * هل الجهاز متصل الآن بشبكة كوفانت؟
     * 1) بالاسم (SSID) إن كان قابلاً للقراءة (يتطلب صلاحية الموقع).
     * 2) وإلا بالبوابة (gateway) التي حُفظت آخر مرة عُرف فيها أن الشبكة كوفانت.
     */
    @Suppress("DEPRECATION")
    private fun isKovantNow(ctx: Context, p: android.content.SharedPreferences): Boolean {
        return try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return false
            val info = wm.connectionInfo
            if (info == null || info.networkId == -1) return false
            val gw = wm.dhcpInfo?.gateway ?: 0
            val ssid = (info.ssid ?: "").replace("\"", "")
            val readable = ssid.isNotEmpty() && !ssid.contains("unknown", ignoreCase = true)
            if (readable) {
                val match = Regex("coav|cova|kovant|كوفا", RegexOption.IGNORE_CASE).containsMatchIn(ssid)
                if (match && gw != 0) p.edit().putInt("kovant_gw", gw).apply()
                match
            } else {
                val saved = p.getInt("kovant_gw", 0)
                saved != 0 && gw == saved
            }
        } catch (_: Exception) {
            false
        }
    }
    private fun dayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun sample(ctx: Context) {
        synchronized(lock) {
            try {
                val rx = TrafficStats.getTotalRxBytes()
                val tx = TrafficStats.getTotalTxBytes()
                if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return

                val mRx = TrafficStats.getMobileRxBytes()
                val mTx = TrafficStats.getMobileTxBytes()
                val hasMobile = mRx != TrafficStats.UNSUPPORTED.toLong() && mTx != TrafficStats.UNSUPPORTED.toLong()

                val total = rx + tx
                val mobile = if (hasMobile) mRx + mTx else 0L

                val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val lastTotal = p.getLong("last_total", -1L)
                val lastMobile = p.getLong("last_mobile", -1L)
                val ed = p.edit()
                if (!p.contains("since")) ed.putLong("since", System.currentTimeMillis())

                if (lastTotal >= 0L) {
                    val dTotal = if (total >= lastTotal) total - lastTotal else total
                    var dMobile = 0L
                    if (hasMobile && lastMobile >= 0L) {
                        dMobile = if (mobile >= lastMobile) mobile - lastMobile else mobile
                    }
                    if (dMobile > dTotal) dMobile = dTotal
                    var dWifi = dTotal - dMobile
                    var dKova = 0L
                    // ما استُهلك أثناء الاتصال بشبكة كوفانت يُسجَّل في عمود كوفا نت (وليس واي فاي)
                    if (dWifi > 0L && isKovantNow(ctx, p)) {
                        dKova = dWifi
                        dWifi = 0L
                    }
                    if (dTotal > 0L) {
                        val key = dayKey()
                        ed.putLong("m_$key", p.getLong("m_$key", 0L) + dMobile)
                        ed.putLong("w_$key", p.getLong("w_$key", 0L) + dWifi)
                        ed.putLong("k_$key", p.getLong("k_$key", 0L) + dKova)
                    }
                }
                ed.putLong("last_total", total).putLong("last_mobile", mobile).apply()
            } catch (_: Exception) {
            }
        }
    }

    fun readDays(ctx: Context): JSArray {
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val dates = java.util.TreeSet<String>()
        for (k in p.all.keys) {
            if (k.startsWith("m_") || k.startsWith("w_") || k.startsWith("k_")) dates.add(k.substring(2))
        }
        val arr = JSArray()
        for (d in dates) {
            val o = JSObject()
            o.put("date", d)
            o.put("mobile", p.getLong("m_$d", 0L))
            o.put("wifi", p.getLong("w_$d", 0L))
            o.put("kova", p.getLong("k_$d", 0L))
            arr.put(o)
        }
        return arr
    }

    fun since(ctx: Context): Long =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("since", System.currentTimeMillis())

    fun reset(ctx: Context) {
        synchronized(lock) {
            val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val gw = sp.getInt("kovant_gw", 0)
            val ed = sp.edit().clear()
            if (gw != 0) ed.putInt("kovant_gw", gw)
            ed.apply()
        }
    }
}

/**
 * TuaTrafficStats — قراءة استهلاك الشبكة من نظام أندرويد مباشرة.
 *
 * يُستخدم لقياس السرعة اللحظية (تنزيل/رفع) بنفس أسلوب تطبيقات مراقبة السرعة.
 *
 * - getUidTraffic: استهلاك التطبيق فقط (بدون أذونات)
 * - getDeviceTraffic: استهلاك الجهاز كامل (الأدق لمراقبة كرت كوفانت)
 * - isSupported: التحقق من دعم العدّادات على هذا الجهاز
 */
@CapacitorPlugin(name = "CovaTrafficStats")
class TuaTrafficStatsPlugin : Plugin() {

    @PluginMethod
    fun getUidTraffic(call: PluginCall) {
        try {
            val uid = Process.myUid()
            val rx = TrafficStats.getUidRxBytes(uid)
            val tx = TrafficStats.getUidTxBytes(uid)

            if (rx == TrafficStats.UNSUPPORTED.toLong() ||
                tx == TrafficStats.UNSUPPORTED.toLong()) {
                call.reject("UNSUPPORTED", "الجهاز لا يدعم عدّادات التطبيق")
                return
            }

            val result = JSObject()
            result.put("rxBytes", rx)
            result.put("txBytes", tx)
            result.put("timestamp", System.currentTimeMillis())
            call.resolve(result)

        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun getDeviceTraffic(call: PluginCall) {
        try {
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()

            if (rx == TrafficStats.UNSUPPORTED.toLong() ||
                tx == TrafficStats.UNSUPPORTED.toLong()) {
                call.reject("UNSUPPORTED", "الجهاز لا يدعم العدّادات الكلية")
                return
            }

            val result = JSObject()
            result.put("rxBytes", rx)
            result.put("txBytes", tx)
            result.put("timestamp", System.currentTimeMillis())
            call.resolve(result)

        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun getMobileTraffic(call: PluginCall) {
        try {
            val rx = TrafficStats.getMobileRxBytes()
            val tx = TrafficStats.getMobileTxBytes()

            if (rx == TrafficStats.UNSUPPORTED.toLong() ||
                tx == TrafficStats.UNSUPPORTED.toLong()) {
                call.reject("UNSUPPORTED", "الجهاز لا يدعم عدّادات بيانات الجوال")
                return
            }

            val result = JSObject()
            result.put("rxBytes", rx)
            result.put("txBytes", tx)
            result.put("timestamp", System.currentTimeMillis())
            call.resolve(result)

        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun getUsageLog(call: PluginCall) {
        try {
            CovaUsageLog.sample(context)
            val res = JSObject()
            res.put("days", CovaUsageLog.readDays(context))
            res.put("since", CovaUsageLog.since(context))
            call.resolve(res)
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun resetUsageLog(call: PluginCall) {
        try {
            CovaUsageLog.reset(context)
            CovaUsageLog.sample(context)
            call.resolve(JSObject().put("success", true))
        } catch (e: Exception) {
            call.reject("Failed: ${e.message}")
        }
    }

    @PluginMethod
    fun isSupported(call: PluginCall) {
        try {
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val supported = rx != TrafficStats.UNSUPPORTED.toLong() &&
                            tx != TrafficStats.UNSUPPORTED.toLong()

            val result = JSObject()
            result.put("supported", supported)
            call.resolve(result)

        } catch (e: Exception) {
            val result = JSObject()
            result.put("supported", false)
            result.put("error", e.message)
            call.resolve(result)
        }
    }
}