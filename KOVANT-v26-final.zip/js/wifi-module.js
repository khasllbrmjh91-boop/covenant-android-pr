/* ═══════════════════════════════════════════════════════════════════
   COVA NET — WiFi Module v5 (TrafficStats + Session Once)
   ═══════════════════════════════════════════════════════════════════
   التغييرات الرئيسية عن v4:
   1. جلب status.html مرة واحدة فقط عند بدء الجلسة
   2. قياس السرعة من CovaTrafficStats (نظام أندرويد) كل ثانية
   3. حساب الرصيد والوقت محلياً (لا جلب دوري)
   4. تجميد كامل عند الخروج من شبكة كوفانت
   5. استئناف هادئ عند العودة
*/

(function() {
    'use strict';

    if (window.__WIFI_MODULE_LOADED__) return;
    window.__WIFI_MODULE_LOADED__ = true;

    let _wifiRouterBase = null;
    let _wifiScanInterval = null;
    let _wifiTotalSeconds = 0;
    let _wifiLastScanResults = [];
    let _currentPage = 'networks';

    /* ── حالة تبويب البيانات (تصميم المقاييس السائلة) ── */
    let _cwdDownPeak = 0;
    let _cwdUpPeak = 0;
    let _cwdConsumedSeconds = 0;
    let _cwdSparkHistory = new Array(30).fill(0);
    let _cwdCurrentTheme = null;
    let _cwdAlerted = false;
    let _cwdThreshold = 500;
    let _cwdWired = false;
    try {
        const savedThreshold = localStorage.getItem('kovant_wifi_balance_threshold');
        if (savedThreshold) {
            const n = Number(savedThreshold);
            if (n >= 100 && n <= 3000) _cwdThreshold = n;
        }
    } catch (_) {}

    /* ═══════════════════════════════════════════════════
       حالة الجلسة — نظام واحد يجلب مرة + يحسب محلياً
       ═══════════════════════════════════════════════════ */
    const _cova = {
        active: false,           // هل الجلسة نشطة؟
        frozen: false,           // هل التجميد مفعل؟
        isKovant: false,         // هل نحن على شبكة كوفانت؟

        // من status.html — البذرة الأولية
        initialRemainingBytes: 0,
        initialUploadBytes: 0,
        initialDownloadBytes: 0,
        remainingBytes: 0,
        unlimited: false,
        ip: '',
        speedLabel: '',

        // من TrafficStats — خط الأساس
        baselineRx: 0,
        baselineTx: 0,
        lastRx: 0,
        lastTx: 0,
        lastTrafficTime: 0,
        downBps: 0,
        upBps: 0,
        trafficSupported: true,

        // مؤقتات
        trafficTimer: null,
        localTimer: null,
        networkTimer: null,

        // آخر SSID
        lastSsid: null,
        lastFetchError: '',
        emptyReason: '',

        // حالة الكرت وشاشة الدخول
        hasData: false,           // هل بيانات كرت معروضة الآن؟
        lastFetchKind: '',        // ok | notLoggedIn | unreachable
        lastLoginPageHtml: '',
        timeLimited: false,
        dataLimited: false,
        expiryChecking: false,
        nextExpiryCheck: 0
    };

    /* ═══════════════════════════════════════════════════
       Helpers
       ═══════════════════════════════════════════════════ */
    function esc(str) {
        return String(str == null ? '' : str).replace(/[&<>"']/g, m => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        })[m]);
    }

    function alertSafe(msg, ok = true) {
        if (typeof showAlert === 'function') {
            try { showAlert(msg, ok); return; } catch (_) {}
        }
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                title: ok ? 'تنبيه' : 'خطأ',
                text: msg,
                icon: ok ? 'info' : 'error',
                background: '#161b22',
                color: '#e6edf3',
                confirmButtonColor: '#1a6fa8'
            });
            return;
        }
        alert(msg);
    }

    function getWifiPlugin() { return window.Capacitor?.Plugins?.TuaWifiManager || null; }
    function getNotifPlugin() { return window.Capacitor?.Plugins?.TuaNotification || null; }
    function getTrafficPlugin() { return window.Capacitor?.Plugins?.CovaTrafficStats || null; }

    function wifiSignalIconSVG(percent) {
        let tier = 1, color = '#f87171';
        if (percent >= 70) { tier = 3; color = '#10b981'; }
        else if (percent >= 40) { tier = 2; color = '#fbbf24'; }
        const dim = 'rgba(255,255,255,0.15)';
        const c1 = tier >= 1 ? color : dim;
        const c2 = tier >= 2 ? color : dim;
        const c3 = tier >= 3 ? color : dim;
        return `<svg viewBox="0 0 24 24" width="26" height="26" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="19" r="1.7" fill="${color}"></circle>
            <path d="M8.3 15.3a5.2 5.2 0 0 1 7.4 0" stroke="${c1}" stroke-width="2.2" fill="none" stroke-linecap="round"></path>
            <path d="M5.1 11.7a9.7 9.7 0 0 1 13.8 0" stroke="${c2}" stroke-width="2.2" fill="none" stroke-linecap="round"></path>
            <path d="M1.9 8.1a14.2 14.2 0 0 1 20.2 0" stroke="${c3}" stroke-width="2.2" fill="none" stroke-linecap="round"></path>
        </svg>`;
    }

    function wifiStrengthMeta(level) {
        const percent = Math.max(0, Math.min(100, Math.round(((level + 100) / 70) * 100)));
        const cls = percent >= 70 ? 'strong' : percent >= 40 ? 'medium' : 'weak';
        const label = percent >= 70 ? 'قوية' : percent >= 40 ? 'متوسطة' : 'ضعيفة';
        return { percent, cls, label };
    }

    /* ═══════════════════════════════════════════════════
       CSS — نفس التصميم
       ═══════════════════════════════════════════════════ */
    const WIFI_CSS = `
    #wifiInterface {
        position: fixed; inset: 0;
        background: #010714;
        color: #fff;
        font-family: 'Cairo', 'Tajawal', sans-serif;
        z-index: 99998;
        display: none;
        flex-direction: column;
        overflow-y: auto;
        direction: rtl;
    }
    #wifiInterface.active { display: flex; }

    .wifi-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 14px 16px;
        background: rgba(10, 21, 39, 0.95);
        backdrop-filter: blur(20px);
        border-bottom: 1px solid rgba(2, 163, 254, 0.15);
        position: sticky; top: 0; z-index: 100;
        flex-shrink: 0;
    }
    .wifi-back-btn, .wifi-refresh-btn {
        width: 40px; height: 40px; border-radius: 12px;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.08);
        color: #e6edf3;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; font-size: 16px; transition: all 0.25s;
    }
    .wifi-back-btn:active, .wifi-refresh-btn:active {
        transform: scale(0.92);
        background: rgba(2,163,254,0.15);
        color: #02a3fe;
    }
    .wifi-header-title {
        font-size: 17px; font-weight: 800;
        background: linear-gradient(135deg, #ffffff, #f7e1b5);
        -webkit-background-clip: text; background-clip: text;
        color: transparent;
    }

    .wifi-tabs {
        display: flex; gap: 6px;
        padding: 12px 18px;
        background: rgba(10,21,39,0.6);
        border-bottom: 1px solid rgba(255,255,255,0.04);
        overflow-x: auto; flex-shrink: 0;
    }
    .wifi-tabs::-webkit-scrollbar { display: none; }
    .wifi-tab {
        flex: 1; min-width: 95px;
        padding: 10px 12px; border-radius: 12px;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.06);
        color: #8fa5c0;
        font-family: 'Cairo', sans-serif;
        font-size: 12px; font-weight: 700;
        cursor: pointer; transition: all 0.25s;
        display: flex; align-items: center; justify-content: center;
        gap: 6px; white-space: nowrap;
    }
    .wifi-tab.active {
        background: linear-gradient(135deg, rgba(2,163,254,0.2), rgba(196,161,97,0.15));
        border-color: rgba(2,163,254,0.4);
        color: #02a3fe;
        box-shadow: 0 4px 16px rgba(2,163,254,0.15);
    }
    .wifi-tab-content { display: none; padding: 18px; flex: 1; overflow-y: auto; }
    .wifi-tab-content.active { display: block; }
    /* وضع «الشبكات القريبة فقط»: يُخفي شريط التبويبات (الشبكات / الراوتر) */
    #wifiInterface.nearby-only .wifi-tabs { display: none !important; }

    .wifi-scan-status {
        display: flex; align-items: center; justify-content: center;
        gap: 10px; padding: 40px 20px;
        color: #6c7e97; font-size: 13px; font-weight: 600;
    }
    .wifi-scan-status i { color: #02a3fe; font-size: 22px; }
    .wifi-networks-list { display: flex; flex-direction: column; gap: 10px; }

    .wifi-network-card {
        display: flex; align-items: center; gap: 12px;
        padding: 14px 16px;
        background: linear-gradient(135deg, #0a1527, #0d1b32);
        border: 1px solid rgba(2,163,254,0.12);
        border-radius: 16px; cursor: pointer; transition: all 0.25s;
    }
    .wifi-network-card:active {
        transform: scale(0.98);
        border-color: rgba(2,163,254,0.4);
        background: linear-gradient(135deg, #0d1b32, #122040);
    }
    .wifi-network-card.connected {
        border-color: rgba(16,185,129,0.4);
        background: linear-gradient(135deg, rgba(16,185,129,0.08), #0d1b32);
        box-shadow: 0 4px 20px rgba(16,185,129,0.15);
    }
    .wifi-net-icon {
        width: 44px; height: 44px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }
    .wifi-net-info { flex: 1; min-width: 0; text-align: right; }
    .wifi-net-ssid {
        font-size: 15px; font-weight: 800; color: #fff; margin-bottom: 5px;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        display: flex; align-items: center; justify-content: flex-end; gap: 6px;
    }
    .wifi-net-ssid i.lock-badge { font-size: 11px; color: #f87171; }
    .wifi-net-meta { display: flex; gap: 6px; justify-content: flex-end; flex-wrap: wrap; }
    .wifi-net-chip {
        padding: 2px 8px;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 6px; font-size: 10px; font-weight: 700; color: #8fa5c0;
    }
    .wifi-net-chip.strong { color: #10b981; border-color: rgba(16,185,129,0.3); }
    .wifi-net-chip.medium { color: #fbbf24; border-color: rgba(251,191,36,0.3); }
    .wifi-net-chip.weak { color: #f87171; border-color: rgba(239,68,68,0.3); }
    .wifi-net-badge {
        padding: 3px 8px;
        background: rgba(16,185,129,0.15);
        border: 1px solid rgba(16,185,129,0.35);
        border-radius: 20px; font-size: 9px; font-weight: 700;
        color: #34d399; margin-left: 8px;
    }

    .wifi-permission-box {
        display: flex; flex-direction: column; align-items: center;
        padding: 40px 24px 30px; text-align: center;
    }
    .wifi-permission-icon-wrap {
        width: 100px; height: 100px;
        background: linear-gradient(135deg, rgba(2,163,254,0.15), rgba(2,163,254,0.05));
        border: 2px solid rgba(2,163,254,0.3);
        border-radius: 28px;
        display: flex; align-items: center; justify-content: center;
        margin-bottom: 24px; position: relative;
        box-shadow: 0 0 50px rgba(2,163,254,0.25);
        animation: wifi-perm-pulse 2.5s ease-in-out infinite;
    }
    @keyframes wifi-perm-pulse {
        0%, 100% { box-shadow: 0 0 50px rgba(2,163,254,0.25); transform: scale(1); }
        50% { box-shadow: 0 0 70px rgba(2,163,254,0.4); transform: scale(1.03); }
    }
    .wifi-permission-icon-wrap i {
        font-size: 46px; color: #02a3fe;
        filter: drop-shadow(0 0 12px rgba(2,163,254,0.5));
    }
    .wifi-permission-title {
        font-size: 21px; font-weight: 800; color: #ffffff;
        margin-bottom: 12px; letter-spacing: -0.3px; line-height: 1.3;
    }
    .wifi-permission-desc {
        font-size: 14px; color: #8fa5c0; line-height: 1.7;
        max-width: 300px; margin: 0 auto 8px; font-weight: 500;
    }
    .wifi-permission-hint {
        font-size: 12px; color: #6c7e97; line-height: 1.6;
        max-width: 300px; margin: 0 auto 26px; padding: 12px 16px;
        background: rgba(2,163,254,0.06);
        border: 1px solid rgba(2,163,254,0.15);
        border-radius: 12px; text-align: right;
    }
    .wifi-permission-hint i { color: #02a3fe; margin-left: 4px; }
    .wifi-permission-hint strong { color: #58b8e8; font-weight: 800; }
    .wifi-permission-actions {
        display: flex; gap: 12px; width: 100%; max-width: 340px; margin: 0 auto;
    }
    .wifi-perm-btn {
        flex: 1; padding: 15px 20px; border: none; border-radius: 15px;
        font-family: 'Cairo', sans-serif; font-size: 14px; font-weight: 800;
        cursor: pointer; transition: all 0.25s;
        display: flex; align-items: center; justify-content: center;
        gap: 8px; letter-spacing: 0.3px;
    }
    .wifi-perm-btn.primary {
        background: linear-gradient(135deg, #2563eb, #02a3fe);
        color: #fff; box-shadow: 0 8px 24px rgba(2,163,254,0.4);
    }
    .wifi-perm-btn.primary:active { transform: scale(0.96); box-shadow: 0 4px 16px rgba(2,163,254,0.6); }
    .wifi-perm-btn.secondary {
        background: rgba(255,255,255,0.05); color: #8fa5c0;
        border: 1px solid rgba(255,255,255,0.1);
    }
    .wifi-perm-btn.secondary:active { transform: scale(0.96); background: rgba(255,255,255,0.1); }
    .wifi-perm-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    .wifi-perm-btn.loading i { animation: wifi-spin 1s linear infinite; }
    @keyframes wifi-spin { to { transform: rotate(360deg); } }

    .wifi-empty-state {
        display: flex; flex-direction: column; align-items: center;
        padding: 60px 20px; text-align: center; color: #6c7e97;
    }
    .wifi-empty-state i { font-size: 60px; color: rgba(2,163,254,0.3); margin-bottom: 16px; }
    .wifi-empty-state p { font-size: 14px; font-weight: 600; line-height: 1.6; }

    #wifiNetworkDetailsPage {
        position: absolute; inset: 0;
        background: #010714;
        z-index: 15;
        display: none;
        flex-direction: column;
        overflow-y: auto;
    }
    #wifiNetworkDetailsPage.active { display: flex; }
    .wifi-detail-hero {
        display: flex; flex-direction: column; align-items: center;
        padding: 34px 20px 24px; text-align: center;
    }
    .wifi-detail-icon-wrap {
        width: 84px; height: 84px; border-radius: 24px;
        background: linear-gradient(135deg, rgba(2,163,254,0.15), rgba(2,163,254,0.05));
        border: 2px solid rgba(2,163,254,0.25);
        display: flex; align-items: center; justify-content: center;
        margin-bottom: 18px;
    }
    .wifi-detail-ssid { font-size: 19px; font-weight: 900; color: #fff; margin-bottom: 6px; word-break: break-word; }
    .wifi-detail-badge {
        padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 800;
    }
    .wifi-detail-grid { padding: 0 18px 24px; display: flex; flex-direction: column; gap: 10px; }
    .wifi-detail-row {
        display: flex; align-items: center; justify-content: space-between;
        padding: 14px 16px;
        background: linear-gradient(135deg, #0a1527, #0d1b32);
        border: 1px solid rgba(2,163,254,0.12);
        border-radius: 14px;
    }
    .wifi-detail-row-label { display: flex; align-items: center; gap: 8px; color: #8fa5c0; font-size: 13px; font-weight: 700; }
    .wifi-detail-row-label i { color: #02a3fe; width: 18px; text-align: center; }
    .wifi-detail-row-value { font-size: 14px; font-weight: 800; color: #fff; direction: ltr; }

    #wifiTab-data { padding: 16px 14px !important; }

    #wifiDataContent {
        display: flex; flex-direction: column; gap: 14px;
        --cwd-wave-1: rgba(16,185,129,.42); --cwd-wave-2: rgba(5,150,105,.88);
        --cwd-text: #6ee7b7; --cwd-glow: rgba(16,185,129,.55);
    }

    .cwd-topbar { display: flex; align-items: center; justify-content: space-between; }
    .cwd-live-badge {
        display: flex; align-items: center; gap: 6px; padding: 5px 11px; border-radius: 999px;
        font-size: 10.5px; font-weight: 800; color: #6ee7b7;
        background: rgba(16,185,129,.10); border: 1px solid rgba(16,185,129,.28);
        transition: all 0.4s ease;
    }
    .cwd-live-dot { width: 6px; height: 6px; border-radius: 50%; background: #10b981; box-shadow: 0 0 8px #10b981; animation: cwdLive 1.6s ease-in-out infinite; }
    @keyframes cwdLive { 0%, 100% { opacity: 1; } 50% { opacity: .35; } }
    .cwd-bell-btn {
        position: relative; width: 34px; height: 34px; display: grid; place-items: center;
        border-radius: 11px; background: rgba(2,163,254,.10); border: 1px solid rgba(2,163,254,.25);
        color: #58b8e8; font-size: 13px; cursor: pointer; transition: all .3s;
    }
    .cwd-bell-btn.armed::after {
        content: ''; position: absolute; top: 5px; right: 5px; width: 6px; height: 6px; border-radius: 50%;
        background: #fbbf24; box-shadow: 0 0 8px #fbbf24;
    }
    .cwd-bell-btn.alert {
        color: #fb7185; background: rgba(244,63,94,.14); border-color: rgba(244,63,94,.55);
        animation: cwdBellShake 1.4s ease-in-out infinite;
    }
    @keyframes cwdBellShake {
        0%, 100% { transform: rotate(0); } 15% { transform: rotate(14deg); } 30% { transform: rotate(-12deg); }
        45% { transform: rotate(10deg); } 60% { transform: rotate(-8deg); } 75% { transform: rotate(6deg); } 90% { transform: rotate(-4deg); }
    }

    .cwd-gauge-card {
        position: relative; display: flex; flex-direction: column; align-items: center;
        padding: 20px 14px; border-radius: 22px;
        background: linear-gradient(150deg, rgba(10,21,39,.9), rgba(4,10,20,.96));
        border: 1px solid rgba(255,255,255,.07);
        box-shadow: 0 20px 44px -22px rgba(0,0,0,.9);
        overflow: hidden; transition: border-color 1.2s ease, box-shadow 1.2s ease;
    }
    .cwd-gauge-card.alert {
        border-color: rgba(244,63,94,.4);
        box-shadow: 0 20px 44px -22px rgba(0,0,0,.9), 0 0 34px -8px rgba(244,63,94,.4);
    }

    .cwd-gauge-wrap { position: relative; display: grid; place-items: center; width: 206px; height: 206px; }
    .cwd-gauge-sm { width: 132px; height: 132px; }

    .cwd-ring { position: absolute; inset: 0; width: 100%; height: 100%; transform: rotate(-90deg); }
    .cwd-ring circle { fill: none; stroke-width: 4; stroke-linecap: round; }
    .cwd-ring-track { stroke: rgba(148,163,184,.12); }
    .cwd-ring-bar { stroke-dasharray: var(--circ); stroke-dashoffset: var(--circ); transition: stroke-dashoffset 1.4s ease; }

    .cwd-fluid-circle {
        position: relative; border-radius: 50%; overflow: hidden;
        display: flex; align-items: center; justify-content: center;
        background: radial-gradient(circle at 50% 25%, #0b1226 0%, #030712 78%);
        box-shadow: inset 0 6px 20px rgba(0,0,0,.9);
    }
    .cwd-fluid-lg { width: 176px; height: 176px; }
    .cwd-fluid-sm { width: 106px; height: 106px; }
    .cwd-fluid-circle::after {
        content: ''; position: absolute; top: 6%; left: 14%; width: 46%; height: 30%; border-radius: 50%;
        background: linear-gradient(180deg, rgba(255,255,255,.10), transparent); filter: blur(6px); z-index: 8;
    }

    .cwd-fluid { position: absolute; left: 0; bottom: 0; width: 100%; height: var(--fill,0%); transition: height 1.6s ease; z-index: 1; }
    .cwd-waves { position: absolute; left: 0; bottom: 0; width: 200%; height: 140%; }
    .cwd-wave-1 { fill: var(--cwd-wave-1); animation: cwdWave 16s cubic-bezier(.36,.45,.63,.53) infinite; }
    .cwd-wave-2 { fill: var(--cwd-wave-2); opacity: .92; animation: cwdWave 10s cubic-bezier(.36,.45,.63,.53) infinite reverse; }
    @keyframes cwdWave {
        0% { transform: translate3d(0,0,0); } 50% { transform: translate3d(-25%,0,0) scaleY(1.1); } 100% { transform: translate3d(-50%,0,0); }
    }

    .cwd-gauge-text { position: relative; z-index: 5; text-align: center; padding: 0 8px; }
    .cwd-g-label { display: block; font-size: 11px; font-weight: 700; color: rgba(255,255,255,.78); margin-bottom: 3px; text-shadow: 0 2px 6px rgba(0,0,0,.9); }
    .cwd-g-value { display: block; font-weight: 900; font-size: 30px; color: #fff; letter-spacing: -.5px; font-variant-numeric: tabular-nums; text-shadow: 0 3px 12px rgba(0,0,0,.9), 0 0 26px var(--cwd-glow); }
    .cwd-g-value small { font-size: 13px; font-weight: 700; color: var(--cwd-text); margin-inline-start: 4px; }
    .cwd-g-sub { display: block; font-size: 10px; font-weight: 700; color: var(--cwd-text); margin-top: 3px; text-shadow: 0 2px 6px rgba(0,0,0,.9); }
    .cwd-s-label { display: block; font-size: 9px; font-weight: 700; color: rgba(255,255,255,.75); margin-bottom: 2px; text-shadow: 0 2px 5px rgba(0,0,0,.9); }
    .cwd-s-value { display: block; font-weight: 900; font-size: 17px; color: #fff; font-variant-numeric: tabular-nums; line-height: 1; }
    .cwd-s-sub { display: block; font-size: 8.5px; font-weight: 700; margin-top: 3px; color: var(--cwd-accent-sub,#7dd3fc); }

    .cwd-bubble {
        position: absolute; bottom: 0; border-radius: 50%; background: rgba(255,255,255,.5);
        opacity: 0; animation-name: cwdBubble; animation-timing-function: linear; animation-iteration-count: infinite; pointer-events: none;
    }
    @keyframes cwdBubble {
        0% { bottom: 0%; opacity: 0; transform: scale(.4); } 12% { opacity: .7; transform: scale(1); }
        75% { opacity: .4; } 100% { bottom: 92%; opacity: 0; transform: scale(1.1); }
    }

    .cwd-mini-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .cwd-mini-card {
        display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 14px 8px 11px;
        border-radius: 18px; background: linear-gradient(150deg, rgba(10,21,39,.85), rgba(4,10,20,.95));
        border: 1px solid rgba(255,255,255,.06);
    }
    .cwd-mini-foot { font-size: 9.5px; font-weight: 700; color: #6c7e97; }

    .cwd-speed-section {
        display: flex; flex-direction: column; gap: 12px; padding: 14px 12px 12px; border-radius: 20px;
        background: linear-gradient(150deg, rgba(10,21,39,.85), rgba(4,10,20,.95)); border: 1px solid rgba(255,255,255,.06);
    }
    .cwd-speed-head { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 800; color: #e6edf3; }
    .cwd-speed-head i { font-size: 11px; color: #58b8e8; padding: 6px; border-radius: 8px; background: rgba(2,163,254,.12); border: 1px solid rgba(2,163,254,.22); }

    .cwd-speed-duo { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .cwd-speedo {
        position: relative; border-radius: 16px; background: linear-gradient(150deg, rgba(20,30,50,.6), rgba(4,10,20,.9));
        border: 1px solid rgba(255,255,255,.06); padding: 10px 8px 8px; display: flex; flex-direction: column; align-items: center; overflow: hidden;
    }
    .cwd-speedo-tag { display: flex; align-items: center; gap: 5px; font-size: 10px; font-weight: 700; color: #8fa5c0; margin-bottom: 2px; }
    .cwd-speedo-svg { width: 100%; height: auto; display: block; }
    .cwd-track { fill: none; stroke: rgba(148,163,184,.12); stroke-width: 6; stroke-linecap: round; }
    .cwd-fill-arc {
        fill: none; stroke: var(--accent); stroke-width: 6; stroke-linecap: round;
        stroke-dasharray: var(--arc-len); stroke-dashoffset: var(--arc-len); transition: stroke-dashoffset 1.2s ease;
        filter: drop-shadow(0 0 5px color-mix(in srgb, var(--accent) 70%, transparent));
    }
    .cwd-needle {
        stroke: #f8fafc; stroke-width: 2.2; stroke-linecap: round; transform-origin: 100px 108px;
        transform: rotate(-90deg); transition: transform 1.2s cubic-bezier(.34,1.4,.5,1);
    }
    .cwd-needle-cap { fill: #f8fafc; }
    .cwd-speedo-readout { position: absolute; top: 56%; left: 50%; transform: translate(-50%,-20%); text-align: center; pointer-events: none; }
    .cwd-speedo-num { display: block; font-weight: 900; font-size: 22px; color: #fff; font-variant-numeric: tabular-nums; letter-spacing: -.5px; line-height: 1; }
    .cwd-speedo-unit { display: block; font-size: 9px; font-weight: 700; color: #6c7e97; margin-top: 3px; }
    .cwd-speedo-foot { display: flex; justify-content: center; gap: 4px; width: 100%; margin-top: 2px; font-size: 9px; color: #6c7e97; font-weight: 600; }

    .cwd-sparkline-card { border-radius: 14px; padding: 9px 11px 6px; background: rgba(0,10,20,.5); border: 1px solid rgba(255,255,255,.05); }
    .cwd-sparkline-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px; font-size: 10px; font-weight: 700; color: #8fa5c0; }
    .cwd-sparkline-head span:last-child { color: #58b8e8; }
    .cwd-sparkline { display: block; width: 100%; height: 52px; }
    .cwd-spark-line { fill: none; stroke: #02a3fe; stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; filter: drop-shadow(0 0 4px rgba(2,163,254,.6)); }
    .cwd-spark-area { fill: url(#cwdSparkGrad); }

    .cwd-data-card {
        border-radius: 18px; background: linear-gradient(150deg, rgba(10,21,39,.85), rgba(4,10,20,.95));
        border: 1px solid rgba(255,255,255,.06); padding: 2px 14px;
    }
    .cwd-data-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 11px 0; border-bottom: 1px solid rgba(255,255,255,.05); }
    .cwd-data-row:last-child { border-bottom: none; }
    .cwd-data-row > span:first-child { font-size: 11.5px; font-weight: 600; color: #8fa5c0; }
    .cwd-data-row > span:last-child { font-weight: 700; font-size: 12.5px; color: #fff; direction: ltr; }
    .cwd-badge { display: inline-flex; align-items: center; gap: 5px; padding: 4px 9px; border-radius: 999px; font-size: 10.5px; font-weight: 700; color: #6ee7b7; background: rgba(16,185,129,.10); border: 1px solid rgba(16,185,129,.24); }

    .cwd-bell-modal {
        position: fixed; inset: 0; background: rgba(2,6,23,.78); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
        display: grid; place-items: center; z-index: 100050; opacity: 0; pointer-events: none; transition: opacity .35s ease; padding: 20px;
    }
    .cwd-bell-modal.open { opacity: 1; pointer-events: auto; }
    .cwd-bell-dialog {
        width: 100%; max-width: 340px; background: linear-gradient(155deg, rgba(12,20,36,.98), rgba(4,10,20,1));
        border: 1px solid rgba(2,163,254,.28); border-radius: 22px; padding: 20px 18px 16px;
        transform: translateY(14px) scale(.96); transition: transform .35s cubic-bezier(.34,1.4,.5,1);
    }
    .cwd-bell-modal.open .cwd-bell-dialog { transform: translateY(0) scale(1); }
    .cwd-bell-dialog-head { display: flex; align-items: center; gap: 11px; margin-bottom: 14px; }
    .cwd-bell-dialog-head .ico {
        width: 40px; height: 40px; display: grid; place-items: center; border-radius: 13px;
        background: linear-gradient(145deg, rgba(251,191,36,.2), rgba(245,158,11,.08)); border: 1px solid rgba(251,191,36,.35); color: #fbbf24; font-size: 15px;
    }
    .cwd-bell-dialog-head h3 { font-size: 14.5px; font-weight: 800; color: #e6edf3; }
    .cwd-bell-dialog-head p { font-size: 10px; color: #6c7e97; margin-top: 2px; }
    .cwd-bell-threshold-display {
        display: flex; align-items: baseline; justify-content: center; gap: 6px; padding: 14px 10px; border-radius: 16px;
        background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.05); margin-bottom: 14px;
    }
    .cwd-bell-threshold-display .num { font-size: 38px; font-weight: 900; color: #fbbf24; }
    .cwd-bell-threshold-display .unit { font-size: 13px; font-weight: 700; color: rgba(251,191,36,.7); }
    .cwd-bell-range { -webkit-appearance: none; width: 100%; height: 6px; border-radius: 999px; background: #334155; margin-bottom: 4px; cursor: pointer; }
    .cwd-bell-range::-webkit-slider-thumb { -webkit-appearance: none; width: 22px; height: 22px; border-radius: 50%; background: #f8fafc; border: 3px solid #05070d; box-shadow: 0 0 0 2px rgba(251,191,36,.8); cursor: grab; }
    .cwd-bell-range::-moz-range-thumb { width: 22px; height: 22px; border-radius: 50%; background: #f8fafc; border: 3px solid #05070d; box-shadow: 0 0 0 2px rgba(251,191,36,.8); cursor: grab; }
    .cwd-bell-range-labels { display: flex; justify-content: space-between; font-size: 9px; color: #6c7e97; font-weight: 600; margin-bottom: 12px; }
    .cwd-bell-presets { display: grid; grid-template-columns: repeat(4,1fr); gap: 6px; margin-bottom: 16px; }
    .cwd-bell-preset { padding: 8px 4px; border-radius: 10px; background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.05); color: #8fa5c0; font-size: 10px; font-weight: 700; cursor: pointer; }
    .cwd-bell-preset.active { background: rgba(251,191,36,.14); border-color: rgba(251,191,36,.5); color: #fbbf24; }
    .cwd-bell-dialog-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .cwd-bell-dialog-actions button { padding: 11px; border-radius: 12px; font-size: 12px; font-weight: 700; cursor: pointer; border: 1px solid transparent; }
    .cwd-bell-dialog-actions .cancel { background: rgba(255,255,255,.04); border-color: rgba(255,255,255,.06); color: #8fa5c0; }
    .cwd-bell-dialog-actions .save { background: linear-gradient(135deg, rgba(251,191,36,.18), rgba(217,119,6,.32)); border-color: rgba(251,191,36,.45); color: #fbbf24; }

    .cwd-toasts {
        position: absolute; left: 50%; bottom: 14px; transform: translateX(-50%);
        display: flex; flex-direction: column-reverse; align-items: center; gap: 8px;
        z-index: 100010; pointer-events: none; width: calc(100% - 32px); max-width: 360px;
    }
    .cwd-toast {
        display: flex; align-items: center; gap: 9px; padding: 11px 16px; border-radius: 14px;
        font-size: 12px; font-weight: 700; color: #e6edf3; background: rgba(10,20,36,.96);
        border: 1px solid rgba(244,63,94,.4); box-shadow: 0 14px 32px -14px rgba(0,0,0,1);
        opacity: 0; transform: translateY(14px) scale(.94); transition: opacity .4s ease, transform .4s cubic-bezier(.34,1.4,.5,1);
    }
    .cwd-toast.show { opacity: 1; transform: translateY(0) scale(1); }
    .cwd-toast i { color: #fb7185; font-size: 13px; }

    @media (max-width: 360px) {
        .cwd-gauge-wrap { width: 180px; height: 180px; }
        .cwd-fluid-lg { width: 154px; height: 154px; }
        .cwd-g-value { font-size: 26px; }
        .cwd-gauge-sm { width: 118px; height: 118px; }
        .cwd-fluid-sm { width: 94px; height: 94px; }
        .cwd-s-value { font-size: 15px; }
        .cwd-speedo-num { font-size: 19px; }
    }

    /* ═══════ تصميم الشبكات القريبة الجديد (nb-) ═══════ */
    #wifiInterface .nb-card { display:flex; align-items:center; gap:12px; padding:16px 14px; background:linear-gradient(135deg,#161b22,#0f1621); border:1px solid rgba(255,255,255,0.06); border-radius:16px; position:relative; cursor:pointer; direction:rtl; transition:transform .2s, background .2s; }
    #wifiInterface .nb-first .nb-card { animation:nbSlideUp .4s ease backwards; }
    #wifiInterface .nb-first .nb-card:nth-child(2){animation-delay:.05s} #wifiInterface .nb-first .nb-card:nth-child(3){animation-delay:.1s} #wifiInterface .nb-first .nb-card:nth-child(4){animation-delay:.15s} #wifiInterface .nb-first .nb-card:nth-child(5){animation-delay:.2s}
    @keyframes nbSlideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    #wifiInterface .nb-card:active { transform:scale(.98); background:rgba(255,255,255,0.03); }
    #wifiInterface .nb-card.connected { border-color:rgba(16,185,129,0.4); background:linear-gradient(135deg,rgba(16,185,129,0.08),rgba(15,22,33,0.9)); box-shadow:0 4px 20px rgba(16,185,129,0.12); }
    #wifiInterface .nb-lock { width:26px; height:26px; display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:14px; }
    #wifiInterface .nb-lock.locked { color:#ef4444; } #wifiInterface .nb-lock.open { color:#3b82f6; }
    #wifiInterface .nb-info { flex:1; min-width:0; text-align:right; }
    #wifiInterface .nb-ssid { font-size:15px; font-weight:800; color:#fff; margin-bottom:6px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:flex; align-items:center; gap:8px; justify-content:flex-end; }
    #wifiInterface .nb-badge { font-size:9px; font-weight:700; color:#10b981; background:rgba(16,185,129,0.15); padding:2px 8px; border-radius:20px; border:1px solid rgba(16,185,129,0.3); }
    #wifiInterface .nb-badge.gold { color:#fbbf24; background:rgba(251,191,36,0.15); border-color:rgba(251,191,36,0.3); }
    #wifiInterface .nb-meta { display:flex; align-items:center; gap:6px; justify-content:flex-end; }
    #wifiInterface .nb-chip { display:inline-flex; align-items:center; padding:3px 9px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08); border-radius:8px; font-size:10px; font-weight:700; color:#8b98a5; white-space:nowrap; }
    #wifiInterface .nb-chip.freq { color:#58b8e8; }
    #wifiInterface .nb-chip.signal { color:#fff; font-weight:800; }
    #wifiInterface .nb-chip.excellent { background:rgba(59,130,246,0.15); border-color:rgba(59,130,246,0.3); color:#58b8e8; }
    #wifiInterface .nb-chip.good { background:rgba(251,191,36,0.15); border-color:rgba(251,191,36,0.3); color:#fbbf24; }
    #wifiInterface .nb-chip.fair { background:rgba(249,115,22,0.15); border-color:rgba(249,115,22,0.3); color:#f97316; }
    #wifiInterface .nb-chip.weak { background:rgba(239,68,68,0.15); border-color:rgba(239,68,68,0.3); color:#ef4444; }
    #wifiInterface .nb-arrow { width:20px; height:20px; display:flex; align-items:center; justify-content:center; color:#4a5568; font-size:12px; flex-shrink:0; }
    #wifiInterface .nb-wifi { width:52px; height:52px; display:flex; align-items:center; justify-content:center; flex-shrink:0; position:relative; padding:4px; }
    #wifiInterface .nb-wifi svg { width:100%; height:100%; display:block; overflow:visible; filter:drop-shadow(0 2px 6px rgba(0,0,0,0.3)); }
    #wifiInterface .nb-wifi .arc { opacity:.12; fill:none; transition:opacity .35s, stroke .35s; }
    #wifiInterface .nb-wifi .dot { opacity:.35; transition:fill .35s, opacity .35s; }
    #wifiInterface .nb-wifi.l1 .dot { fill:#ef4444; opacity:1; } #wifiInterface .nb-wifi.l1 .arc { stroke:#ef4444; }
    #wifiInterface .nb-wifi.l2 .dot { fill:#f97316; opacity:1; } #wifiInterface .nb-wifi.l2 .arc { stroke:#f97316; } #wifiInterface .nb-wifi.l2 .arc-1 { opacity:1; }
    #wifiInterface .nb-wifi.l3 .dot { fill:#fbbf24; opacity:1; } #wifiInterface .nb-wifi.l3 .arc { stroke:#fbbf24; } #wifiInterface .nb-wifi.l3 .arc-1, #wifiInterface .nb-wifi.l3 .arc-2 { opacity:1; }
    #wifiInterface .nb-wifi.l4 .dot { fill:#3b82f6; opacity:1; } #wifiInterface .nb-wifi.l4 .arc { stroke:#3b82f6; opacity:1; }
    #wifiInterface .nb-wifi.conn .dot { fill:#10b981 !important; opacity:1 !important; } #wifiInterface .nb-wifi.conn .arc { stroke:#10b981 !important; opacity:1 !important; }
    #wifiInterface .nb-wifi.conn::after { content:''; position:absolute; top:2px; left:2px; width:10px; height:10px; background:#10b981; border:2px solid #0a0f1a; border-radius:50%; box-shadow:0 0 8px rgba(16,185,129,0.6); animation:nbPulse 2s ease-in-out infinite; }
    @keyframes nbPulse { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.15);opacity:.7} }

    /* صفحة التفاصيل الجديدة */
    #wifiNetworkDetailsPage { background:#0a0f1a; overflow:hidden; direction:rtl; }
    #wifiNetworkDetailsPage .nb-dh { display:flex; align-items:center; padding:14px 12px; gap:8px; background:#0a0f1a; border-bottom:1px solid rgba(255,255,255,0.04); min-height:76px; flex-shrink:0; }
    #wifiNetworkDetailsPage .nb-dbtn { width:40px; height:40px; display:flex; align-items:center; justify-content:center; border:none; border-radius:10px; background:transparent; color:#e6edf3; font-size:18px; cursor:pointer; flex-shrink:0; }
    #wifiNetworkDetailsPage .nb-dbtn:active { background:rgba(255,255,255,0.08); transform:scale(.95); }
    #wifiNetworkDetailsPage .nb-dtitle { flex:1; text-align:center; min-width:0; padding:0 4px; }
    #wifiNetworkDetailsPage .nb-dline { display:flex; align-items:center; justify-content:center; gap:8px; margin-bottom:4px; flex-direction:row-reverse; }
    #wifiNetworkDetailsPage .nb-dline h1 { font-size:17px; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin:0; }
    #wifiNetworkDetailsPage .nb-dconn { display:inline-flex; align-items:center; gap:4px; padding:3px 10px; background:#052e1f; color:#10b981; border-radius:20px; font-size:10px; font-weight:700; border:1px solid #065f46; flex-shrink:0; }
    #wifiNetworkDetailsPage .nb-dconn i { width:6px; height:6px; background:#10b981; border-radius:50%; box-shadow:0 0 6px #10b981; animation:nbPulse 2s ease-in-out infinite; }
    #wifiNetworkDetailsPage .nb-dmac { font-size:11px; color:#6b7a8a; direction:ltr; letter-spacing:.5px; font-weight:500; }
    #wifiNetworkDetailsPage .nb-dscroll { flex:1; overflow-y:auto; padding:14px 14px 30px; }
    #wifiNetworkDetailsPage .nb-dscroll::-webkit-scrollbar { width:0; }
    #wifiNetworkDetailsPage .nb-hero { display:flex; align-items:center; gap:12px; padding:16px 14px; background:linear-gradient(135deg,#1a1f2e,#12161f); border:1px solid rgba(255,255,255,0.05); border-radius:18px; margin-bottom:12px; }
    #wifiNetworkDetailsPage .nb-hchips { display:flex; flex-direction:column; gap:6px; flex-shrink:0; }
    #wifiNetworkDetailsPage .nb-hchip { display:inline-flex; align-items:center; justify-content:center; padding:5px 10px; background:rgba(59,130,246,0.12); border:1px solid rgba(59,130,246,0.25); border-radius:8px; color:#58b8e8; font-size:11px; font-weight:700; direction:ltr; white-space:nowrap; min-width:62px; }
    #wifiNetworkDetailsPage .nb-hcenter { flex:1; text-align:center; min-width:0; padding:0 4px; }
    #wifiNetworkDetailsPage .nb-hpct { font-size:30px; font-weight:900; line-height:1; margin-bottom:4px; }
    #wifiNetworkDetailsPage .nb-hdbm { font-size:12px; color:#8b98a5; font-weight:600; direction:ltr; margin-bottom:4px; }
    #wifiNetworkDetailsPage .nb-hlabel { font-size:13px; font-weight:800; }
    #wifiNetworkDetailsPage .nb-tabs { display:flex; gap:4px; margin-bottom:14px; padding:5px; background:#12161f; border:1px solid rgba(255,255,255,0.05); border-radius:14px; }
    #wifiNetworkDetailsPage .nb-tab { flex:1; padding:10px 6px; border:none; background:transparent; color:#6b7a8a; font-family:inherit; font-size:12px; font-weight:700; cursor:pointer; border-radius:10px; display:flex; align-items:center; justify-content:center; gap:6px; }
    #wifiNetworkDetailsPage .nb-tab.active { background:linear-gradient(135deg,#1a3a5f,#142b47); color:#58b8e8; box-shadow:0 2px 10px rgba(59,130,246,0.15); border:1px solid rgba(88,184,232,0.25); }
    #wifiNetworkDetailsPage .nb-icard { background:linear-gradient(135deg,#1a1f2e,#12161f); border:1px solid rgba(255,255,255,0.05); border-radius:18px; margin-bottom:12px; overflow:hidden; }
    #wifiNetworkDetailsPage .nb-ich { display:flex; align-items:center; gap:10px; padding:14px 16px; }
    #wifiNetworkDetailsPage .nb-ict { font-size:14px; font-weight:800; color:#fff; }
    #wifiNetworkDetailsPage .nb-ici { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:16px; flex-shrink:0; padding:8px; color:#fff; }
    #wifiNetworkDetailsPage .nb-ici svg { width:100%; height:100%; overflow:visible; }
    #wifiNetworkDetailsPage .nb-ici svg .arc, #wifiNetworkDetailsPage .nb-ici svg .dot { fill:#fff; stroke:#fff; opacity:1; }
    #wifiNetworkDetailsPage .nb-ici svg .arc { fill:none; }
    #wifiNetworkDetailsPage .nb-ici.orange { background:linear-gradient(135deg,#b45309,#d97706); } #wifiNetworkDetailsPage .nb-ici.blue { background:linear-gradient(135deg,#1e40af,#2563eb); }
    #wifiNetworkDetailsPage .nb-ici.green { background:linear-gradient(135deg,#065f46,#10b981); } #wifiNetworkDetailsPage .nb-ici.cyan { background:linear-gradient(135deg,#0e7490,#06b6d4); }
    #wifiNetworkDetailsPage .nb-ici.red { background:linear-gradient(135deg,#991b1b,#dc2626); } #wifiNetworkDetailsPage .nb-ici.teal { background:linear-gradient(135deg,#0f766e,#14b8a6); }
    #wifiNetworkDetailsPage .nb-row { display:flex; align-items:center; justify-content:space-between; padding:13px 16px; gap:12px; min-height:46px; }
    #wifiNetworkDetailsPage .nb-row:not(:last-child), #wifiNetworkDetailsPage .nb-proto:not(:last-child) { border-bottom:1px solid rgba(255,255,255,0.035); }
    #wifiNetworkDetailsPage .nb-rl { font-size:12px; color:#8b98a5; font-weight:600; text-align:right; flex-shrink:0; }
    #wifiNetworkDetailsPage .nb-rv { font-size:13px; font-weight:800; color:#fff; text-align:left; flex:1; word-break:break-word; }
    #wifiNetworkDetailsPage .nb-rv.ltr { direction:ltr; }
    #wifiNetworkDetailsPage .nb-proto { display:flex; align-items:center; justify-content:space-between; padding:14px 16px; gap:12px; min-height:60px; }
    #wifiNetworkDetailsPage .nb-pr { display:flex; flex-direction:column; gap:3px; text-align:right; flex:1; min-width:0; }
    #wifiNetworkDetailsPage .nb-pn { font-size:14px; font-weight:800; color:#fff; direction:ltr; text-align:right; }
    #wifiNetworkDetailsPage .nb-pd { font-size:11px; color:#8b98a5; font-weight:500; }
    #wifiNetworkDetailsPage .nb-pb { display:inline-flex; align-items:center; gap:5px; padding:5px 11px; border-radius:20px; font-size:10px; font-weight:700; white-space:nowrap; flex-shrink:0; background:rgba(148,163,184,0.08); color:#94a3b8; border:1px solid rgba(148,163,184,0.15); }
    #wifiNetworkDetailsPage .nb-pb.yes { background:rgba(16,185,129,0.12); color:#10b981; border-color:rgba(16,185,129,0.3); }
    #wifiNetworkDetailsPage .nb-hlive { display:inline-flex; align-items:center; gap:6px; margin-top:6px; padding:3px 10px; border-radius:20px; font-size:10px; font-weight:700; color:#10b981; background:rgba(16,185,129,0.12); border:1px solid rgba(16,185,129,0.3); }
    #wifiNetworkDetailsPage .nb-hlive .nb-ldot { width:7px; height:7px; border-radius:50%; background:#10b981; animation:nbLivePulse 1.4s infinite; }
    #wifiNetworkDetailsPage .nb-hlive.off { color:#94a3b8; background:rgba(148,163,184,0.10); border-color:rgba(148,163,184,0.25); }
    #wifiNetworkDetailsPage .nb-hlive.off .nb-ldot { background:#94a3b8; animation:none; }
    @keyframes nbLivePulse { 0%,100% { opacity:1; } 50% { opacity:.3; } }
    `;

    /* ═══════════════════════════════════════════════════
       HTML — نفس التصميم
       ═══════════════════════════════════════════════════ */
    const WIFI_HTML = `
    <div id="wifiInterface">
        <div id="wifiNetworksPage" style="display:flex; flex-direction:column; width:100%; height:100%; position:absolute; inset:0;">
            <div class="wifi-header">
                <button class="wifi-back-btn" onclick="closeWifiPage()">
                    <i class="fa-solid fa-arrow-right"></i>
                </button>
                <h2 class="wifi-header-title">شبكة كوفا نت</h2>
                <button class="wifi-refresh-btn" onclick="loadWifiNetworks()">
                    <i class="fa-solid fa-rotate"></i>
                </button>
            </div>

            <div class="wifi-tabs">
                <button class="wifi-tab active" data-tab="nearby" onclick="switchWifiTab('nearby', this)">
                    <i class="fa-solid fa-wifi"></i> الشبكات
                </button>
                <button class="wifi-tab" data-tab="data" onclick="switchWifiTab('data', this)">
                    <i class="fa-solid fa-tower-broadcast"></i> الراوتر
                </button>
            </div>

            <div id="wifiTab-nearby" class="wifi-tab-content active" style="flex:1; overflow-y:auto;">
                <div class="wifi-scan-status" id="wifiScanStatus">
                    <i class="fa-solid fa-circle-notch fa-spin"></i>
                    <span>جاري البحث عن الشبكات...</span>
                </div>
                <div class="wifi-networks-list" id="wifiNetworksList"></div>
            </div>

            <div id="wifiTab-data" class="wifi-tab-content">
                <div id="wifiDataEmpty" class="wifi-empty-state">
                    <i class="fa-solid fa-sim-card"></i>
                    <p>لا توجد بيانات كرت متاحة حالياً<br><small id="wifiEmptyHint" style="color:#6c7e97;">تأكد إن جهازك متصل بشبكة كوفا نت</small></p>
                </div>

                <div id="wifiDataContent" style="display:none;">

                    <div class="cwd-topbar">
                        <span class="cwd-live-badge" id="cwdLiveBadge"><span class="cwd-live-dot"></span> مباشر</span>
                        <button class="cwd-bell-btn" id="cwdBellBtn" title="تنبيه الرصيد المتبقي"><i class="fa-solid fa-bell"></i></button>
                    </div>

                    <div class="cwd-gauge-card" id="cwdGaugeCard">
                        <div class="cwd-gauge-wrap">
                            <svg class="cwd-ring" viewBox="0 0 206 206" aria-hidden="true">
                                <defs>
                                    <linearGradient id="cwdGradMain" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stop-color="#10b981" id="cwdGradStop1"/>
                                        <stop offset="55%" stop-color="#34d399" id="cwdGradStop2"/>
                                        <stop offset="100%" stop-color="#6ee7b7" id="cwdGradStop3"/>
                                    </linearGradient>
                                </defs>
                                <circle class="cwd-ring-track" cx="103" cy="103" r="98"/>
                                <circle class="cwd-ring-bar" id="cwdRingMain" cx="103" cy="103" r="98" stroke="url(#cwdGradMain)" style="--circ:615.75; filter:drop-shadow(0 0 7px rgba(16,185,129,.55));"/>
                            </svg>
                            <div class="cwd-fluid-circle cwd-fluid-lg" id="cwdDataGauge" style="--fill:0%;">
                                <div class="cwd-fluid" id="cwdDataFluid">
                                    <svg class="cwd-waves" viewBox="0 0 400 120" preserveAspectRatio="none" aria-hidden="true">
                                        <path class="cwd-wave-1" d="M0,42 C50,12 50,72 100,42 C150,12 150,72 200,42 C250,12 250,72 300,42 C350,12 350,72 400,42 L400,120 L0,120 Z"/>
                                        <path class="cwd-wave-2" d="M0,52 C50,80 50,24 100,52 C150,80 150,24 200,52 C250,80 250,24 300,52 C350,80 350,24 400,52 L400,120 L0,120 Z"/>
                                    </svg>
                                </div>
                                <div class="cwd-gauge-text">
                                    <span class="cwd-g-label">الرصيد المتبقي</span>
                                    <span class="cwd-g-value" id="cwdDataVal">--<small>GB</small></span>
                                    <span class="cwd-g-sub" id="cwdDataSub">جارٍ التحميل…</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="cwd-mini-grid">
                        <div class="cwd-mini-card">
                            <div class="cwd-gauge-wrap cwd-gauge-sm">
                                <svg class="cwd-ring" viewBox="0 0 132 132" aria-hidden="true">
                                    <defs>
                                        <linearGradient id="cwdGradCyan" x1="0%" y1="0%" x2="100%" y2="100%">
                                            <stop offset="0%" stop-color="#67e8f9"/>
                                            <stop offset="100%" stop-color="#0891b2"/>
                                        </linearGradient>
                                    </defs>
                                    <circle class="cwd-ring-track" cx="66" cy="66" r="61"/>
                                    <circle class="cwd-ring-bar" id="cwdRingConsumed" cx="66" cy="66" r="61" stroke="url(#cwdGradCyan)" style="--circ:383.3; filter:drop-shadow(0 0 6px rgba(34,211,238,.6));"/>
                                </svg>
                                <div class="cwd-fluid-circle cwd-fluid-sm" id="cwdConsumedGauge" style="--fill:0%; --cwd-accent-sub:#67e8f9;">
                                    <div class="cwd-fluid" id="cwdConsumedFluid">
                                        <svg class="cwd-waves" viewBox="0 0 400 120" preserveAspectRatio="none" aria-hidden="true">
                                            <path class="cwd-wave-1" style="fill:rgba(34,211,238,.38);" d="M0,42 C50,12 50,72 100,42 C150,12 150,72 200,42 C250,12 250,72 300,42 C350,12 350,72 400,42 L400,120 L0,120 Z"/>
                                            <path class="cwd-wave-2" style="fill:rgba(8,145,178,.88);opacity:.92;" d="M0,52 C50,80 50,24 100,52 C150,80 150,24 200,52 C250,80 250,24 300,52 C350,80 350,24 400,52 L400,120 L0,120 Z"/>
                                        </svg>
                                    </div>
                                    <div class="cwd-gauge-text">
                                        <span class="cwd-s-label">الوقت المستهلك</span>
                                        <span class="cwd-s-value" id="cwdConsumedVal">--</span>
                                        <span class="cwd-s-sub" id="cwdConsumedSub"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="cwd-mini-foot">هذه الجلسة</div>
                        </div>

                        <div class="cwd-mini-card">
                            <div class="cwd-gauge-wrap cwd-gauge-sm">
                                <svg class="cwd-ring" viewBox="0 0 132 132" aria-hidden="true">
                                    <defs>
                                        <linearGradient id="cwdGradViolet" x1="0%" y1="0%" x2="100%" y2="100%">
                                            <stop offset="0%" stop-color="#d8b4fe"/>
                                            <stop offset="100%" stop-color="#7c3aed"/>
                                        </linearGradient>
                                    </defs>
                                    <circle class="cwd-ring-track" cx="66" cy="66" r="61"/>
                                    <circle class="cwd-ring-bar" id="cwdRingRemaining" cx="66" cy="66" r="61" stroke="url(#cwdGradViolet)" style="--circ:383.3; filter:drop-shadow(0 0 6px rgba(168,85,247,.65));"/>
                                </svg>
                                <div class="cwd-fluid-circle cwd-fluid-sm" id="cwdRemainingGauge" style="--fill:0%; --cwd-accent-sub:#d8b4fe;">
                                    <div class="cwd-fluid" id="cwdRemainingFluid">
                                        <svg class="cwd-waves" viewBox="0 0 400 120" preserveAspectRatio="none" aria-hidden="true">
                                            <path class="cwd-wave-1" style="fill:rgba(192,132,252,.42);" d="M0,42 C50,12 50,72 100,42 C150,12 150,72 200,42 C250,12 250,72 300,42 C350,12 350,72 400,42 L400,120 L0,120 Z"/>
                                            <path class="cwd-wave-2" style="fill:rgba(147,51,234,.88);opacity:.92;" d="M0,52 C50,80 50,24 100,52 C150,80 150,24 200,52 C250,80 250,24 300,52 C350,80 350,24 400,52 L400,120 L0,120 Z"/>
                                        </svg>
                                    </div>
                                    <div class="cwd-gauge-text">
                                        <span class="cwd-s-label">الوقت المتبقي</span>
                                        <span class="cwd-s-value" id="cwdRemainingVal">--</span>
                                        <span class="cwd-s-sub" id="cwdRemainingSub"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="cwd-mini-foot">ينتهي قريباً</div>
                        </div>
                    </div>

                    <div class="cwd-speed-section">
                        <div class="cwd-speed-head"><i class="fa-solid fa-gauge-simple-high"></i> سرعة الجلسة الحالية</div>
                        <div class="cwd-speed-duo">
                            <div class="cwd-speedo" style="--accent:#38bdf8;">
                                <div class="cwd-speedo-tag"><i class="fa-solid fa-arrow-down"></i> التنزيل</div>
                                <svg class="cwd-speedo-svg" viewBox="0 0 200 120" aria-hidden="true">
                                    <path class="cwd-track" d="M 14 108 A 86 86 0 0 1 186 108"/>
                                    <path class="cwd-fill-arc" id="cwdDownArc" d="M 14 108 A 86 86 0 0 1 186 108" style="--arc-len:270.2"/>
                                    <line class="cwd-needle" id="cwdDownNeedle" x1="100" y1="108" x2="100" y2="38"/>
                                    <circle class="cwd-needle-cap" cx="100" cy="108" r="4.5"/>
                                </svg>
                                <div class="cwd-speedo-readout">
                                    <span class="cwd-speedo-num" id="cwdDownNum">0.0</span>
                                    <span class="cwd-speedo-unit">Mbps</span>
                                </div>
                                <div class="cwd-speedo-foot">أقصى: <span id="cwdDownPeak">0.0</span></div>
                            </div>
                            <div class="cwd-speedo" style="--accent:#a855f7;">
                                <div class="cwd-speedo-tag"><i class="fa-solid fa-arrow-up"></i> الرفع</div>
                                <svg class="cwd-speedo-svg" viewBox="0 0 200 120" aria-hidden="true">
                                    <path class="cwd-track" d="M 14 108 A 86 86 0 0 1 186 108"/>
                                    <path class="cwd-fill-arc" id="cwdUpArc" d="M 14 108 A 86 86 0 0 1 186 108" style="--arc-len:270.2"/>
                                    <line class="cwd-needle" id="cwdUpNeedle" x1="100" y1="108" x2="100" y2="38"/>
                                    <circle class="cwd-needle-cap" cx="100" cy="108" r="4.5"/>
                                </svg>
                                <div class="cwd-speedo-readout">
                                    <span class="cwd-speedo-num" id="cwdUpNum">0.0</span>
                                    <span class="cwd-speedo-unit">Mbps</span>
                                </div>
                                <div class="cwd-speedo-foot">أقصى: <span id="cwdUpPeak">0.0</span></div>
                            </div>
                        </div>

                        <div class="cwd-sparkline-card">
                            <div class="cwd-sparkline-head">
                                <span>سرعة التنزيل — آخر دقيقة</span>
                                <span id="cwdSparkNow">0.0 Mbps</span>
                            </div>
                            <svg class="cwd-sparkline" id="cwdSparkSvg" viewBox="0 0 300 60" preserveAspectRatio="none">
                                <defs>
                                    <linearGradient id="cwdSparkGrad" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stop-color="rgba(2,163,254,.40)"/>
                                        <stop offset="100%" stop-color="rgba(2,163,254,0)"/>
                                    </linearGradient>
                                </defs>
                                <path class="cwd-spark-area" id="cwdSparkArea" d=""/>
                                <polyline class="cwd-spark-line" id="cwdSparkLine" points=""/>
                            </svg>
                        </div>
                    </div>

                    <div class="cwd-data-card">
                        <div class="cwd-data-row"><span>حالة السرعة</span><span class="cwd-badge" id="cwdSpeedStatus"><i class="fa-solid fa-bolt"></i> --</span></div>
                        <div class="cwd-data-row"><span>عنوان الاتصال (IP)</span><span id="cwdIpVal">--</span></div>
                        <div class="cwd-data-row"><span>مدة الجلسة</span><span id="cwdSessionVal">--:--</span></div>
                        <div class="cwd-data-row"><span>إجمالي الرفع</span><span id="cwdTotalUp">--</span></div>
                        <div class="cwd-data-row"><span>إجمالي التنزيل</span><span id="cwdTotalDown">--</span></div>
                    </div>

                </div>

                <div class="cwd-toasts" id="cwdToasts"></div>

                <div class="cwd-bell-modal" id="cwdBellModal">
                    <div class="cwd-bell-dialog">
                        <div class="cwd-bell-dialog-head">
                            <div class="ico"><i class="fa-solid fa-bell"></i></div>
                            <div>
                                <h3>تنبيه الرصيد المتبقي</h3>
                                <p>سيتم تنبيهك عند وصول الرصيد إلى القيمة المحددة</p>
                            </div>
                        </div>
                        <div class="cwd-bell-threshold-display">
                            <span class="num" id="cwdBellThresholdDisplay">500</span>
                            <span class="unit">MB</span>
                        </div>
                        <input type="range" class="cwd-bell-range" id="cwdBellRange" min="100" max="3000" step="50" value="500">
                        <div class="cwd-bell-range-labels"><span>100 MB</span><span>1.5 GB</span><span>3 GB</span></div>
                        <div class="cwd-bell-presets">
                            <button class="cwd-bell-preset" data-val="200">200 MB</button>
                            <button class="cwd-bell-preset active" data-val="500">500 MB</button>
                            <button class="cwd-bell-preset" data-val="1000">1 GB</button>
                            <button class="cwd-bell-preset" data-val="2000">2 GB</button>
                        </div>
                        <div class="cwd-bell-dialog-actions">
                            <button class="cancel" id="cwdBellCancel">إلغاء</button>
                            <button class="save" id="cwdBellSave"><i class="fa-solid fa-check"></i> حفظ</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="wifiNetworkDetailsPage">
            <div class="nb-dh">
                <button class="nb-dbtn" onclick="nbShareNetwork()"><i class="fa-solid fa-share-nodes"></i></button>
                <div class="nb-dtitle">
                    <div class="nb-dline">
                        <h1 id="nbDetSsid">—</h1>
                        <span class="nb-dconn" id="nbDetBadge" style="display:none;"><i></i> متصل</span>
                    </div>
                    <div class="nb-dmac" id="nbDetMac">—</div>
                </div>
                <button class="nb-dbtn" onclick="closeWifiNetworkDetailsPage()"><i class="fa-solid fa-chevron-right"></i></button>
            </div>
            <div class="nb-dscroll" id="nbDetScroll">
                <div class="nb-hero">
                    <div id="nbHeroIcon"></div>
                    <div class="nb-hcenter">
                        <div class="nb-hpct" id="nbHeroPct">—</div>
                        <div class="nb-hdbm" id="nbHeroDbm">—</div>
                        <div class="nb-hlabel" id="nbHeroLabel">—</div>
                        <div class="nb-hlive" id="nbHeroLive"><span class="nb-ldot"></span><span id="nbHeroLiveTxt">مباشر</span></div>
                    </div>
                    <div class="nb-hchips">
                        <div class="nb-hchip" id="nbHeroBand">—</div>
                        <div class="nb-hchip" id="nbHeroCh">—</div>
                    </div>
                </div>
                <div class="nb-tabs">
                    <button class="nb-tab" data-tab="security" onclick="nbSwitchTab('security', this)"><i class="fa-solid fa-lock"></i> الأمان</button>
                    <button class="nb-tab" data-tab="protocols" onclick="nbSwitchTab('protocols', this)"><i class="fa-solid fa-shield-halved"></i> البروتوكولات</button>
                    <button class="nb-tab active" data-tab="overview" onclick="nbSwitchTab('overview', this)"><i class="fa-solid fa-circle-info"></i> نظرة عامة</button>
                </div>
                <div id="nbDetTabContent"></div>
            </div>
        </div>
    </div>
    `;

    /* ═══════════════════════════════════════════════════
       الحقن
       ═══════════════════════════════════════════════════ */
    function injectCSS() {
        if (document.getElementById('wifi-module-styles')) return;
        const style = document.createElement('style');
        style.id = 'wifi-module-styles';
        style.textContent = WIFI_CSS;
        document.head.appendChild(style);
    }

    function injectHTML() {
        if (document.getElementById('wifiInterface')) return;
        const temp = document.createElement('div');
        temp.innerHTML = WIFI_HTML.trim();
        document.body.appendChild(temp.firstElementChild);
    }

    function hookBrand() {
        const brands = document.querySelectorAll('.top-bar .brand');
        brands.forEach(brand => {
            if (brand.dataset.wifiHooked === '1') return;
            brand.dataset.wifiHooked = '1';
            brand.style.cursor = 'pointer';
            brand.addEventListener('click', function(e) {
                e.preventDefault();
                openWifiPage();
            });
        });
    }

    /* ═══════════════════════════════════════════════════
       فتح/إغلاق
       ═══════════════════════════════════════════════════ */
    window.openWifiPage = async function(opts) {
        injectCSS();
        injectHTML();
        const page = document.getElementById('wifiInterface');
        if (!page) return;
        // opts.nearbyOnly === true: تُعرض الشبكات القريبة فقط بدون تبويب الراوتر
        const nearbyOnly = !!(opts && opts.nearbyOnly === true);
        page.classList.toggle('nearby-only', nearbyOnly);
        const titleEl = page.querySelector('.wifi-header-title');
        if (titleEl) titleEl.textContent = nearbyOnly ? 'الشبكات القريبة' : 'شبكة كوفا نت';
        if (nearbyOnly) switchWifiTab('nearby', page.querySelector('.wifi-tab[data-tab="nearby"]'));
        page.classList.add('active');
        document.body.style.overflow = 'hidden';
        showNetworksPage();
        await startSpeedService();
        setTimeout(onWifiPageOpen, 100);
    };

    window.closeWifiPage = async function() {
        const page = document.getElementById('wifiInterface');
        if (page) page.classList.remove('active');
        document.body.style.overflow = '';
        nbStopLive();
        stopWifiAutoRefresh();
        covaStopSession();
        // الإشعار الدائم يبقى شغالاً: هو الذي يسجّل استهلاك الإنترنت اليومي في الخلفية
    };

    function showNetworksPage() {
        document.getElementById('wifiNetworksPage').style.display = 'flex';
        document.getElementById('wifiNetworkDetailsPage').classList.remove('active');
        _currentPage = 'networks';
    }

    async function onWifiPageOpen() {
        const granted = await requestWifiPermissions();
        if (!granted) {
            renderWifiPermissionNeeded();
            return;
        }
        loadWifiNetworks();
        startWifiAutoRefresh();
    }

    /* ═══════════════════════════════════════════════════
       الصلاحيات
       ═══════════════════════════════════════════════════ */
    async function requestWifiPermissions() {
        const Wifi = getWifiPlugin();
        if (!Wifi) {
            alertSafe('ميزة WiFi متاحة في تطبيق Android فقط', false);
            return false;
        }
        try {
            let perms = await Wifi.checkPermissions();
            if (perms.location !== 'granted') perms = await Wifi.requestPermissions();
            if (perms.location !== 'granted') return false;

            const state = await Wifi.isWifiEnabled();
            if (!state.enabled) {
                alertSafe('يرجى تشغيل WiFi', false);
                try { await Wifi.openWifiSettings(); } catch (_) {}
                return false;
            }

            try { await Wifi.scan({ minRssi: -100 }); }
            catch (err) {
                const code = err?.code || '';
                if (code === 'LOCATION_OFF' || code === 'LOCATION_DISABLED') {
                    alertSafe('يرجى تشغيل خدمة الموقع (GPS)', false);
                    try { await Wifi.requestLocationEnable(); } catch (_) {
                        try { await Wifi.openLocationSettings(); } catch (__) {}
                    }
                    return false;
                }
            }
            return true;
        } catch (err) {
            console.error('Permission:', err);
            return false;
        }
    }

    function renderWifiPermissionNeeded() {
        const list = document.getElementById('wifiNetworksList');
        const status = document.getElementById('wifiScanStatus');
        if (status) status.style.display = 'none';
        if (!list) return;

        list.innerHTML = `
            <div class="wifi-permission-box">
                <div class="wifi-permission-icon-wrap">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <h3 class="wifi-permission-title">صلاحية الموقع مطلوبة</h3>
                <p class="wifi-permission-desc">امنح الصلاحية لعرض الشبكات القريبة</p>
                <div class="wifi-permission-hint">
                    <i class="fa-solid fa-lightbulb"></i>
                    اختر <strong>"أثناء استخدام التطبيق"</strong><br>
                    حتى لا يُطلب منك مرة أخرى<br>
                    <span style="display:block; margin-top:6px; font-size:11px; color:#6c7e97;">
                        <i class="fa-solid fa-circle-info"></i>
                        لا نستخدم موقعك الفعلي — فقط لقراءة أسماء الشبكات
                    </span>
                </div>
                <div class="wifi-permission-actions">
                    <button class="wifi-perm-btn primary" id="wifiPermAllowBtn" onclick="handleWifiPermAllow(this)">
                        <i class="fa-solid fa-check-circle"></i>
                        <span>السماح</span>
                    </button>
                    <button class="wifi-perm-btn secondary" onclick="openWifiSettingsFromPermission()">
                        <i class="fa-solid fa-cog"></i>
                        <span>فتح الإعدادات</span>
                    </button>
                </div>
            </div>
        `;
    }

    window.handleWifiPermAllow = async function(btn) {
        if (btn) {
            btn.disabled = true;
            btn.classList.add('loading');
            btn.innerHTML = '<i class="fa-solid fa-circle-notch"></i> <span>جاري الطلب...</span>';
        }

        const Wifi = getWifiPlugin();
        if (!Wifi) {
            alertSafe('الإضافة غير متوفرة', false);
            if (btn) { btn.disabled = false; btn.classList.remove('loading'); }
            return;
        }

        try {
            const res = await Wifi.requestPermissions();
            if (res.location === 'granted') {
                const state = await Wifi.isWifiEnabled();
                if (!state.enabled) {
                    alertSafe('يرجى تشغيل WiFi');
                    try { await Wifi.openWifiSettings(); } catch (_) {}
                }
                setTimeout(async () => {
                    const ok = await requestWifiPermissions();
                    if (ok) {
                        loadWifiNetworks();
                        startWifiAutoRefresh();
                    } else {
                        renderWifiPermissionNeeded();
                    }
                }, 400);
            } else {
                setTimeout(() => { renderWifiPermissionNeeded(); }, 300);
            }
        } catch (err) {
            console.error('Request:', err);
            alertSafe('تعذر طلب الصلاحية', false);
            if (btn) {
                btn.disabled = false;
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fa-solid fa-check-circle"></i> <span>السماح</span>';
            }
        }
    };

    window.openWifiSettingsFromPermission = async function() {
        const Wifi = getWifiPlugin();
        if (!Wifi) {
            alertSafe('افتح إعدادات الهاتف يدوياً', false);
            return;
        }
        try {
            if (Wifi.openAppSettings) await Wifi.openAppSettings();
            else if (Wifi.openLocationSettings) await Wifi.openLocationSettings();
            else if (Wifi.openWifiSettings) await Wifi.openWifiSettings();
        } catch (_) {
            alertSafe('افتح: الإعدادات ← التطبيقات ← COVA NET ← الصلاحيات', false);
        }
    };

    /* ═══════════════════════════════════════════════════
       فحص الشبكات
       ═══════════════════════════════════════════════════ */
    window.loadWifiNetworks = async function() {
        const list = document.getElementById('wifiNetworksList');
        const status = document.getElementById('wifiScanStatus');
        if (!list) return;

        const firstLoad = !list.querySelector('.nb-card');
        list.classList.toggle('nb-first', firstLoad);
        if (firstLoad) {
            if (status) status.style.display = 'flex';
            list.innerHTML = '';
        }

        const Wifi = getWifiPlugin();
        if (!Wifi) {
            if (status) status.style.display = 'none';
            list.innerHTML = `
                <div class="wifi-empty-state">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <p>إضافة WiFi غير متوفرة</p>
                </div>`;
            return;
        }

        try {
            const result = await Wifi.scan({ minRssi: -95 });
            const networks = (result.networks || []).sort((a, b) => b.level - a.level);
            _wifiLastScanResults = networks;

            const connectedNet = networks.find(n => n.isConnected);
            if (connectedNet && connectedNet.SSID) recordWifiLocation(connectedNet.SSID);
            if (status) status.style.display = 'none';

            if (!networks.length) {
                list.innerHTML = `
                    <div class="wifi-empty-state">
                        <i class="fa-solid fa-wifi"></i>
                        <p>لا توجد شبكات قريبة<br><small style="color:#6c7e97;">اضغط زر التحديث</small></p>
                    </div>`;
                return;
            }
            list.innerHTML = networks.map((net, i) => renderWifiCard(net, i)).join('');
        } catch (err) {
            if (status) status.style.display = 'none';
            const code = err?.code || '';
            if (code === 'PERMISSION_DENIED' || code === 'LOCATION_OFF') {
                renderWifiPermissionNeeded();
                return;
            }
            list.innerHTML = `
                <div class="wifi-empty-state">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <p>تعذر قراءة الشبكات<br><small style="color:#6c7e97;">${esc(err.message || '')}</small></p>
                </div>`;
        }
    };

    /* ═══════════════════════════════════════════════════
       تصميم الشبكات القريبة الجديد + صفحة التفاصيل
       ═══════════════════════════════════════════════════ */
    let _nbCurrent = null;
    let _nbTab = 'overview';

    function nbPercent(dbm) { return Math.max(0, Math.min(100, Math.round(((dbm + 100) / 70) * 100))); }
    function nbLevel(p) { return p >= 75 ? 4 : p >= 50 ? 3 : p >= 25 ? 2 : 1; }
    function nbStrengthClass(p) { return p >= 70 ? 'excellent' : p >= 50 ? 'good' : p >= 30 ? 'fair' : 'weak'; }
    function nbLabel(p) {
        if (p >= 75) return { text: 'ممتاز', color: '#3b82f6' };
        if (p >= 50) return { text: 'جيد', color: '#fbbf24' };
        if (p >= 25) return { text: 'مقبول', color: '#fbbf24' };
        return { text: 'ضعيف', color: '#f97316' };
    }
    function nbBand(freq) { return freq >= 5925 ? '6' : freq > 4000 ? '5' : '2.4'; }
    function nbSvg() {
        return `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path class="arc arc-3" d="M 2 8.5 Q 12 0.5 22 8.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>
            <path class="arc arc-2" d="M 6 12.5 Q 12 6.5 18 12.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>
            <path class="arc arc-1" d="M 9.5 16 Q 12 13.5 14.5 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/>
            <circle class="dot" cx="12" cy="19.5" r="1.4" fill="currentColor"/>
        </svg>`;
    }
    function nbIcon(p, connected) {
        return `<div class="nb-wifi l${nbLevel(p)}${connected ? ' conn' : ''}">${nbSvg()}</div>`;
    }
    function nbSecType(caps) {
        const c = String(caps || '').toUpperCase();
        if (c.includes('SAE')) return 'WPA3';
        if (c.includes('WPA2') || c.includes('RSN')) return 'WPA2';
        if (c.includes('WPA')) return 'WPA';
        if (c.includes('WEP')) return 'WEP';
        return 'Open';
    }

    /* بطاقة الشبكة في القائمة */
    function renderWifiCard(net, idx) {
        const level = typeof net.level === 'number' ? net.level : -100;
        const p = nbPercent(level);
        const hasLock = nbSecType(net.capabilities) !== 'Open';
        const connected = net.isConnected === true;
        const strongest = idx === 0 && !connected;
        return `
            <div class="nb-card ${connected ? 'connected' : ''}" onclick="showWifiNetworkDetails(${idx})">
                <div class="nb-arrow"><i class="fa-solid fa-chevron-left"></i></div>
                ${nbIcon(p, connected)}
                <div class="nb-info">
                    <div class="nb-ssid">
                        ${connected ? '<span class="nb-badge">متصل</span>' : ''}
                        ${strongest ? '<span class="nb-badge gold"><i class="fa-solid fa-crown" style="font-size:8px;margin-left:3px;"></i>الأقوى</span>' : ''}
                        <span>${esc(net.SSID || '(شبكة مخفية)')}</span>
                    </div>
                    <div class="nb-meta">
                        <span class="nb-chip">Ch ${net.channel || '—'}</span>
                        <span class="nb-chip freq">GHz ${nbBand(net.frequency || 0)}</span>
                        <span class="nb-chip signal ${nbStrengthClass(p)}">${p}%</span>
                    </div>
                </div>
                <div class="nb-lock ${hasLock ? 'locked' : 'open'}"><i class="fa-solid ${hasLock ? 'fa-lock' : 'fa-lock-open'}"></i></div>
            </div>`;
    }

    /* القيم: كلها مقروءة فعلاً من فحص هاتف المستخدم (SSID / BSSID / dBm / التردد / القناة / الأمان)
       أو مشتقة منها بشكل حتمي. الحقول الاختيارية (channelWidth / wifiStandard / linkSpeed / is80211mc)
       لا تظهر إلا إذا أرسلها الـ plugin الأصلي. لا تُخمَّن أي قيمة (أُزيلت: SNR وجودة الرابط
       وأقصى سرعة وسرعة الاتصال المحسوبة والمعدلات القديمة وعرض القناة المقدَّر). */
    function nbDetails(net) {
        const level = typeof net.level === 'number' ? net.level : -100;
        const p = nbPercent(level);
        const freq = net.frequency || 0;
        const channel = net.channel || 0;
        const band = nbBand(freq);
        const caps = String(net.capabilities || '');
        const capsU = caps.toUpperCase();
        const dist = freq ? Math.max(1, Math.min(300, Math.pow(10, (27.55 - 20 * Math.log10(freq) + 15 - level) / 20))) : null;
        const mac = net.BSSID || '—';
        const firstByte = parseInt(String(mac).split(':')[0], 16);
        const localMac = !isNaN(firstByte) && (firstByte & 2) === 2;
        return {
            ssid: net.SSID, mac, level, percent: p, channel, freq, band,
            isDFS: band === '5' && channel >= 52 && channel <= 144,
            distance: dist === null ? null : Math.round(dist * 10) / 10,
            connected: net.isConnected === true, security: caps || '[OPEN]', secType: nbSecType(caps),
            localMac,
            has11r: capsU.includes('FT/') || capsU.includes('-FT'),
            has11w: capsU.includes('MFPR') || capsU.includes('MFPC') || capsU.includes('SAE') || capsU.includes('OWE'),
            hasEnterprise: capsU.includes('EAP'), hasWPS: capsU.includes('WPS'),
            width: Number.isFinite(net.channelWidth) && net.channelWidth > 0 ? net.channelWidth : null,
            standard: net.wifiStandard ? String(net.wifiStandard) : null,
            linkSpeed: Number.isFinite(net.linkSpeed) && net.linkSpeed > 0 ? net.linkSpeed : null,
            mc: typeof net.is80211mc === 'boolean' ? net.is80211mc : null
        };
    }

    function nbRow(label, value, ltr, style) {
        return `<div class="nb-row"><div class="nb-rl">${label}</div><div class="nb-rv${ltr ? ' ltr' : ''}"${style ? ` style="${style}"` : ''}>${value}</div></div>`;
    }
    function nbProto(name, desc, on, known) {
        const badge = on ? '<span class="nb-pb yes"><i class="fa-solid fa-circle-check"></i>مدعوم</span>'
                         : `<span class="nb-pb"><i class="fa-solid fa-circle-minus"></i>${known ? 'غير مدعوم' : 'غير معروف'}</span>`;
        return `<div class="nb-proto"><div class="nb-pr"><div class="nb-pn">${name}</div><div class="nb-pd">${desc}</div></div>${badge}</div>`;
    }
    function nbCard(color, iconHtml, title, body) {
        return `<div class="nb-icard"><div class="nb-ich"><div class="nb-ici ${color}">${iconHtml}</div><div class="nb-ict">${title}</div></div>${body}</div>`;
    }

    function nbOverview(d) {
        const cards = [];
        cards.push(nbCard('orange', nbSvg(), 'قوة الإشارة',
            nbRow('قوة الإشارة (RSSI)', d.level + ' dBm', true) +
            nbRow('نسبة الإشارة', d.percent + '%', true) +
            (d.distance !== null ? nbRow('المسافة التقريبية (محسوبة من الإشارة)', '≈ ' + d.distance.toFixed(1) + ' m', true) : '')));
        cards.push(nbCard('blue', '<i class="fa-solid fa-tower-broadcast"></i>', 'الراديو',
            nbRow('التردد', d.freq ? d.freq + ' MHz' : '—', true) +
            nbRow('القناة', d.channel || '—', true) +
            (d.width ? nbRow('عرض القناة', d.width + ' MHz', true) : '') +
            nbRow('قناة DFS', d.isDFS ? 'نعم' : 'لا')));
        if (d.standard || d.linkSpeed) {
            cards.push(nbCard('orange', '<i class="fa-solid fa-bolt"></i>', 'الأداء',
                (d.standard ? nbRow('معيار الواي فاي', esc(d.standard), true) : '') +
                (d.linkSpeed ? nbRow('سرعة الاتصال الفعلية', d.linkSpeed + ' Mbps', true) : '')));
        }
        cards.push(nbCard('cyan', '<i class="fa-solid fa-microchip"></i>', 'معلومات الجهاز',
            nbRow('عنوان MAC (BSSID)', esc(d.mac), true) +
            nbRow('نوع العنوان', d.localMac ? 'محلي / عشوائي' : 'عالمي (مُصنّع)')));
        return cards.join('');
    }

    function nbProtocols(d) {
        const cards = [];
        cards.push(nbCard('blue', nbSvg(), 'النطاق والمعيار',
            (d.standard ? nbRow('معيار الواي فاي', esc(d.standard), true) : '') +
            nbRow('النطاق', 'GHz ' + d.band, true) +
            (d.width ? nbRow('عرض القناة', 'MHz ' + d.width, true) : '')));
        cards.push(nbCard('blue', '<i class="fa-solid fa-arrows-rotate"></i>', 'التجوال',
            nbProto('802.11r', 'انتقال سريع بين نقاط الوصول', d.has11r, true)));
        if (d.mc !== null) {
            cards.push(nbCard('teal', '<i class="fa-solid fa-location-dot"></i>', 'قياس المسافة',
                nbProto('802.11mc', 'قياس التوقيت الحقيقي', d.mc, true)));
        }
        cards.push(nbCard('orange', '<i class="fa-solid fa-lock"></i>', 'بروتوكولات الأمان',
            nbRow('نوع التشفير', d.secType === 'Open' ? 'Open' : d.secType, true) +
            nbRow('802.11w', d.has11w ? 'معلن' : 'غير معلن') +
            nbRow('المؤسسات (802.1X)', d.hasEnterprise ? 'نعم' : 'لا') +
            nbRow('WPS', d.hasWPS ? 'مفعّل' : 'معطل')));
        return cards.join('');
    }

    function nbRecs(t) {
        const R = {
            'Open': [['⚠️ شبكة مفتوحة', 'لا تستخدم بيانات حساسة', '#ef4444'], ['توصية', 'استخدم VPN عند الاتصال', '#fbbf24']],
            'WEP':  [['⚠️ تشفير قديم', 'WEP غير آمن', '#ef4444'], ['توصية', 'حدّث الراوتر إلى WPA2/WPA3', '#fbbf24']],
            'WPA':  [['⚠️ تشفير قديم', 'يُنصح بالترقية', '#fbbf24'], ['توصية', 'استخدم WPA2 أو WPA3', '#3b82f6']],
            'WPA2': [['✅ مستوى جيد', 'حماية مقبولة', '#10b981'], ['توصية', 'ترقية إلى WPA3 إن أمكن', '#3b82f6']],
            'WPA3': [['✅ ممتاز', 'أحدث معايير الأمان', '#10b981'], ['الحالة', 'الشبكة آمنة', '#10b981']]
        };
        return (R[t] || []).map(r => nbRow(r[0], r[1], false, 'color:' + r[2])).join('');
    }

    function nbSecurity(d) {
        const secure = d.secType !== 'Open';
        return nbCard(secure ? 'green' : 'red', `<i class="fa-solid ${secure ? 'fa-lock' : 'fa-lock-open'}"></i>`, 'حالة الأمان',
                nbRow('حالة الحماية', secure ? '🔒 محمية' : '🔓 مفتوحة', false, 'color:' + (secure ? '#10b981' : '#ef4444')) +
                nbRow('نوع الأمان', d.secType) +
                nbRow('الإعداد الأصلي', esc(d.security), true, 'font-size:11px')) +
            nbCard(secure ? 'blue' : 'red', '<i class="fa-solid fa-triangle-exclamation"></i>', 'توصيات الأمان', nbRecs(d.secType));
    }

    function nbRenderTab() {
        const box = document.getElementById('nbDetTabContent');
        if (!box || !_nbCurrent) return;
        const d = nbDetails(_nbCurrent);
        box.innerHTML = _nbTab === 'protocols' ? nbProtocols(d) : _nbTab === 'security' ? nbSecurity(d) : nbOverview(d);
    }

    window.nbSwitchTab = function(tab, el) {
        _nbTab = tab;
        document.querySelectorAll('#wifiNetworkDetailsPage .nb-tab').forEach(t => t.classList.remove('active'));
        if (el) el.classList.add('active');
        nbRenderTab();
    };

    window.nbShareNetwork = function() {
        if (!_nbCurrent) return;
        const d = nbDetails(_nbCurrent);
        const text = `📡 شبكة: ${d.ssid}\n📍 MAC: ${d.mac}\n📶 الإشارة: ${d.percent}% (${d.level} dBm)\n📡 القناة: ${d.channel}\n🌐 التردد: ${d.freq} MHz\n🔒 الأمان: ${d.security}`;
        if (navigator.share) navigator.share({ title: 'بيانات الشبكة', text }).catch(() => {});
        else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => alertSafe('تم نسخ بيانات الشبكة', true)).catch(() => alertSafe('تعذر النسخ', false));
    };

    /* ═══════════════════════════════════════════════════
       فتح صفحة تفاصيل الشبكة (بالفهرس في القائمة الأخيرة)
       ═══════════════════════════════════════════════════ */
    /* تعبئة رأس التفاصيل + التبويب الحالي من _nbCurrent (تُستعمل عند الفتح وعند كل تحديث مباشر) */
    function nbRefreshDetails() {
        if (!_nbCurrent) return;
        const d = nbDetails(_nbCurrent);
        const lab = nbLabel(d.percent);
        const $ = id => document.getElementById(id);
        $('nbDetSsid').textContent = d.ssid;
        $('nbDetMac').textContent = d.mac;
        $('nbDetBadge').style.display = d.connected ? 'inline-flex' : 'none';
        $('nbHeroIcon').innerHTML = nbIcon(d.percent, d.connected);
        $('nbHeroPct').textContent = d.percent + '%';
        $('nbHeroPct').style.color = lab.color;
        $('nbHeroDbm').textContent = '(' + d.level + ' dBm)';
        $('nbHeroLabel').textContent = lab.text;
        $('nbHeroLabel').style.color = lab.color;
        $('nbHeroBand').textContent = 'GHz ' + d.band;
        $('nbHeroCh').textContent = 'Ch ' + (d.channel || '—');
        nbRenderTab();
    }

    function nbSig(n) { return [n.level, n.frequency, n.channel, n.isConnected, n.capabilities, n.BSSID, n.channelWidth, n.wifiStandard, n.linkSpeed].join('|'); }
    function nbSetLive(on, text) {
        const box = document.getElementById('nbHeroLive');
        const txt = document.getElementById('nbHeroLiveTxt');
        if (box) box.classList.toggle('off', !on);
        if (txt) txt.textContent = text;
    }

    /* تحديث تلقائي مباشر: يعيد فحص الشبكات الحقيقية من الهاتف كل ~4 ثوانٍ طالما صفحة التفاصيل مفتوحة.
       أندرويد نفسه يحدّ عدد عمليات المسح، فتتغير القيم بمعدل ما يسلّمه النظام من نتائج. */
    let _nbLiveTimer = null;
    let _nbLiveRun = 0;
    function nbStopLive() {
        _nbLiveRun++;
        if (_nbLiveTimer) { clearTimeout(_nbLiveTimer); _nbLiveTimer = null; }
    }
    function nbStartLive() {
        nbStopLive();
        const run = _nbLiveRun;
        nbSetLive(true, 'مباشر');
        const tick = async () => {
            if (run !== _nbLiveRun || _currentPage !== 'details' || !_nbCurrent) return;
            const Wifi = getWifiPlugin();
            if (!Wifi) { nbSetLive(false, 'غير متاح'); return; }
            try {
                const res = await Wifi.scan({ minRssi: -100 });
                if (run !== _nbLiveRun) return;
                const fresh = (res.networks || []).find(n => n.SSID === _nbCurrent.SSID);
                if (fresh) {
                    const changed = nbSig(fresh) !== nbSig(_nbCurrent);
                    _nbCurrent = fresh;
                    if (changed) nbRefreshDetails();
                    nbSetLive(true, 'مباشر · ' + new Date().toLocaleTimeString('en-GB'));
                } else {
                    nbSetLive(false, 'الشبكة خارج النطاق حالياً');
                }
            } catch (err) {
                const code = err && err.code;
                nbSetLive(false, code === 'WIFI_OFF' ? 'الواي فاي مغلق' : (code === 'LOCATION_OFF' || code === 'PERMISSION_DENIED') ? 'فعّل الموقع والإذن' : 'تعذّر التحديث');
            }
            if (run === _nbLiveRun) _nbLiveTimer = setTimeout(tick, 4000);
        };
        _nbLiveTimer = setTimeout(tick, 1500);
    }

    window.showWifiNetworkDetails = function(idx) {
        const net = _wifiLastScanResults[idx];
        if (!net || !net.SSID) return;
        _nbCurrent = net;
        _nbTab = 'overview';
        document.querySelectorAll('#wifiNetworkDetailsPage .nb-tab').forEach(t => t.classList.remove('active'));
        const first = document.querySelector('#wifiNetworkDetailsPage .nb-tab[data-tab="overview"]');
        if (first) first.classList.add('active');
        nbRefreshDetails();
        document.getElementById('wifiNetworksPage').style.display = 'none';
        document.getElementById('wifiNetworkDetailsPage').classList.add('active');
        document.getElementById('nbDetScroll').scrollTop = 0;
        _currentPage = 'details';
        nbStartLive();
    };

    window.closeWifiNetworkDetailsPage = function() {
        nbStopLive();
        showNetworksPage();
        loadWifiNetworks();   // يُحدّث القائمة بنتائج مطابقة لما رآه المستخدم
    };

    /* ═══════════════════════════════════════════════════
       التبويبات — معدّلة: تشغيل/إيقاف الجلسة
       ═══════════════════════════════════════════════════ */
    window.switchWifiTab = function(tab, el) {
        document.querySelectorAll('.wifi-tab').forEach(t => t.classList.remove('active'));
        if (el) el.classList.add('active');
        document.querySelectorAll('.wifi-tab-content').forEach(c => c.classList.remove('active'));
        const target = document.getElementById('wifiTab-' + tab);
        if (target) target.classList.add('active');

        if (tab === 'data') {
            covaStartSession();
        } else {
            covaStopSession();
        }
    };

    /* ═══════════════════════════════════════════════════
       التحديث الدوري لقائمة الشبكات
       ═══════════════════════════════════════════════════ */
    function startWifiAutoRefresh() {
        if (_wifiScanInterval) clearInterval(_wifiScanInterval);
        _wifiScanInterval = setInterval(() => {
            if (document.hidden) return;
            if (_currentPage !== 'networks') return;
            loadWifiNetworks();
        }, 15000);
    }

    function stopWifiAutoRefresh() {
        if (_wifiScanInterval) {
            clearInterval(_wifiScanInterval);
            _wifiScanInterval = null;
        }
    }

    /* ═══════════════════════════════════════════════════
       تسجيل الموقع
       ═══════════════════════════════════════════════════ */
    let _wifiLastLoggedSsid = null;
    let _wifiLastLoggedAt = 0;

    function recordWifiLocation(ssid) {
        if (!ssid) return;
        if (typeof APP === 'undefined' || !APP.user || !APP.user.phone) return;
        if (typeof database === 'undefined') return;
        if (!navigator.geolocation) return;

        const now = Date.now();
        if (ssid === _wifiLastLoggedSsid && (now - _wifiLastLoggedAt) < 2 * 60 * 1000) return;

        navigator.geolocation.getCurrentPosition(async (pos) => {
            try {
                await database.ref('locations/' + APP.user.phone).update({
                    lat: pos.coords.latitude,
                    lng: pos.coords.longitude,
                    name: APP.user.fullName || APP.user.phone,
                    isAgent: !!APP.user.isAgent,
                    wifiSsid: ssid,
                    updatedAt: firebase.database.ServerValue.TIMESTAMP
                });
                _wifiLastLoggedSsid = ssid;
                _wifiLastLoggedAt = now;
                console.log('📍 تم تسجيل الموقع مع شبكة:', ssid);
            } catch (e) {
                console.error('❌ تعذر تسجيل موقع الواي فاي:', e);
            }
        }, (err) => {
            console.warn('⚠️ تعذر تحديد الموقع:', err.message);
        }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 });
    }

    /* ═══════════════════════════════════════════════════
       عنوان الراوتر
       ═══════════════════════════════════════════════════ */
    async function getRouterBase() {
        return 'http://www.c.com';
    }

    /* ═══════════════════════════════════════════════════
       نظام الجلسة — جلب مرة واحدة + قياس محلي
       ═══════════════════════════════════════════════════ */

    async function covaStartSession() {
        _cova.active = true;
        _cova.frozen = false;

        // 1. اكتشاف الشبكة
        await covaDetectNetwork();

        // 2. دائماً نبدأ المؤقتات (حتى لو ليست كوفانت — سنراقب)
        covaStartTrafficSampling();
        covaStartLocalTimer();
        covaStartNetworkWatch();

        if (!_cova.isKovant) {
            covaShowEmpty(_cova.emptyReason);
            return;
        }

        // 3. جلب status.html مرة واحدة
        const data = await fetchCovaRouterData();
        if (!data || !data.loggedIn) {
            // الراوتر وصل لكن لا توجد بيانات كرت (غير مسجَّل أو انتهى) → شاشة إدخال الكرت
            if (_cova.lastFetchKind === 'notLoggedIn') {
                covaShowLogin({ portalHtml: _cova.lastLoginPageHtml });
                return;
            }
            covaShowEmpty('جهازك متصل بشبكة كوفا نت لكن تعذّر الوصول لبيانات الراوتر (' + (await getRouterBase()) + ') — جرّب زر التحديث أعلى الصفحة' + (_cova.lastFetchError ? '\n[' + _cova.lastFetchError + ']' : ''));
            return;
        }

        // 4. حفظ القيم الأولية
        covaApplyRouterData(data);

        // 5. أخذ خط أساس من TrafficStats
        await covaTakeTrafficBaseline();

        // 6. رسم
        covaShowContent();
        covaRenderAll();
    }

    function covaStopSession() {
        clAnimStop();
        _cova.active = false;
        _cova.frozen = false;
        if (_cova.trafficTimer) { clearInterval(_cova.trafficTimer); _cova.trafficTimer = null; }
        if (_cova.localTimer) { clearInterval(_cova.localTimer); _cova.localTimer = null; }
        if (_cova.networkTimer) { clearInterval(_cova.networkTimer); _cova.networkTimer = null; }
    }

    async function covaTakeTrafficBaseline() {
        const plugin = getTrafficPlugin();
        if (!plugin) { _cova.trafficSupported = false; return; }
        try {
            const res = await plugin.getDeviceTraffic();
            _cova.baselineRx = res.rxBytes;
            _cova.baselineTx = res.txBytes;
            _cova.lastRx = res.rxBytes;
            _cova.lastTx = res.txBytes;
            _cova.lastTrafficTime = res.timestamp;
            _cova.trafficSupported = true;
        } catch (e) {
            console.warn('⚠️ TrafficStats غير متاح:', e);
            _cova.trafficSupported = false;
        }
    }

    function covaStartTrafficSampling() {
        if (_cova.trafficTimer) clearInterval(_cova.trafficTimer);
        if (!_cova.trafficSupported) return;

        _cova.trafficTimer = setInterval(async () => {
            if (!_cova.active || _cova.frozen) return;
            if (document.hidden) return;

            const plugin = getTrafficPlugin();
            if (!plugin) return;

            try {
                const res = await plugin.getDeviceTraffic();
                const now = res.timestamp;
                const rx = res.rxBytes;
                const tx = res.txBytes;

                if (_cova.lastTrafficTime > 0) {
                    const elapsed = (now - _cova.lastTrafficTime) / 1000;
                    if (elapsed > 0.3) {
                        const rxDelta = Math.max(0, rx - _cova.lastRx);
                        const txDelta = Math.max(0, tx - _cova.lastTx);
                        _cova.downBps = rxDelta / elapsed;
                        _cova.upBps = txDelta / elapsed;

                        // خصم من الرصيد المحلي (التنزيل فقط عادة)
                        if (_cova.isKovant && !_cova.unlimited) {
                            _cova.remainingBytes = Math.max(0, _cova.remainingBytes - rxDelta);
                        }
                    }
                }

                _cova.lastRx = rx;
                _cova.lastTx = tx;
                _cova.lastTrafficTime = now;

                covaRenderSpeed();
                covaRenderRemaining();
                covaCheckAlert();
                if (_cova.hasData && _cova.dataLimited && !_cova.unlimited && _cova.remainingBytes <= 0) covaVerifyExpiry();
            } catch (e) {
                // تجاهل
            }
        }, 1000);
    }

    function covaStartLocalTimer() {
        if (_cova.localTimer) clearInterval(_cova.localTimer);
        _cova.localTimer = setInterval(() => {
            if (!_cova.active || _cova.frozen) return;
            if (document.hidden) return;
            if (!_cova.isKovant) return;

            if (!_cova.hasData) return;            // لا بيانات كرت (شاشة الدخول ظاهرة)
            if (_wifiTotalSeconds > 0) _wifiTotalSeconds--;
            _cwdConsumedSeconds++;
            renderWifiTimeGauges();
            if (_cova.timeLimited && _wifiTotalSeconds === 0) covaVerifyExpiry();
        }, 1000);
    }

    function covaStartNetworkWatch() {
        if (_cova.networkTimer) clearInterval(_cova.networkTimer);
        _cova.networkTimer = setInterval(covaCheckNetworkChange, 10000);
    }

    async function covaCheckNetworkChange() {
        if (!_cova.active) return;
        if (document.hidden) return;

        const Wifi = getWifiPlugin();
        if (!Wifi) return;

        try {
            const result = await Wifi.scan({ minRssi: -95 });
            const networks = result.networks || [];
            const connected = networks.find(n => n.isConnected);

            if (!connected) {
                if (_cova.isKovant) covaOnLeaveKovant();
                return;
            }

            const ssid = connected.SSID || '';
            const isKovantNow = /coav|cova|kovant|كوفا/i.test(ssid);

            if (isKovantNow && !_cova.isKovant) {
                _cova.isKovant = true;
                _cova.lastSsid = ssid;
                await covaOnReturnToKovant();
            } else if (!isKovantNow && _cova.isKovant) {
                _cova.isKovant = false;
                _cova.lastSsid = ssid;
                covaOnLeaveKovant();
            }
        } catch (e) {
            // تجاهل
        }
    }

    function covaOnLeaveKovant() {
        _cova.frozen = true;
        const badge = document.getElementById('cwdLiveBadge');
        if (badge) {
            badge.innerHTML = '<span class="cwd-live-dot" style="background:#fbbf24;box-shadow:0 0 8px #fbbf24;animation:none"></span> خارج كوفانت';
            badge.style.color = '#fbbf24';
            badge.style.background = 'rgba(245,158,11,.10)';
            badge.style.borderColor = 'rgba(245,158,11,.28)';
        }
    }

    async function covaOnReturnToKovant() {
        _cova.frozen = false;

        // جلب مرة واحدة للتصحيح
        const data = await fetchCovaRouterData();
        if (!data || !data.loggedIn) {
            if (_cova.lastFetchKind === 'notLoggedIn') {
                covaShowLogin({ portalHtml: _cova.lastLoginPageHtml });   // لا يوجد كرت فعّال → شاشة الدخول
            } else {
                _cova.frozen = true;
            }
            return;
        }

        // تحديث القيم
        covaApplyRouterData(data);

        // إعادة ضبط baseline
        await covaTakeTrafficBaseline();

        // استعادة الشارة الخضراء
        const badge = document.getElementById('cwdLiveBadge');
        if (badge) {
            badge.innerHTML = '<span class="cwd-live-dot"></span> مباشر';
            badge.style.color = '';
            badge.style.background = '';
            badge.style.borderColor = '';
        }

        covaShowContent();
        covaRenderAll();
    }

    async function covaDetectNetwork() {
        const Wifi = getWifiPlugin();
        if (!Wifi) {
            _cova.isKovant = false;
            _cova.emptyReason = 'الإضافة الأصلية لكشف شبكة الواي فاي غير مُثبَّتة في هذا الإصدار من التطبيق (TuaWifiManagerPlugin)';
            return;
        }
        try {
            const result = await Wifi.scan({ minRssi: -95 });
            const networks = result.networks || [];
            const connected = networks.find(n => n.isConnected);
            if (connected && connected.SSID) {
                _cova.isKovant = /coav|cova|kovant|كوفا/i.test(connected.SSID);
                _cova.lastSsid = connected.SSID;
                _cova.emptyReason = _cova.isKovant ? '' : ('جهازك متصل بشبكة "' + connected.SSID + '" — هذه ليست شبكة كوفا نت');
            } else {
                _cova.isKovant = false;
                _cova.emptyReason = 'جهازك غير متصل بأي شبكة واي فاي حالياً، أو صلاحية الموقع/خدمة GPS غير مُفعّلة (مطلوبة لمسح الشبكات)';
            }
        } catch (e) {
            _cova.isKovant = false;
            _cova.emptyReason = 'تعذّر مسح شبكات الواي فاي — تأكد من منح صلاحية الموقع للتطبيق وتفعيل خدمة الموقع (GPS) على جهازك';
        }
    }

    function covaShowEmpty(reason) {
        covaHideLogin();
        const empty = document.getElementById('wifiDataEmpty');
        const content = document.getElementById('wifiDataContent');
        if (empty) empty.style.display = 'flex';
        if (content) content.style.display = 'none';
        const hint = document.getElementById('wifiEmptyHint');
        if (hint) {
            hint.textContent = reason || 'تأكد إن جهازك متصل بشبكة كوفا نت';
            hint.style.whiteSpace = 'pre-line';
            hint.style.wordBreak = 'break-word';
        }
    }

    function covaShowContent() {
        covaHideLogin();
        const empty = document.getElementById('wifiDataEmpty');
        const content = document.getElementById('wifiDataContent');
        if (empty) empty.style.display = 'none';
        if (content) content.style.display = 'block';
    }

    function covaRenderAll() {
        cwdSeedBubbles('cwdDataFluid', 6);
        cwdSeedBubbles('cwdConsumedFluid', 4);
        cwdSeedBubbles('cwdRemainingFluid', 4);
        covaRenderRemaining();
        renderWifiTimeGauges();
        covaRenderSpeed();
        covaRenderInfo();
        covaCheckAlert();
    }

    function covaRenderRemaining() {
        const el = (id) => document.getElementById(id);
        const unlimited = _cova.unlimited;
        const remainingBytes = _cova.remainingBytes;
        const remainingGB = remainingBytes / (1024 * 1024 * 1024);
        const usedSinceStart = Math.max(0, _cova.initialRemainingBytes - remainingBytes);
        const total = _cova.initialRemainingBytes + usedSinceStart;
        const percent = unlimited ? 100 : (total > 0 ? (remainingBytes / total) * 100 : 0);

        el('cwdDataGauge') && el('cwdDataGauge').style.setProperty('--fill', cwdClamp(percent, unlimited ? 100 : 6, 100) + '%');
        if (el('cwdDataVal')) {
            el('cwdDataVal').innerHTML = unlimited
                ? '∞<small>مفتوحة</small>'
                : remainingGB.toFixed(2) + '<small>GB</small>';
        }
        if (el('cwdDataSub')) {
            el('cwdDataSub').textContent = unlimited
                ? 'الباقة مفتوحة (غير محدودة)'
                : 'من أصل ' + (total / (1024 * 1024 * 1024)).toFixed(2) + ' جيجابايت';
        }
        cwdSetRing(el('cwdRingMain'), CWD_ARC_MAIN, percent);
        cwdApplyTheme(unlimited ? 'good' : cwdThemeFor(percent));
    }

    function covaRenderSpeed() {
        const el = (id) => document.getElementById(id);
        const downMbps = (_cova.downBps * 8) / 1e6;
        const upMbps = (_cova.upBps * 8) / 1e6;

        _cwdDownPeak = cwdUpdateSpeedo(downMbps, CWD_DOWN_MAX_MBPS, el('cwdDownArc'), el('cwdDownNeedle'), el('cwdDownNum'), el('cwdDownPeak'), _cwdDownPeak);
        _cwdUpPeak = cwdUpdateSpeedo(upMbps, CWD_UP_MAX_MBPS, el('cwdUpArc'), el('cwdUpNeedle'), el('cwdUpNum'), el('cwdUpPeak'), _cwdUpPeak);
        cwdRenderSpark(downMbps);
    }

    function covaRenderInfo() {
        const el = (id) => document.getElementById(id);
        if (el('cwdSpeedStatus')) el('cwdSpeedStatus').innerHTML = '<i class="fa-solid fa-bolt"></i> ' + esc(_cova.speedLabel || '—');
        if (el('cwdIpVal')) el('cwdIpVal').textContent = _cova.ip || '—';

        const rxSince = Math.max(0, _cova.lastRx - _cova.baselineRx);
        const txSince = Math.max(0, _cova.lastTx - _cova.baselineTx);
        if (el('cwdTotalUp')) el('cwdTotalUp').textContent = formatWifiBytes(_cova.initialUploadBytes + txSince);
        if (el('cwdTotalDown')) el('cwdTotalDown').textContent = formatWifiBytes(_cova.initialDownloadBytes + rxSince);
    }

    function covaCheckAlert() {
        if (!_cova.isKovant || !_cova.hasData) return; // ✅ إصلاح: لا تُطلق تنبيه رصيد وهمي بدون بيانات حقيقية من شبكة كوفا نت
        const remainingMB = _cova.remainingBytes / (1024 * 1024);
        cwdCheckAlert(_cova.unlimited, remainingMB);
    }

    /* ═══════════════════════════════════════════════════
       أدوات المقاييس
       ═══════════════════════════════════════════════════ */
    function cwdClamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

    const CWD_ARC_MAIN = 2 * Math.PI * 98;
    const CWD_ARC_SM = 2 * Math.PI * 61;
    const CWD_SPEEDO_ARC = 270.2;
    const CWD_DOWN_MAX_MBPS = 100;
    const CWD_UP_MAX_MBPS = 30;

    const CWD_THEMES = {
        good: { ring1: '#10b981', ring2: '#34d399', ring3: '#6ee7b7', wave1: 'rgba(16,185,129,.42)', wave2: 'rgba(5,150,105,.88)', text: '#6ee7b7', glow: 'rgba(16,185,129,.55)' },
        mid:  { ring1: '#f59e0b', ring2: '#fbbf24', ring3: '#fcd34d', wave1: 'rgba(245,158,11,.42)', wave2: 'rgba(217,119,6,.88)', text: '#fcd34d', glow: 'rgba(245,158,11,.60)' },
        low:  { ring1: '#f43f5e', ring2: '#fb7185', ring3: '#fda4af', wave1: 'rgba(244,63,94,.42)', wave2: 'rgba(225,29,72,.88)', text: '#fda4af', glow: 'rgba(244,63,94,.65)' }
    };

    function cwdThemeFor(percent) {
        if (percent > 60) return 'good';
        if (percent > 30) return 'mid';
        return 'low';
    }

    function cwdApplyTheme(themeName) {
        if (_cwdCurrentTheme === themeName) return;
        _cwdCurrentTheme = themeName;
        const t = CWD_THEMES[themeName];
        const content = document.getElementById('wifiDataContent');
        const s1 = document.getElementById('cwdGradStop1');
        const s2 = document.getElementById('cwdGradStop2');
        const s3 = document.getElementById('cwdGradStop3');
        if (s1) s1.setAttribute('stop-color', t.ring1);
        if (s2) s2.setAttribute('stop-color', t.ring2);
        if (s3) s3.setAttribute('stop-color', t.ring3);
        if (content) {
            content.style.setProperty('--cwd-wave-1', t.wave1);
            content.style.setProperty('--cwd-wave-2', t.wave2);
            content.style.setProperty('--cwd-text', t.text);
            content.style.setProperty('--cwd-glow', t.glow);
        }
    }

    function cwdSetRing(node, circ, percent) {
        if (!node) return;
        const p = cwdClamp(percent, 0, 100);
        node.style.strokeDashoffset = (circ * (1 - p / 100)).toFixed(2);
    }

    function cwdSeedBubbles(hostId, count) {
        const host = document.getElementById(hostId);
        if (!host || host.dataset.seeded === '1') return;
        host.dataset.seeded = '1';
        const frag = document.createDocumentFragment();
        for (let i = 0; i < count; i++) {
            const b = document.createElement('span');
            b.className = 'cwd-bubble';
            const size = 2.5 + Math.random() * 4;
            b.style.width = size + 'px';
            b.style.height = size + 'px';
            b.style.left = (8 + Math.random() * 82) + '%';
            b.style.animationDuration = (12 + Math.random() * 10).toFixed(1) + 's';
            b.style.animationDelay = (-Math.random() * 20).toFixed(1) + 's';
            frag.appendChild(b);
        }
        host.appendChild(frag);
    }

    function cwdUpdateSpeedo(speedMbps, max, arcEl, needleEl, numEl, peakEl, prevPeak) {
        const pct = cwdClamp((speedMbps / max) * 100, 0, 100);
        if (arcEl) arcEl.style.strokeDashoffset = (CWD_SPEEDO_ARC * (1 - pct / 100)).toFixed(2);
        if (needleEl) {
            const angle = -90 + (pct / 100) * 180;
            needleEl.style.transform = 'rotate(' + angle.toFixed(2) + 'deg)';
        }
        if (numEl) numEl.textContent = speedMbps.toFixed(1);
        const newPeak = Math.max(prevPeak, speedMbps);
        if (peakEl) peakEl.textContent = newPeak.toFixed(1);
        return newPeak;
    }

    const CWD_SPARK_W = 300, CWD_SPARK_H = 60;
    function cwdRenderSpark(downMbps) {
        _cwdSparkHistory.shift();
        _cwdSparkHistory.push(downMbps);

        const sparkMax = Math.max(10, Math.max.apply(null, _cwdSparkHistory) * 1.25);
        const n = _cwdSparkHistory.length;
        const stepX = CWD_SPARK_W / (n - 1);
        let points = '';
        _cwdSparkHistory.forEach((v, i) => {
            const x = i * stepX;
            const y = CWD_SPARK_H - cwdClamp((v / sparkMax) * (CWD_SPARK_H - 8), 0, CWD_SPARK_H - 8) - 3;
            points += x.toFixed(1) + ',' + y.toFixed(1) + ' ';
        });

        const line = document.getElementById('cwdSparkLine');
        const area = document.getElementById('cwdSparkArea');
        const now = document.getElementById('cwdSparkNow');
        if (line) line.setAttribute('points', points.trim());
        if (area) {
            const areaPath = 'M0,' + CWD_SPARK_H + ' L' + points.trim().split(' ').join(' L') + ' L' + CWD_SPARK_W + ',' + CWD_SPARK_H + ' Z';
            area.setAttribute('d', areaPath);
        }
        if (now) now.textContent = downMbps.toFixed(1) + ' Mbps';
    }

    function cwdFormatDurationSplit(totalSeconds) {
        const s = Math.max(0, Math.floor(totalSeconds || 0));
        if (s >= 86400) {
            const days = Math.floor(s / 86400);
            const hours = Math.floor((s % 86400) / 3600);
            return { value: String(days), unit: 'يوم', sub: 'و ' + hours + ' ساعة' };
        }
        if (s >= 3600) {
            const hours = Math.floor(s / 3600);
            const mins = Math.floor((s % 3600) / 60);
            return { value: String(hours), unit: 'س', sub: 'و ' + mins + ' دقيقة' };
        }
        const mins = Math.floor(s / 60);
        const secs = s % 60;
        return { value: String(mins), unit: 'د', sub: 'و ' + secs + ' ثانية' };
    }

    function renderWifiTimeGauges() {
        const el = (id) => document.getElementById(id);
        const consumed = _cwdConsumedSeconds;
        const remaining = _wifiTotalSeconds;
        const totalSession = consumed + remaining;

        const consumedPercent = totalSession > 0 ? cwdClamp((consumed / totalSession) * 100, 0, 100) : 0;
        const remainingPercent = totalSession > 0 ? cwdClamp((remaining / totalSession) * 100, 0, 100) : 0;

        const cFmt = cwdFormatDurationSplit(consumed);
        const rFmt = cwdFormatDurationSplit(remaining);

        el('cwdConsumedGauge') && el('cwdConsumedGauge').style.setProperty('--fill', cwdClamp(consumedPercent, 6, 100) + '%');
        if (el('cwdConsumedVal')) el('cwdConsumedVal').innerHTML = cFmt.value + '<small>' + cFmt.unit + '</small>';
        if (el('cwdConsumedSub')) el('cwdConsumedSub').textContent = cFmt.sub;
        cwdSetRing(el('cwdRingConsumed'), CWD_ARC_SM, consumedPercent);

        el('cwdRemainingGauge') && el('cwdRemainingGauge').style.setProperty('--fill', cwdClamp(remainingPercent, 6, 100) + '%');
        if (el('cwdRemainingVal')) el('cwdRemainingVal').innerHTML = rFmt.value + '<small>' + rFmt.unit + '</small>';
        if (el('cwdRemainingSub')) el('cwdRemainingSub').textContent = rFmt.sub;
        cwdSetRing(el('cwdRingRemaining'), CWD_ARC_SM, remainingPercent);

        const mm = String(Math.floor(consumed / 60) % 60).padStart(2, '0');
        const hh = String(Math.floor(consumed / 3600)).padStart(2, '0');
        if (el('cwdSessionVal')) el('cwdSessionVal').textContent = hh + ':' + mm;
    }

    /* ─────────── تنبيه انخفاض الرصيد ─────────── */
    function cwdCheckAlert(unlimited, remainingMB) {
        const bellBtn = document.getElementById('cwdBellBtn');
        const gaugeCard = document.getElementById('cwdGaugeCard');
        if (unlimited) {
            _cwdAlerted = false;
            if (bellBtn) bellBtn.classList.remove('alert');
            if (gaugeCard) gaugeCard.classList.remove('alert');
            return;
        }

        const below = remainingMB <= _cwdThreshold;
        if (below && !_cwdAlerted) {
            _cwdAlerted = true;
            if (bellBtn) { bellBtn.classList.remove('armed'); bellBtn.classList.add('alert'); }
            if (gaugeCard) gaugeCard.classList.add('alert');

            const text = remainingMB >= 1000 ? (remainingMB / 1000).toFixed(2) + ' GB' : Math.round(remainingMB) + ' MB';
            cwdShowToast('تنبيه: الرصيد المتبقي وصل إلى ' + text);
            if (navigator.vibrate) { try { navigator.vibrate([120, 60, 120, 60, 200]); } catch (_) {} }
        } else if (!below && _cwdAlerted) {
            _cwdAlerted = false;
            if (bellBtn) { bellBtn.classList.remove('alert'); bellBtn.classList.add('armed'); }
            if (gaugeCard) gaugeCard.classList.remove('alert');
        }
    }

    function cwdShowToast(message) {
        const host = document.getElementById('cwdToasts');
        if (!host) return;
        const t = document.createElement('div');
        t.className = 'cwd-toast';
        t.innerHTML = '<i class="fa-solid fa-bell"></i><span>' + esc(message) + '</span>';
        host.appendChild(t);
        requestAnimationFrame(() => t.classList.add('show'));
        setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 500); }, 3200);
        while (host.children.length > 2) host.firstElementChild.remove();
    }

    function cwdUpdatePresets(val) {
        document.querySelectorAll('.cwd-bell-preset').forEach(p => {
            p.classList.toggle('active', Number(p.dataset.val) === Number(val));
        });
    }

    function wireCwdOnce() {
        if (_cwdWired) return;
        _cwdWired = true;

        const bellBtn = document.getElementById('cwdBellBtn');
        const modal = document.getElementById('cwdBellModal');
        const range = document.getElementById('cwdBellRange');
        const display = document.getElementById('cwdBellThresholdDisplay');
        const cancelBtn = document.getElementById('cwdBellCancel');
        const saveBtn = document.getElementById('cwdBellSave');

        if (bellBtn && _cwdThreshold > 0) bellBtn.classList.add('armed');

        if (bellBtn && modal) {
            bellBtn.addEventListener('click', () => {
                if (range) range.value = _cwdThreshold;
                if (display) display.textContent = _cwdThreshold;
                cwdUpdatePresets(_cwdThreshold);
                modal.classList.add('open');
            });
            modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('open'); });
        }
        if (cancelBtn && modal) cancelBtn.addEventListener('click', () => modal.classList.remove('open'));

        if (range && display) {
            range.addEventListener('input', (e) => {
                const v = Number(e.target.value);
                display.textContent = v;
                cwdUpdatePresets(v);
            });
        }

        document.querySelectorAll('.cwd-bell-preset').forEach(p => {
            p.addEventListener('click', () => {
                const v = Number(p.dataset.val);
                if (range) range.value = v;
                if (display) display.textContent = v;
                cwdUpdatePresets(v);
            });
        });

        if (saveBtn && range && modal) {
            saveBtn.addEventListener('click', () => {
                const v = Number(range.value);
                _cwdThreshold = v;
                _cwdAlerted = false;
                try { localStorage.setItem('kovant_wifi_balance_threshold', String(v)); } catch (_) {}

                const bellBtnEl = document.getElementById('cwdBellBtn');
                const gaugeCard = document.getElementById('cwdGaugeCard');
                if (bellBtnEl) { bellBtnEl.classList.remove('alert'); bellBtnEl.classList.add('armed'); }
                if (gaugeCard) gaugeCard.classList.remove('alert');

                modal.classList.remove('open');
                const displayVal = v >= 1000 ? (v / 1000).toFixed(1) + ' GB' : v + ' MB';
                cwdShowToast('تم حفظ التنبيه عند ' + displayVal);
            });
        }
    }

    /* ═══════════════════════════════════════════════════
       تسجيل الدخول بالكرت (بوابة www.c.com)
       تظهر شاشة الدخول فقط عندما لا توجد بيانات كرت (غير مسجَّل أو انتهى).
       ═══════════════════════════════════════════════════ */
    const COVA_PORTAL = {
        loginPaths: ['/login', '/'],   // نجرّبها بالترتيب: http://www.c.com/login ثم http://www.c.com/
        userParam: 'username',      // اسم حقل رقم الكرت
        passParam: 'password',      // اسم حقل كلمة المرور
        passwordMode: 'same',       // 'same' = كلمة المرور نفس رقم الكرت | 'empty' = فارغة
        dstParam: 'dst',            // صفحة الوجهة بعد النجاح (Captive Portal القياسي)
        dstValue: 'http://www.c.com/status',
        speedParam: 'speed',        // قيمة السرعة المختارة (1، 2، 4 …)
        extraParams: {}             // أي باراميترات ثابتة أخرى
    };
    const COVA_CARD_KEY = 'kovant_wifi_saved_card';
    const COVA_SPEEDS = [1, 2, 4, 8, 16, 32];
    let _clBusy = false;
    let _clSpeed = null;
    let _clWired = false;
    let _clAnim = null;

    function covaLoadSaved() {
        try {
            const j = JSON.parse(localStorage.getItem(COVA_CARD_KEY) || 'null');
            return j && j.card ? j : null;
        } catch (_) { return null; }
    }
    /* كل كرت صحيح جديد يُحفظ ويستبدل السابق — تستعمله البصمة */
    function covaSaveCard(card, speed, expired) {
        try { localStorage.setItem(COVA_CARD_KEY, JSON.stringify({ card, speed: speed || null, savedAt: Date.now(), expired: !!expired })); } catch (_) {}
    }
    function covaMarkSavedExpired(card) {
        const s = covaLoadSaved();
        if (!s || (card && s.card !== card)) return;
        s.expired = true; s.expiredAt = Date.now();
        try { localStorage.setItem(COVA_CARD_KEY, JSON.stringify(s)); } catch (_) {}
    }
    function covaMaskCard(c) { c = String(c || ''); return c.length > 4 ? '••••' + c.slice(-4) : c; }

    /* ── تصنيف نص رسالة البوابة (النص الأصلي يُعرض كاملاً دائماً) ── */
    function covaClassifyPortalText(t) {
        const s = String(t || '');
        if (/حظر|محظور|banned|blocked|black ?list|suspend|disabled|معطل|موقوف|ممنوع/i.test(s)) return 'banned';
        if (/انتهت|انتهى|منتهي|expired|uptime limit|limit reached|quota|exhaust|استنفد|نفد|نفذ|لا يوجد رصيد/i.test(s)) return 'expired';
        if (/already (?:logged|in use|active)|مستخدم (?:بالفعل|حالياً|من قبل|على جهاز)|قيد الاستخدام|no more sessions|جلسة أخرى|another device|مسجل الدخول بالفعل|active session/i.test(s)) return 'inuse';
        if (/invalid|incorrect|wrong|not found|unknown|خطأ|خاطئ|غير صحيح|غير صالح|غير موجود|فشل|failed/i.test(s)) return 'wrong';
        return 'unknown';
    }
    const CL_KINDS = {
        wrong:       { cls: 'err',  icon: 'fa-circle-xmark',        title: 'رقم الكرت غير صحيح' },
        banned:      { cls: 'err',  icon: 'fa-ban',                 title: 'الكرت محظور' },
        expired:     { cls: 'warn', icon: 'fa-hourglass-end',       title: 'انتهى الكرت' },
        inuse:       { cls: 'warn', icon: 'fa-user-lock',           title: 'الكرت مستخدم حالياً' },
        unknown:     { cls: 'info', icon: 'fa-circle-info',         title: 'رسالة من الشبكة' },
        unreachable: { cls: 'err',  icon: 'fa-plug-circle-xmark',   title: 'تعذّر الوصول للراوتر' },
        info:        { cls: 'info', icon: 'fa-circle-info',         title: 'تنبيه' },
        ok:          { cls: 'ok',   icon: 'fa-circle-check',        title: 'تم تسجيل الدخول' }
    };

    /* استخراج رسالة البوابة كما تظهر في www.c.com */
    function covaExtractPortalMessage(html, strict) {
        if (!html) return '';
        const raw = String(html);
        const h = raw.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ');
        const found = [];
        const re = /<(\w+)[^>]*(?:class|id)\s*=\s*["'][^"']*(?:error|alert|msg|message|notice|warn|danger|info|status)[^"']*["'][^>]*>([\s\S]*?)<\/\1>/gi;
        let m;
        while ((m = re.exec(h))) {
            const t = stripWifiHtmlTags(m[2]);
            if (t && t.length >= 3 && found.indexOf(t) === -1) found.push(t);
        }
        if (found.length) return found.join('\n').slice(0, 600);
        const al = raw.match(/alert\(\s*["']([^"']{3,300})["']/i);
        if (al) return al[1];
        if (strict) return '';
        const body = h.replace(/<(?:input|button|label|form|select|option|textarea)[\s\S]*?>/gi, ' ');
        return stripWifiHtmlTags(body).slice(0, 400);
    }

    /* طلب GET عبر شبكة الواي فاي (native ثم CapacitorHttp ثم fetch) */
    async function covaHttpGet(url, timeout) {
        const Wifi = getWifiPlugin();
        const CapHttp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;
        const errs = [];
        if (Wifi && Wifi.httpGet) {
            try { const r = await Wifi.httpGet({ url, timeout }); return { html: r.body || '', status: r.status }; }
            catch (e) { errs.push('native: ' + ((e && (e.message || e.code)) || e)); }
        }
        if (CapHttp) {
            try {
                const r = await CapHttp.get({ url, connectTimeout: timeout, readTimeout: timeout });
                return { html: typeof r.data === 'string' ? r.data : JSON.stringify(r.data || ''), status: r.status };
            } catch (e) { errs.push('http: ' + ((e && (e.message || e.code)) || e)); }
        }
        try { const r = await fetch(url, { cache: 'no-store' }); return { html: await r.text(), status: r.status }; }
        catch (e) { errs.push('fetch: ' + ((e && (e.message || e.code)) || e)); }
        throw new Error(errs.join(' | '));
    }

    /* طلب POST (x-www-form-urlencoded) عبر شبكة الواي فاي (native ثم CapacitorHttp ثم fetch) */
    async function covaHttpPost(url, bodyStr, timeout) {
        const Wifi = getWifiPlugin();
        const CapHttp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;
        const FORM = 'application/x-www-form-urlencoded';
        const errs = [];
        if (Wifi && Wifi.httpPost) {
            try { const r = await Wifi.httpPost({ url, body: bodyStr, contentType: FORM, timeout }); return { html: r.body || '', status: r.status }; }
            catch (e) { errs.push('native: ' + ((e && (e.message || e.code)) || e)); }
        }
        if (CapHttp) {
            try {
                const r = await CapHttp.post({
                    url, headers: { 'Content-Type': FORM }, data: bodyStr,
                    connectTimeout: timeout, readTimeout: timeout
                });
                return { html: typeof r.data === 'string' ? r.data : JSON.stringify(r.data || ''), status: r.status };
            } catch (e) { errs.push('http: ' + ((e && (e.message || e.code)) || e)); }
        }
        try {
            const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': FORM }, body: bodyStr, cache: 'no-store' });
            return { html: await r.text(), status: r.status };
        } catch (e) { errs.push('fetch: ' + ((e && (e.message || e.code)) || e)); }
        throw new Error(errs.join(' | '));
    }

    /* ── واجهة الدخول ── */
    const CL_CSS = `
    #covaLogin { position:relative; display:none; min-height:calc(100vh - 150px); overflow:hidden; border-radius:26px; padding:20px 14px 26px; color:#fff; font-family:'Tajawal','Cairo',sans-serif; background: radial-gradient(circle at 20% 30%, #001d3a 0%, #010714 100%); border:1px solid rgba(2,163,254,.25); }
    #covaLogin * { box-sizing:border-box; }
    #covaLogin .cl-canvas { position:absolute; inset:0; width:100%; height:100%; z-index:0; pointer-events:none; opacity:.9; }
    #covaLogin::after { content:""; position:absolute; inset:0; z-index:0; pointer-events:none; background-image:linear-gradient(to right, rgba(2,163,254,.10) 1px, transparent 1px), linear-gradient(to bottom, rgba(196,161,97,.10) 1px, transparent 1px); background-size:46px 46px; -webkit-mask-image:radial-gradient(circle at 50% 40%, #000 25%, transparent 78%); mask-image:radial-gradient(circle at 50% 40%, #000 25%, transparent 78%); }
    #covaLogin .cl-wrap { position:relative; z-index:2; max-width:460px; margin:0 auto; display:flex; flex-direction:column; align-items:center; }
    #covaLogin .cl-brand { text-align:center; margin-bottom:8px; }
    #covaLogin .cl-sphere { position:relative; width:104px; height:104px; margin:0 auto 8px; display:flex; align-items:center; justify-content:center; background:rgba(1,20,40,.5); border-radius:50%; box-shadow:0 0 40px rgba(2,163,254,.45), 0 0 0 2px rgba(196,161,97,.3); }
    #covaLogin .cl-ring { position:absolute; border-radius:50%; border:2px solid transparent; pointer-events:none; }
    #covaLogin .cl-ring.r1 { width:94px; height:94px; border-top:2px dashed #02a3fe; border-right:2px solid #c4a161; border-bottom:2px dotted #02a3fe; animation:clSpin 12s linear infinite; }
    #covaLogin .cl-ring.r2 { width:74px; height:74px; border-bottom:2px solid #f7e1b5; border-left:2px dashed #02a3fe; animation:clSpinR 8s linear infinite; }
    #covaLogin .cl-ring.r3 { width:54px; height:54px; border-top:2px dotted #c4a161; border-right:2px solid rgba(2,163,254,.7); animation:clSpin 6s linear infinite; }
    #covaLogin .cl-core { font-size:2.3rem; color:#f7e1b5; filter:drop-shadow(0 0 10px #c4a161) drop-shadow(0 0 4px #02a3fe); animation:clFloat 3s ease-in-out infinite; }
    #covaLogin .cl-title { font-size:2.3rem; font-weight:800; letter-spacing:2px; background:linear-gradient(135deg,#fff,#f7e1b5,#c4a161); -webkit-background-clip:text; background-clip:text; color:transparent; margin:6px 0 0; }
    #covaLogin .cl-slogan { color:#c4a161; font-size:.95rem; letter-spacing:3px; border-top:1px dashed rgba(196,161,97,.7); display:inline-block; padding-top:6px; font-weight:500; }
    #covaLogin .cl-welcome { text-align:center; margin:16px 0 14px; }
    #covaLogin .cl-welcome h2 { font-size:1.45rem; font-weight:500; color:#f0f3f8; margin:0; }
    #covaLogin .cl-tag { display:flex; align-items:center; justify-content:center; gap:12px; margin-top:6px; color:#b9c7da; font-size:.95rem; }
    #covaLogin .cl-line { width:44px; height:1px; background:linear-gradient(90deg, transparent, #c4a161, #02a3fe, transparent); }
    #covaLogin .cl-card { width:100%; background:rgba(0,15,35,.6); backdrop-filter:blur(14px); -webkit-backdrop-filter:blur(14px); border-radius:34px; border:1px solid rgba(2,163,254,.4); padding:24px 18px; box-shadow:0 24px 40px rgba(0,0,0,.5), 0 0 0 1px rgba(196,161,97,.25) inset; }
    #covaLogin .cl-field { position:relative; margin-bottom:16px; }
    #covaLogin .cl-field > i { position:absolute; right:18px; top:50%; transform:translateY(-50%); color:#9aaec5; font-size:1.15rem; }
    #covaLogin .cl-input { width:100%; background:rgba(1,10,22,.8); border:1px solid #2a4b6e; border-radius:60px; padding:15px 50px 15px 22px; color:#fff; font-size:1.05rem; font-family:inherit; outline:none; letter-spacing:1px; transition:.25s; }
    #covaLogin .cl-input:focus { border-color:#c4a161; box-shadow:0 0 15px rgba(196,161,97,.5), 0 0 30px rgba(2,163,254,.2); }
    #covaLogin .cl-input::placeholder { color:#6c7e97; font-weight:300; letter-spacing:0; }
    #covaLogin .cl-speed { width:100%; background:rgba(1,10,22,.8); border:1px solid #2a4b6e; border-radius:60px; padding:14px 20px; color:#f5e5c8; font-family:inherit; font-size:1rem; font-weight:500; display:flex; align-items:center; gap:10px; cursor:pointer; margin-bottom:16px; transition:.25s; }
    #covaLogin .cl-speed:active, #covaLogin .cl-speed:focus-visible { border-color:#c4a161; box-shadow:0 0 18px rgba(196,161,97,.35); }
    #covaLogin .cl-speed .fa-gauge-high { color:#c4a161; }
    #covaLogin .cl-speed .cl-st { flex:1; text-align:right; }
    #covaLogin .cl-speed .cl-sv { font-weight:700; font-size:.92rem; color:#7f92aa; white-space:nowrap; }
    #covaLogin .cl-speed .cl-sv.has { color:#7fd0ff; text-shadow:0 0 12px rgba(2,163,254,.8); }
    #covaLogin .cl-speed .fa-chevron-left { font-size:.75rem; color:#6c7e97; }
    #covaLogin .cl-row { display:flex; gap:10px; align-items:stretch; }
    #covaLogin .cl-login { flex:1; background:linear-gradient(100deg,#c4a161,#efdaa6,#c4a161); border:none; border-radius:60px; padding:15px; font-size:1.2rem; font-weight:800; font-family:inherit; color:#0a1929; cursor:pointer; box-shadow:0 8px 20px rgba(0,0,0,.5), 0 0 16px rgba(196,161,97,.6); }
    #covaLogin .cl-login:active { transform:scale(.96); }
    #covaLogin .cl-login:disabled, #covaLogin .cl-finger:disabled, #covaLogin .cl-speed:disabled { opacity:.55; cursor:default; }
    #covaLogin .cl-finger { flex:0 0 58px; width:58px; border-radius:60px; background:rgba(2,163,254,.12); border:1.5px solid #02a3fe; color:#7fd0ff; font-size:1.55rem; cursor:pointer; display:flex; align-items:center; justify-content:center; box-shadow:0 0 16px rgba(2,163,254,.25); }
    #covaLogin .cl-finger:active { transform:scale(.94); }
    #covaLogin .cl-finger.scanning { animation:clPulse .6s ease-in-out infinite; color:#fff; }
    #covaLogin .cl-saved { margin-top:12px; text-align:center; font-size:.78rem; color:#8fa6c2; }
    #covaLogin .cl-saved b { color:#f7e1b5; letter-spacing:1px; }
    #covaLogin .cl-saved .exp { color:#fbbf24; }
    #covaLogin .cl-busy { display:none; align-items:center; justify-content:center; gap:10px; margin:0 0 14px; padding:12px; border-radius:20px; background:rgba(2,163,254,.10); border:1px solid rgba(2,163,254,.35); color:#bfe6ff; font-size:.9rem; font-weight:600; }
    #covaLogin .cl-spin { width:18px; height:18px; border-radius:50%; border:2.5px solid rgba(127,208,255,.3); border-top-color:#7fd0ff; animation:clSpin .8s linear infinite; }
    #covaLogin .cl-msg { display:none; margin:0 0 14px; padding:14px 16px; border-radius:20px; text-align:right; }
    #covaLogin .cl-msg .h { display:flex; align-items:center; gap:8px; font-weight:800; font-size:1rem; margin-bottom:6px; }
    #covaLogin .cl-msg .t { font-size:.92rem; line-height:1.7; white-space:pre-line; word-break:break-word; color:#f0f3f8; }
    #covaLogin .cl-msg .s { margin-top:8px; font-size:.7rem; color:#8fa6c2; }
    #covaLogin .cl-msg.err  { background:rgba(244,63,94,.12);  border:1px solid rgba(244,63,94,.45); } #covaLogin .cl-msg.err .h  { color:#fda4af; }
    #covaLogin .cl-msg.warn { background:rgba(245,158,11,.12); border:1px solid rgba(245,158,11,.45); } #covaLogin .cl-msg.warn .h { color:#fcd34d; }
    #covaLogin .cl-msg.info { background:rgba(2,163,254,.10);  border:1px solid rgba(2,163,254,.35); } #covaLogin .cl-msg.info .h { color:#7fd0ff; }
    #covaLogin .cl-msg.ok   { background:rgba(16,185,129,.12); border:1px solid rgba(16,185,129,.45); } #covaLogin .cl-msg.ok .h   { color:#6ee7b7; }
    #covaLogin .cl-feats { display:flex; justify-content:space-between; align-items:center; width:100%; margin-top:22px; gap:6px; background:rgba(0,5,15,.5); border-radius:50px; padding:12px 6px; border:.5px solid rgba(2,163,254,.5); }
    #covaLogin .cl-feat { text-align:center; flex:1; }
    #covaLogin .cl-feat i { font-size:1.4rem; color:#c4a161; margin-bottom:5px; display:inline-block; }
    #covaLogin .cl-feat strong { font-size:.78rem; display:block; color:#f0ede8; }
    #covaLogin .cl-feat span { font-size:.62rem; color:#b6c8e0; }
    #covaLogin .cl-sep { width:1px; height:36px; background:linear-gradient(to bottom, transparent, #c4a161, #02a3fe, transparent); }
    #covaLogin .cl-foot { margin-top:18px; font-size:.65rem; color:#6c7e97; text-align:center; letter-spacing:1px; }
    #covaLogin .cl-modal { position:fixed; inset:0; z-index:100050; background:rgba(0,0,0,.8); backdrop-filter:blur(8px); display:flex; align-items:center; justify-content:center; visibility:hidden; opacity:0; transition:.25s; padding:20px; }
    #covaLogin .cl-modal.active { visibility:visible; opacity:1; }
    #covaLogin .cl-mcard { width:92%; max-width:420px; background:rgba(0,15,35,.92); border-radius:34px; border:1px solid rgba(2,163,254,.5); padding:28px 20px; position:relative; box-shadow:0 30px 50px rgba(0,0,0,.8), 0 0 0 1px rgba(196,161,97,.3) inset; transform:scale(.92); transition:.25s; }
    #covaLogin .cl-modal.active .cl-mcard { transform:scale(1); }
    #covaLogin .cl-mclose { position:absolute; top:12px; left:16px; background:transparent; border:none; color:#c4a161; font-size:1.8rem; cursor:pointer; line-height:1; }
    #covaLogin .cl-mtitle { font-size:1.5rem; font-weight:700; text-align:center; color:#f7e1b5; margin-bottom:4px; }
    #covaLogin .cl-msub { text-align:center; color:#9aaec5; font-size:.85rem; margin-bottom:18px; }
    #covaLogin .cl-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; margin-bottom:18px; }
    #covaLogin .cl-opt { padding:14px 8px; border-radius:20px; border:1.5px solid #2a4b6e; background:rgba(1,10,22,.8); color:#dfe9f5; font-family:inherit; font-size:.95rem; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; transition:.2s; }
    #covaLogin .cl-opt i { color:#c4a161; }
    #covaLogin .cl-opt.sel { border-color:#c4a161; background:rgba(196,161,97,.18); color:#fff; box-shadow:0 0 18px rgba(196,161,97,.5); }
    #covaLogin .cl-confirm { width:100%; background:linear-gradient(100deg,#c4a161,#efdaa6,#c4a161); border:none; border-radius:60px; padding:14px; font-size:1.1rem; font-weight:800; font-family:inherit; color:#0a1929; cursor:pointer; }
    @keyframes clSpin { to { transform:rotate(360deg); } }
    @keyframes clSpinR { to { transform:rotate(-360deg); } }
    @keyframes clFloat { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-5px); } }
    @keyframes clPulse { 0%,100% { box-shadow:0 0 15px rgba(2,163,254,.5); border-color:#02a3fe; } 50% { box-shadow:0 0 36px rgba(2,163,254,1), 0 0 50px rgba(196,161,97,.6); border-color:#c4a161; } }
    `;

    function covaLoginHTML() {
        const opts = COVA_SPEEDS.map(s => '<button class="cl-opt" type="button" data-speed="' + s + '"><i class="fa-solid fa-bolt"></i> ' + s + ' ميجا</button>').join('');
        return `
        <canvas class="cl-canvas" id="clCanvas"></canvas>
        <div class="cl-wrap">
            <div class="cl-brand">
                <div class="cl-sphere"><div class="cl-ring r1"></div><div class="cl-ring r2"></div><div class="cl-ring r3"></div><i class="fas fa-wifi cl-core"></i></div>
                <h1 class="cl-title">COVA NET</h1>
                <div class="cl-slogan">سرعة تجمعنا</div>
            </div>
            <div class="cl-welcome"><h2>أهلًا بك في شبكة كوفا نت</h2>
                <div class="cl-tag"><span class="cl-line"></span><span>عالمك يبدأ من هنا</span><span class="cl-line"></span></div></div>
            <div class="cl-card">
                <div class="cl-busy" id="clBusy"><span class="cl-spin"></span><span id="clBusyTxt">جاري تسجيل الدخول…</span></div>
                <div class="cl-msg" id="clMsg"><div class="h"><i id="clMsgIcon" class="fa-solid"></i><span id="clMsgTitle"></span></div><div class="t" id="clMsgText"></div><div class="s" id="clMsgSrc">رسالة شبكة كوفا نت</div></div>
                <div class="cl-field"><i class="fa-solid fa-id-card"></i><input class="cl-input" type="text" id="clCard" inputmode="numeric" placeholder="رقم الكرت" autocomplete="off"></div>
                <button class="cl-speed" id="clSpeedBtn" type="button"><i class="fa-solid fa-gauge-high"></i><span class="cl-st">اختيار السرعة</span><span class="cl-sv" id="clSpeedLabel">غير محددة</span><i class="fa-solid fa-chevron-left"></i></button>
                <div class="cl-row"><button class="cl-login" id="clLoginBtn" type="button">دخول</button><button class="cl-finger" id="clFingerBtn" type="button" aria-label="الدخول بالبصمة"><i class="fa-solid fa-fingerprint"></i></button></div>
                <div class="cl-saved" id="clSaved"></div>
            </div>
            <div class="cl-feats">
                <div class="cl-feat"><i class="fa-solid fa-gauge-high"></i><strong>سرعة عالية</strong><span>تجربة إنترنت بلا حدود</span></div><div class="cl-sep"></div>
                <div class="cl-feat"><i class="fa-solid fa-shield-halved"></i><strong>أمان وموثوقية</strong><span>حماية اتصالك دائماً</span></div><div class="cl-sep"></div>
                <div class="cl-feat"><i class="fa-solid fa-wifi"></i><strong>اتصال مستقر</strong><span>دائماً أقرب إليك</span></div>
            </div>
            <div class="cl-foot">© كوفا نت — شبكة الأجيال القادمة</div>
        </div>
        <div class="cl-modal" id="clModal"><div class="cl-mcard"><button class="cl-mclose" id="clModalClose" type="button">&times;</button>
            <div class="cl-mtitle">اختيار السرعة</div><div class="cl-msub">اختر سرعة الكرت الخاصة بك</div>
            <div class="cl-grid" id="clGrid">${opts}</div>
            <button class="cl-confirm" id="clConfirmSpeed" type="button">تأكيد السرعة</button></div></div>`;
    }

    function covaEnsureLoginUI() {
        if (document.getElementById('covaLogin')) return true;
        const tab = document.getElementById('wifiTab-data');
        if (!tab) return false;
        if (!document.getElementById('covaLoginStyle')) {
            const st = document.createElement('style');
            st.id = 'covaLoginStyle';
            st.textContent = CL_CSS;
            document.head.appendChild(st);
        }
        const box = document.createElement('div');
        box.id = 'covaLogin';
        box.innerHTML = covaLoginHTML();
        tab.insertBefore(box, tab.firstChild);
        covaWireLoginUI();
        return true;
    }

    function clEl(id) { return document.getElementById(id); }

    function clSetSpeed(v) {
        _clSpeed = v ? String(v) : null;
        const lab = clEl('clSpeedLabel');
        if (lab) { lab.textContent = _clSpeed ? _clSpeed + ' ميجا' : 'غير محددة'; lab.classList.toggle('has', !!_clSpeed); }
    }
    function clOpenSpeed() {
        document.querySelectorAll('#covaLogin .cl-opt').forEach(o => o.classList.toggle('sel', o.dataset.speed === _clSpeed));
        clEl('clModal').classList.add('active');
    }
    function clCloseSpeed() { clEl('clModal').classList.remove('active'); }

    function clShowMsg(kind, text, title) {
        const k = CL_KINDS[kind] || CL_KINDS.unknown;
        const box = clEl('clMsg');
        if (!box) return;
        box.className = 'cl-msg ' + k.cls;
        clEl('clMsgIcon').className = 'fa-solid ' + k.icon;
        clEl('clMsgTitle').textContent = title || k.title;
        clEl('clMsgText').textContent = text || '';
        clEl('clMsgSrc').style.display = (kind === 'unknown' || kind === 'wrong' || kind === 'banned' || kind === 'expired' || kind === 'inuse') ? 'block' : 'none';
        box.style.display = 'block';
    }
    function clClearMsg() { const b = clEl('clMsg'); if (b) b.style.display = 'none'; }
    function clSetBusy(on, txt) {
        const b = clEl('clBusy');
        if (b) { b.style.display = on ? 'flex' : 'none'; }
        if (txt && clEl('clBusyTxt')) clEl('clBusyTxt').textContent = txt;
        ['clLoginBtn', 'clFingerBtn', 'clSpeedBtn', 'clCard'].forEach(id => { const e = clEl(id); if (e) e.disabled = !!on; });
    }
    function clRenderSaved() {
        const el = clEl('clSaved');
        if (!el) return;
        const s = covaLoadSaved();
        el.innerHTML = s
            ? ('<i class="fa-solid fa-fingerprint"></i> الكرت المحفوظ للبصمة: <b>' + esc(covaMaskCard(s.card)) + '</b>' + (s.expired ? ' <span class="exp">(منتهي)</span>' : ''))
            : '<i class="fa-solid fa-fingerprint"></i> سيُحفظ أول كرت صحيح تدخله لاستخدام البصمة';
    }

    /* خلفية الشبكة المتحركة (خفيفة، تعمل فقط والشاشة ظاهرة) */
    function clAnimStart() {
        const cv = clEl('clCanvas');
        if (!cv || _clAnim) return;
        const ctx = cv.getContext('2d');
        let w = 0, h = 0, pts = [];
        const resize = () => {
            const r = cv.parentElement.getBoundingClientRect();
            w = cv.width = Math.max(1, Math.floor(r.width)); h = cv.height = Math.max(1, Math.floor(r.height));
            pts = Array.from({ length: 38 }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .6, vy: (Math.random() - .5) * .6, g: Math.random() > .6, r: Math.random() * 2 + 1.2 }));
        };
        resize();
        const step = () => {
            if (!_clAnim) return;
            if (!document.hidden) {
                ctx.clearRect(0, 0, w, h);
                for (const p of pts) {
                    p.x += p.vx; p.y += p.vy;
                    if (p.x < 0 || p.x > w) p.vx *= -1;
                    if (p.y < 0 || p.y > h) p.vy *= -1;
                    ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832);
                    ctx.fillStyle = p.g ? 'rgba(196,161,97,.9)' : 'rgba(2,163,254,.9)'; ctx.fill();
                }
                for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
                    const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y, d = Math.sqrt(dx * dx + dy * dy);
                    if (d < 100) { ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.strokeStyle = 'rgba(120,170,200,' + ((1 - d / 100) * .45) + ')'; ctx.lineWidth = .7; ctx.stroke(); }
                }
            }
            _clAnim.id = requestAnimationFrame(step);
        };
        _clAnim = { id: 0 };
        _clAnim.id = requestAnimationFrame(step);
    }
    function clAnimStop() {
        if (_clAnim) { cancelAnimationFrame(_clAnim.id); _clAnim = null; }
    }

    function covaWireLoginUI() {
        if (_clWired) return;
        _clWired = true;
        const card = clEl('clCard');
        card.addEventListener('input', function() { this.value = this.value.replace(/\D/g, '').slice(0, 16); });
        card.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); covaDoLogin(card.value, _clSpeed); } });
        clEl('clSpeedBtn').addEventListener('click', clOpenSpeed);
        clEl('clModalClose').addEventListener('click', clCloseSpeed);
        clEl('clModal').addEventListener('click', e => { if (e.target === clEl('clModal')) clCloseSpeed(); });
        clEl('clGrid').addEventListener('click', e => {
            const b = e.target.closest('.cl-opt'); if (!b) return;
            document.querySelectorAll('#covaLogin .cl-opt').forEach(o => o.classList.remove('sel'));
            b.classList.add('sel'); b.dataset.pick = '1'; _clPick = b.dataset.speed;
        });
        clEl('clConfirmSpeed').addEventListener('click', () => {
            if (!_clPick && !_clSpeed) { clShowMsg('info', 'يرجى اختيار السرعة أولاً', 'تنبيه'); clCloseSpeed(); return; }
            if (_clPick) clSetSpeed(_clPick);
            clCloseSpeed();
        });
        clEl('clLoginBtn').addEventListener('click', () => covaDoLogin(card.value, _clSpeed));
        clEl('clFingerBtn').addEventListener('click', clFingerprint);
    }
    let _clPick = null;

    function covaShowLogin(opts) {
        if (!covaEnsureLoginUI()) return;
        opts = opts || {};
        const empty = document.getElementById('wifiDataEmpty');
        const content = document.getElementById('wifiDataContent');
        if (empty) empty.style.display = 'none';
        if (content) content.style.display = 'none';
        _cova.hasData = false;
        const box = clEl('covaLogin');
        box.style.display = 'block';
        const saved = covaLoadSaved();
        if (!_clSpeed && saved && saved.speed) clSetSpeed(saved.speed);
        clRenderSaved();
        if (!_clBusy) {
            clClearMsg();
            // رسالة البوابة الحالية (إن كانت صفحتها تعرض رسالة فعلاً)
            const m = covaExtractPortalMessage(opts.portalHtml, true);
            if (m) clShowMsg(covaClassifyPortalText(m), m);
        }
        clAnimStart();
    }
    function covaHideLogin() {
        const box = document.getElementById('covaLogin');
        if (box) box.style.display = 'none';
        clAnimStop();
    }

    /* ── نافذة «انتهى الكرت» ── */
    let _clExpiredKey = '';
    function covaExpiredPopup(card, text) {
        const key = card + '|' + Math.floor(Date.now() / 60000);
        if (_clExpiredKey === key) return;
        _clExpiredKey = key;
        const body = (text ? '<div style="margin:6px 0 10px;white-space:pre-line">' + esc(text) + '</div>' : '') +
            '<div style="color:#9aaec5;font-size:.9rem">' + (card ? 'الكرت <b style="color:#f7e1b5;letter-spacing:1px">' + esc(covaMaskCard(card)) + '</b> انتهت صلاحيته.' : 'انتهت صلاحية الكرت.') + '<br>أدخل كرتاً جديداً للمتابعة.</div>';
        if (typeof Swal !== 'undefined') {
            Swal.fire({ icon: 'warning', title: 'انتهى الكرت', html: body, confirmButtonText: 'إدخال كرت جديد', background: '#0b1626', color: '#e6edf3', confirmButtonColor: '#c4a161' });
        } else {
            alertSafe('انتهى الكرت ' + covaMaskCard(card) + ' — أدخل كرتاً جديداً', false);
        }
    }

    /* ── تسجيل الدخول: إرسال الكرت ثم انتظار ظهور بياناته ── */
    async function covaDoLogin(cardRaw, speed) {
        if (_clBusy) return;
        const card = String(cardRaw || '').replace(/\D/g, '');
        if (!card) { clShowMsg('wrong', 'يرجى إدخال رقم الكرت', 'تنبيه'); return; }
        if (card.length < 6) { clShowMsg('wrong', 'رقم الكرت غير صحيح، تأكد من إدخال الرقم كاملاً', 'تنبيه'); return; }
        if (!speed) { clShowMsg('info', 'يرجى اختيار سرعة الكرت أولاً', 'تنبيه'); clOpenSpeed(); return; }

        _clBusy = true;
        clClearMsg();
        clSetBusy(true, 'جاري الاتصال بالراوتر…');
        try {
            const base = await getRouterBase();
            const p = new URLSearchParams();
            p.set(COVA_PORTAL.userParam, card);
            p.set(COVA_PORTAL.passParam, COVA_PORTAL.passwordMode === 'same' ? card : '');
            if (COVA_PORTAL.dstParam) p.set(COVA_PORTAL.dstParam, COVA_PORTAL.dstValue);
            if (COVA_PORTAL.speedParam) p.set(COVA_PORTAL.speedParam, speed);
            Object.keys(COVA_PORTAL.extraParams).forEach(k => p.set(k, COVA_PORTAL.extraParams[k]));
            const bodyStr = p.toString();

            // POST إلى /login ثم إلى / (البديل) — نتوقف عند أول رد يحمل نجاحاً أو رسالة صريحة من البوابة
            let resp = null, lastErr = null, data0 = null;
            for (const path of COVA_PORTAL.loginPaths) {
                let r;
                try {
                    r = await covaHttpPost(base + path, bodyStr, 8000);
                } catch (e) { lastErr = e; continue; }
                resp = r;
                const dd = parseCovaRouterData(r.html || '');
                if (dd.loggedIn && dd.hasIds) { data0 = dd; break; }           // صفحة النجاح (status) رجعت مباشرة
                const msg = covaExtractPortalMessage(r.html, true);
                if (msg && covaClassifyPortalText(msg) !== 'unknown') break;     // خطأ/حظر/انتهاء صريح من البوابة
                if (r.status === 404 || r.status === 405) continue;              // المسار غير مدعوم → جرّب البديل
                // رد غير حاسم: نجرّب التحقق من status قبل الانتقال للمسار البديل
                const chk = await fetchCovaRouterData();
                if (chk && chk.loggedIn) { data0 = chk; break; }
            }
            if (!resp) {
                clShowMsg('unreachable', 'تأكد أنك متصل بشبكة كوفا نت ثم حاول مجدداً.\n' + ((lastErr && lastErr.message) || ''));
                return;
            }

            const loginText = covaExtractPortalMessage(resp.html, false);
            const loginKind = covaClassifyPortalText(loginText);
            let data = null;
            const direct = parseCovaRouterData(resp.html || '');
            if (data0) data = data0;
            else if (direct.loggedIn && direct.hasIds) data = direct;

            // رسالة صريحة من البوابة (خطأ/حظر/انتهاء) → نتحقق مرة واحدة فقط بدل الانتظار الطويل
            const maxTries = (!data && loginKind !== 'unknown') ? 1 : 8;
            for (let i = 0; i < maxTries && !data; i++) {
                clSetBusy(true, i < 2 ? 'جاري التحقق من الكرت…' : 'بانتظار ظهور بيانات الكرت…');
                await new Promise(r => setTimeout(r, i === 0 ? 700 : 1500));
                const d = await fetchCovaRouterData();
                if (d && d.loggedIn) { data = d; break; }
                if (_cova.lastFetchKind === 'unreachable') break;
            }

            if (data) {
                covaSaveCard(card, speed, false);       // كل كرت صحيح جديد يُحفظ للبصمة
                _clExpiredKey = '';
                covaApplyRouterData(data);
                await covaTakeTrafficBaseline();
                covaHideLogin();
                covaShowContent();
                covaRenderAll();
                return;
            }

            if (_cova.lastFetchKind === 'unreachable') {
                clShowMsg('unreachable', 'فقد الاتصال بالراوتر أثناء التحقق من الكرت. حاول مجدداً.');
                return;
            }
            let text = loginText;
            if (!text || text.length < 3) text = covaExtractPortalMessage(_cova.lastLoginPageHtml, false);
            const kind = covaClassifyPortalText(text);
            if (kind === 'expired') { covaMarkSavedExpired(card); clRenderSaved(); covaExpiredPopup(card, text); }
            clShowMsg(kind, text || 'لم تظهر بيانات الكرت. تأكد من الرقم والسرعة ثم حاول مجدداً.', kind === 'unknown' && !text ? 'لم تظهر بيانات الكرت' : undefined);
        } finally {
            _clBusy = false;
            clSetBusy(false);
            clRenderSaved();
        }
    }

    /* ── البصمة: تُعبّئ آخر كرت صحيح محفوظ (حتى لو انتهى) ── */
    async function covaBioGate() {
        const Bio = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TuaBiometric;
        if (!Bio) return { ok: true };       // خارج التطبيق (متصفح): لا توجد بصمة للتحقق
        const text = { title: 'بصمة الكرت', subtitle: 'كوفا نت', description: 'ضع إصبعك لتعبئة الكرت المحفوظ' };
        try {
            if (typeof Bio.authenticate === 'function') {
                const r = await Bio.authenticate(text);
                return { ok: !!(r && r.success) };
            }
            // إصدار تطبيق أقدم: نستعمل بصمة دخول التطبيق كبوابة إن كانت مفعّلة
            const h = await Bio.hasSecret();
            if (h && h.hasSecret) {
                const r = await Bio.verifyAndGetSecret(text);
                return { ok: !!(r && r.success) };
            }
            return { ok: false, msg: 'فعّل بصمة الدخول من إعدادات التطبيق أولاً، أو حدّث التطبيق لاستخدام بصمة الكرت.' };
        } catch (e) {
            const m = String((e && (e.message || e.code)) || e);
            if (/cancel|user|negative|lockout/i.test(m)) return { ok: false };
            return { ok: false, msg: 'تعذّر التحقق من البصمة' };
        }
    }

    async function clFingerprint() {
        if (_clBusy) return;
        const saved = covaLoadSaved();
        if (!saved) {
            clShowMsg('info', 'لا يوجد كرت محفوظ بعد. سجّل الدخول بكرت صحيح مرة واحدة وسيُحفظ تلقائياً لاستخدام البصمة.', 'لا يوجد كرت محفوظ');
            return;
        }
        const btn = clEl('clFingerBtn');
        btn.classList.add('scanning');
        const g = await covaBioGate();
        btn.classList.remove('scanning');
        if (!g.ok) { if (g.msg) clShowMsg('info', g.msg, 'البصمة'); return; }

        clEl('clCard').value = saved.card;                 // التعبئة التلقائية في الحقل
        if (saved.speed) clSetSpeed(saved.speed);
        if (saved.expired) {                                // تُعبَّأ حتى لو انتهى الكرت
            clShowMsg('expired', 'هذا الكرت انتهى سابقاً. أدخل كرتاً جديداً.', 'انتهى الكرت');
            covaExpiredPopup(saved.card);
            return;
        }
        covaDoLogin(saved.card, _clSpeed);
    }

    /* ── تطبيق بيانات الراوتر على الحالة ── */
    function covaApplyRouterData(data) {
        _cova.initialRemainingBytes = data.remainingDownloadBytes || 0;
        _cova.initialUploadBytes = data.uploadBytes || 0;
        _cova.initialDownloadBytes = data.downloadBytes || 0;
        _cova.remainingBytes = _cova.initialRemainingBytes;
        _cova.unlimited = !!data.remainingDownloadUnlimited;
        _cova.ip = data.ip || '';
        _cova.speedLabel = data.speedLabel || '';
        _wifiTotalSeconds = data.remainingSeconds || 0;
        _cwdConsumedSeconds = data.consumedSeconds || 0;
        _cova.timeLimited = (data.remainingSeconds || 0) > 0;
        _cova.dataLimited = !_cova.unlimited && _cova.initialRemainingBytes > 0;
        _cova.hasData = true;
        _cova.frozen = false;
    }

    /* ── كشف انتهاء الكرت: نتأكد من الراوتر قبل الإعلان ── */
    async function covaVerifyExpiry() {
        if (_cova.expiryChecking || Date.now() < _cova.nextExpiryCheck) return;
        _cova.expiryChecking = true;
        _cova.nextExpiryCheck = Date.now() + 10000;
        try {
            const d = await fetchCovaRouterData();
            if (!d && _cova.lastFetchKind === 'unreachable') return;       // لا إعلان دون تأكيد من الراوتر
            const timeOk = !_cova.timeLimited || (d && d.remainingSeconds > 0);
            const dataOk = !_cova.dataLimited || (d && (d.remainingDownloadUnlimited || d.remainingDownloadBytes > 0));
            if (d && d.loggedIn && timeOk && dataOk) { covaApplyRouterData(d); return; }   // مجرد انحراف الحساب المحلي
            covaHandleExpired();
        } finally { _cova.expiryChecking = false; }
    }
    function covaHandleExpired() {
        const s = covaLoadSaved();
        if (s) { covaMarkSavedExpired(s.card); }
        _cova.hasData = false;
        covaShowLogin();
        covaExpiredPopup(s ? s.card : '');
    }

    /* ═══════════════════════════════════════════════════
       جلب status.html وتحليلها
       ═══════════════════════════════════════════════════ */
    async function fetchCovaRouterData() {
        const Wifi = getWifiPlugin();
        const CapHttp = window.Capacitor?.Plugins?.CapacitorHttp;
        const base = await getRouterBase();
        const urls = [`${base}/status.html`, `${base}/status`];
        const errors = [];
        let fallback = null;
        let sawHtml = false;
        let lastHtml = '';
        _cova.lastFetchError = '';

        for (const url of urls) {
            const page = url.split('/').pop();
            const attempts = [];
            // 1) الأفضل: HTTP خام عبر شبكة الواي فاي (لا يتأثر بقيود cleartext ولا بتوجيه بيانات الجوال)
            if (Wifi && Wifi.httpGet) {
                attempts.push(['native', async () => {
                    const r = await Wifi.httpGet({ url, timeout: 6000 });
                    return { html: r.body || '', status: r.status };
                }]);
            }
            // 2) CapacitorHttp
            if (CapHttp) {
                attempts.push(['http', async () => {
                    const r = await CapHttp.get({ url, connectTimeout: 5000, readTimeout: 5000 });
                    return { html: typeof r.data === 'string' ? r.data : JSON.stringify(r.data || ''), status: r.status };
                }]);
            }
            // 3) fetch (يعمل فقط خارج التطبيق)
            attempts.push(['fetch', async () => {
                const r = await fetch(url, { cache: 'no-store' });
                return { html: await r.text(), status: r.status };
            }]);

            for (const [name, run] of attempts) {
                try {
                    const r = await run();
                    if (!r.html) { errors.push(`${name}/${page}: رد فارغ (HTTP ${r.status})`); continue; }
                    sawHtml = true; lastHtml = r.html;
                    const parsed = parseCovaRouterData(r.html);
                    if (parsed.loggedIn && parsed.hasIds) { _cova.lastFetchKind = 'ok'; return parsed; }
                    if (parsed.loggedIn) { if (!fallback) fallback = parsed; break; }
                    errors.push(`${name}/${page}: HTTP ${r.status} — الصفحة لا تحوي بيانات الكرت`);
                } catch (e) {
                    errors.push(`${name}/${page}: ${(e && (e.message || e.code)) || e}`);
                }
            }
        }
        _cova.lastFetchError = errors.join(' | ');
        _cova.lastFetchKind = fallback ? 'ok' : (sawHtml ? 'notLoggedIn' : 'unreachable');
        _cova.lastLoginPageHtml = fallback ? '' : lastHtml;
        return fallback;
    }

    function stripWifiHtmlTags(html) {
        return String(html || '')
            .replace(/<[^>]*>/g, ' ')
            .replace(/&nbsp;/gi, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function extractWifiFieldById(html, id) {
        const re = new RegExp('id=["\']' + id + '["\'][^>]*>([\\s\\S]*?)<', 'i');
        const m = html.match(re);
        if (!m) return '';
        return m[1].replace(/&nbsp;/gi, ' ').replace(/\s+/g, ' ').trim();
    }

    function extractLabelSection(plainText, label, span = 40) {
        const idx = plainText.indexOf(label);
        if (idx === -1) return '';
        return plainText.substring(idx + label.length, idx + label.length + span);
    }

    function parseDurationToSeconds(section) {
        if (!section) return 0;
        let total = 0;
        const day = section.match(/(\d+)\s*يوم/);
        const hour = section.match(/(\d+)\s*ساع(?:ة|تين|ات)/);
        const min = section.match(/(\d+)\s*دقيق(?:ة|تين|ائق)/);
        const sec = section.match(/(\d+)\s*(?:ثانية|ثواني|ثانيتين)/);
        if (day) total += parseInt(day[1], 10) * 86400;
        if (hour) total += parseInt(hour[1], 10) * 3600;
        if (min) total += parseInt(min[1], 10) * 60;
        if (sec) total += parseInt(sec[1], 10);
        return total;
    }

    function parseCovaRouterData(html) {
        const data = {
            ip: '', speedLabel: '', uploadBytes: 0, downloadBytes: 0,
            consumedSeconds: 0, remainingSeconds: 0,
            remainingDownloadUnlimited: false, remainingDownloadBytes: 0,
            loggedIn: false
        };

        data.loggedIn = /id=["']bytesin["']/i.test(html) || (/الرفع/.test(html) && /التنزيل/.test(html));
        data.hasIds = /id=["']bytesin["']/i.test(html);
        if (!data.loggedIn) return data;

        const plain = stripWifiHtmlTags(html);
        const sizeRe = /([0-9]+(?:\.[0-9]+)?)\s*(جيجا بايت|ميجا بايت|كيلو بايت|بايت)/;

        const speedText = extractWifiFieldById(html, 'speed-status') || extractLabelSection(plain, 'السرعة الحالية');
        data.speedLabel = speedText.trim();

        const ipSection = extractLabelSection(plain, 'عنوان الاتصال', 40);
        const ipMatch = ipSection.match(/(?:\d{1,3}\.){3}\d{1,3}/) || plain.match(/(?:\d{1,3}\.){3}\d{1,3}/);
        if (ipMatch) data.ip = ipMatch[0];

        const upText = extractWifiFieldById(html, 'bytesin') || extractLabelSection(plain, 'الرفع');
        const upMatch = upText.match(sizeRe);
        if (upMatch) data.uploadBytes = parseWifiSize(upMatch[1], upMatch[2]);

        const downText = extractWifiFieldById(html, 'bytesout') || extractLabelSection(plain, 'التنزيل');
        const downMatch = downText.match(sizeRe);
        if (downMatch) data.downloadBytes = parseWifiSize(downMatch[1], downMatch[2]);

        const consumedText = extractWifiFieldById(html, 'timeup') || extractLabelSection(plain, 'الوقت المستهلك');
        data.consumedSeconds = parseDurationToSeconds(consumedText);

        const remainingText = extractWifiFieldById(html, 'timeLeft') || extractLabelSection(plain, 'الوقت المتبقي');
        data.remainingSeconds = parseDurationToSeconds(remainingText);

        const remainingDownloadText = extractWifiFieldById(html, 'bytesto') || extractLabelSection(plain, 'التحميل المتبقي');
        if (/مفتوح|غير محدود|unlimited/i.test(remainingDownloadText)) {
            data.remainingDownloadUnlimited = true;
        } else {
            const rdMatch = remainingDownloadText.match(sizeRe);
            if (rdMatch) data.remainingDownloadBytes = parseWifiSize(rdMatch[1], rdMatch[2]);
        }

        return data;
    }

    function parseWifiSize(value, unit) {
        const n = parseFloat(value) || 0;
        const u = unit.toLowerCase();
        if (u.includes('جيجا')) return n * 1024 * 1024 * 1024;
        if (u.includes('ميجا')) return n * 1024 * 1024;
        if (u.includes('كيلو')) return n * 1024;
        return n;
    }

    function formatWifiBytes(bytes) {
        if (!bytes || bytes < 1) return '0 B';
        if (bytes >= 1024 * 1024 * 1024) return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
        if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(2) + ' MB';
        if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return bytes.toFixed(0) + ' B';
    }

    function formatWifiSpeed(bps) {
        if (!bps || bps < 1) return '0 B/s';
        if (bps >= 1024 * 1024) return (bps / 1024 / 1024).toFixed(2) + ' MB/s';
        if (bps >= 1024) return (bps / 1024).toFixed(1) + ' KB/s';
        return bps.toFixed(0) + ' B/s';
    }

    /* ═══════════════════════════════════════════════════
       الإشعار الدائم — يقوده CovaForegroundService
       (JS يطلب فقط التشغيل/الإيقاف والصلاحية، لا يُحدّث القيم)
       مرتبط الآن بفتح/إغلاق صفحة الواي فاي، مستقل عن التبويبات
       ═══════════════════════════════════════════════════ */
    async function startSpeedService() {
        const Notif = getNotifPlugin();
        if (!Notif) return;
        try {
            const perm = await Notif.checkPermissions();
            if (perm.notifications !== 'granted') {
                const res = await Notif.requestPermissions();
                if (res.notifications !== 'granted') return;
            }
            await Notif.startForegroundService();
        } catch (_) {}
    }

    function stopSpeedService() {
        const Notif = getNotifPlugin();
        if (!Notif) return;
        try { Notif.stopForegroundService(); } catch (_) {}
    }

    function formatDurationArabic(totalSeconds) {
        if (!totalSeconds || totalSeconds <= 0) return '—';
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const mins = Math.floor((totalSeconds % 3600) / 60);
        const parts = [];
        if (days) parts.push(`${days} يوم`);
        if (hours) parts.push(`${hours} س`);
        if (mins) parts.push(`${mins} د`);
        return parts.join(' ') || 'أقل من دقيقة';
    }

    /* ═══════════════════════════════════════════════════
       Init
       ═══════════════════════════════════════════════════ */
    function init() {
        injectCSS();
        injectHTML();
        wireCwdOnce();

        const observer = new MutationObserver(hookBrand);
        observer.observe(document.body, { childList: true, subtree: true });

        setTimeout(hookBrand, 300);
        setTimeout(hookBrand, 1000);
        setTimeout(hookBrand, 2500);
        setTimeout(hookBrand, 5000);

        console.log('✅ COVA WiFi Module v5 (TrafficStats + Session) loaded');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            stopWifiAutoRefresh();
        } else if (_currentPage === 'networks') {
            startWifiAutoRefresh();
        }
    });

})();