# FIXES-REPORT — KOVANT-v25

## جدول الأخطاء

| # | الخطأ | الملف:السطر | الحالة | السبب / ما تم |
|---|---|---|---|---|
| 1 | مسار غير موجود في الكاش `/index(4) (2).html` | `service-worker.js:5` | ✅ أُصلح | حُذف المسار (يوجد `/index.html` فعلاً). رُفع الكاش من `v17` إلى `v18` (سطر 3) |
| 2 | `npm test` (jest) بلا أي ملف اختبار | `package.json:11` | ✅ أُصلح | أُضيف `tests/smoke.test.js` (4 فحوصات) وبقي سكربت `test` كما هو |
| 3 | README: الخادم "API فقط" دون ذكر الاستثناء | `README.md:34` | ✅ أُصلح | أُضيف استثناء `admin-sadaq-pricing.html` (`server.js:2207`) |
| 4 | README: ملفات Android "في الجذر" | `README.md:26` | ✅ أُصلح | صُحّحت: المصادر في `android/` وهي غير مكتملة |
| 5 | تعدد أسماء المشروع (KovaNet / kovant-v6 / كوفانت / COVA NET) | `README.md:1,3` · `package.json:2` · `capacitor.config.json:3` · `index.html` (13 سطراً) | ⏸️ بانتظار قرار | لم يُغيَّر أي اسم. القائمة الكاملة في قسم "خيارات" أدناه |
| 6 | مجلد `android/` غير قابل للبناء (بلا gradle/Manifest) | `android/` | ⏸️ بانتظار قرار | نقطة خطرة، راجع قسم "المرحلة 3" |
| 7 | `MainActivity.kt` يسجّل 5 إضافات فقط، بينما `capacitor.config.json` و`js/device-usage.js` يستخدمان `TuaNotification` و`CovaTrafficStats` | `MainActivity.kt:14-18` · `capacitor.config.json:39-44` · `js/device-usage.js:18-19` | ✅ أُصلح (المرحلة 1-C) | غالباً ستكون `undefined` في الـ WebView لأن إضافات Capacitor المحلية تحتاج تسجيلاً يدوياً. سُجّلت الإضافتان في `MainActivity.kt` (سطور 10–11 و21–22) |
| 8 | `setup-native-plugins.py` ينسخ 5 ملفات فقط من أصل 9 في `native-plugins/android/` (يستثني TuaNotification وTuaTrafficStats وCovaForegroundService وSpeedOverlayService) | `setup-native-plugins.py:39-40` | ✅ أُصلح (المرحلة 1-D) | صار ينسخ 9 ملفات + res/ + google-services.json ويضيف التبعيات الناقصة، وحُذف قسم تعديل MainActivity منه |

## خيارات للمتبقي

**البند 5 (التسمية)** — الأماكن الحالية:
- `README.md` سطر 1، 3: `KovaNet`
- `package.json` سطر 2: `kovant-v6`
- `capacitor.config.json` سطر 3: `كوفانت`
- `index.html`: أسطر 166, 214, 227, 278, 1756, 1771, 1780, 1812, 2308, 2472, 2474, 2486, 2515 (كوفانت / COVA NET)
- الخيار أ: توحيد الاسم التقني إلى `kovant` (README و package.json) وإبقاء "كوفانت / COVA NET" كاسم عرض للمستخدم.
- الخيار ب: الإبقاء كما هو، وإضافة جملة في README تشرح الأسماء.
- ملاحظة: `appId` (`com.kova.cash`) و`name` في package.json لا ينبغي المساس بهما بلا داعٍ لأنهما مرتبطان بـ Firebase.

**البندان 6 و8** — راجع المرحلة 3 أدناه.

## المرحلة 3 — فحص `android/` (بدون أي تعديل)

الموجود فعلاً (9 ملفات، كلها تحت `android/app/src/main/java/com/kova/cash/`):
`MainActivity.kt` (21 سطراً) · `SMSForegroundService.java` (983) · `SMSDatabase.java` (114) · `SMSWorker.java` (111) · `SmsGatewaySettings.java` (124) · `BootReceiver.java` (47) · `ConnectivityReceiver.java` (35) · `SMSWorkerScheduler.java` (25) · `SMSRetryManager.java` (19).

- `MainActivity.kt` مخصص: يسجّل `TuaBiometric` و`TuaSmsSender` و`TuaWifiManager` و`TuaSmsInbox` و`TuaSmsSettings` قبل `super.onCreate` (بحزمة `com.kova.cash.plugins`).
- **لا يوجد `AndroidManifest.xml`**، ولذلك لا يمكن استعادة تصريحات Services/Receivers منه. لكن الكود يكشف ما يجب أن يحويه:
  - Services: `SMSForegroundService` و`CovaForegroundService` و`SpeedOverlayService` (يستخدم `FOREGROUND_SERVICE_TYPE_SPECIAL_USE`).
  - Receivers: `BootReceiver` (BOOT_COMPLETED وLOCKED_BOOT_COMPLETED) و`ConnectivityReceiver`، مع استقبال `SMS_RECEIVED`.
  - صلاحيات يستخدمها الكود: `READ_SMS` `RECEIVE_SMS` `SEND_SMS` `READ_PHONE_STATE` `ACCESS_FINE_LOCATION` `ACCESS_COARSE_LOCATION` `POST_NOTIFICATIONS`، وما يلزم للـ foreground service والـ overlay (لم أجد ما يؤكدها نصياً، فتحتاج مراجعة).
- **لا يوجد `build.gradle`**، والكود يعتمد على Firebase (Database وAuth) وWorkManager وAndroidX (core)، ويحتاج `androidx.biometric` و`androidx.security:security-crypto` (حسب `setup-native-plugins.py:42-44`).
- ملفات الإضافات الأصلية (`native-plugins/android/*.kt`) ليست داخل شجرة `android/`؛ ينسخها السكربت.
- **تخصيصات لا تُستعاد آلياً بعد `cap add android`:** كل ملفات Java الـ 8 و`MainActivity.kt` المخصص، وتصريحات Manifest المذكورة أعلاه (غير موجودة أصلاً بنسخة محفوظة)، وأي `res/xml` أو intent-filters (غير موجودة في الأرشيف).

### الخيار أ: إعادة توليد المجلد (`npx cap add android`)
- ✅ يضمن بنية Gradle وManifest صحيحة ومتوافقة مع Capacitor 6.
- ⚠️ يلزم نسخ ملفات Java وKotlin والإضافات يدوياً إلى الحزمة الصحيحة (`com.kova.cash` و`com.kova.cash.plugins`).
- ⚠️ Manifest الجديد سيكون عاماً، ويجب كتابة Services وReceivers والصلاحيات من الصفر، وأي نسيان يعني تعطل الخدمات بصمت على الجهاز.
- ⚠️ يجب نقل `google-services.json` إلى `android/app/` وإضافة تبعيات gradle.
- ⚠️ `MainActivity.kt` سيُستبدل بالافتراضي وعليك استرجاع تسجيل الإضافات (احتفظ بنسخة قبل البدء).

### الخيار ب: إكمال الناقص يدوياً دون حذف
- ✅ لا يُفقد أي ملف حالي.
- ⚠️ كتابة `build.gradle` (مشروع + app) و`settings.gradle` و`gradle.properties` و`AndroidManifest.xml` يدوياً دون مرجع مولَّد، فإصدارات AGP وGradle والـ SDK قد لا تتوافق مع Capacitor 6 وتسبب أخطاء بناء.
- ⚠️ احتمال أكبر لنسيان ملفات مولَّدة (`capacitor.settings.gradle`, `res/`, `xml/file_paths`).

**توصيتي (للمعلومة فقط):** الخيار أ، لأن الاعتماد على هيكل مولَّد رسمياً أقل خطراً من كتابة Gradle يدوياً. لكن القرار لك، ولم أنفّذ شيئاً.


## ملاحظة للـ CI (GitHub Actions)
ملفات Java الثمانية و`MainActivity.kt` موجودة حالياً داخل `android/` فقط. إن كان الـ workflow سينفّذ `npx cap add android` فسيفشل أو يتجاهل لوجود المجلد، ولذلك يجب نقل هذه الملفات خارج `android/` (أو نقل `android/` جانباً أولاً) واستعادتها بعد التوليد، مع حذف `MainActivity.java` المولَّد قبل نسخ `MainActivity.kt`.

## تحديث الواجهة (صفحة المستخدم)
- زر «سداد» في شبكة الخدمات استُبدل بزر «الواي فاي» (`index.html:1792`) ويفتح الشبكات القريبة فقط (`openWifiPage({nearbyOnly:true})` في `js/wifi-module.js`، بلا تبويب الراوتر). النقر على شعار «كوفانت» ما زال يفتح الصفحة الكاملة.
- صفحات تحويل لحساب وكشف الحساب وباقات النت وُحِّدت ألوانها وتصميمها مع صفحة المستخدم عبر كتلة CSS في آخر `css/user-app.css` (للشاشة فقط، لا تمس الطباعة).
- رُفع كاش الـ Service Worker إلى `kova-cache-v19`.
- ملاحظة: صفحة سداد (`sadaqInterface`) لم تُحذف، لكنها لم تعد قابلة للوصول من الشاشة الرئيسية.

## تحديث: أيقونة الباقات وصفحة تفاصيل الشبكة
- زر «باقات النت» صار «الباقات» بأيقونة تذكرة/كرت (`fa-ticket`) في الشاشة الرئيسية وشريط التنقل وعنوان صفحة الباقات.
- صفحة تفاصيل الشبكة: أُزيلت القيم المحسوبة/الثابتة (SNR، جودة الرابط، أقصى سرعة، سرعة الاتصال المحسوبة، المعدلات القديمة، عرض القناة المقدَّر، 802.11k/v/az)، وبقيت القيم المقروءة فعلاً من الهاتف أو المشتقة منها (RSSI، BSSID، التردد، القناة، الأمان، DFS، WPS، 802.11r/w) مع مسافة تقريبية موسومة.
- تحديث مباشر كل ~4 ثوانٍ أثناء فتح التفاصيل، مع مؤشر «مباشر · وقت آخر قراءة».
- الحقول الاختيارية (channelWidth / wifiStandard / linkSpeed / is80211mc) تظهر عند إرسالها من `TuaWifiManagerPlugin.kt`؛ إضافتها لم تُنفَّذ بانتظار الموافقة.
- الكاش: `kova-cache-v20`.

## تحديث: حقول حقيقية في تفاصيل الشبكة (Kotlin)
- `TuaWifiManagerPlugin.kt` صار يرسل `channelWidth` (API 23+) و`wifiStandard` (API 30+) و`linkSpeed` (للشبكة المتصلة)، كلها محمية بفحص `SDK_INT` و`try/catch` وتُرجع null على الأجهزة القديمة.
- `js/wifi-module.js` يلتقطها ويحدّثها مباشرة (`nbSig`).
- الكاش: `kova-cache-v21`. أُضيف `.gitignore`.
- لم يُترجَم Kotlin محلياً؛ أول بناء في الـ CI هو الاختبار الحقيقي.

## تحديث: صفحة تسجيل الدخول بالكرت (تبويب الراوتر)
- تظهر شاشة إدخال الكرت فقط عند عدم وجود بيانات كرت (غير مسجَّل أو انتهى)، وتختفي عند ظهور بيانات الكرت. بعد الإدخال تنتظر الشاشة ظهور البيانات ثم تنتقل إليها.
- رسالة بوابة www.c.com (خطأ/حظر/انتهاء/جلسة مستخدمة) تُعرض بنصها كما ترجعه البوابة مع تصنيف.
- البصمة: كل كرت صحيح جديد يُحفظ (يستبدل السابق)؛ البصمة تُعبّئ الكرت المحفوظ حتى لو انتهى. انتهاء الكرت يُظهر نافذة «انتهى الكرت» ثم شاشة الدخول.
- يعتمد الدخول على إعداد `COVA_PORTAL` أعلى كتلة الكود في `js/wifi-module.js` (مسار/حقول البوابة). القيم الافتراضية افتراضية وتحتاج مطابقة مع صفحة www.c.com الحقيقية.
- دالة `authenticate` في `TuaBiometricPlugin.kt` مقترحة ولم تُحفظ بانتظار الموافقة؛ بدونها تعمل البصمة عبر بصمة دخول التطبيق إن كانت مفعّلة.
- الكاش: `kova-cache-v22`.
