/* ============================================================
 * COVANT — صفحة الترحيب بعد تسجيل الدخول
 * تظهر لثوانٍ ثم تنتقل بسلاسة إلى التطبيق (ويمكن تخطّيها بالضغط)
 * ============================================================ */
(function (window, document) {
    'use strict';
    var DURATION = 2600;
    var timer = null;

    function greeting() {
        var h = new Date().getHours();
        if (h >= 4 && h < 12) return 'صباح الخير';
        if (h >= 12 && h < 17) return 'مساء الخير';
        if (h >= 17 && h < 21) return 'مساء النور';
        return 'مرحباً بك';
    }

    function ensure() {
        var el = document.getElementById('welcomeOverlay');
        if (el) return el;
        el = document.createElement('div');
        el.id = 'welcomeOverlay';
        el.addEventListener('click', hide);
        document.body.appendChild(el);
        return el;
    }

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function hide() {
        var el = document.getElementById('welcomeOverlay');
        if (!el || !el.classList.contains('show')) return;
        clearTimeout(timer);
        el.classList.add('hide');
        setTimeout(function () { el.classList.remove('show', 'hide'); el.innerHTML = ''; }, 600);
    }

    function show(user, opts) {
        try {
            opts = opts || {};
            var name = (opts.name || (user && (user.fullName || user.name)) || '').trim() || 'عميلنا العزيز';
            var acc = opts.account != null ? opts.account : (user && (user.accountNumber || user.phone)) || '';
            var initial = name.replace(/\s+/g, '').charAt(0) || 'ك';
            var el = ensure();
            clearTimeout(timer);
            el.classList.remove('hide');
            el.style.setProperty('--wl-dur', DURATION + 'ms');
            el.innerHTML =
                '<div class="wl-badge"><span class="wl-ring"></span><span class="wl-ring r2"></span><div class="wl-avatar">' + esc(initial) + '</div></div>' +
                '<div class="wl-hello">' + esc(opts.greeting || greeting()) + '</div>' +
                '<div class="wl-name">' + esc(name) + '</div>' +
                (acc ? '<div class="wl-acc"><i class="fa-solid fa-id-card"></i><span>' + esc(acc) + '</span></div>' : '') +
                '<div class="wl-msg">' + esc(opts.message || 'يسعدنا وجودك في كوفانت') + '</div>' +
                '<div class="wl-bar"><i></i></div><div class="wl-skip">اضغط للمتابعة</div>';
            el.classList.add('show');
            timer = setTimeout(hide, DURATION);
        } catch (e) { /* الترحيب تحسين بصري فقط ولا يجب أن يعطّل الدخول */ }
    }

    window.showWelcomeScreen = show;
    window.hideWelcomeScreen = hide;
}(window, document));
