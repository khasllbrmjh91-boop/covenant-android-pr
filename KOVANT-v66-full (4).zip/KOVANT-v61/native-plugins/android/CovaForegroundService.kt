package com.kova.cash.plugins

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.RemoteViews
import java.util.Locale
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import com.kova.cash.R

/**
 * CovaForegroundService — خدمة تعمل في الخلفية، تقرأ سرعة الإنترنت كل ثانية
 * وتحدّث الإشعار الدائم حتى عندما يكون التطبيق مغلقاً.
 *
 * يستخدم Custom Layout (RemoteViews) مطابق لتصميم Internet Speed Meter Lite
 */
class CovaForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "cova_net_speed"
        const val CHANNEL_NAME = "سرعة الإنترنت"
        const val NOTIF_ID = 90001
        const val PREFS_NAME = "cova_speed_settings"
        const val UPDATE_INTERVAL_MS = 1000L
        const val NUMBER_SIZE_RATIO = 0.70f // ارتفاع رقم أيقونة السرعة (نسبة من الأيقونة)
        const val UNIT_SIZE_RATIO = 0.45f   // ارتفاع وحدة أيقونة السرعة (نسبة من الأيقونة)

        @Volatile
        var isRunning = false
    }

    private var handler: Handler? = null
    private var updateRunnable: Runnable? = null

    private var lastRxBytes = 0L
    private var lastTxBytes = 0L
    private var lastSampleTime = 0L
    private var usageTicks = 0L

    private var wifiStartRx = 0L
    private var wifiStartTx = 0L

    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        createChannel()
        captureStartUsage()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("0", "KB/s", "0 ك ب/ث", "0 ك ب/ث", "0 ب"))
        isRunning = true

        handler = Handler(Looper.getMainLooper())
        updateRunnable = object : Runnable {
            override fun run() {
                try { updateSpeed() } catch (_: Exception) {}
                // سجل الاستهلاك اليومي (جوال/واي فاي) — كل 5 ثوانٍ
                usageTicks++
                if (usageTicks % 5L == 1L) { try { CovaUsageLog.sample(applicationContext) } catch (_: Exception) {} }
                handler?.postDelayed(this, UPDATE_INTERVAL_MS)
            }
        }
        handler?.post(updateRunnable!!)

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        try { CovaUsageLog.sample(applicationContext) } catch (_: Exception) {}
        updateRunnable?.let { handler?.removeCallbacks(it) }
        handler = null
        try { NotificationManagerCompat.from(this).cancel(NOTIF_ID) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun captureStartUsage() {
        val totalRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
        val totalTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)

        val mobileRx = TrafficStats.getMobileRxBytes()
        val mobileTx = TrafficStats.getMobileTxBytes()

        val hasMobileStats = mobileRx != TrafficStats.UNSUPPORTED.toLong() &&
                             mobileTx != TrafficStats.UNSUPPORTED.toLong()

        if (hasMobileStats) {
            wifiStartRx = totalRx - mobileRx
            wifiStartTx = totalTx - mobileTx
        } else {
            wifiStartRx = totalRx
            wifiStartTx = totalTx
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW).apply {
                description = "إشعار دائم يعرض سرعة الإنترنت"
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
                lockscreenVisibility = if (prefs.getBoolean("hideOnLock", false))
                    Notification.VISIBILITY_SECRET else Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(ch)
        }
    }

    private fun hasNotifPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") ==
                PackageManager.PERMISSION_GRANTED
    }

    private fun updateSpeed() {
        val now = System.currentTimeMillis()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()

        if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return

        if (lastSampleTime > 0L) {
            val elapsed = (now - lastSampleTime) / 1000.0
            if (elapsed > 0.5) {
                val rxDelta = (rx - lastRxBytes).coerceAtLeast(0L)
                val txDelta = (tx - lastTxBytes).coerceAtLeast(0L)

                val downBps = rxDelta / elapsed
                val upBps = txDelta / elapsed

                val downFmt = formatSpeedParts(downBps)
                val upFmt = formatSpeedParts(upBps)

                val wifiUsage = getWifiUsage()

                val notif = buildNotification(
                    downFmt.number,
                    downFmt.unit,
                    downFmt.fullText,
                    upFmt.fullText,
                    wifiUsage
                )

                if (hasNotifPermission()) {
                    try {
                        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                        nm.notify(NOTIF_ID, notif)
                    } catch (_: Exception) {}
                }
            }
        }

        lastRxBytes = rx
        lastTxBytes = tx
        lastSampleTime = now
    }

    private fun getWifiUsage(): String {
        val totalRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
        val totalTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)

        val mobileRx = TrafficStats.getMobileRxBytes()
        val mobileTx = TrafficStats.getMobileTxBytes()

        val hasMobileStats = mobileRx != TrafficStats.UNSUPPORTED.toLong() &&
                             mobileTx != TrafficStats.UNSUPPORTED.toLong()

        var wifiUsed: Long

        if (hasMobileStats) {
            val wifiNow = (totalRx - mobileRx) + (totalTx - mobileTx)
            val wifiStart = wifiStartRx + wifiStartTx
            wifiUsed = (wifiNow - wifiStart).coerceAtLeast(0L)
        } else {
            val totalNow = totalRx + totalTx
            val totalStart = wifiStartRx + wifiStartTx
            wifiUsed = (totalNow - totalStart).coerceAtLeast(0L)
        }

        return formatUsage(wifiUsed)
    }

    private fun formatUsage(bytes: Long): String {
        return when {
            bytes >= 1024L * 1024L * 1024L -> {
                String.format(Locale.US, "%.2f ج ب", bytes / 1024.0 / 1024.0 / 1024.0)
            }
            bytes >= 1024L * 1024L -> {
                String.format(Locale.US, "%.1f م ب", bytes / 1024.0 / 1024.0)
            }
            bytes >= 1024L -> {
                String.format(Locale.US, "%.0f ك ب", bytes / 1024.0)
            }
            else -> {
                "$bytes ب"
            }
        }
    }

    private data class SpeedParts(val number: String, val unit: String, val fullText: String)

    /**
     * أيقونة شريط الحالة: الرقم كبير + الوحدة (KB/s أو MB/s ...) تحته.
     * حجم الرقم ثابت دائماً (2 و22 و222 بنفس الحجم تماماً، كلٌّ في موضعه)،
     * وحجم الوحدة ثابت دائماً (KB/s و MB/s بنفس الحجم). الحجمان يُحسبان مرة
     * واحدة من أعرض رقم (999) وأعرض وحدة، فلا يوجد أي تصغير أو تكبير تلقائي.
     * الموضع العمودي ثابت (من ارتفاع الأرقام والحرف K) فلا يقفز الرقم.
     * الأرقام لاتينية دائماً.
     */
    private fun buildSpeedIcon(number: String, unit: String): IconCompat {
        return try {
            val size = 192
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.TRANSPARENT)

            val maxWidth = size * 0.98f
            val gap = size * 0.03f

            // الرقم العشري (1.5 أو 99.9) يُعرض صحيحاً في الأيقونة
            val iconNumber = number.substringBefore('.').take(3)

            fun newPaint() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            }
            val numPaint = newPaint()
            val unitPaint = newPaint()

            // ارتفاع الرقم = 70٪ من الأيقونة، ثابت دائماً لكل الأرقام (2 و22 و222).
            // إن كان عرض "999" أكبر من الأيقونة يُضغط أفقياً بنسبة ثابتة (scaleX)
            // بدل تقليل الارتفاع، وتُطبَّق النسبة نفسها على كل الأرقام.
            numPaint.textSize = size * NUMBER_SIZE_RATIO
            val numW = numPaint.measureText("999")
            numPaint.textScaleX = if (numW > maxWidth) maxWidth / numW else 1f

            // ارتفاع الوحدة = 45٪ من الأيقونة، ثابت دائماً لكل الوحدات (KB/s و MB/s ...)
            unitPaint.textSize = size * UNIT_SIZE_RATIO
            var widestUnit = 1f
            for (u in arrayOf("KB/s", "MB/s", "GB/s", "Kbps", "Mbps", "Gbps", "B/s", "bps")) {
                widestUnit = maxOf(widestUnit, unitPaint.measureText(u))
            }
            unitPaint.textScaleX = if (widestUnit > maxWidth) maxWidth / widestUnit else 1f

            // مواضع عمودية ثابتة من حدود "0" و"K" (وليس من نص القيمة الحالية)
            val nb = android.graphics.Rect()
            val ub = android.graphics.Rect()
            numPaint.getTextBounds("0", 0, 1, nb)
            unitPaint.getTextBounds("K", 0, 1, ub)
            val total = nb.height() + gap + ub.height()
            val top = (size - total) / 2f
            val numBaseline = top - nb.top
            val unitBaseline = top + nb.height() + gap - ub.top

            canvas.drawText(iconNumber, size / 2f, numBaseline, numPaint)
            canvas.drawText(unit, size / 2f, unitBaseline, unitPaint)

            IconCompat.createWithBitmap(bitmap)
        } catch (_: Exception) {
            IconCompat.createWithResource(this, android.R.drawable.stat_sys_download_done)
        }
    }

    private fun formatSpeedParts(bps: Double): SpeedParts {
        val useBits = prefs.getString("unit", "bytes") == "bits"
        val value = if (useBits) bps * 8.0 else bps
        val unitShort = if (useBits) "Kbps" else "KB/s"

        return when {
            value >= 1024.0 * 1024.0 * 1024.0 -> {
                val v = value / 1024.0 / 1024.0 / 1024.0
                val num = if (v >= 10) v.toInt().toString() else String.format(Locale.US, "%.1f", v)
                val unit = if (useBits) "Gbps" else "GB/s"
                SpeedParts(num, unit, "$num $unit")
            }
            value >= 1024.0 * 1024.0 -> {
                val v = value / 1024.0 / 1024.0
                val num = if (v >= 100) v.toInt().toString() else String.format(Locale.US, "%.1f", v)
                val unit = if (useBits) "Mbps" else "MB/s"
                SpeedParts(num, unit, "$num $unit")
            }
            value >= 1024.0 -> {
                val v = value / 1024.0
                val num = v.toInt().toString()
                SpeedParts(num, unitShort, "$num $unitShort")
            }
            else -> {
                val v = value.toInt()
                val unit = if (useBits) "bps" else "B/s"
                SpeedParts(v.toString(), unit, "$v $unit")
            }
        }
    }

    private fun buildNotification(
        number: String,
        unit: String,
        downText: String,
        upText: String,
        usageText: String
    ): Notification {
        val customView = RemoteViews(packageName, R.layout.cova_notification)
        customView.setTextViewText(R.id.cova_title, "كوفانت")
        customView.setTextViewText(R.id.cova_line1, "تحت: $downText   فوق: $upText")
        customView.setTextViewText(R.id.cova_line2, "الاستخدام: $usageText")

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(buildSpeedIcon(number, unit))
            .setCustomContentView(customView)
            .setCustomBigContentView(customView)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (prefs.getBoolean("hideOnLock", false)) {
            builder.setVisibility(NotificationCompat.VISIBILITY_SECRET)
        } else {
            builder.setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        }

        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                val pi = PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                builder.setContentIntent(pi)
            }
        } catch (_: Exception) {}

        return builder.build()
    }
}
