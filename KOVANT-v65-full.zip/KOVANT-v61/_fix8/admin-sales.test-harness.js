// تشغيل: TZ=Asia/Aden ORIG=/path/to/dir-with-previous-sales-analysis.js node _fix10/sales-analysis.test-harness.js   (من جذر المشروع)
// ORIG: مجلد فيه sales-analysis.js القديم (قبل المرحلة ب) — الافتراضي /home/claude/orig
process.env.TZ = process.env.TZ || 'Asia/Aden';
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const R = process.cwd(), O = process.env.ORIG || '/home/claude/orig';
let pass = 0; const ok = (c, m) => { assert.ok(c, 'FAIL: ' + m); pass++; console.log('  ✓', m); };
const J = x => JSON.stringify(x);
const eq = (a, b, m) => { assert.strictEqual(J(a), J(b), 'FAIL: ' + m + '\n  got:  ' + J(a) + '\n  want: ' + J(b)); pass++; console.log('  ✓', m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const tick = () => sleep(15);
if (new Date().getTimezoneOffset() !== -180) console.warn('⚠️ شغّل الاختبار بـ TZ=Asia/Aden (UTC+3)');

const NOW = Date.UTC(2026, 10, 25, 9, 0, 0);     // 2026-11-25 12:00 اليمن
const YE = 3 * 3600 * 1000, DAYMS = 86400000;
const yeKey = ms => new Date(ms + YE).toISOString().slice(0, 10);

// ---------------- قاعدة بيانات وهمية (دلالات استعلامات RTDB المستخدمة) ----------------
function mkDB(root) {
  const log = [], listeners = [];
  const getAt = p => p.split('/').filter(Boolean).reduce((o, k) => o == null ? undefined : o[k], root);
  const setAt = (p, v) => { const ks = p.split('/').filter(Boolean); let o = root; for (let i = 0; i < ks.length - 1; i++) o = o[ks[i]] = o[ks[i]] || {}; if (v === null || v === undefined) delete o[ks[ks.length - 1]]; else o[ks[ks.length - 1]] = v; };
  const clone = v => v === undefined ? null : JSON.parse(JSON.stringify(v));
  const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
  function snapOf(path, q) {
    let data = clone(getAt(path));
    const mkSnap = (key, val, ordered) => ({
      key, val: () => clone(val), exists: () => val != null,
      forEach: cb => { for (const [k, v] of ordered || []) { if (cb({ key: k, val: () => clone(v) }) === true) break; } }
    });
    if (data == null || typeof data !== 'object') return mkSnap(path.split('/').pop(), data, []);
    let entries = Object.entries(data);
    const keyOf = ([k, v]) => q.order === 'key' ? [k, ''] : q.order === 'child' ? [(v && v[q.child] !== undefined) ? v[q.child] : null, k] : [0, k];
    if (q.order === 'child') entries = entries.filter(e => keyOf(e)[0] !== null || q.startAt === undefined && q.endAt === undefined);
    entries.sort((a, b) => { const x = keyOf(a), y = keyOf(b); return q.order === 'key' ? cmp(a[0], b[0]) : (cmp(x[0], y[0]) || cmp(x[1], y[1])); });
    if (q.startAt !== undefined) entries = entries.filter(e => { const [v, k] = keyOf(e); if (q.order === 'key') return e[0] >= q.startAt; return q.startAtKey !== undefined ? (cmp(v, q.startAt) || cmp(k, q.startAtKey)) >= 0 : v >= q.startAt; });
    if (q.endAt !== undefined) entries = entries.filter(e => { const [v, k] = keyOf(e); if (q.order === 'key') return e[0] <= q.endAt; return q.endAtKey !== undefined ? (cmp(v, q.endAt) || cmp(k, q.endAtKey)) <= 0 : v <= q.endAt; });
    if (q.limitLast) entries = entries.slice(-q.limitLast);
    if (q.limitFirst) entries = entries.slice(0, q.limitFirst);
    const obj = {}; entries.forEach(([k, v]) => obj[k] = v);
    return mkSnap(path.split('/').pop(), Object.keys(obj).length ? obj : null, entries);
  }
  function Q(path, q) {
    const self = {
      orderByKey: () => Q(path, { ...q, order: 'key' }),
      orderByChild: c => Q(path, { ...q, order: 'child', child: c }),
      startAt: (v, k) => Q(path, { ...q, startAt: v, startAtKey: k }),
      endAt: (v, k) => Q(path, { ...q, endAt: v, endAtKey: k }),
      limitToLast: n => Q(path, { ...q, limitLast: n }),
      limitToFirst: n => Q(path, { ...q, limitFirst: n }),
      once: async () => { log.push({ kind: 'once', path, ...q }); return snapOf(path, q); },
      on(ev, cb) { log.push({ kind: 'on', path, ...q }); const l = { path, q, cb }; listeners.push(l); setTimeout(() => cb(snapOf(path, q)), 0); return cb; },
      off(ev, cb) { const i = listeners.findIndex(l => l.cb === cb); if (i >= 0) listeners.splice(i, 1); }
    };
    return self;
  }
  return {
    root, log, listeners, ref: p => Q(p, {}),
    write(path, v) { setAt(path, v); listeners.forEach(l => { if (l.path === path || path.startsWith(l.path + '/') || l.path.startsWith(path + '/')) l.cb(snapOf(l.path, l.q)); }); },
    push(path, v) { const k = 'P' + String(Math.random()).slice(2, 10); this.write(path + '/' + k, v); return k; }
  };
}

// ---------------- DOM وهمي ----------------
function mkDOM() {
  const reg = {}, docHandlers = {};
  const mkEl = (id) => {
    const e = { id, _h: {}, _html: '', style: {}, textContent: '', disabled: false, offsetWidth: 0, clientWidth: 300, scrollWidth: 0, scrollLeft: 0, children: [],
      classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { (f === undefined ? !this._s.has(c) : f) ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } },
      setAttribute() { }, getAttribute() { return null; }, removeAttribute() { }, setProperty() { },
      addEventListener(ev, fn) { (e._h[ev] = e._h[ev] || []).push(fn); },
      querySelector() { return null; }, querySelectorAll() { return []; }, closest() { return null; },
      getBoundingClientRect() { return { left: 0, top: 0, bottom: 0, width: 0 }; }, appendChild() { }, remove() { },
      click() { (e._h.click || []).forEach(f => f({ stopPropagation() { }, target: e })); },
      insertAdjacentElement(pos, el) { register(el); return el; },
      get innerHTML() { return e._html; }, set innerHTML(v) { e._html = String(v); if (e._isCard) register(e); }
    };
    e.parentNode = { querySelector: () => null, insertAdjacentElement: (pos, el) => { el._isCard = true; register(el); return el; } };
    return e;
  };
  function register(card) { const re = /id="(\w+)"/g; let m; while ((m = re.exec(card._html))) { if (!reg[m[1]]) reg[m[1]] = mkEl(m[1]); } }
  const IDS = ['saStatus', 'saStatusTitle', 'saStatusSub', 'saLive', 'saLiveBadge', 'saLiveToggle', 'saLastUpdate', 'saDpc', 'saDpcToggle', 'saDpcText', 'saDpcMode', 'saFromSec', 'saToSec', 'saFromToday', 'saToToday', 'saFromHint', 'saToHint', 'saWarn', 'saWarnText', 'saApply',
    'saFromDay', 'saFromMonth', 'saFromYear', 'saToDay', 'saToMonth', 'saToYear', 'saSpark', 'saTotal', 'saTotalSub', 'saGrowthPill', 'saGrowth', 'saTx', 'saAvg', 'saChartCard', 'saChartTitle', 'saChartPeriod', 'saChartLive', 'saChartUnit', 'saZoomIn', 'saZoomOut', 'saZoomReset',
    'saStatPeak', 'saStatPeakLbl', 'saStatAvg', 'saStatLow', 'saStatLowLbl', 'saStatVol', 'saYAxis', 'saScroll', 'saViewport', 'saHighlight', 'saHlTitle', 'saHlSub', 'saHlVal', 'saTooltip', 'saTtHead', 'saTtVal', 'saTtDelta', 'saTtFill', 'saTable', 'saDonut', 'saDonutTotal', 'saCatList', 'saGauges', 'saInsights', 'saExport'];
  IDS.forEach(i => reg[i] = mkEl(i));
  const doc = { getElementById: id => reg[id] || null, querySelectorAll: () => [], createElement: () => mkEl('card'), addEventListener(ev, fn) { (docHandlers[ev] = docHandlers[ev] || []).push(fn); }, body: { appendChild() { } } };
  return { reg, doc, docHandlers };
}

// ---------------- بيانات اصطناعية ----------------
// حركات خزينة: بيع كروت (تطبيق/SMS) + ضجيج (إيداع/آجل/سداد) على مدى ~27 شهراً
function buildData() {
  const tx = {}, pkgs = ['p10', 'p5', 'p20', 'p50', 'p1', 'p100', 'p7', 'p3'];
  const names = { p10: 'ستور 10$', p5: 'ستور 5$', p20: 'ستور 20$', p50: 'ستور 50$', p1: 'ستور 1$', p100: 'ستور 100$', p7: 'ستور 7$', p3: 'ستور 3$' };
  const price = { p10: 1000, p5: 500, p20: 2000, p50: 5000, p1: 100, p100: 10000, p7: 700, p3: 300 };
  const buyers = ['أحمد', 'سالم', 'نور', 'ليلى', 'خالد'];
  let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  let n = 0; const daily = {}, byPkg = {}; const salesRows = [];
  const start = NOW - 27 * 30 * DAYMS;
  for (let t = start; t <= NOW - 1800000; t += 1000 * 60 * (20 + Math.floor(rnd() * 140))) {
    const kind = rnd();
    const key = '-N' + String(++n).padStart(7, '0');
    if (kind < 0.62 || kind < 0.8) {          // بيع
      const pkg = pkgs[Math.floor(rnd() * pkgs.length)], cnt = 1 + Math.floor(rnd() * 3), sms = rnd() < 0.2;
      const amount = price[pkg] * cnt, who = buyers[Math.floor(rnd() * buyers.length)];
      tx[key] = { type: sms ? 'card_sale_sms' : 'card_sale', changeAmount: amount, amount, direction: 'credit', timestamp: t, date: new Date(t).toISOString(), details: `بيع ${cnt} كرت من ${sms ? '' : 'باقة '}${names[pkg]}${sms ? ' عبر SMS' : ''}`, performedBy: who, status: 'completed' };
      const dk = yeKey(t); const d = daily[dk] || (daily[dk] = { count: 0, amount: 0 }); d.count += cnt; d.amount += amount;
      const b = byPkg[pkg] || (byPkg[pkg] = { totalCount: 0, totalAmount: 0 }); b.totalCount += cnt; b.totalAmount += amount;
      salesRows.push({ key, t, amount, cnt, who, sms });
    } else if (kind < 0.88) tx[key] = { type: 'deposit', changeAmount: -3000, amount: 3000, timestamp: t, details: 'إيداع', performedBy: 'admin' };
    else if (kind < 0.95) tx[key] = { type: 'credit', changeAmount: -8000, amount: 8000, timestamp: t, details: 'فاتورة آجلة', performedBy: 'admin' };
    else tx[key] = { type: 'debt_payment', changeAmount: 2500, amount: 2500, timestamp: t, details: 'سداد', performedBy: 'admin' };
  }
  const meta = {}; pkgs.forEach(p => meta[p] = { name: names[p], sellPrice: String(price[p]), availableCount: 5 }); meta.gift_cards = { x: 1 };
  return { tx, daily, byPkg, meta, salesRows };
}

// ---------------- تحميل الصفحة داخل vm ----------------
function loadPage(file, db, { patch = s => s, now = NOW } = {}) {
  const { reg, doc, docHandlers } = mkDOM();
  class FD extends Date { constructor(...a) { if (a.length === 0) super(now); else super(...a); } static now() { return now; } }
  const alerts = [], blobs = [];
  const win = { addEventListener() { }, confirm: () => true, backfillCalls: 0 };
  const ctx = { console: { ...console, log: () => { }, warn: () => { }, error: () => { } }, window: win, document: doc, database: db, Date: FD, setTimeout, clearTimeout, setInterval, clearInterval, Promise, Math, JSON, Object, Array, Number, String, Set, isFinite, isNaN, parseFloat, parseInt, RegExp,
    waitForFirebaseAuth: async () => ({}), showAlert: (m, ok) => alerts.push([m, ok]), requestAnimationFrame: f => setTimeout(f, 0), URL: { createObjectURL: b => { blobs.push(b); return 'blob:x'; }, revokeObjectURL() { } }, Blob: class { constructor(p) { this.parts = p; } } };
  ctx.database = db; ctx.global = ctx;
  vm.createContext(ctx);
  let src = fs.readFileSync(file, 'utf8');
  src = patch(src);
  // خطّاف اختبار فقط (لا يُسلَّم): كشف الداخليات
  const names = ['S', 'aggregate', 'buildDataset', 'loadChart', 'loadRecent', 'reloadAll', 'resetRecent', 'categoryStats', 'customerStats', 'pollRecentNew', 'pollHourNew', 'attachTreasury', 'applyRange', 'setLive', 'exportCsv', 'runBackfill', 'modeFor'];
  src = src.replace('window.SalesAnalysis = {', 'window.__T = {' + names.map(n => n + ': (typeof ' + n + ' !== "undefined" ? ' + n + ' : null)').join(', ') + '};\n    window.SalesAnalysis = {');
  vm.runInContext(src, ctx);
  return { win, ctx, reg, doc, docHandlers, alerts, blobs, T: win.__T };
}
const setRange = (T, reg, from, to) => { T.S.from = new Date(from[0], from[1] - 1, from[2]); T.S.to = new Date(to[0], to[1] - 1, to[2]); };
const treasuryQueries = db => db.log.filter(l => l.path === 'treasury/transactions');
let db;

(async () => {
  const D = buildData();
  const mkRoot = () => ({ treasury: { transactions: JSON.parse(J(D.tx)) }, stats: { sales_daily_total: JSON.parse(J(D.daily)), sales_by_pkg: JSON.parse(J(D.byPkg)) }, kova_store_public: JSON.parse(J(D.meta)), kova_store: { p10: { cards: { c: { code: 'SECRET' } }, sold: { s: { code: 'SOLD' } } } }, all_transactions: { a: { x: 1 } } });
  console.log('\nبيانات اصطناعية: ' + Object.keys(D.tx).length + ' حركة خزينة، ' + D.salesRows.length + ' بيع، ' + Object.keys(D.daily).length + ' يوماً');

  // ================= [1] مطابقة الأرقام: القديم (كل treasury) ↔ الجديد (مجمّع) =================
  console.log('\n[1] مطابقة الأرقام مع النسخة القديمة (نفس أنواع المبيعات)');
  const ranges = [['آخر 7 أيام (يومي)', [2026, 11, 19], [2026, 11, 25]], ['آخر 30 يوم (يومي)', [2026, 10, 27], [2026, 11, 25]], ['آخر 90 يوم (شهري)', [2026, 8, 27], [2026, 11, 25]], ['6 أشهر (شهري)', [2026, 6, 1], [2026, 11, 25]], ['سنة (شهري)', [2025, 11, 26], [2026, 11, 25]], ['بين سنتين (سنوي)', [2024, 1, 1], [2026, 11, 25]], ['يوم واحد (ساعات)', [2026, 11, 25], [2026, 11, 25]], ['3 أيام (ساعات)', [2026, 11, 23], [2026, 11, 25]]];
  for (const [label, f, t] of ranges) {
    db = mkDB(mkRoot());
    const oldP = loadPage(O + '/sales-analysis.js', db, { patch: s => s.replace("const SALES_TYPES = ['card_purchase', 'credit'];", "const SALES_TYPES = ['card_sale', 'card_sale_sms'];") });
    const oldS = oldP.T.S; setRange(oldP.T, oldP.reg, f, t); oldS.opened = true; oldP.T.attachTreasury(); await tick(); await tick();
    const oldD = oldP.T.buildDataset();
    db = mkDB(mkRoot());
    const nw = loadPage(R + '/js/sales-analysis.js', db);
    nw.T.S.opened = true; setRange(nw.T, nw.reg, f, t); nw.T.loadChart(); await tick(); await tick(); await tick();
    const newD = nw.T.buildDataset();
    eq([newD.mode, newD.labels.length], [oldD.mode, oldD.labels.length], label + ': نفس النمط والتسميات (' + newD.mode + ' × ' + newD.labels.length + ')');
    eq(newD.values.map(Math.round), oldD.values.map(Math.round), label + ': القيم الحالية متطابقة');
    eq(newD.prev.map(Math.round), oldD.prev.map(Math.round), label + ': قيم الفترة السابقة متطابقة');
    eq([newD.total, newD.prevTotal], [oldD.total, oldD.prevTotal], label + ': الإجمالي والسابق متطابقان');
    // العدّاد الجديد = كروت (لا عمليات)
    const wantCards = D.salesRows.filter(r => { const k = yeKey(r.t); return k >= (f[0] + '-' + String(f[1]).padStart(2, '0') + '-' + String(f[2]).padStart(2, '0')) && k <= (t[0] + '-' + String(t[1]).padStart(2, '0') + '-' + String(t[2]).padStart(2, '0')); }).reduce((s, r) => s + r.cnt, 0);
    eq(newD.count, wantCards, label + ': العدّاد = عدد الكروت المباعة (' + newD.count + ')');
  }

  // ================= [2] أنماط القراءة (لا قراءة كاملة) =================
  console.log('\n[2] أنماط القراءة');
  db = mkDB(mkRoot());
  const P = loadPage(R + '/js/sales-analysis.js', db);
  P.win.SalesAnalysis.open(); await sleep(60);
  const S = P.T.S;
  const q = db.log;
  ok(!q.some(l => /^all_transactions/.test(l.path)), 'لا أي قراءة من all_transactions');
  ok(!q.some(l => /^kova_store(\/|$)/.test(l.path)), 'لا أي قراءة من kova_store (لا كروت ولا سجلات بيع) — kova_store_public فقط');
  ok(q.some(l => l.path === 'kova_store_public'), 'kova_store_public تُقرأ للاسم');
  ok(treasuryQueries(db).every(l => l.kind === 'once' && l.order === 'child' && l.child === 'timestamp' && l.startAt !== undefined && l.endAt !== undefined && l.limitLast >= 100), 'كل استعلامات treasury/transactions: once + orderByChild(timestamp) + startAt/endAt + limitToLast (بلا on(value) وبلا قراءة كاملة)');
  ok(!db.listeners.some(l => l.path === 'treasury/transactions'), 'لا أي مستمع دائم على treasury/transactions');
  const dq = q.filter(l => l.path === 'stats/sales_daily_total');
  ok(dq.every(l => l.order === 'key' && l.startAt && l.endAt || l.limitFirst === 1 || l.path.includes('/')), 'sales_daily_total: دائماً بنطاق مفاتيح (أو فحص limitToFirst(1))');
  const bq = q.filter(l => l.path === 'stats/sales_by_pkg');
  eq(bq.length, 1, 'sales_by_pkg: قراءة واحدة (on) عند الفتح');
  ok(db.listeners.filter(l => l.path.startsWith('stats/sales_daily_total/')).length === 1, 'مستمع LIVE واحد صغير على عقدة اليوم فقط');
  // عدد العقد المقروءة للرسم الافتراضي (6 أشهر + السابقة)
  // 7 / 30 يوم
  for (const [days, f] of [[7, [2026, 11, 19]], [30, [2026, 10, 27]]]) {
    db.log.length = 0; setRange(P.T, P.reg, f, [2026, 11, 25]); P.T.loadChart(); await tick(); await tick();
    const l = db.log.filter(x => x.path === 'stats/sales_daily_total' && x.startAt)[0];
    const got = Object.keys(Object.fromEntries(Object.entries(D.daily).filter(([k]) => k >= l.startAt && k <= l.endAt))).length;
    ok(got <= days * 2, days + ' يوم: استعلام واحد يُرجع ' + got + ' عقدة (الحالية + السابقة للمقارنة) بدل ' + days * 20 + ' قراءة سابقاً');
    console.log('     ↳ النطاق: ' + l.startAt + ' → ' + l.endAt + ' | عقد مُرجعة: ' + got);
  }

  // ================= [3] الفئات: أفضل 5 + أخرى =================
  console.log('\n[3] أفضل الفئات (sales_by_pkg + kova_store_public)');
  P.T.S.opened = true;
  const cs = P.T.categoryStats();
  eq(cs.cats.length, 6, '5 فئات + «أخرى»');
  eq(cs.cats[5].name, 'أخرى', 'السادسة «أخرى»');
  const tot = Object.values(D.byPkg).reduce((s, x) => s + x.totalCount, 0);
  eq([cs.total, cs.cats.reduce((s, c) => s + c.count, 0)], [tot, tot], 'إجمالي الكروت = مجموع كل الباقات (الدونات تُغلق على 100%)');
  const sorted = Object.entries(D.byPkg).sort((a, b) => b[1].totalCount - a[1].totalCount);
  eq(cs.cats.slice(0, 5).map(c => c.name), sorted.slice(0, 5).map(([id]) => D.meta[id].name), 'الترتيب تنازلي والأسماء من kova_store_public');
  ok(!cs.cats.some(c => c.id === 'gift_cards'), 'gift_cards مستثناة');
  ok(/ستور/.test(P.reg.saCatList.innerHTML) && /%/.test(P.reg.saCatList.innerHTML), 'القائمة معروضة بالنسب');

  // ================= [4] جدول آخر العمليات =================
  console.log('\n[4] جدول آخر العمليات (limitToLast(100) + عرض المزيد + تاريخ + نوع)');
  db = mkDB(mkRoot()); const P4 = loadPage(R + '/js/sales-analysis.js', db); P4.win.SalesAnalysis.open(); await sleep(60);
  const S4 = P4.T.S;
  setRange(P4.T, P4.reg, [2026, 9, 1], [2026, 11, 25]); P4.T.resetRecent(); db.log.length = 0; await P4.T.loadRecent(false);
  const first = db.log.filter(l => l.path === 'treasury/transactions');
  eq([first[0].limitLast, first[0].order, first[0].child], [100, 'child', 'timestamp'], 'الدفعة الأولى: orderByChild(timestamp).limitToLast(100)');
  eq([first[0].startAt, first[0].endAt], [Date.UTC(2026, 8, 1) - YE, Date.UTC(2026, 10, 26) - YE - 1], 'startAt/endAt = حدود الفترة بتوقيت اليمن');
  const rowsAll = Object.values(D.tx).filter(t => t.timestamp >= Date.UTC(2026, 8, 1) - YE && t.timestamp < Date.UTC(2026, 10, 26) - YE);
  const salesInRange = rowsAll.filter(t => t.type === 'card_sale' || t.type === 'card_sale_sms').sort((a, b) => b.timestamp - a.timestamp);
  ok(S4.recent.length > 0 && S4.recent.every(r => r.type === 'card_sale' || r.type === 'card_sale_sms'), 'فلتر النوع: مبيعات فقط (لا إيداع/آجل/سداد) — ' + S4.recent.length + ' صف');
  ok(first.length <= 5, 'دفعات خام ≤ ' + 5 + ' لكل ضغطة (' + first.length + ' فعلياً)');
  eq(S4.recent.map(r => r.ms), salesInRange.slice(0, S4.recent.length).map(t => t.timestamp), 'الصفوف = أحدث المبيعات بترتيب تنازلي بلا فجوات');
  ok(S4.recent.length >= 100 || !S4.recentMore, 'تُجمع 100 بيع (أو ينتهي النطاق)');
  const before = S4.recent.length; ok(S4.recentMore, 'زر «عرض المزيد» متاح'); 
  P4.reg.saRecentMore.click(); await sleep(40);
  ok(S4.recent.length > before, 'عرض المزيد يحمّل أقدم (' + before + ' → ' + S4.recent.length + ')');
  const ids = S4.recent.map(r => r.id); eq(new Set(ids).size, ids.length, 'بلا تكرار بين الصفحات (مؤشر timestamp+key)');
  eq(S4.recent.map(r => r.ms), salesInRange.slice(0, S4.recent.length).map(t => t.timestamp), 'الصفحة الثانية تكمل الترتيب تماماً');
  const more2 = db.log.filter(l => l.path === 'treasury/transactions' && l.endAtKey !== undefined);
  ok(more2.length > 0 && more2.every(l => l.limitLast === 100), 'عرض المزيد: endAt(oldestTs, oldestKey).limitToLast(100)');
  // حتى النهاية
  let guard = 0; while (S4.recentMore && guard++ < 30) { P4.reg.saRecentMore.click(); await sleep(30); }
  eq(S4.recent.length, salesInRange.length, 'بعد استنفاد الصفحات: كل مبيعات الفترة (' + salesInRange.length + ') بلا نقص');
  ok(P4.reg.saRecentMore.style.display === 'none', 'الزر يختفي عند انتهاء البيانات');
  // الفترة الضيقة
  setRange(P4.T, P4.reg, [2026, 11, 20], [2026, 11, 22]); P4.T.resetRecent(); await P4.T.loadRecent(false);
  const lo = Date.UTC(2026, 10, 20) - YE, hi = Date.UTC(2026, 10, 23) - YE;
  ok(S4.recent.length > 0 && S4.recent.every(r => r.ms >= lo && r.ms < hi), 'فلترة التاريخ startAt/endAt: كل الصفوف داخل 20→22 نوفمبر');
  ok(/عملية/.test(P4.reg.saRecentInfo.textContent), 'عدّاد الصفوف يظهر');
  ok(/أحمد|سالم|نور|ليلى|خالد/.test(P4.reg.saRecent.innerHTML), 'اسم العميل يُقرأ من performedBy (الخادم لا يكتب customerName)');
  const cu = P4.T.customerStats(); ok(cu.length > 0 && cu.reduce((s, c) => s + c.amount, 0) === S4.recent.reduce((s, r) => s + r.amount, 0), 'مؤشرات العملاء من الصفوف المحمّلة فقط');
  // تصدير
  P4.T.exportCsv(); ok(P4.blobs.length === 1 && P4.blobs[0].parts[0].split('\n').length === S4.recent.length + 1, 'تصدير CSV = الصفوف المعروضة');

  // ================= [5] العقد الفارغة =================
  console.log('\n[5] عقد فارغة → «لا توجد بيانات — اضغط إعادة حساب كامل»');
  const emptyRoot = mkRoot(); delete emptyRoot.stats.sales_daily_total; delete emptyRoot.stats.sales_by_pkg;
  db = mkDB(emptyRoot); const P5 = loadPage(R + '/js/sales-analysis.js', db); P5.win.SalesAnalysis.open(); await sleep(60);
  ok(P5.T.S.noData === true, 'noData مُكتشف (فحص limitToFirst(1))');
  ok(/لا توجد بيانات — اضغط إعادة حساب كامل/.test(P5.reg.saViewport.innerHTML) && /sa-backfill-btn/.test(P5.reg.saViewport.innerHTML), 'رسالة الرسم + زر إعادة الحساب');
  ok(/لا توجد بيانات — اضغط إعادة حساب كامل/.test(P5.reg.saCatList.innerHTML), 'رسالة الفئات');
  ok(/لا توجد بيانات — اضغط إعادة حساب كامل/.test(P5.reg.saStatusTitle.textContent), 'شريط الحالة');
  let called = 0;
  P5.win.backfillSalesData = async () => { called++; db.write('stats/sales_daily_total', JSON.parse(J(D.daily))); db.write('stats/sales_by_pkg', JSON.parse(J(D.byPkg))); };
  const clickBtn = P5.docHandlers.click.find(f => true);
  P5.docHandlers.click.forEach(f => f({ target: { closest: sel => sel === '.sa-backfill-btn' ? {} : null } }));
  await sleep(120);
  eq(called, 1, 'الضغط على «إعادة حساب كامل» يستدعي backfillSalesData() مرة واحدة');
  ok(P5.T.S.noData === false && P5.T.S.dataset && P5.T.S.dataset.total > 0, 'بعد الحساب يُعاد التحميل وتظهر الأرقام');
  ok(Object.keys(P5.T.S.pkgs).length > 0 && P5.T.categoryStats().total > 0, 'الفئات تتحدّث تلقائياً من المستمع');
  // فترة بلا مبيعات والعقد موجودة → رسالة عادية
  db = mkDB(mkRoot()); const P5b = loadPage(R + '/js/sales-analysis.js', db); P5b.win.SalesAnalysis.open(); await sleep(60);
  setRange(P5b.T, P5b.reg, [2030, 1, 1], [2030, 1, 10]); P5b.T.loadChart(); await sleep(40); P5b.T.S.dataset = P5b.T.buildDataset();
  ok(P5b.T.S.noData === false, 'فترة بلا مبيعات والعقد موجودة: ليست «غير مهيّأة»');

  // ================= [6] LIVE =================
  console.log('\n[6] المتابعة المباشرة');
  db = mkDB(mkRoot()); const P6 = loadPage(R + '/js/sales-analysis.js', db); P6.win.SalesAnalysis.open(); await sleep(60);
  const today = yeKey(NOW), cur = P6.T.S.daily[today] || { count: 0, amount: 0 };
  db.write('stats/sales_daily_total/' + today, { count: cur.count + 2, amount: cur.amount + 3000 }); await tick();
  eq(P6.T.S.daily[today].amount, cur.amount + 3000, 'بيع جديد يظهر فوراً عبر مستمع عقدة اليوم');
  const n0 = P6.T.S.recent.length;
  db.write('treasury/transactions/-NZZZ1', { type: 'card_sale', changeAmount: 3000, amount: 3000, timestamp: NOW - 1000, details: 'بيع 2 كرت من باقة ستور 10$', performedBy: 'جديد' });
  db.write('treasury/transactions/-NZZZ0', { type: 'deposit', changeAmount: -10, amount: 10, timestamp: NOW - 500, details: 'إيداع', performedBy: 'x' });
  db.log.length = 0; await P6.T.pollRecentNew();
  eq(P6.T.S.recent.length, n0 + 1, 'الاستعلام الدوري يضيف البيع الجديد فقط (الإيداع يُتجاهل)');
  eq(P6.T.S.recent[0].customer, 'جديد', 'الأحدث في الأعلى');
  const pq = db.log.filter(l => l.path === 'treasury/transactions'); ok(pq.length === 1 && pq[0].startAt > NOW - 3 * DAYMS && pq[0].limitLast === 100, 'الاستعلام الدوري: startAt(آخر timestamp + 1) + limitToLast(100) فقط');
  // ساعات
  setRange(P6.T, P6.reg, [2026, 11, 25], [2026, 11, 25]); P6.T.loadChart(); await sleep(40); P6.T.S.dataset = P6.T.buildDataset();
  eq(P6.T.S.dataset.mode, 'hour', 'يوم واحد = عرض بالساعة');
  const h0 = P6.T.S.dataset.total; db.write('treasury/transactions/-NZZZ2', { type: 'card_sale_sms', changeAmount: 700, amount: 700, timestamp: NOW - 100, details: 'بيع 1 كرت من ستور 7$ عبر SMS', performedBy: 'ي' });
  await P6.T.pollHourNew(); eq(P6.T.S.dataset.total, h0 + 700, 'العرض بالساعة يلتقط البيع الجديد بالاستعلام الدوري');
  // إلغاء الاستجابات المتأخرة
  db = mkDB(mkRoot()); const P7 = loadPage(R + '/js/sales-analysis.js', db); P7.win.SalesAnalysis.open(); await sleep(60);
  setRange(P7.T, P7.reg, [2026, 11, 1], [2026, 11, 10]); P7.T.loadChart(); setRange(P7.T, P7.reg, [2026, 11, 15], [2026, 11, 25]); P7.T.loadChart(); await sleep(60);
  ok(Object.keys(P7.T.S.daily).every(k => k >= '2026-11-04'), 'الطلب الأحدث يغلب (الاستجابة المتأخرة تُهمل)');
  P7.win.SalesAnalysis.close(); ok(db.listeners.length === 0, 'عند الإغلاق: لا مستمعين متبقين'); 

  // ================= [7] سقف العرض بالساعة =================
  console.log('\n[7] سقف العرض بالساعة');
  db = mkDB(mkRoot());
  const P8 = loadPage(R + '/js/sales-analysis.js', db, { patch: s => s.replace('const HOUR_CAP = 1500;', 'const HOUR_CAP = 20;') }); P8.win.SalesAnalysis.open(); await sleep(60);
  setRange(P8.T, P8.reg, [2026, 11, 23], [2026, 11, 25]); P8.T.loadChart(); await sleep(60);
  ok(P8.T.S.hourTruncated === true && /20 حركة/.test(P8.reg.saStatusTitle.textContent), 'عند بلوغ السقف: تنبيه صريح بدل رقم ناقص صامت');
  eq(treasuryQueries(db).filter(l => l.limitLast === 20).length > 0, true, 'الاستعلام محدود بـ limitToLast(HOUR_CAP)');

  // ================= [8] ثوابت الملف =================
  console.log('\n[8] فحص نصي للملف');
  const src = fs.readFileSync(R + '/js/sales-analysis.js', 'utf8');
  ok(!/all_transactions/.test(src.replace(/\/\/.*$/gm, '')), 'لا ذكر لـ all_transactions في الشيفرة (خارج التعليقات)');
  ok(!/KovaSoldReader|kova_store\/|\.on\('value', S\.txFn/.test(src), 'لا KovaSoldReader ولا kova_store/ ولا مستمع value على treasury');
  ok(/const SALES_TYPES = \['card_sale', 'card_sale_sms'\]/.test(src), 'SALES_TYPES = card_sale + card_sale_sms');
  console.log('\nكل الاختبارات نجحت: ' + pass + ' تحقق');
  process.exit(0);
})().catch(e => { console.error('\n✗', e.stack || e.message); process.exit(1); });
