# قائمة النشر (الإصلاح 4 كاملاً حتى الآن)
1. قواعد Firebase (database.rules.json): stats/treasury، kova_store/$pkg فهارس، admin_sales، stats/sales_daily.
2. server.js (يتضمن: stats/summary، stats/treasury، _sellCardToUser: admin_sales + sales_daily + recipient/packageId/packageName).
3. الواجهة (js/*).
4. مرة واحدة بعد النشر، من Console بحساب أدمن في وقت هادئ:
   - await backfillSalesData()          // admin_sales/{id}/soldCount + stats/sales_daily من سجلات البيع الفعلية
   - زر «إعادة حساب كامل» في اللوحة      // stats/summary + stats/treasury
5. تحقق: بطاقة «مباع» تعرض أرقاماً، stats/sales_daily فيه أيام، وشراء تجريبي يزيد admin_sales وsales_daily ويكتب recipient في السجل.
