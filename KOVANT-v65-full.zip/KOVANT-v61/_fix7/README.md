# مرحلة 1+2: soldCount + تنظيف صفحات التحليل
- server.js: سطر واحد (soldCount) في _sellCardToUser.
- admin-logic.js: backfillSoldCounts() + KovaSoldReader + إنقاص soldCount عند حذف سجلات البيع.
- agents/users/sales-analysis.js: استبدال on('value') على kova_store بـ KovaSoldReader.
- بعد النشر: await backfillSoldCounts()  (مرة واحدة، وقت هادئ).
- اختبار: node _fix7/soldcount-and-analysis.test-harness.js
