// تشغيل: node _fix7/soldcount-and-analysis.test-harness.js   (من جذر المشروع)
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const R=process.cwd(), O=process.env.ORIG||'/home/claude/orig';
let pass=0; const ok=(c,m)=>{assert.ok(c,'FAIL: '+m); pass++; console.log('  ✓',m);};
const eq=(a,b,m)=>{assert.strictEqual(JSON.stringify(a),JSON.stringify(b),'FAIL: '+m); pass++; console.log('  ✓',m);};
const INC=n=>({__inc:n});

(async()=>{
  // ================= fake DB =================
  const mk=()=>{
    const store={A:{name:'ستور 10$',sellPrice:'10',cards:{c1:{code:'1'},c2:{code:'2'}},sold:{}},B:{name:'ستور 5$',sellPrice:'5',cards:{c1:{code:'3'}},sold:{}},gift_cards:{x:1}};
    for(let i=0;i<40;i++) store.A.sold['s'+i]={code:'9'+i,customerId:'77'+(i%5),timestamp:1700000000000+i*1000,price:10};
    for(let i=0;i<7;i++) store.B.sold['t'+i]={code:'8'+i,customerId:'88'+(i%3),timestamp:1700000500000+i*1000,price:5};
    const pub={A:{name:'ستور 10$',sellPrice:'10',availableCount:2},B:{name:'ستور 5$',sellPrice:'5',availableCount:1}};
    const root={kova_store:store,kova_store_public:pub}; const L=[]; const lst={};
    const get=p=>p.split('/').filter(Boolean).reduce((o,k)=>o==null?undefined:o[k],root);
    const setp=(p,v)=>{const ks=p.split('/').filter(Boolean);let o=root;for(let i=0;i<ks.length-1;i++)o=o[ks[i]]=o[ks[i]]||{};if(v===null)delete o[ks[ks.length-1]];else o[ks[ks.length-1]]=v;};
    const notify=()=>{Object.keys(lst).forEach(p=>lst[p].forEach(cb=>cb({val:()=>{const v=get(p);return v===undefined?null:JSON.parse(JSON.stringify(v));}})));};
    const apply=u=>{Object.keys(u).forEach(k=>{const v=u[k]; if(v&&v.__inc!==undefined) setp(k,(Number(get(k))||0)+v.__inc); else setp(k,v===undefined?null:v);});notify();};
    const db={root,L,
      ref:p=>({on(ev,cb){L.push({op:'on',p});(lst[p]=lst[p]||[]).push(cb);setTimeout(()=>cb({val:()=>{const v=get(p);return v===undefined?null:JSON.parse(JSON.stringify(v));}}),0);},
        off(ev,cb){L.push({op:'off',p});lst[p]=(lst[p]||[]).filter(x=>x!==cb);},
        once:async()=>{L.push({op:'once',p});const v=get(p);return {val:()=>v===undefined?null:JSON.parse(JSON.stringify(v)),exists:()=>v!=null};},
        set:async v=>{L.push({op:'set',p});apply({[p]:v});}, update:async u=>{apply(Object.fromEntries(Object.entries(u).map(([k,v])=>[(p?p+'/':'')+k,v])));}}),
      update:async u=>{L.push({op:'update',keys:Object.keys(u)});apply(u);}};
    db.listeners=lst; return db;
  };

  // ================= 2) KovaSoldReader =================
  console.log('\n[2] KovaSoldReader — بديل on(kova_store)');
  const adm=fs.readFileSync(R+'/js/admin-logic.js','utf8');
  const r0=adm.indexOf('window.backfillSoldCounts'), r1=adm.indexOf('// يضمن وجود بيانات الفئات (عامة)');
  const DB=mk(); let boot=0;
  const ctx={database:DB,console:{...console,table:()=>{}},Object,Promise,Array,setTimeout,clearTimeout,JSON,Number,
    waitForFirebaseAuth:async()=>({}),window:{},_bootstrapPublicIfEmpty:()=>{boot++;}};
  vm.createContext(ctx); vm.runInContext(adm.slice(r0,r1)+'\nthis.W=window;',ctx);
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  let got=[]; const unsub=ctx.W.KovaSoldReader.subscribe(s=>got.push(JSON.parse(JSON.stringify(s))),e=>{throw e;});
  await sleep(120);
  ok(got.length>=1,'وصلت بيانات أولى');
  const first=got[got.length-1];
  eq(Object.keys(first).sort(),['A','B'],'الفئات من kova_store_public (بدون gift_cards)');
  eq(first.A.sold,DB.root.kova_store.A.sold,'سجلات بيع A مطابقة للأصل');
  eq([first.A.name,first.A.sellPrice,first.B.name,first.B.sellPrice],['ستور 10$','10','ستور 5$','5'],'name/sellPrice من النسخة العامة');
  ok(!('cards' in first.A),'لا يوجد cards في المخرجات');
  ok(DB.L.every(l=>!(l.p==='kova_store'||/\/cards/.test(l.p||''))),'لم تُقرأ kova_store كاملة ولا أي مسار cards إطلاقاً');
  ok(DB.L.filter(l=>l.op==='on').map(l=>l.p).sort().join()==='kova_store/A/sold,kova_store/B/sold,kova_store_public','المستمعات: public + sold لكل فئة فقط');
  // حركة حية: بيع جديد
  const n0=got.length; DB.root.kova_store.A.sold.s99={code:'999',customerId:'770',timestamp:1700009999000}; await DB.ref('kova_store/A/sold').update({s99:DB.root.kova_store.A.sold.s99}); await sleep(100);
  ok(got.length>n0 && Object.keys(got[got.length-1].A.sold).length===41,'تحديث حي: سجل بيع جديد يظهر (41)');
  // إضافة فئة جديدة
  DB.root.kova_store.C={name:'ستور 20$',sellPrice:'20',sold:{z:{code:'5',customerId:'1',timestamp:1}}}; await DB.ref('kova_store_public').update({C:{name:'ستور 20$',sellPrice:'20',availableCount:0}}); await sleep(100);
  ok(got[got.length-1].C && got[got.length-1].C.sold.z,'فئة جديدة تُشترَك تلقائياً');
  await DB.ref('kova_store_public').update({C:null}); await sleep(100);
  ok(!got[got.length-1].C && DB.L.some(l=>l.op==='off'&&l.p==='kova_store/C/sold'),'فئة محذوفة: يُلغى اشتراكها');
  unsub(); const nn=got.length; await DB.ref('kova_store/A/sold').update({s98:{code:'1'}}); await sleep(80);
  ok(got.length===nn && Object.keys(DB.listeners).every(p=>DB.listeners[p].length===0),'unsubscribe يُلغي كل المستمعات ولا بيانات بعده');
  // public فارغة
  const DB2=mk(); DB2.root.kova_store_public={}; ctx.database=DB2; let g2=[]; const u2=ctx.W.KovaSoldReader.subscribe(s=>g2.push(s),()=>{}); await sleep(100);
  ok(g2.length===1 && Object.keys(g2[0]).length===0 && boot===1,'public فارغة: تُرسل {} وتُطلق التهيئة الأولى مرة واحدة'); u2();

  // ================= 3) توافق منطق الصفحات =================
  console.log('\n[3] نفس نتائج منطق الصفحات قبل/بعد');
  const full=JSON.parse(JSON.stringify(mk().root.kova_store)); // الشكل القديم: snap.val() لـ kova_store كاملة
  const newShape=first;
  const sa=fs.readFileSync(R+'/js/sales-analysis.js','utf8');
  const cs=sa.slice(sa.indexOf('function collectSold'),sa.indexOf('/* ---------- التجميع'));
  const c2={Object,Number}; vm.createContext(c2); vm.runInContext(cs+'\nthis.f=collectSold;',c2);
  const sortF=a=>a.sort((x,y)=>x.ms-y.ms||x.cat.localeCompare(y.cat));
  eq(sortF(c2.f(newShape)),sortF(c2.f(full)),'sales-analysis.collectSold: نفس الناتج');
  // agents/users: فهرس الكود→(فئة،سعر،مستلم) ومجاميع المشتري
  const idx=st=>{const o={},sums={};Object.keys(st).forEach(cid=>{if(cid==='gift_cards')return;const cat=st[cid];if(!cat||!cat.sold)return;const price=Number(cat.sellPrice)||0;Object.keys(cat.sold).forEach(id=>{const it=cat.sold[id];o[it.code]={cid,cn:cat.name||cid,price,cust:it.customerId};const s=sums[it.customerId]||(sums[it.customerId]={a:0,n:0});s.a+=price;s.n++;});});return {o,sums};};
  eq(idx(newShape),idx(full),'agents/users: فهرس الأكواد ومجاميع المشترين: نفس الناتج');
  for(const f of ['agents','users','sales']){const t=fs.readFileSync(`${R}/js/${f}-analysis.js`,'utf8'); ok(!/database\.ref\('kova_store'\)/.test(t),f+'-analysis لا يقرأ kova_store كاملة');}
  // الحجم
  const bytes=o=>JSON.stringify(o).length; const m=mk().root;
  const soldOnly=bytes({A:m.kova_store.A.sold,B:m.kova_store.B.sold})+bytes(m.kova_store_public);
  console.log('   (بيانات صغيرة) قبل: '+bytes(m.kova_store)+' بايت · بعد: '+soldOnly+' بايت — يُحذف كل cards ومعلومات الفئات');

  console.log('\nكل الاختبارات نجحت: '+pass+' تحقق');
})().catch(e=>{console.error('\n✗',e.message);process.exit(1);});
