const fs=require('fs'), vm=require('vm');
const src=fs.readFileSync('/home/claude/kv/server.js','utf8');
const h0=src.indexOf('const STATS_SUMMARY_PATH'), h1=src.indexOf('// ============================================================\n// Sessions');
const helper=src.slice(h0,h1);
const r0=src.indexOf('let _statsRecalcRunning'), r1=src.indexOf('// ============================================================\n// تعيين نوع الحساب');
const recalc=src.slice(r0,r1);
const a0=src.indexOf("app.post('/admin/set-activation'"), a1=src.indexOf('// ============================================================\n// 🔧 الإصلاح 4: إعادة حساب');
const setAct=src.slice(a0,a1);

// ---- fake RTDB ----
const INC=Symbol('inc');
function makeDb(root){
  let pageReads=0;
  const get=(path)=>path.split('/').filter(Boolean).reduce((o,k)=>o==null?undefined:o[k],root);
  const setp=(path,val)=>{const ks=path.split('/').filter(Boolean);let o=root;for(let i=0;i<ks.length-1;i++){o=o[ks[i]]=o[ks[i]]||{};}o[ks[ks.length-1]]=val;};
  const snapOf=(k,v)=>({key:k,val:()=>v===undefined?null:JSON.parse(JSON.stringify(v)),exists:()=>v!==undefined&&v!==null});
  return {pageReads:()=>pageReads, root,
    ref:(path)=>({
      once:async()=>snapOf(path.split('/').pop(),get(path)),
      set:async(v)=>setp(path,v),
      update:async(u)=>{for(const k of Object.keys(u)){const full=path+'/'+k;const v=u[k];
          if(v&&v[INC]!==undefined){setp(full,(Number(get(full))||0)+v[INC]);} else setp(full,v);}},
      orderByKey:()=>{let st={};const q={startAt:(k)=>{st.start=k;return q;},limitToFirst:(n)=>{st.n=n;return q;},
        once:async()=>{pageReads++;let ents=Object.entries(get(path)||{}).sort((a,b)=>a[0]<b[0]?-1:1);
          if(st.start!==undefined) ents=ents.filter(e=>e[0]>=st.start); ents=ents.slice(0,st.n);
          return {forEach:(fn)=>{for(const [k,v] of ents){if(fn({key:k,val:()=>v})===true)break;}}};}};return q;}
    })};
}
const root={users:{}};
// 1234 مستخدماً (بينهم 999) بأرصدة وفواتير وتفعيل متفاوت
let expected={usersCount:0,activatedCount:0,totalBalance:0,totalDebts:0,totalInvoices:0};
root.users['999']={fullName:'admin',balance:0,isActivated:true};
for(let i=0;i<1234;i++){
  const ph='7'+String(10000000+i); const bal=(i%17)*125.5; const act=i%3!==0;
  const u={fullName:'u'+i,balance:bal,isActivated:act};
  if(i%5===0){u.invoices={a:{status:'active',remainingAmount:1000+i,totalAmount:2000},b:{status:'paid',remainingAmount:0},c:{status:'active',remainingAmount:0}};}
  root.users[ph]=u;
  expected.usersCount++; if(act) expected.activatedCount++; expected.totalBalance+=bal;
  if(i%5===0){expected.totalDebts+=1000+i; expected.totalInvoices++;}
}
const db=makeDb(root);
const handlers={};
const ctx={db, admin:{database:{ServerValue:{increment:n=>({[INC]:n})}}}, console, Date, Math, Number, JSON, Object,
  verifyAdmin:async()=>({isAdmin:true}), app:{post:(p,fn)=>{handlers[p]=fn;}} };
vm.createContext(ctx); vm.runInContext(helper+'\n'+recalc+'\n'+setAct+'\nthis._upd=_updateStatsSummary;',ctx);
const ok=(c,m)=>{console.log((c?'PASS':'FAIL')+' — '+m); if(!c) process.exitCode=1;};
const call=async(path,body)=>{let out={status:200};const res={status(c){out.status=c;return res;},json(o){out.body=o;return res;}};await handlers[path]({body,headers:{}},res);return out;};
const near=(a,b)=>Math.abs(a-b)<0.005;

(async()=>{
  // قبل أي إعادة حساب: تحديثات تراكمية لا تجعل اللوحة «جاهزة»
  await ctx._upd({usersDelta:1});
  ok(!db.root.stats.summary.recalculatedAt,'قبل إعادة الحساب: لا recalculatedAt (اللوحة تعرض «قيد الحساب»)');
  // إعادة حساب أولى
  let r=await call('/admin/recalculate-stats',{});
  const S=()=>db.root.stats.summary;
  ok(r.body.success && r.body.usersCount===expected.usersCount,'عدد المستخدمين المحسوب = '+expected.usersCount+' (بدون 999)');
  ok(S().activatedCount===expected.activatedCount && near(S().totalBalance,expected.totalBalance) && near(S().totalDebts,expected.totalDebts) && S().totalInvoices===expected.totalInvoices,'الإحصاءات = المجموع اليدوي (رصيد/ديون/فواتير/مفعّلون)');
  ok(db.pageReads()>=3,'قراءة users على دفعات ('+db.pageReads()+' دفعات) بلا تكرار عنصر حدّي');
  ok(S().recalculatedAt>0,'recalculatedAt مضبوط');

  // ---- محاكاة العمليات (نفس القيم التي تمرّرها نقاط server.js) مع تغيير البيانات الفعلية ----
  const U=ph=>db.root.users[ph];
  const phA='710000001', phB='710000002', phC='710000005';  // C لديه فواتير
  // 1) تسجيل مستخدم جديد
  db.root.users['799999999']={fullName:'new',balance:0,isActivated:false}; await ctx._upd({usersDelta:1});
  // 2) create-user مفعّل
  db.root.users['799999998']={fullName:'new2',balance:0,isActivated:true}; await ctx._upd({usersDelta:1,activatedDelta:1});
  // 3) /activate (كان غير مفعّل) ثم تكرار الاستدعاء لا يضاعف
  U('799999999').isActivated=true; await ctx._upd({activatedDelta:1});
  // 4) set-activation عبر الـ endpoint الحقيقي: تعطيل مفعّل ثم تفعيل معطّل ثم تكرار نفس الحالة
  const actUser=Object.keys(db.root.users).find(k=>k!=='999'&&db.root.users[k].isActivated===true&&k!=='799999999'&&k!=='799999998');
  let rr=await call('/admin/set-activation',{phone:actUser,active:false}); ok(rr.body.success && U(actUser).isActivated===false,'set-activation يعطّل');
  rr=await call('/admin/set-activation',{phone:actUser,active:false}); ok(rr.body.success,'تكرار نفس الحالة لا يغيّر العدّاد');
  rr=await call('/admin/set-activation',{phone:'999',active:false}); ok(rr.status===400,'رفض تعطيل حساب الأدمن 999');
  rr=await call('/admin/set-activation',{phone:'700000000',active:true}); ok(rr.status===404,'مستخدم غير موجود → 404');
  // 5) إيداع +500
  U(phA).balance+=500; await ctx._upd({balanceDelta:500});
  // 6) فاتورة آجلة 3000: رصيد +3000، دين +3000، فاتورة +1
  U(phB).balance+=3000; await ctx._upd({balanceDelta:3000}); U(phB).invoices={x:{status:'active',remainingAmount:3000,totalAmount:3000}}; await ctx._upd({debtsDelta:3000,invoicesDelta:1});
  // 7) سداد جزئي 1000 ثم سداد الباقي 2000 (تُسدّ الفاتورة)
  U(phB).balance-=1000; U(phB).invoices.x.remainingAmount=2000; await ctx._upd({balanceDelta:-1000,debtsDelta:-1000,invoicesDelta:0});
  U(phB).balance-=2000; U(phB).invoices.x.remainingAmount=0; U(phB).invoices.x.status='paid'; await ctx._upd({balanceDelta:-2000,debtsDelta:-2000,invoicesDelta:-1});
  // 8) تحويل بين مستخدمين: لا استدعاء (نقل). نفّذ النقل في البيانات فقط
  U(phA).balance-=100; U(phC).balance+=100;
  // 9) تحويل إداري 999 → مستخدم +250
  U(phC).balance+=250; await ctx._upd({balanceDelta:250});
  // 10) شراء كرت 400 ثم فشل واسترداد (صافي صفر) ثم شراء ناجح 150 و SMS 90
  await ctx._upd({balanceDelta:-400}); await ctx._upd({balanceDelta:400});
  U(phA).balance-=150; await ctx._upd({balanceDelta:-150}); U(phB).balance=Math.max(0,U(phB).balance); 
  U(phA).balance-=90; await ctx._upd({balanceDelta:-90});
  // 11) webhook شحن خارجي +700
  U(phA).balance+=700; await ctx._upd({balanceDelta:700});
  // 12) سداد (sadaq) -60 ثم استرداد +60 ثم سداد ناجح -45
  await ctx._upd({balanceDelta:-60}); await ctx._upd({balanceDelta:60}); U(phC).balance-=45; await ctx._upd({balanceDelta:-45});

  const incr={...S()};
  const rc=await call('/admin/recalculate-stats',{});
  const drift=rc.body.drift;
  ok(Object.values(drift).every(v=>v===0),'بعد 12 نوع عملية: التراكمي = إعادة الحساب الكامل (drift='+JSON.stringify(drift)+')');
  ok(near(incr.totalBalance,S().totalBalance) && incr.usersCount===S().usersCount,'الأرقام التراكمية قبل الإعادة مطابقة بعدها');

  // ---- فشل التحديث لا يرمي ----
  ctx.db.ref=()=>({update:async()=>{throw new Error('net down');}});
  let threw=false; try{ await ctx._upd({balanceDelta:5}); }catch(e){threw=true;}
  ok(!threw,'فشل كتابة stats لا يُفشل العملية المالية (يُسجَّل فقط)');
  // ---- منع التزامن ----
  console.log('done');
})();
