const fs=require('fs'), vm=require('vm');
const src=fs.readFileSync('/home/claude/kv/js/admin-logic.js','utf8');
const blk=src.slice(src.indexOf('// >>> KV-FIX4-BEGIN'), src.indexOf('// <<< KV-FIX4-END'));
const a=src.indexOf('function _renderUserCards('), b=src.indexOf('window.renderAdminAgents = renderAdminUsers;');
const render=src.slice(a,b);

// ---- fake firebase ----
function makeDb(data){
  let reads=0, bytes=0;
  function snap(key,val){ return { key, val:()=>val===undefined?null:JSON.parse(JSON.stringify(val)), exists:()=>val!==undefined&&val!==null,
    child:()=>({val:()=>null}) }; }
  function listSnap(entries){ // entries: [[k,v]] ordered
    return { val:()=>entries.length?Object.fromEntries(entries):null, numChildren:()=>entries.length,
      forEach:(fn)=>{ for(const [k,v] of entries){ if(fn({key:k,val:()=>v})===true) break; } }, exists:()=>entries.length>0 };
  }
  function query(path,st){
    return {
      orderByChild:(c)=>query(path,{...st,order:c}),
      equalTo:(v)=>query(path,{...st,eq:v}),
      startAt:(v,k)=>query(path,{...st,start:{v,k}}),
      endAt:(v,k)=>query(path,{...st,end:{v,k}}),
      limitToLast:(n)=>query(path,{...st,last:n}),
      limitToFirst:(n)=>query(path,{...st,first:n}),
      once:async()=>{
        reads++;
        let ents=Object.entries(data.users);
        const f=st.order; const val=(e)=>{const x=e[1][f]; return x===undefined?null:x;};
        const cmp=(e1,e2)=>{const a=val(e1),b=val(e2); if(a===b) return e1[0]<e2[0]?-1:e1[0]>e2[0]?1:0; if(a===null) return -1; if(b===null) return 1; return a<b?-1:1;};
        ents.sort(cmp);
        const cmpPair=(e,p)=>{const a=val(e); const pv=p.v===undefined?null:p.v; if(a!==pv) return (a===null?-1:pv===null?1:(a<pv?-1:1)); if(p.k===undefined) return 0; return e[0]<p.k?-1:e[0]>p.k?1:0;};
        if(st.eq!==undefined) ents=ents.filter(e=>val(e)===st.eq);
        if(st.start) ents=ents.filter(e=>cmpPair(e,st.start)>=0);
        if(st.end) ents=ents.filter(e=>cmpPair(e,st.end)<=0);
        if(st.last) ents=ents.slice(-st.last);
        if(st.first) ents=ents.slice(0,st.first);
        bytes+=ents.length;
        return listSnap(ents);
      }
    };
  }
  return { ref:(p)=>{
      const m=p.match(/^users\/(.+)$/);
      if(m) return { once:async()=>{reads++; bytes++; return snap(m[1],data.users[m[1]]);} };
      return query(p,{});
    }, stats:()=>({reads,bytes}) };
}

// ---- dataset ----
const users={};
let t=1700000000000;
for(let i=0;i<130;i++){ const ph='7'+String(10000000+i); users[ph]={fullName:'عميل '+i,accountNumber:String(100000+i),createdAt:t+Math.floor(i/3)*1000,balance:i}; } // 3 per same createdAt
for(let i=0;i<4;i++){ users['7'+String(30000000+i)]={fullName:'قديم '+i,accountNumber:String(900+i)}; } // بدون createdAt
for(let i=0;i<120;i++){ const ph='7'+String(50000000+i); users[ph]={fullName:'وكيل '+i,accountNumber:String(200000+i),createdAt:t+999999+i,userType:'agent'}; }
for(let i=0;i<7;i++){ const ph='7'+String(60000000+i); users[ph]={fullName:'نقطة '+i,accountNumber:String(300000+i),createdAt:t+888888+i,userType:'pos'}; }
users['999']={fullName:'admin',createdAt:t+5};

const els={};
const mk=()=>({innerText:'',innerHTML:'',value:'',style:{display:'block'},addEventListener(){}});
['adminUsersContainer','adminUserCountSpan','adminSearchUsers','adminAgentsContainer','adminAgentCountSpan','adminSearchAgents','adminPageUsers','adminPageAgents'].forEach(i=>els[i]=mk());
const db=makeDb({users});
const ctx={APP:{adminUsers:[],_adminUsersListener:null}, database:db, console, $n:v=>Number(v)||0, normalizeUserType:t=>!t?'':(t==='pos'?'pos':'agent'),
  adminUserCardHTML:u=>`<card ${u.phone}>`, document:{getElementById:i=>els[i]||null}, setTimeout, clearTimeout, window:{}};
ctx.window=ctx; vm.createContext(ctx);
vm.runInContext(blk+'\n'+render+'\nfunction renderAdminUsers(){const arr=APP.adminUsers||[];_renderUserCards("adminUsersContainer","adminUserCountSpan","adminSearchUsers",arr.filter(u=>!u.userType),"عميل","x","e","users");_renderUserCards("adminAgentsContainer","adminAgentCountSpan","adminSearchAgents",arr.filter(u=>!!u.userType),"وكيل","x","e","agents");}',ctx);
const ok=(c,m)=>{console.log((c?'PASS':'FAIL')+' — '+m); if(!c) process.exitCode=1;};
const run=(code)=>vm.runInContext(code,ctx);

(async()=>{
  const regular=Object.keys(users).filter(k=>k!=='999'&&!users[k].userType);
  const allNon999=Object.keys(users).filter(k=>k!=='999');
  // ---- users paging (صفحة المستخدمين تحمّل الجميع تقنياً: الوكلاء داخل السجلات أيضاً) ----
  els.adminPageAgents.style.display='none';
  await run('_adminLoadUsersPage(true)');
  let pg=ctx.APP._adminPg;
  ok(pg.users.hasMore && ctx.APP.adminUsers.length===50,'الصفحة الأولى 50 وhasMore=true ('+ctx.APP.adminUsers.length+')');
  ok(/تحميل المزيد/.test(els.adminUsersContainer.innerHTML)||ctx.APP.adminUsers.every(u=>u.userType),'الزر يظهر (أو كلها وكلاء فتُخفى البطاقات)');
  let guard=0; while(pg.users.hasMore && guard++<20) await run('_adminLoadUsersPage(false)');
  const got=ctx.APP.adminUsers.map(u=>u.phone);
  ok(got.length===allNon999.length && new Set(got).size===got.length,'استعراض كل الصفحات بلا تكرار ولا فقد ('+got.length+'/'+allNon999.length+')');
  ok(!got.includes('999'),'حساب 999 مستبعد');
  ok(got.some(p=>p.startsWith('73')),'مستخدمو بلا createdAt وصلوا في آخر الصفحات');
  ok(!pg.users.hasMore && !/تحميل المزيد/.test(els.adminUsersContainer.innerHTML),'لا زر بعد آخر صفحة');
  const sorted=ctx.APP.adminUsers.every((u,i,a)=>i===0||(a[i-1].createdAt||0)>=(u.createdAt||0));
  ok(sorted,'الترتيب الأحدث أولاً');
  // ---- إعادة تحميل تحفظ العمق ----
  const before=ctx.APP.adminUsers.length; const c0=pg.users.count;
  await run('_adminLoadUsersPage(true)');
  ok(ctx.APP._adminPg.users.count===Math.min(Math.max(c0,50),200),'إعادة التحميل تحفظ العمق حتى السقف (count='+ctx.APP._adminPg.users.count+')');
  // ---- agents paging ----
  els.adminPageAgents.style.display='block';
  await run('_adminLoadAgentsPage(true)');
  let ag=ctx.APP._adminPg.agents;
  ok(ag.types.agent.hasMore && !ag.types.pos.hasMore,'وكلاء: hasMore للوكيل فقط (pos=7)');
  guard=0; while((ag.types.agent.hasMore||ag.types.pos.hasMore)&&guard++<10) await run('_adminLoadAgentsPage(false)');
  const agents=ctx.APP.adminUsers.filter(u=>u.userType);
  ok(agents.length===127 && new Set(agents.map(u=>u.phone)).size===127,'كل الوكلاء ونقاط البيع (127) بلا تكرار');
  // ---- search ----
  await run('_adminServerSearch("0"+"967711")'.replace('0"+"967711','x')); // لا شيء
  els.adminSearchUsers.value='967710000007';
  await run('_adminServerSearch("967710000007")');
  ok(ctx.APP.adminUsers.find(u=>u.phone==='710000007'),'بحث بالهاتف مع 967 (قراءة مباشرة)');
  els.adminSearchUsers.value='100005';
  await run('_adminServerSearch("100005")');
  ok(/710000005/.test(els.adminUsersContainer.innerHTML),'بحث برقم الحساب يظهر البطاقة');
  els.adminSearchUsers.value='عميل 12';
  await run('_adminServerSearch("عميل 12")');
  ok(/710000012/.test(els.adminUsersContainer.innerHTML),'بحث بالاسم (بادئة) يعمل');
  els.adminSearchUsers.value='zzzz';
  await run('_adminServerSearch("zzzz")');
  ok(/لا توجد نتائج/.test(els.adminUsersContainer.innerHTML),'لا نتائج → رسالة');
  // search-only يختفي بعد مسح البحث
  const fresh=makeDb({users}); ctx.database=fresh; ctx.APP._adminPg=null; ctx.APP.adminUsers=[];
  await run('_adminLoadUsersPage(true)');
  els.adminSearchUsers.value='100100'; await run('_adminServerSearch("100100")');
  const target=Object.keys(users).find(k=>users[k].accountNumber==='100100');
  ok(/card /.test(els.adminUsersContainer.innerHTML) && els.adminUsersContainer.innerHTML.includes(target),'نتيجة بحث من خارج الصفحة المحمّلة تظهر أثناء البحث');
  els.adminSearchUsers.value=''; await run('renderAdminUsers()');
  ok(!els.adminUsersContainer.innerHTML.includes(target),'وتختفي بعد مسح البحث (لا تلوّث القائمة)');
  // ---- refresh single ----
  users['710000003'].balance=555; const r=await run('adminRefreshUser("710000003")');
  ok(r.balance===555,'adminRefreshUser يقرأ مستخدماً واحداً ويحدّث الرصيد');
  console.log('reads/records (آخر db):',fresh.stats());
})();
