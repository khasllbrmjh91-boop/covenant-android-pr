// تشغيل: node _fix5/treasury.test-harness.js   (من جذر المشروع)
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const ROOT=process.cwd();
const server=fs.readFileSync(ROOT+'/server.js','utf8');
const adminNew=fs.readFileSync(ROOT+'/js/admin-logic.js','utf8');
const adminOld=fs.readFileSync(process.env.ORIG_ADMIN||'/home/claude/orig/admin-logic.js','utf8');
let pass=0; const ok=(c,m)=>{assert.ok(c,'FAIL: '+m); pass++; console.log('  ✓',m);};

// ============ fake RTDB (مسارات + orderByKey + orderByChild + increment) ============
const INC=Symbol('inc');
function makeDb(root){
  const calls=[];
  const get=p=>p.split('/').filter(Boolean).reduce((o,k)=>o==null?undefined:o[k],root);
  const setp=(p,v)=>{const ks=p.split('/').filter(Boolean);let o=root;for(let i=0;i<ks.length-1;i++)o=o[ks[i]]=o[ks[i]]||{};o[ks[ks.length-1]]=v;};
  const snapOf=(k,v)=>({key:k,val:()=>v===undefined?null:JSON.parse(JSON.stringify(v)),exists:()=>v!=null});
  const listSnap=ents=>({val:()=>ents.length?Object.fromEntries(ents):null,forEach:fn=>{for(const [k,v] of ents){if(fn({key:k,val:()=>v})===true)break;}}});
  function query(path,st){
    return {orderByKey:()=>query(path,{...st,by:'key'}),orderByChild:c=>query(path,{...st,by:c}),
      startAt:(v,k)=>query(path,{...st,start:{v,k}}),endAt:(v,k)=>query(path,{...st,end:{v,k}}),
      limitToFirst:n=>query(path,{...st,first:n}),limitToLast:n=>query(path,{...st,last:n}),
      once:async()=>{
        calls.push({path,st});
        let ents=Object.entries(get(path)||{});
        const val=e=>st.by==='key'?e[0]:(e[1][st.by]===undefined?null:e[1][st.by]);
        const cmp=(a,b)=>{const x=val(a),y=val(b); if(x===y) return a[0]<b[0]?-1:a[0]>b[0]?1:0; if(x===null) return -1; if(y===null) return 1; return x<y?-1:1;};
        ents.sort(cmp);
        const cmpPair=(e,p)=>{const a=val(e); if(st.by==='key'){ return e[0]<p.v?-1:e[0]>p.v?1:0; }
          const pv=p.v===undefined?null:p.v; if(a!==pv) return a===null?-1:pv===null?1:(a<pv?-1:1);
          if(p.k===undefined) return 0; return e[0]<p.k?-1:e[0]>p.k?1:0;};
        if(st.start) ents=ents.filter(e=>cmpPair(e,st.start)>=0);
        if(st.end) ents=ents.filter(e=>cmpPair(e,st.end)<=0);
        if(st.last) ents=ents.slice(-st.last);
        if(st.first) ents=ents.slice(0,st.first);
        return listSnap(ents);
      }};
  }
  return {root,calls,failUpdate:false,
    ref(path){const q=query(path,{});return {...q,
      once:async()=>{calls.push({path,st:{}});return snapOf(path.split('/').pop(),get(path));},
      set:async v=>setp(path,v),
      update:async u=>{ if(this.failUpdate) throw new Error('boom');
        for(const k of Object.keys(u)){const full=path+'/'+k;const v=u[k];
          if(v&&v[INC]!==undefined) setp(full,(Number(get(full))||0)+v[INC]); else setp(full,v);}}};}};
}

// ================== 1) الخادم ==================
console.log('\n[1] server.js — stats/treasury');
const h0=server.indexOf('const TREASURY_STATS_PATH'), h1=server.indexOf('// ============================================================\n// Sessions');
const helper=server.slice(h0,h1);
const r0=server.indexOf('let _treasuryStatsRecalcRunning'), r1=server.indexOf('// ============================================================\n// تعيين نوع الحساب');
const recalc=server.slice(r0,r1);

function boot(root){
  const db=makeDb(root); let handler;
  const ctx={db,console:{...console,error:()=>{}},Number,Math,Object,JSON,Date,
    admin:{database:{ServerValue:{increment:n=>({[INC]:n})}}},
    verifyAdmin:async()=>({isAdmin:true}),app:{post:(p,fn)=>{if(p==='/admin/recalculate-treasury-stats')handler=fn;}}};
  vm.createContext(ctx);
  vm.runInContext(helper+'\n'+recalc+'\nthis._upd=_updateTreasuryStats; this._deltas=_treasuryStatsDeltas;',ctx);
  const call=async()=>{let out,code=200;await handler({},{status:c=>({json:j=>{code=c;out=j;}}),json:j=>{out=j;}});return {out,code};};
  return {db,ctx,call};
}

// بيانات: 1234 حركة (تتخطى حد الصفحة 500 مرتين) بأنواع مختلطة + رصيد متّسق مع المجموع
const types=['card_sale','card_sale_sms','deposit','credit','debt_payment','capital_injection','card_delete_refund','weird'];
const root={treasury:{transactions:{},summary:{balance:0}}};
const A=boot(root);
let seed=7; const rnd=()=>{seed=(seed*1103515245+12345)&0x7fffffff;return seed/0x7fffffff;};
const mkTx=(i)=>{const type=types[Math.floor(rnd()*types.length)];
  const amt=Math.round((1+rnd()*500)*100)/100; const neg=(type==='deposit'||type==='credit'||type==='card_delete_refund');
  return {type,changeAmount:neg?-amt:amt,timestamp:1700000000000+i*1000};};

(async()=>{
  // تهيئة أولى بلا حركات
  let r=await A.call(); ok(r.out.success && r.out.txCount===0,'تهيئة أولى على خزينة فارغة');
  // تطبيق 1234 حركة «كما يفعل recordTreasuryMovement»: كتابة الحركة + الرصيد + تحديث الإحصاء التراكمي
  for(let i=0;i<1234;i++){const tx=mkTx(i); root.treasury.transactions['k'+String(i).padStart(5,'0')]=tx;
    root.treasury.summary.balance=Math.round((root.treasury.summary.balance+tx.changeAmount)*100)/100;
    await A.ctx._upd(tx.type,tx.changeAmount);}
  const incremental={...root.stats.treasury};
  r=await A.call();
  ok(r.out.success && r.out.txCount===1234,'إعادة الحساب تقرأ 1234 حركة عبر الصفحات بلا تكرار ولا نقص (حد الصفحة 500)');
  const pages=A.db.calls.filter(c=>c.path==='treasury/transactions'&&c.st.by==='key').length;
  ok(pages===3+1,'عدد صفحات القراءة = '+pages+' (3 للحركات + 1 للتهيئة الأولى)');
  const d=r.out.drift; ok(['totalSales','totalDeposits','totalInvoicesPaid','legacyCreditSum'].every(k=>Math.abs(d[k])<0.005),'التحديث التراكمي = إعادة الحساب الكاملة (drift=0): '+JSON.stringify(d));
  ok(r.out.balanceDrift===0,'مجموع الحركات = رصيد الخزينة (balanceDrift=0)');
  // التطابق مع المعادلات القديمة للوحة
  const all=Object.values(root.treasury.transactions);
  const oldBalance=all.reduce((s,t)=>s+t.changeAmount,0);
  const oldSales=all.filter(t=>t.type==='credit').reduce((s,t)=>s+t.changeAmount,0);
  ok(Math.abs(oldBalance-root.treasury.summary.balance)<0.01,'رصيد الخزينة القديم (Σ changeAmount) = treasury/summary/balance');
  ok(Math.abs(oldSales-root.stats.treasury.legacyCreditSum)<0.01,'legacyCreditSum = معادلة «إجمالي المبيعات» القديمة بالضبط ('+oldSales.toFixed(2)+')');
  const salesReal=all.filter(t=>['card_sale','card_sale_sms','card_purchase'].includes(t.type)).reduce((s,t)=>s+t.changeAmount,0);
  ok(Math.abs(salesReal-root.stats.treasury.totalSales)<0.01,'totalSales = مبيعات الكروت الفعلية');
  ok(root.stats.treasury.legacyCreditSum<0 && root.stats.treasury.totalSales>0,'تأكيد الملاحظة: «المعادلة القديمة» سالبة بينما المبيعات الفعلية موجبة');
  // الأنواع غير المتتبَّعة لا تُنشئ حقولاً
  ok(!('capital_injection' in root.stats.treasury)&&Object.keys(A.ctx._deltas('weird',5)).length===0,'الأنواع غير المتتبَّعة تُتجاهل');
  // انحراف الرصيد يُكتشف ولا يُصلَح تلقائياً
  root.treasury.summary.balance+=25; r=await A.call();
  ok(r.out.balanceDrift===-25 && root.treasury.summary.balance===oldBalance+25 || Math.abs(r.out.balanceDrift+25)<0.01,'اكتشاف انحراف الرصيد (−25) دون تعديل الرصيد');
  root.treasury.summary.balance-=25;
  // فشل كتابة الإحصاء لا يرمي
  A.db.failUpdate=true; let threw=false; try{await A.ctx._upd('card_sale',10);}catch(e){threw=true;} A.db.failUpdate=false;
  ok(!threw,'فشل تحديث الإحصاء لا يرمي (الحركة المالية لا تتأثر)');
  // قيم غير صالحة
  ok(Object.keys(A.ctx._deltas('card_sale',NaN)).length===0&&Object.keys(A.ctx._deltas('card_sale',0)).length===0,'قيم NaN/0 تُتجاهل');

  // ================== 2) المتصفح: الصفحات ==================
  console.log('\n[2] admin-logic.js — _tFeedLoad (آخر 50 + عرض المزيد)');
  const f0=adminNew.indexOf('const _TFEED_PAGE'), f1=adminNew.indexOf('// ============================================================',f0);
  function bootClient(txs,balance){
    const rootC={treasury:{transactions:txs,summary:{balance}}}; const db=makeDb(rootC);
    const els={}; const el=id=>els[id]||(els[id]={innerText:'',innerHTML:'',style:{display:''},value:''});
    const ctx={database:db,console,Number,Math,Object,JSON,Date,Promise,Array,
      $n:v=>Number(v)||0,$fmt:v=>(Number(v)||0).toFixed(2),esc:s=>String(s??''),Swal:{fire:(...a)=>{throw new Error('Swal:'+a.join('|'));}},
      document:{getElementById:id=>el(id),createElement:()=>({style:{}, set innerHTML(v){this._h=v;}, get innerHTML(){return this._h||'';}}),querySelector:()=>null},
      window:{},APP:{},showAlert(){},};
    vm.createContext(ctx); return {ctx,db,els,root:rootC};
  }
  // 237 حركة، بعضها بنفس timestamp (تعادل)، وبعضها بلا timestamp
  const txs={}; for(let i=0;i<237;i++){const ts=1700000000000+Math.floor(i/4)*60000; const d=new Date(ts);
    txs['t'+String(i).padStart(4,'0')]={type:i%3?'card_sale':'deposit',changeAmount:i%3?(i+1):-(i+1),timestamp:ts,date:d.toISOString(),dateStr:d.toISOString().slice(0,10)};}
  txs['zzOldNoTs']={type:'capital_injection',changeAmount:100,date:'2023-01-01T00:00:00.000Z'}; // قديمة بلا timestamp
  const C=bootClient(txs,Object.values(txs).reduce((s,t)=>s+t.changeAmount,0));
  vm.runInContext(adminNew.slice(f0,f1)+'\nthis._tFeed=_tFeed; this._load=_tFeedLoad;',C.ctx);
  const sorted=Object.entries(txs).sort((a,b)=>{const x=a[1].timestamp??null,y=b[1].timestamp??null; if(x===y)return a[0]<b[0]?-1:1; if(x===null)return -1; if(y===null)return 1; return x<y?-1:1;}).map(e=>e[0]);
  await C.ctx._load(false);
  ok(C.ctx._tFeed.items.length===50 && C.ctx._tFeed.items.map(t=>t.id).join()===sorted.slice(-50).join(),'أول تحميل = آخر 50 بالترتيب الصحيح');
  ok(C.ctx._tFeed.hasMore===true,'hasMore=true');
  let guard=0; while(C.ctx._tFeed.hasMore && guard++<20){ const before=C.ctx._tFeed.items.length; await C.ctx._load(true); ok(C.ctx._tFeed.items.length>before && C.ctx._tFeed.items.length<=before+50,'عرض المزيد: +'+(C.ctx._tFeed.items.length-before)+' (الإجمالي '+C.ctx._tFeed.items.length+')'); }
  const got=C.ctx._tFeed.items.map(t=>t.id);
  ok(got.length===sorted.length && got.join()===sorted.join(),'بعد استنفاد الصفحات: كل الحركات ('+got.length+') بلا تكرار ولا نقص حتى مع تعادل timestamp وسجل بلا timestamp');
  ok(C.ctx._tFeed.hasMore===false,'hasMore=false عند النهاية');
  // مضاعف تام للصفحة (150 حركة) لا يُنتج زراً فارغاً
  const t150={}; for(let i=0;i<150;i++) t150['x'+String(i).padStart(3,'0')]={type:'card_sale',changeAmount:1,timestamp:1700000000000+i,date:new Date(1700000000000+i).toISOString()};
  const C2=bootClient(t150,150); vm.runInContext(adminNew.slice(f0,f1)+'\nthis._tFeed=_tFeed; this._load=_tFeedLoad;',C2.ctx);
  await C2.ctx._load(false); await C2.ctx._load(true);
  ok(C2.ctx._tFeed.items.length===100 && C2.ctx._tFeed.hasMore===true,'150 حركة: بعد صفحتين (100) يبقى «عرض المزيد»');
  await C2.ctx._load(true);
  ok(C2.ctx._tFeed.items.length===150 && C2.ctx._tFeed.hasMore===false,'150 حركة = 3 صفحات بالضبط: الزر يختفي في آخر صفحة (لا ضغطة فارغة)');
  // ===== مقارنة كشف الخزينة قبل/بعد =====
  console.log('\n[3] كشف الخزينة: النسخة القديمة (تنزيل كل شيء) مقابل الجديدة');
  const sl=(src,a,b)=>src.slice(src.indexOf(a),src.indexOf(b));
  const oldFn=sl(adminOld,'async function fetchTreasuryReport()','function printTreasuryReport');
  const newFn=sl(adminNew,'function _renderTreasuryMoreBox','function printTreasuryReport');
  const oldFnSafe=oldFn.length>100?oldFn:null;
  assert.ok(oldFnSafe && newFn.length>100,'استخراج الدوال');
  function runReport(kind,from,to,more){
    const T=bootClient(txs,Object.values(txs).reduce((s,t)=>s+t.changeAmount,0));
    T.ctx.window={};
    const el=id=>T.els[id]||(T.els[id]={innerText:'',innerHTML:'',style:{display:''}});
    T.els['from-text-treasury']={innerText:from||''}; T.els['to-text-treasury']={innerText:to||''};
    let boot_='';
    if(kind==='old'){ boot_=`const _TreasuryCache={async get(){return (await database.ref('treasury/transactions').once('value')).val()||{};}};`; }
    else { boot_=adminNew.slice(f0,f1); }
    T.ctx.document.getElementById=id=>el(id);
    vm.runInContext(boot_+'\n'+(kind==='old'?oldFn:newFn)+'\nthis.run=fetchTreasuryReport;',T.ctx);
    return T;
  }
  const rows=T=>{const h=T.els['table-body-treasury'].innerHTML; return h.split('<tr>').slice(1).map(x=>x.replace(/\s+/g,' ').trim());};
  const day=ms=>{const d=new Date(ms);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');};
  const t0=1700000000000, tN=1700000000000+Math.floor(236/4)*60000;
  // الأيام: كل الحركات داخل ~1 ساعة؛ نختبر نطاق اليوم، من فقط، إلى فقط، ونطاقاً فارغاً
  for(const [name,f,t] of [['نطاق يوم الحركات',day(t0),day(tN)],['من فقط',day(t0),''],['إلى فقط','',day(tN)],['نطاق بلا حركات','2020-01-01','2020-01-02']]){
    const O=runReport('old',f,t); await O.ctx.run(); const N=runReport('new',f,t); await N.ctx.run();
    const ro=rows(O), rn=rows(N);
    if(!f&&!t){}
    ok(JSON.stringify(ro)===JSON.stringify(rn)&&['totalDebitTreasury','totalCreditTreasury','totalNetTreasury'].every(k=>O.els[k].innerText===N.els[k].innerText),name+': الصفوف والإجماليات والرصيد الجاري مطابقة للنسخة القديمة ('+ro.length+' صف)');
  }
  // بلا نطاق: آخر 50 في الجديد = آخر 50 صفاً في القديم (بما فيها الرصيد الجاري)
  const O=runReport('old','',''); await O.ctx.run(); const N=runReport('new','',''); await N.ctx.run();
  const ro=rows(O), rn=rows(N);
  ok(rn.length===50 && JSON.stringify(ro.slice(-50))===JSON.stringify(rn),'بلا نطاق: آخر 50 صفاً (مع الرصيد الجاري) مطابقة تماماً لآخر 50 من النسخة القديمة');
  ok(N.els['rep-from-treasury'].innerText==='آخر 50 حركة','عنوان الفترة يوضّح «آخر 50 حركة»');
  const lastRunning=/<td class="balance"[^>]*>([^<]*)<\/td>/g; let m,lastBal; while((m=lastRunning.exec(N.els['table-body-treasury'].innerHTML))) lastBal=m[1];
  ok(Number(lastBal)===Number(N.root.treasury.summary.balance.toFixed(2)),'آخر رصيد جارٍ = رصيد الخزينة الحالي ('+lastBal+')');
  // الحجم المنقول
  const readsNew=N.db.calls.filter(c=>c.path==='treasury/transactions').length;
  ok(N.db.calls.every(c=>!(c.path==='treasury/transactions' && !c.st.last && !c.st.start && !c.st.end)),'الجديد لا يقرأ treasury/transactions كاملة أبداً (كل استعلام مقيّد بحد/نطاق)');
  console.log('\nكل الاختبارات نجحت: '+pass+' تحقق');
})().catch(e=>{console.error('\n✗',e.message);process.exit(1);});
