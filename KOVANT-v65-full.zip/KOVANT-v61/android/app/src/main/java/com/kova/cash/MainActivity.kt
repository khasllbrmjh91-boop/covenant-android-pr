package com.kova.cash

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import com.getcapacitor.BridgeActivity
import com.kova.cash.plugins.TuaBiometricPlugin
import com.kova.cash.plugins.TuaSmsSenderPlugin
import com.kova.cash.plugins.TuaWifiManagerPlugin
import com.kova.cash.plugins.TuaSmsInboxPlugin
import com.kova.cash.plugins.TuaSmsSettingsPlugin
import com.kova.cash.plugins.TuaNotificationPlugin
import com.kova.cash.plugins.TuaTrafficStatsPlugin

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Capacitor يقرأ قائمة الإضافات داخل super.onCreate()، لذلك يجب التسجيل قبله.
        registerPlugin(TuaBiometricPlugin::class.java)
        registerPlugin(TuaSmsSenderPlugin::class.java)
        registerPlugin(TuaWifiManagerPlugin::class.java)
        registerPlugin(TuaSmsInboxPlugin::class.java)
        registerPlugin(TuaSmsSettingsPlugin::class.java)
        registerPlugin(TuaNotificationPlugin::class.java)
        registerPlugin(TuaTrafficStatsPlugin::class.java)
        super.onCreate(savedInstanceState)
        createDefaultNotificationChannel()
    }

    // قناة إشعارات FCM الافتراضية: السيرفر يرسل channelId = kovant_default، ولو لم تكن موجودة
    // يعرض أندرويد الإشعار في قناة احتياطية بلا صوت/أولوية.
    private fun createDefaultNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel("kovant_default") != null) return
        val ch = NotificationChannel("kovant_default", "إشعارات كوفانت", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "إشعارات العمليات والرسائل"
            enableVibration(true)
        }
        nm.createNotificationChannel(ch)
    }
}
