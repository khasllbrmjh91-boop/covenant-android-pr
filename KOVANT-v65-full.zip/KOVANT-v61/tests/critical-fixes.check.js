'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const admin = fs.readFileSync(path.join(root, 'js/admin-logic.js'), 'utf8');
const topup = fs.readFileSync(path.join(root, 'js/topup-approval-logic.js'), 'utf8');
const wifi = fs.readFileSync(path.join(root, 'wifi-networks.html'), 'utf8');
const rules = JSON.parse(fs.readFileSync(path.join(root, 'database.rules.json'), 'utf8'));
const analysis = fs.readFileSync(path.join(root, 'js/sales-analysis.js'), 'utf8');

function between(text, start, end) {
  const a = text.indexOf(start);
  assert.notEqual(a, -1, `missing section: ${start}`);
  const b = text.indexOf(end, a + start.length);
  assert.notEqual(b, -1, `missing section end: ${end}`);
  return text.slice(a, b);
}

const sell = between(server, 'async function _sellCardToUser(o)', 'function _buildCardSaleRollbackUpdates(o)');
assert.ok(sell.indexOf('const soldKeys = [];') < sell.indexOf('soldKeys.push(soldKey)'), 'soldKeys must be initialized before use');
for (const p of [
  'stats/sales_daily_total/\' + dayKey + \'/count',
  'stats/sales_daily_total/\' + dayKey + \'/amount',
  'stats/sales_by_pkg/\' + packageId + \'/totalCount',
  'stats/sales_by_pkg/\' + packageId + \'/totalAmount'
]) assert.ok(sell.includes(p), `sale update missing ${p}`);

const rollback = between(server, 'function _buildCardSaleRollbackUpdates(o)', "app.post('/api/purchase-package'");
for (const p of [
  "users/' + buyerPhone + '/history/",
  "notifications/' + buyerPhone + '/",
  "kova_store_public/' + pkg + '/availableCount",
  "admin_sales/' + pkg + '/soldCount",
  "stats/sales_daily/' + pkg + '/",
  "stats/sales_daily_total/' + saleWrite.dayKey + '/",
  "stats/sales_by_pkg/' + pkg + '/",
  'inc(-saleWrite.count)',
  'inc(-saleWrite.totalAmount)'
]) assert.ok(rollback.includes(p), `rollback missing ${p}`);
assert.ok(server.includes("_buildCardSaleRollbackUpdates({ saleWrite, buyerPhone: phone, packageId, reserved, treasuryMovement, adminNotificationPath })"), 'API purchase path must call rollback helper');
assert.ok(server.includes("_buildCardSaleRollbackUpdates({ saleWrite, buyerPhone: fromPhone, packageId: pkgId, reserved, treasuryMovement })"), 'SMS purchase path must call rollback helper');

const backfill = between(admin, 'async function _backfillSalesAggregatesFromTreasury()', 'window.backfillSalesDaily =');
assert.ok(backfill.includes("tx.type !== 'card_sale' && tx.type !== 'card_sale_sms'"), 'backfill must filter both sale types');
assert.ok(backfill.includes("database.ref('stats/sales_daily_total').set("), 'daily totals must be absolute set');
assert.ok(backfill.includes("database.ref('stats/sales_by_pkg').set("), 'package totals must be absolute set');
assert.ok(admin.includes("orderByChild('timestamp')"), 'sold pages must order by timestamp');
assert.ok(admin.includes('limitToLast(window.KovaSoldReader.PAGE_SIZE)'), 'sold initial page must be capped');
assert.ok(admin.includes("query.once('value')"), 'sold page must use a one-time read');
const soldReader = between(admin, 'window.KovaSoldReader = {', '// يضمن وجود بيانات الفئات');
assert.ok(!/query\.on\(['"]value['"]/.test(soldReader) && !/soldRef\.on\(['"]value['"]/.test(soldReader), 'sold records must not attach a persistent value listener');
assert.ok(soldReader.includes('عرض المزيد من الكروت المباعة'), 'sold reader must expose a load-more control');

assert.equal(rules.rules.stats.sales_daily_total['.write'], 'auth != null && auth.token.isAdmin === true');
assert.equal(rules.rules.stats.sales_by_pkg['.write'], 'auth != null && auth.token.isAdmin === true');
assert.ok(analysis.includes("stats/sales_daily_total"), 'analysis page must read daily totals');
assert.ok(analysis.includes("stats/sales_by_pkg"), 'analysis page must read package totals');
for (const fn of ['function loadAdminDevices()', 'function loadAdminVisitors()']) {
  const start = admin.indexOf(fn);
  assert.notEqual(start, -1, `missing ${fn}`);
  const body = admin.slice(start, start + 5000);
  assert.ok(body.includes("orderByChild('createdAt')") || body.includes('adminLoadMore'), `${fn} must route through bounded pages`);
}
assert.ok(admin.includes("migrations['users/'+phone+'/createdAt']=0"), 'createdAt migration must use zero for legacy records');
assert.ok(admin.includes('limitToLast(50+(paging?1:0))'), 'user admin pages must be limited to 50 (+cursor boundary)');
assert.ok(wifi.includes("orderByChild('last').limitToLast(100).once('value')"), 'wifi initial read must be the bounded lightweight index');
assert.ok(wifi.includes("orderByChild('timestamp').limitToLast(60).once('value')"), 'wifi records must load only on user selection and cap at 60');
assert.ok(topup.includes("orderByChild('receivedAt').limitToLast(this.inboxPageSize)") && topup.includes("this.inboxQuery.once('value')"), 'SMS inbox initial read must be once and capped at 50');
assert.ok(!/database\.ref\('sms_inbox'\)\.on\(['"]value['"]/.test(topup), 'SMS inbox must not listen to the full node');
assert.ok(topup.includes('TuaStore.loadMoreInbox()'), 'SMS inbox must expose a load-more control');
for (const key of ['sms_inbox', 'topup_processed_log', 'settings', 'wallets', 'admin', 'loginBanners']) {
  assert.ok(rules.rules[key], `missing Firebase rules root ${key}`);
}
console.log('critical fixes contract checks: PASS');
