const fs = require('fs');
const assert = require('assert');
const path = require('path');
const root = path.resolve(__dirname, '..');
const sms = fs.readFileSync(path.join(root, 'js/sms-logic.js'), 'utf8');
const user = fs.readFileSync(path.join(root, 'js/user-logic.js'), 'utf8');
const topup = fs.readFileSync(path.join(root, 'js/topup-approval-logic.js'), 'utf8');
const admin = fs.readFileSync(path.join(root, 'js/admin-logic.js'), 'utf8');
const rules = JSON.parse(fs.readFileSync(path.join(root, 'database.rules.json'), 'utf8')).rules;

for (const [node, order] of [['sms_queue', 'createdAt'], ['sms_raw_inbox', 'timestamp'], ['sms_commands', 'ts']]) {
  assert(sms.includes("'" + node + "'") && sms.includes("orderByChild(order)") && sms.includes("limitToLast(realSmsState.sizes[kind])"), `${node} should use a bounded, ordered query`);
  assert(!new RegExp("ref\\('" + node + "'\\)\\.on\\('value'").test(sms), `${node} must not have an unbounded value listener`);
  assert(rules[node] && rules[node]['.indexOn'].includes(order), `${node}.${order} should be indexed`);
}
assert(sms.includes("kind === 'queue' ? 'createdAt' : kind === 'inbox' ? 'timestamp' : 'ts'"), 'SMS paths should use their requested ordering keys');
assert(sms.includes("ref('sms_commands').orderByChild('ts').limitToLast(smsAutoPageSize)"), 'Auto commands should use ts pagination');
assert(sms.includes('loadMoreAutoCommands') && sms.includes('عرض المزيد'), 'SMS should offer more results');
assert(topup.includes("orderByChild('status').equalTo(status).limitToLast(this.pages[status])"), 'Top-ups should be queried by status with a limit');
assert(topup.includes('tuaLoadMoreRequests') && topup.includes('عرض المزيد'), 'Top-ups should offer more results');
assert(user.includes("orderByChild('timestamp').limitToLast(APP._notifPageSize)"), 'Notifications should start with a 20-item ordered window');
assert(user.includes('loadOlderNotifications') && user.includes('تحميل الأقدم'), 'Notifications should offer older results');
assert(admin.includes('await window.backfillSalesData()'), 'Full recalculation should run the sales backfill');
console.log('stage7 pagination contract checks: PASS');
