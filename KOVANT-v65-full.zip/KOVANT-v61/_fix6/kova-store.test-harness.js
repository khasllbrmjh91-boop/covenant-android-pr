// تشغيل: node _fix6/kova-store.test-harness.js   (من جذر المشروع)
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const ROOT=process.cwd();
const src=fs.readFileSync(ROOT+'/js/admin-logic.js','utf8');
const rules=JSON.parse(fs.readFileSync(ROOT+'/database.rules.json','utf8')).rules;
let pass=0; const ok=(c,m)=>{assert.ok(c,'FAIL: '+m); pass++; console.log('  ✓',m);};

// ---------- بيانات ----------
const T0=1700000000000, DAY=86400000;
const store={}, pub={};
function cat(id,name,n,soldN,price){
  const cards={}, sold={};
  for(let i=0;i<n;i++) cards['-Nc'+String(i).padStart(5,'0')]={code:(i%7===0?'5551':'1000')+String(i).padStart(8,'0'),addedAt:T0+Math.floor(i/10)*DAY};
  for(let i=0;i<soldN;i++) sold['-Ns'+String(i).padStart(5,'0')]={code:'9000'+String(i).padStart(8,'0'),customerId:'77'+String(i).padStart(7,'0'),timestamp:T0+i*3600000,package:name,price};
  store[id]={name,sellPrice:String(price),duration:'30 يوم',cardLength:12,cards,sold};
  pub[id]={name,sellPrice:String(price),mostRequested:false,availableCount:n};
}
cat('A','ستور 10$',1234,700,10); cat('B','ستور 5$',30,5,5); cat('C','ستور 20$',100,0,20); cat('D','فارغة',0,0,1);
const FULL_BYTES=JSON.stringify(store).length;

// ---------- RTDB وهمي ----------
let served=0, log=[];
function makeDb(){
  const get=p=>p.split('/').filter(Boolean).reduce((o,k)=>o==null?undefined:o[k],{kova_store:store,kova_store_public:pub});
  const del=p=>{const ks=p.split('/').filter(Boolean);let o={kova_store:store,kova_store_public:pub};for(let i=0;i<ks.length-1;i++)o=o[ks[i]];delete o[ks[ks.length-1]];};
  const bytes=v=>v===undefined?0:JSON.stringify(v).length;
  const snapL=ents=>({val:()=>Object.fromEntries(ents),forEach:fn=>{for(const [k,v] of ents){if(fn({key:k,val:()=>v})===true)break;}}});
  function q(path,st){return{orderByKey:()=>q(path,{...st,by:'$key'}),orderByChild:c=>q(path,{...st,by:c}),
    startAt:(v,k)=>q(path,{...st,s:{v,k}}),endAt:(v,k)=>q(path,{...st,e:{v,k}}),limitToFirst:n=>q(path,{...st,n}),
    once:async()=>{ const d=get(path)||{}; let ents=Object.entries(d);
      if(st.by&&st.by!=='$key'){ // استعلام فرعي يتطلب فهرساً في القواعد
        const m=path.match(/^kova_store\/[^/]+\/(cards|sold)$/); assert.ok(m,'orderByChild على مسار غير متوقع '+path);
        const idx=rules.kova_store.$pkg[m[1]]['.indexOn']; assert.ok(idx.includes(st.by),'غياب .indexOn='+st.by+' على '+path);
      }
      const val=e=>st.by==='$key'?e[0]:(e[1]&&e[1][st.by]!==undefined?e[1][st.by]:null);
      ents.sort((a,b)=>{const x=val(a),y=val(b); if(x===y)return a[0]<b[0]?-1:a[0]>b[0]?1:0; if(x===null)return -1; if(y===null)return 1; return x<y?-1:1;});
      const cmp=(e,p)=>{ if(st.by==='$key') return e[0]<p.v?-1:e[0]>p.v?1:0; const a=val(e); if(a!==p.v) return a===null?-1:(a<p.v?-1:1); if(p.k===undefined)return 0; return e[0]<p.k?-1:e[0]>p.k?1:0;};
      if(st.s) ents=ents.filter(e=>st.by==='$key'?cmp(e,{v:st.s.v})>=0:cmp(e,st.s)>=0);
      if(st.e) ents=ents.filter(e=>cmp(e,st.e)<=0);
      if(st.n) ents=ents.slice(0,st.n);
      const out=Object.fromEntries(ents); served+=bytes(out); log.push({path,by:st.by||null,n:ents.length}); return snapL(ents);} };}
  return {ref:path=>({...q(path,{}),
    once:async()=>{const v=get(path); served+=bytes(v); log.push({path,full:true}); return {val:()=>v===undefined?null:v,exists:()=>v!=null};},
    on(ev,cb){this._cb=cb; cb({val:()=>get(path)||null});}, off(){},
    update:async()=>{}, remove:async()=>{del(path);}}),
    update:async u=>{for(const k of Object.keys(u)) if(u[k]===null) del(k);}};
}

// ---------- DOM وهمي ----------
const els={}; const el=id=>els[id]||(els[id]={value:'',innerHTML:'',_t:'',get textContent(){return this._t;},set textContent(v){this._t=String(v);},style:{},addEventListener(ev,cb){(this._l=this._l||{})[ev]=cb;},classList:{add(){},remove(){}}});
const db=makeDb(); db.ref=((o)=>(p)=>o(p))(db.ref);
const ctx={database:{ref:db.ref,update:db.update},console:{...console,warn:()=>{}},Number,Math,Object,JSON,Date,Promise,Array,Set,setTimeout,
  APP:{storeData:{}},waitForFirebaseAuth:async()=>({}),esc:s=>String(s??''),showAlert:()=>{},
  firebase:{database:{ServerValue:{increment:n=>({inc:n})}}},_pubInc:n=>({inc:n}),logTreasuryTransaction:async()=>{},
  Swal:{fire:async()=>({isConfirmed:true})},window:{},document:{getElementById:id=>el(id),createElement:()=>({style:{}})},
  renderAdminStore(){},populateCardSelect(){},_loadCardLengths(){},_pubFromCat(){return{}},URL:{}};
vm.createContext(ctx);
const a0=src.indexOf('function _catAvail('), a1=src.indexOf('function renderAdminStore() {');
const b0=src.indexOf('function populateCategoryFilter'), b1=src.indexOf('window.SoldManager = SoldManager;')+'window.SoldManager = SoldManager;'.length;
vm.runInContext(src.slice(a0,a1)+'\n'+src.slice(src.indexOf('function _cardDateStr'),src.indexOf('function renderCardsPage'))+'\n'+src.slice(b0,b1)+'\nthis.SM=StoreManager;this.SO=SoldManager;this.loadAdminStore=loadAdminStore;this._ensure=_ensureAdminStoreMeta;this.pubOnly=typeof _bootstrapPublicIfEmpty;',ctx);
const fullReads=()=>log.filter(l=>/^kova_store$/.test(l.path)).length;
const cardReads=()=>log.filter(l=>/^kova_store\/[^/]+\/(cards|sold)$/.test(l.path));
const cardsInGrid=pre=>(el(pre+'CardsGridContainer').innerHTML.match(/class="card-item/g)||[]).length;

(async()=>{
  console.log('\n[1] فتح صفحة إدارة الباقات / لوحة التحكم');
  served=0; log=[]; ctx.loadAdminStore();
  ok(Object.keys(ctx.APP.storeData).length===4 && fullReads()===0,'الفئات من kova_store_public فقط (بدون قراءة kova_store)');
  ok(log.every(l=>!/^kova_store\//.test(l.path)||l.path==='kova_store_public'),'لا قراءة لأي مسار cards/sold عند فتح الصفحة');
  const openBytes=JSON.stringify(pub).length+served; ok(openBytes<1500,'حجم فتح الصفحة = '+openBytes+' بايت (قبل: '+FULL_BYTES+' بايت)');
  ok(ctx.pubOnly==='function','مسار الإقلاع الأول (public فارغة) موجود');

  console.log('\n[2] صفحة «الكروت المتوفرة»: لا تنزيل قبل اختيار فئة');
  log=[]; served=0; await ctx.SM.load();
  ok(cardReads().length===0 && log.every(l=>/cardLength$/.test(l.path)) && served<50,'فتح الصفحة بلا فئة: صفر بايت من الكروت');
  ok(/اختر فئة/.test(el('storeCardsGridContainer').innerHTML),'رسالة «اختر فئة لعرض كروتها»');
  ok(/اختر فئة/.test(el('storeCardCategoryFilter').innerHTML),'القائمة تعرض الفئات من النسخة العامة');
  ok(typeof el('storeCardCategoryFilter')._l?.change==='function','اختيار الفئة يجلب كروتها مباشرة (change)');

  console.log('\n[3] اختيار فئة A (1234 كرتاً) + عرض المزيد');
  el('storeCardCategoryFilter').value='A'; log=[]; served=0; await ctx.SM.applyFilters();
  ok(cardsInGrid('store')===50 && ctx.SM._hasMore===true,'أول دفعة: 50 كرتاً + hasMore');
  const firstBytes=served; ok(firstBytes<JSON.stringify(Object.fromEntries(Object.entries(store.A.cards).slice(0,52))).length+10,'نُقل ~52 كرتاً فقط ('+firstBytes+' بايت من أصل '+JSON.stringify(store.A.cards).length+')');
  ok(el('storeCardsCount').textContent==='1234' && el('storeCardsTotalPages').textContent==='25','العدد 1234 والصفحات 25 من availableCount بلا قراءة الكروت');
  ok(ctx.SM._items[0].id==='-Nc00000' && /الأقدم/.test(el('storeCardsGridContainer').innerHTML),'الأقدم أولاً (ترتيب البيع) وعلامة ⭐');
  let g=0; while(ctx.SM._hasMore && g++<40){ const b=ctx.SM._items.length; await ctx.SM.loadMore(); const d=ctx.SM._items.length-b; if(ctx.SM._hasMore) assert.strictEqual(d,50); }
  const ids=ctx.SM._items.map(i=>i.id), want=Object.keys(store.A.cards).sort();
  ok(ids.length===1234 && new Set(ids).size===1234 && ids.join()===want.join(),'بعد «عرض المزيد» حتى النهاية: 1234 كرتاً بلا تكرار ولا نقص وبالترتيب');
  ok(ctx.SM._hasMore===false && !/عرض المزيد/.test(el('storeCardsPagination').innerHTML),'زر «عرض المزيد» يختفي في النهاية');
  ok(cardReads().every(l=>l.n<=52),'كل قراءة ≤ 52 عنصراً');

  console.log('\n[4] حالات حدّية للدفعات');
  el('storeCardCategoryFilter').value='B'; await ctx.SM.applyFilters(); ok(ctx.SM._items.length===30 && !ctx.SM._hasMore,'فئة بـ 30 كرتاً: دفعة واحدة بلا زر');
  el('storeCardCategoryFilter').value='C'; await ctx.SM.applyFilters(); ok(ctx.SM._items.length===50 && ctx.SM._hasMore,'فئة بـ 100: 50 + زر');
  await ctx.SM.loadMore(); ok(ctx.SM._items.length===100 && !ctx.SM._hasMore,'100 كرت = دفعتان بالضبط بلا ضغطة فارغة');
  el('storeCardCategoryFilter').value='D'; await ctx.SM.applyFilters(); ok(ctx.SM._items.length===0 && /لا توجد كروت/.test(el('storeCardsGridContainer').innerHTML),'فئة فارغة: «لا توجد كروت»');
  // سباق: تبديل فئة أثناء التحميل
  el('storeCardCategoryFilter').value='A'; const p1=ctx.SM.applyFilters(); el('storeCardCategoryFilter').value='B'; const p2=ctx.SM.applyFilters(); await Promise.all([p1,p2]);
  ok(ctx.SM._catId==='B' && ctx.SM._items.length===30 && ctx.SM._items.every(i=>i.categoryId==='B'),'تبديل الفئة أثناء التحميل: النتيجة الأحدث فقط');

  console.log('\n[5] البحث بالكود (بادئة) وفلتر التاريخ — بفهارس القواعد');
  el('storeCardCategoryFilter').value='A'; el('storeCardCodeSearch').value='5551';
  log=[]; await ctx.SM.applyFilters(); let g2=0; while(ctx.SM._hasMore&&g2++<20) await ctx.SM.loadMore();
  const wantCode=Object.entries(store.A.cards).filter(([k,v])=>v.code.startsWith('5551')).map(e=>e[0]).sort();
  ok(ctx.SM._items.length===wantCode.length && new Set(ctx.SM._items.map(i=>i.id)).size===wantCode.length,'بحث بادئة الكود: '+wantCode.length+' نتيجة صحيحة ومقسّمة على دفعات بلا تكرار');
  ok(ctx.SM._items.every(i=>i.code.startsWith('5551')),'كل النتائج تبدأ بالبحث');
  el('storeCardCodeSearch').value=''; el('storeCardDateFrom').value=new Date(T0+10*DAY).toISOString().slice(0,10); el('storeCardDateTo').value=new Date(T0+19*DAY).toISOString().slice(0,10);
  await ctx.SM.applyFilters(); let g3=0; while(ctx.SM._hasMore&&g3++<20) await ctx.SM.loadMore();
  const f=new Date(el('storeCardDateFrom').value).setHours(0,0,0,0), t=new Date(el('storeCardDateTo').value).setHours(23,59,59,999);
  const wantDate=Object.entries(store.A.cards).filter(([k,v])=>v.addedAt>=f&&v.addedAt<=t).map(e=>e[0]);
  ok(ctx.SM._items.length===wantDate.length && ctx.SM._items.every(i=>i.addedAt>=f&&i.addedAt<=t),'فلتر التاريخ من الخادم: '+wantDate.length+' كرتاً داخل النطاق فقط');
  ok(el('storeCardsCount').textContent===String(wantDate.length),'مع فلتر: العدد = المحمَّل (لا يستخدم availableCount)');
  ok(rules.kova_store.$pkg.cards['.indexOn'].includes('addedAt')&&rules.kova_store.$pkg.cards['.indexOn'].includes('code')&&rules.kova_store.$pkg.sold['.indexOn'].includes('timestamp'),'القواعد تحتوي الفهارس المطلوبة (addedAt, code, timestamp)');
  await ctx.SM.resetFilters(); ok(ctx.SM._catId==='' && /اختر فئة/.test(el('storeCardsGridContainer').innerHTML),'إعادة الضبط تعود لحالة «اختر فئة»');

  console.log('\n[6] حذف كرت/دفعة وتصدير');
  el('storeCardCategoryFilter').value='B'; await ctx.SM.applyFilters();
  await ctx.SM.deleteOne('B','-Nc00001'); ok(ctx.SM._items.length===29 && !ctx.SM._items.some(i=>i.id==='-Nc00001'),'deleteOne يزيل الكرت من القائمة المعروضة');
  const before=ctx.SM._items.length; await ctx.SM.deleteAll(); ok(ctx.SM._items.length===0,'deleteAll يحذف المعروض ('+before+') ويفرغ القائمة');
  el('storeCardCategoryFilter').value='A'; await ctx.SM.applyFilters();
  let warned=false; ctx.showAlert=(m)=>{ if(/المعروضة فقط/.test(m)) warned=true; }; ctx.exportCardsCsv=()=>{}; 
  ctx.SM._exportLoaded('x.csv'); ok(true,'تصدير المعروض لا يرمي');

  console.log('\n[7] «الكروت المباعة»');
  el('soldCardCategoryFilter').value='A'; log=[]; served=0; await ctx.SO.load(); // load يحافظ على الاختيار
  ok(ctx.SO._items.length===50 && ctx.SO._hasMore,'المباع: أول 50 سجلاً فقط من 700');
  ok(el('soldCardsCount').textContent==='50+','العدد «50+» لأن soldCount غير معروف (لا نخمّنه)');
  ok(ctx.SO._items[0].buyer==='770000000','المشتري يظهر من customerId');
  let g4=0; while(ctx.SO._hasMore&&g4++<30) await ctx.SO.loadMore(); ok(ctx.SO._items.length===700,'700 سجل بلا نقص');
  pub.A.soldCount=700; ctx.APP.storeData=JSON.parse(JSON.stringify(pub)); ctx.SO._render(); ok(el('soldCardsCount').textContent==='700','إن أُضيف soldCount مستقبلاً يظهر الإجمالي الدقيق تلقائياً');

  console.log('\n[8] المقارنة قبل/بعد (فتح الصفحة + أول فئة)');
  console.log('   قبل: '+FULL_BYTES+' بايت (كل kova_store) · بعد: فتح '+openBytes+' + أول فئة '+firstBytes+' بايت');
  console.log('\nكل الاختبارات نجحت: '+pass+' تحقق');
})().catch(e=>{console.error('\n✗',e.message,e.stack.split('\n')[1]);process.exit(1);});
