# الإصلاح 4 — الجزء 5: kova_store في لوحة الأدمن
- الملفات المعدّلة (فوق الجزء 4): js/admin-logic.js, database.rules.json (فهارس فقط). server.js لم يُلمس.
- اختبار: node _fix6/kova-store.test-harness.js   (و node _fix5/treasury.test-harness.js)
- diff هذا الجزء: _fix6/admin-logic.js.diff  |  القواعد (تراكمي مع الجزء 4): _fix6/database.rules.json.cumulative.diff
