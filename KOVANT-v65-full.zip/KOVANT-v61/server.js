// ============================================================
// 🚀 كوفانت - الخادم الخلفي (Render)
// ============================================================
// المتغيرات البيئية المطلوبة:
// - JWT_SECRET: مفتاح سري لتوقيع JWT
// - ADMIN_PASSWORD: كلمة مرور حساب الأدمن (999)
// - FIREBASE_SERVICE_ACCOUNT: JSON لمفتاح خدمة Firebase
// - FIREBASE_DATABASE_URL: رابط قاعدة بيانات Firebase
// - SYSTEM_USERNAME: اسم المستخدم من مزود API الخارجي
// - SYSTEM_PASSWORD: كلمة المرور من مزود API الخارجي
// - API_BASE_URL: الرابط الأساسي للـ API الخارجي
// - BACKPASS_KEY: كلمة سر عشوائية للتحقق من Webhook
// - API_KEY: مفتاح لحماية نقطة /send
// - BOT_KEY: مفتاح سري يطابق ما يرسله بوت التلجرام لحماية نقطة /activate
// ============================================================

const express = require('express');
const admin = require('firebase-admin');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs'); // ✅ جديد — تشفير كلمات المرور بقوة (يستبدل SHA-256 البسيط)
const helmet = require('helmet');
// معالج أخطاء داخلي — لا يعتمد الخادم على أي ملف محلي آخر.
function errorHandler(error, req, res, next) {
    if (res.headersSent) return next(error);
    console.error('Unhandled request error:', error);
    res.status(error.statusCode || 500).json({
        success: false,
        error: process.env.NODE_ENV === 'production' ? 'خطأ داخلي بالخادم' : (error.message || 'خطأ داخلي')
    });
}

const app = express();
app.set('trust proxy', 1); // خلف Render/بروكسي — ضروري لعمل rate-limit بشكل صحيح على IP الحقيقي
app.use(express.json({
    limit: '100kb',
    verify: (req, res, buf) => { req.rawBody = Buffer.from(buf); }
}));
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            frameAncestors: ["'none'"]
        }
    },
    frameguard: { action: 'deny' },
    noSniff: true
}));

// صفحة أسعار سداد هي المسار الوحيد المسموح بتضمينه داخل التطبيق.
app.use((req, res, next) => {
    if (req.path === '/admin-pricing') res.removeHeader('X-Frame-Options');
    next();
});

// ============================================================
// 1. CORS (السماح بالطلبات من Netlify)
// ============================================================
const ALLOWED_ORIGINS = (process.env.FRONTEND_ORIGINS || process.env.FRONTEND_ORIGIN || '')
    .split(',').map(value => value.trim()).filter(Boolean);
app.use((req, res, next) => {
    const requestOrigin = req.headers.origin;
    if (requestOrigin && !ALLOWED_ORIGINS.includes(requestOrigin)) {
        return res.status(403).json({ success: false, error: 'Origin غير مسموح' });
    }
    if (requestOrigin) res.header('Access-Control-Allow-Origin', requestOrigin);
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key, Idempotency-Key');
    res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});

// ============================================================
// 2. التحقق من متغيرات البيئة — إلزامي، بدون أي قيم افتراضية للأسرار
// ============================================================
const REQUIRED_SECRETS = [
    'FIREBASE_SERVICE_ACCOUNT',
    'JWT_SECRET',
    'BOT_KEY',
    'API_KEY',
    'ADMIN_PASSWORD',
    'BACKPASS_KEY'
];
const missingSecrets = REQUIRED_SECRETS.filter(k => !process.env[k]);
if (missingSecrets.length > 0) {
    console.error(`❌ متغيرات بيئة إلزامية غير مضبوطة: ${missingSecrets.join(', ')}`);
    console.error('   لن يعمل الخادم بدونها لأسباب أمنية — لا توجد قيم افتراضية.');
    process.exit(1);
}
if (process.env.JWT_SECRET.length < 32) {
    console.error('❌ JWT_SECRET قصير جداً (يُفضّل 32 حرفاً عشوائياً على الأقل). أنشئ واحداً بـ: openssl rand -hex 32');
    process.exit(1);
}

// ============================================================
// 3. تهيئة Firebase Admin SDK
// ============================================================
let serviceAccount;
try {
    serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
} catch (e) {
    console.error('❌ JSON غير صالح');
    process.exit(1);
}

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: process.env.FIREBASE_DATABASE_URL || 'https://kova-cash-default-rtdb.firebaseio.com'
});
const db = admin.database();

// ============================================================
// 4. دوال مساعدة عامة
// ============================================================
function sha256Hex(text) {
    return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

// Firebase قد يبدأ transaction بقيمة محلية null أثناء Cold Start.
// نقرأ القيمة أولاً ثم نستخدمها فقط كقيمة أولية للـ callback؛ أما التحقق
// النهائي والتعارض بين الطلبات فيبقى ذرياً داخل Firebase transaction.
async function transactionWithWarmValue(ref, updater, label = 'transaction') {
    let lastResult = null;
    for (let attempt = 0; attempt < 3; attempt++) {
        const warmSnapshot = await ref.once('value');
        const warmedValue = warmSnapshot.val();
        lastResult = await ref.transaction(current => {
            const candidate = current === null || current === undefined ? warmedValue : current;
            return updater(candidate);
        });
        console.log(`🔍 ${label} المحاولة ${attempt + 1}:`, {
            committed: lastResult.committed,
            warmExists: warmSnapshot.exists(),
            value: lastResult.snapshot.val()
        });
        if (lastResult.committed) return lastResult;
        if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 200));
    }
    return lastResult;
}


// ============================================================
// Device Lookup — فهرس عكسي للأجهزة (بدل قراءة كل المستخدمين)
// ============================================================
async function linkDeviceToUser(deviceId, phone) {
    if (!deviceId) return;
    const hash = sha256Hex(String(deviceId));
    await db.ref('device_lookup/' + hash).set(phone);
}

async function unlinkDevice(deviceId) {
    if (!deviceId) return;
    const hash = sha256Hex(String(deviceId));
    await db.ref('device_lookup/' + hash).remove();
}

// ============================================================
// Treasury Summary — رقم مُجمّع (بدل قراءة كل المعاملات)
// ============================================================
async function updateTreasurySummary(delta) {
    await transactionWithWarmValue(
        db.ref('treasury/summary/balance'),
        cur => (Number(cur) || 0) + Number(delta),
        'تحديث ملخص الخزينة'
    );
}

async function getTreasurySummary() {
    const snap = await db.ref('treasury/summary/balance').once('value');
    return Number(snap.val()) || 0;
}

// سجل خزينة موحد: نفس delta يُستخدم في summary وtransactions وfull_ledger.
// رأس المال والمبيعات موجبان، وإيداع العميل/تغذية رصيده سالبة، وسداد
// الفاتورة موجب. إذا فشل أي سجل بعد transaction نُعيد الرصيد فوراً.
async function recordTreasuryMovement(delta, details = {}) {
    const amount = Number(delta);
    if (!Number.isFinite(amount) || amount === 0) throw new Error('قيمة حركة الخزينة غير صحيحة');
    const timestamp = Date.now();
    const transactionKey = db.ref('treasury/transactions').push().key;
    const ledgerKey = db.ref('full_ledger').push().key;
    const movement = {
        type: details.type || 'treasury_adjustment', changeAmount: amount,
        amount: Math.abs(amount), direction: amount < 0 ? 'debit' : 'credit',
        date: new Date(timestamp).toISOString(), dateStr: new Date(timestamp).toLocaleString('ar-YE'),
        timestamp, details: details.details || '', performedBy: details.performedBy || 'نظام',
        status: 'completed'
    };
    if (details.packageId != null) movement.packageId = String(details.packageId);
    if (Number.isFinite(Number(details.count)) && Number(details.count) > 0) movement.count = Number(details.count);
    const balanceRef = db.ref('treasury/summary/balance');
    const balanceTx = await transactionWithWarmValue(
        balanceRef,
        cur => (Number(cur) || 0) + amount,
        'تحديث رصيد الخزينة'
    );
    if (!balanceTx.committed) throw new Error('تعذر تحديث treasury/summary/balance');
    try {
        const updates = {};
        updates['treasury/transactions/' + transactionKey] = movement;
        updates['full_ledger/' + ledgerKey] = { ...movement, ledgerType: 'treasury', treasuryTransactionId: transactionKey };
        updates['treasury/summary/updatedAt'] = timestamp;
        await db.ref().update(updates);
        // 🔧 الإصلاح 5: بعد نجاح الحركة والدفتر معاً (لا rollback بعد هذه النقطة) — أفضل جهد ولا يرمي
        await _updateTreasuryStats(movement.type, amount);
        return { transactionKey, ledgerKey, balance: Number(balanceTx.snapshot.val()) || 0 };
    } catch (error) {
        await transactionWithWarmValue(
            balanceRef,
            cur => (Number(cur) || 0) - amount,
            'rollback رصيد الخزينة'
        ).catch(rollbackError => {
            console.error('❌ فشل rollback لرصيد الخزينة:', rollbackError);
        });
        throw error;
    }
}

// ============================================================
// Stats Summary — ملخص إحصاءات لوحة الأدمن (تراكمي، الإصلاح 4)
// ============================================================
// 🔧 الإصلاح 4: كانت اللوحة الرئيسية تقرأ users كاملة (~45 ميجا) لتجمع الأرصدة والديون.
// الآن تقرأ لوحة الأدمن عقدة stats/summary الصغيرة، ويحدّثها الخادم تراكمياً بعد كل عملية.
//   usersCount     عدد المستخدمين (بدون حساب الأدمن 999)
//   activatedCount عدد المفعّلين (isActivated === true)
//   totalBalance   مجموع أرصدة users/*/balance
//   totalDebts     مجموع remainingAmount للفواتير status=active
//   totalInvoices  عدد الفواتير النشطة
// نستخدم ServerValue.increment: عملية ذرّية في الخادم (كالـ transaction) بدون قراءة ولا إعادة محاولة،
// فلا تتعارض الطلبات المتزامنة على هذه العقدة الساخنة ولا تتأثر بمشكلة null عند Cold Start.
// ⚠️ لا ترمي أخطاء أبداً: فشل الإحصاء لا يجب أن يُفشل عملية مالية نُفّذت فعلاً (يُصحَّح لاحقاً بـ /admin/recalculate-stats).
// قبل أول إعادة حساب لا يوجد recalculatedAt فتعرض اللوحة «قيد الحساب» ولا تثق بالأرقام الجزئية.
const STATS_SUMMARY_PATH = 'stats/summary';
async function _updateStatsSummary(d = {}) {
    try {
        const num = v => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
        const deltas = {
            usersCount: num(d.usersDelta),
            activatedCount: num(d.activatedDelta),
            totalBalance: num(d.balanceDelta),
            totalDebts: num(d.debtsDelta),
            totalInvoices: num(d.invoicesDelta)
        };
        const updates = {};
        for (const k of Object.keys(deltas)) {
            if (deltas[k] !== 0) updates[k] = admin.database.ServerValue.increment(deltas[k]);
        }
        if (!Object.keys(updates).length) return;
        updates.updatedAt = Date.now();
        await db.ref(STATS_SUMMARY_PATH).update(updates);
    } catch (error) {
        console.error('⚠️ _updateStatsSummary فشل (العملية الأصلية لم تتأثر، أعد الحساب لاحقاً):', error.message, JSON.stringify(d));
    }
}

// ============================================================
// Treasury Stats — إحصاءات الخزينة التراكمية (الإصلاح 5)
// ============================================================
// 🔧 الإصلاح 5: كانت لوحة الأدمن تنزّل كل treasury/transactions (10+ ميجا) لتجمع «إجمالي المبيعات» ورصيد الخزينة.
// الآن تحدّث الخادم عقدة stats/treasury تراكمياً مع كل حركة خزينة (ServerValue.increment):
//   totalSales            Σ changeAmount لأنواع card_sale / card_sale_sms / card_purchase (موجبة)
//   totalDeposits         Σ |changeAmount| لنوع deposit (إيداع نقدي + تغذية رصيد)
//   totalInvoicesPaid     Σ changeAmount لنوع debt_payment (سداد فواتير)
//   legacyCreditSum       Σ changeAmount (موقّع) لنوع credit = فواتير آجلة صادرة (سالبة) — هو بالضبط الرقم الذي كانت
//                         اللوحة تعرضه تحت «إجمالي المبيعات»؛ نحتفظ به ليتطابق الرقم قبل/بعد (راجع DASH_SALES_MODE)
// رصيد الخزينة لا يُكرَّر هنا: مصدره الوحيد treasury/summary/balance (يُحدَّث بـ transaction).
// ⚠️ لا ترمي أخطاء أبداً: فشل الإحصاء لا يُفشل حركة خزينة نُفّذت فعلاً (يُصحَّح بـ /admin/recalculate-treasury-stats).
// ⚠️ نسخة مطابقة لهذا التصنيف موجودة في js/firebase-config.js (_treasuryStatsDeltas) للحركات التي يكتبها المتصفح.
const TREASURY_STATS_PATH = 'stats/treasury';
function _treasuryStatsDeltas(type, changeAmount) {
    const c = Number(changeAmount);
    if (!Number.isFinite(c) || c === 0) return {};
    switch (type) {
        case 'card_sale': case 'card_sale_sms': case 'card_purchase': return { totalSales: c };
        case 'deposit': return { totalDeposits: Math.abs(c) };
        case 'debt_payment': return { totalInvoicesPaid: c };
        case 'credit': return { legacyCreditSum: c };
        default: return {};
    }
}
async function _updateTreasuryStats(type, changeAmount) {
    try {
        const deltas = _treasuryStatsDeltas(type, changeAmount);
        const keys = Object.keys(deltas);
        if (!keys.length) return;
        const updates = {};
        for (const k of keys) updates[k] = admin.database.ServerValue.increment(deltas[k]);
        updates.updatedAt = Date.now();
        await db.ref(TREASURY_STATS_PATH).update(updates);
    } catch (error) {
        console.error('⚠️ _updateTreasuryStats فشل (حركة الخزينة لم تتأثر، أعد الحساب لاحقاً):', error.message, type, changeAmount);
    }
}

// ============================================================
// Sessions — مسار منفصل للتوكنات
// ============================================================
async function saveSession(phone, refreshHash, expiry) {
    await db.ref('sessions/' + phone).set({
        refreshTokenHash: refreshHash,
        refreshTokenExpiry: expiry,
        updatedAt: Date.now()
    });
}

async function getSession(phone) {
    const snap = await db.ref('sessions/' + phone).once('value');
    return snap.val();
}

async function clearSession(phone) {
    await db.ref('sessions/' + phone).remove();
}

// ============================================================
// Idempotency — حماية العمليات المعلقة من التنفيذ المكرر
// ============================================================
// يعمل هذا السجل كقفل قصير العمر ثم يحفظ الاستجابة النهائية. إذا أعاد
// جهاز العميل نفس operationId بعد عودة الإنترنت، نعيد نفس الاستجابة
// بدلاً من خصم الرصيد أو بيع الكرت مرتين.
const IDEMPOTENCY_PROCESSING_TTL_MS = 10 * 60 * 1000;

function getOperationId(req) {
    const value = req.headers['idempotency-key'] || req.body?.operationId;
    if (!value) return null;
    const id = String(value).trim();
    return id && id.length <= 128 && /^[A-Za-z0-9._:-]+$/.test(id) ? id : null;
}

async function claimIdempotency(phone, operationId) {
    if (!operationId) return { enabled: false, claimed: true };
    const key = sha256Hex(String(operationId));
    const ref = db.ref('operation_dedup/' + sha256Hex(String(phone)) + '/' + key);
    const claimId = crypto.randomBytes(16).toString('hex');
    const result = await ref.transaction(current => {
        if (!current) return { status: 'processing', claimId, createdAt: Date.now() };
        if (current.status === 'processing' && Date.now() - Number(current.createdAt || 0) > IDEMPOTENCY_PROCESSING_TTL_MS) {
            return { status: 'processing', claimId, createdAt: Date.now(), retryOf: current.claimId || null };
        }
        return current;
    });
    const current = result.snapshot.val() || {};
    if (current.claimId === claimId) return { enabled: true, claimed: true, ref };
    if (current.status === 'complete' && current.response) {
        return { enabled: true, claimed: false, status: 200, response: current.response };
    }
    return { enabled: true, claimed: false, status: 409, response: { success: false, error: 'العملية قيد المعالجة، أعد المحاولة بعد لحظات' } };
}

async function completeIdempotency(context, response) {
    if (!context || !context.enabled || !context.ref) return;
    await context.ref.update({ status: 'complete', response, completedAt: Date.now() });
}

const BCRYPT_ROUNDS = 12;
async function hashPasswordStrong(plain) {
    return await bcrypt.hash(plain, BCRYPT_ROUNDS);
}
async function verifyPasswordStrong(plain, hash) {
    try {
        return await bcrypt.compare(plain, hash);
    } catch (e) {
        return false;
    }
}
function isBcryptHash(str) {
    return typeof str === 'string' && /^\$2[aby]\$/.test(str);
}

const REFRESH_TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 يوماً

function generateRefreshToken() {
    return crypto.randomBytes(32).toString('hex');
}

async function issueSessionTokens(phone, isAdmin) {
    const accessToken = jwt.sign(
        isAdmin ? { phone: '999', isAdmin: true } : { phone },
        process.env.JWT_SECRET,
        { expiresIn: '15m' }
    );
    const refreshToken = generateRefreshToken();
    const refreshHash = sha256Hex(refreshToken);
    await saveSession(phone, refreshHash, Date.now() + REFRESH_TOKEN_TTL_MS);
    return { accessToken, refreshToken };
}

function safeEqual(a, b) {
    const bufA = Buffer.from(String(a || ''));
    const bufB = Buffer.from(String(b || ''));
    if (bufA.length !== bufB.length) {
        crypto.timingSafeEqual(bufA, bufA);
        return false;
    }
    return crypto.timingSafeEqual(bufA, bufB);
}

function isValidYemeniPhone(p) {
    return /^7\d{8}$/.test(String(p || ''));
}

function generateAccountNumber() {
    return '40' + Math.floor(10000000 + Math.random() * 90000000).toString();
}

async function isAccountNumberUnique(acc) {
    const snap = await db.ref('users').orderByChild('accountNumber').equalTo(acc).once('value');
    return !snap.exists();
}

async function getUniqueAccountNumber() {
    for (let i = 0; i < 20; i++) {
        const c = generateAccountNumber();
        if (await isAccountNumberUnique(c)) return c;
    }
    throw new Error('تعذر توليد رقم حساب فريد');
}

async function isDeviceLinkedToOtherAccount(deviceId, excludePhone) {
    if (!deviceId) return false;
    const hash = sha256Hex(String(deviceId));
    const snap = await db.ref('device_lookup/' + hash).once('value');
    const owner = snap.val();
    return owner && owner !== excludePhone;
}

// إعدادات FCM الموحّدة لأندرويد: الأيقونة الصغيرة يجب أن تكون ic_stat_kovant (بيضاء شفافة)،
// وليس ic_launcher الملوّن — أندرويد يحوّل الأيقونة الصغيرة إلى silhouette فتظهر مربعاً أبيض.
const ANDROID_PUSH = {
    priority: 'high',
    notification: {
        icon: 'ic_stat_kovant',
        color: '#1A6FA8',
        channelId: 'kovant_default',
        sound: 'default',
        defaultVibrateTimings: true
    }
};
const WEBPUSH_CONFIG = {
    headers: { Urgency: 'high' },
    notification: { icon: '/icons/icon-192.png', badge: '/icons/badge-96x96.png' }
};

// يحفظ الإشعار في notifications/{phone} ليظهر في صفحة الإشعارات (للمستخدم والأدمن 999).
// المفتاح فريد لكل استدعاء؛ الفشل هنا لا يُفشل الإرسال.
async function persistNotification(phone, title, body, type) {
    try {
        const ts = Date.now();
        const key = `${ts}_push_${Math.random().toString(36).slice(2, 7)}`;
        const rec = { id: key, title: String(title || ''), message: String(body || ''), type: type || 'push', timestamp: ts, isRead: false };
        if (String(phone) === '999') rec.read = false;     // صفحة الأدمن تقرأ الحقل القديم read
        await db.ref(`notifications/${phone}/${key}`).set(rec);
    } catch (err) {
        console.error(`❌ persistNotification فشل للرقم ${phone}:`, err.message);
    }
}

// opts.persist=false عندما يكتب المستدعي سجل الإشعار بنفسه (لمنع التكرار)
async function sendPush(phone, title, body, opts = {}) {
    if (opts.persist !== false) await persistNotification(phone, title, body, opts.type);
    try {
        let token = (await db.ref(`user_tokens/${phone}/token`).once('value')).val();
        if (!token) token = (await db.ref(`users/${phone}/fcmToken`).once('value')).val();
        if (!token) return;
        await admin.messaging().send({
            notification: { title, body },
            token,
            android: ANDROID_PUSH,
            webpush: WEBPUSH_CONFIG
        });
    } catch (err) {
        console.error(`❌ sendPush فشل للرقم ${phone}:`, err.message);
    }
}

function fmtMoney(n) {
    return Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

async function createFirebaseAuthToken(phone, isAdmin) {
    try {
        return await admin.auth().createCustomToken(String(phone), { isAdmin: !!isAdmin });
    } catch (err) {
        console.error('❌ فشل توليد Firebase custom token:', err.message);
        return null;
    }
}

// ============================================================
// 4.5 محددات معدل الطلبات (Rate Limiting)
// ============================================================
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, error: 'محاولات كثيرة جداً، حاول لاحقاً' }
});

const chargeLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 5,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'محاولات شحن كثيرة جداً، حاول لاحقاً' }
});

const generalLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 60,
    standardHeaders: true,
    legacyHeaders: false
});
app.use(generalLimiter);

// ============================================================
// 5. نقاط الفحص (للـ Keep-Alive و cron-job)
// ============================================================
app.get('/', (req, res) => {
    res.status(200).send('✅ Kovant Backend is running!');
});

app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/ping', (req, res) => {
    res.status(200).send('pong');
});

// بطاقات بانر صفحة الدخول (عامة - تُقرأ قبل تسجيل الدخول). تُدار من: نظام التطبيق > إدارة إعلانات الدخول
app.get('/api/public/login-banners', async (req, res) => {
    try {
        const snap = await db.ref('loginBanners').once('value');
        const raw = snap.exists() ? snap.val() : [];
        const list = (Array.isArray(raw) ? raw : Object.values(raw)).filter(Boolean).slice(0, 12).map(c => ({
            icon: String(c.icon || 'fa-solid fa-bullhorn').slice(0, 60),
            title: String(c.title || '').slice(0, 60),
            desc: String(c.desc || '').slice(0, 120),
            duration: Math.max(1, Math.min(120, Number(c.duration) || 5)),
            image: /^(https?:\/\/|data:image\/)/i.test(String(c.image || '')) ? String(c.image) : '',
            active: c.active !== false
        }));
        res.set('Cache-Control', 'public, max-age=30');
        res.json({ success: true, banners: list });
    } catch (e) {
        res.status(500).json({ success: false, banners: [] });
    }
});

// ============================================================
// 6. نقطة إرسال الإشعارات (/send)
// ============================================================
const API_KEY = process.env.API_KEY;

app.post('/send', async (req, res) => {
    const authHeader = req.headers['x-api-key'];
    if (!safeEqual(authHeader, API_KEY)) {
        return res.status(403).json({ error: 'غير مصرح' });
    }

    const { token, title, body } = req.body;
    if (!token) {
        return res.status(400).json({ error: 'التوكن مطلوب' });
    }

    try {
        const message = {
            notification: { title: title || 'كوفانت', body: body || 'لديك إشعار جديد' },
            token,
            android: ANDROID_PUSH,
            webpush: WEBPUSH_CONFIG
        };
        const response = await admin.messaging().send(message);
        res.json({ success: true, response });
    } catch (error) {
        console.error('❌ فشل:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============================================================
// 7. نقطة /register — إنشاء الحساب
// ============================================================
app.post('/register', authLimiter, async (req, res) => {
    try {
        const {
            firstName, fatherName, grandfatherName, familyName,
            birthDay, birthMonth, birthYear, address,
            phone, password, confirmPassword, referralCode,
            deviceId, deviceName, fingerprint, deviceAnalytics
        } = req.body || {};

        const fullName = [firstName, fatherName, grandfatherName, familyName].filter(Boolean).join(' ');
        if (!fullName) {
            return res.status(400).json({ success: false, error: 'يرجى إدخال الاسم الكامل' });
        }
        if (!phone || !isValidYemeniPhone(phone)) {
            return res.status(400).json({ success: false, error: 'رقم الجوال يجب أن يبدأ بـ 7 ويتكون من 9 أرقام' });
        }
        if (!password || password.length < 6) {
            return res.status(400).json({ success: false, error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
        }
        if (password !== confirmPassword) {
            return res.status(400).json({ success: false, error: 'كلمتا المرور غير متطابقتين' });
        }
        if (await isDeviceLinkedToOtherAccount(deviceId, phone)) {
            return res.status(409).json({ success: false, error: 'هذا الجهاز مرتبط بحساب آخر' });
        }

        const existingSnap = await db.ref('users/' + phone).once('value');
        if (existingSnap.exists()) {
            return res.status(409).json({ success: false, error: 'هذا الرقم مسجل مسبقاً' });
        }

        const accountNumber = await getUniqueAccountNumber();
        const hashedPassword = await hashPasswordStrong(password);
        const birthDate = (birthDay && birthMonth && birthYear)
            ? `${String(birthYear).padStart(4, '0')}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`
            : '';

        const newUser = {
            fullName,
            firstName: firstName || '', fatherName: fatherName || '',
            grandfatherName: grandfatherName || '', familyName: familyName || '',
            birthDate,
            address: address || '',
            phone,
            password: hashedPassword,
            referralCode: referralCode || '',
            accountNumber,
            balance: 0,
            createdAt: Date.now(),
            isActivated: false,
            maxDevices: 1,
            devices: deviceId ? {
                [deviceId]: {
                    deviceName: deviceName || 'جهاز غير معروف',
                    fingerprint: fingerprint || '',
                    addedAt: Date.now(),
                    lastUsed: Date.now(),
                    analytics: deviceAnalytics || {}
                }
            } : {},
            history: {}
        };

        await db.ref('users/' + phone).set(newUser);
        // 🔧 الإصلاح 4: مستخدم جديد غير مفعّل ⇒ usersCount +1 فقط
        await _updateStatsSummary({ usersDelta: 1 });
        if (deviceId) {
            await linkDeviceToUser(deviceId, phone);
        }

        await db.ref('notifications/999').push({
            id: Date.now() + '_new_user',
            title: 'مستخدم جديد',
            message: `قام المستخدم ${fullName} (${phone}) بالتسجيل`,
            type: 'admin',
            read: false,
            timestamp: Date.now()
        });
        sendPush('999', 'مستخدم جديد', `قام المستخدم ${fullName} (${phone}) بالتسجيل`, { persist: false });

        res.json({ success: true, accountNumber, fullName });
    } catch (error) {
        console.error('❌ /register فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// 8. نقطة /login — تسجيل الدخول مع JWT
// ============================================================
app.post('/login', authLimiter, async (req, res) => {
    try {
        const { phone, password, deviceId, deviceName, fingerprint, deviceAnalytics } = req.body || {};
        if (!phone || !password) {
            return res.status(400).json({ success: false, error: 'بيانات ناقصة' });
        }

        // ---- حساب الأدمن (999) ----
        if (phone === '999') {
            const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
            if (!ADMIN_PASSWORD || !safeEqual(password, ADMIN_PASSWORD)) {
                return res.status(401).json({ success: false, error: 'كلمة المرور غير صحيحة' });
            }
            const adminSnap = await db.ref('users/999').once('value');
            const adminData = adminSnap.val() || {
                fullName: 'ادارة كوفانت',
                phone: '999',
                accountNumber: '9999999999',
                balance: 0,
                isActivated: true,
                isAdmin: true
            };
            const { accessToken, refreshToken } = await issueSessionTokens('999', true);
            const firebaseToken = await createFirebaseAuthToken('999', true);
            return res.json({
                success: true,
                isAdmin: true,
                token: accessToken,
                refreshToken: refreshToken,
                firebaseToken: firebaseToken,
                user: { ...adminData, phone: '999' }
            });
        }

        // ---- مستخدم عادي ----
        const snap = await db.ref('users/' + phone).once('value');
        if (!snap.exists()) {
            return res.status(404).json({ success: false, error: 'رقم الجوال غير مسجل' });
        }
        const data = snap.val();

        const LOCKOUT_THRESHOLD = 5;
        const LOCKOUT_DURATION_MS = 15 * 60 * 1000;
        const lockUntil = Number(data.lockUntil || 0);
        if (lockUntil > Date.now()) {
            const minutesLeft = Math.ceil((lockUntil - Date.now()) / 60000);
            return res.status(429).json({
                success: false,
                error: `الحساب مقفل مؤقتاً بسبب محاولات دخول فاشلة متكررة. حاول مجدداً بعد ${minutesLeft} دقيقة`
            });
        }

        let passwordOk = false;
        let needsRehash = false;
        if (isBcryptHash(data.password)) {
            passwordOk = await verifyPasswordStrong(password, data.password);
        } else if (data.password === sha256Hex(password)) {
            passwordOk = true;
            needsRehash = true;
        } else if (data.password === password) {
            passwordOk = true;
            needsRehash = true;
        }

        if (!passwordOk) {
            const newFailCount = Number(data.failedAttempts || 0) + 1;
            const updates = { failedAttempts: newFailCount };
            if (newFailCount >= LOCKOUT_THRESHOLD) {
                updates.lockUntil = Date.now() + LOCKOUT_DURATION_MS;
                updates.failedAttempts = 0;
            }
            await db.ref('users/' + phone).update(updates);
            return res.status(401).json({ success: false, error: 'كلمة المرور غير صحيحة' });
        }

        const successUpdates = { failedAttempts: 0, lockUntil: 0 };
        if (needsRehash) {
            successUpdates.password = await hashPasswordStrong(password);
        }
        await db.ref('users/' + phone).update(successUpdates);

        if (data.isActivated === false) {
            return res.status(403).json({ success: false, error: 'حسابك غير مفعّل بعد. يرجى التفعيل عبر تلجرام' });
        }

        if (deviceId) {
            await db.ref('users/' + phone + '/devices/' + deviceId).update({
                deviceName: deviceName || 'جهاز غير معروف',
                fingerprint: fingerprint || '',
                lastUsed: Date.now(),
                analytics: deviceAnalytics || {}
            });
        }
        await linkDeviceToUser(deviceId, phone);

        const freshSnap = await db.ref('users/' + phone).once('value');
        const freshData = freshSnap.val();
        const {
            password: _userPw, pin: _userPin,
            refreshTokenHash: _rtHash, refreshTokenExpiry: _rtExp,
            failedAttempts: _fa, lockUntil: _lu,
            ...safeUser
        } = freshData;

        const { accessToken, refreshToken } = await issueSessionTokens(phone, false);
        const firebaseToken = await createFirebaseAuthToken(phone, false);

        sendPush(phone, 'تم تسجيل الدخول بنجاح', `رصيدك ${Number(freshData.balance || 0).toFixed(2)} YER`);

        res.json({
            success: true,
            token: accessToken,
            refreshToken: refreshToken,
            firebaseToken: firebaseToken,
            user: { ...safeUser, phone: phone }
        });
    } catch (error) {
        console.error('❌ /login فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// 9. نقطة /transfer — التحويل الداخلي (مع JWT)
// ============================================================
app.post('/change-phone-number', authLimiter, async (req, res) => {
    try {
        const decoded = verifyUserToken(req);
        if (!decoded) return res.status(401).json({ success: false, error: 'مطلوب تسجيل الدخول' });

        const oldPhone = decoded.phone;
        const { newPhone } = req.body || {};
        if (!newPhone || !isValidYemeniPhone(newPhone)) {
            return res.status(400).json({ success: false, error: 'رقم الجوال يجب أن يبدأ بـ 7 ويتكون من 9 أرقام' });
        }
        if (newPhone === oldPhone) return res.status(400).json({ success: false, error: 'هذا هو رقمك الحالي' });

        const [existingSnap, userSnap, notificationsSnap, sessionSnap, tokenSnap] = await Promise.all([
            db.ref('users/' + newPhone).once('value'),
            db.ref('users/' + oldPhone).once('value'),
            db.ref('notifications/' + oldPhone).once('value'),
            db.ref('sessions/' + oldPhone).once('value'),
            db.ref('user_tokens/' + oldPhone).once('value')
        ]);
        if (existingSnap.exists()) return res.status(409).json({ success: false, error: 'هذا الرقم مستخدم من قبل حساب آخر' });
        if (!userSnap.exists()) return res.status(404).json({ success: false, error: 'الحساب غير موجود' });

        const fullData = { ...userSnap.val(), phone: newPhone };
        const updates = {};
        updates['users/' + newPhone] = fullData;
        updates['users/' + oldPhone] = null;
        if (notificationsSnap.exists()) {
            updates['notifications/' + newPhone] = notificationsSnap.val();
            updates['notifications/' + oldPhone] = null;
        }
        if (sessionSnap.exists()) {
            updates['sessions/' + newPhone] = sessionSnap.val();
            updates['sessions/' + oldPhone] = null;
        }
        if (tokenSnap.exists()) {
            updates['user_tokens/' + newPhone] = tokenSnap.val();
            updates['user_tokens/' + oldPhone] = null;
        }
        for (const deviceId of Object.keys(fullData.devices || {})) {
            updates['device_lookup/' + sha256Hex(String(deviceId))] = newPhone;
        }
        const auditKey = db.ref('audit_log').push().key;
        updates['audit_log/' + auditKey] = {
            action: 'change_phone_number', oldPhone, newPhone,
            migrated: ['users', 'notifications', 'sessions', 'user_tokens', 'device_lookup'],
            performedAt: Date.now(), performedBy: oldPhone
        };

        // كل مسارات الترحيل تُكتب في تحديث Firebase ذري واحد.
        await db.ref().update(updates);
        res.json({ success: true, oldPhone, newPhone });
    } catch (error) {
        console.error('❌ /change-phone-number فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/change-password', authLimiter, async (req, res) => {
    try {
        const decoded = verifyUserToken(req);
        if (!decoded) return res.status(401).json({ success: false, error: 'مطلوب تسجيل الدخول' });

        const { oldPassword, newPassword } = req.body || {};
        if (!oldPassword || !newPassword || newPassword.length < 6) {
            return res.status(400).json({ success: false, error: 'بيانات غير صحيحة' });
        }

        const phone = decoded.phone;
        const snap = await db.ref('users/' + phone).once('value');
        if (!snap.exists()) return res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
        const user = snap.val();

        const matches = isBcryptHash(user.password)
            ? await verifyPasswordStrong(oldPassword, user.password)
            : (user.password === sha256Hex(oldPassword) || user.password === oldPassword);

        if (!matches) {
            return res.status(401).json({ success: false, error: 'كلمة المرور الحالية غير صحيحة' });
        }

        const newHash = await hashPasswordStrong(newPassword);
        await db.ref('users/' + phone).update({ password: newHash });

        res.json({ success: true });
    } catch (error) {
        console.error('❌ /change-password فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/change-pin', authLimiter, async (req, res) => {
    try {
        const decoded = verifyUserToken(req);
        if (!decoded) return res.status(401).json({ success: false, error: 'مطلوب تسجيل الدخول' });

        const { oldPin, newPin } = req.body || {};
        if (!newPin || !/^\d{4}$/.test(newPin)) {
            return res.status(400).json({ success: false, error: 'PIN يجب أن يكون 4 أرقام' });
        }

        const phone = decoded.phone;
        const snap = await db.ref('users/' + phone).once('value');
        if (!snap.exists()) return res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
        const user = snap.val();

        if (user.pin) {
            const matches = isBcryptHash(user.pin)
                ? await verifyPasswordStrong(oldPin || '', user.pin)
                : (user.pin === sha256Hex(oldPin || '') || user.pin === oldPin);
            if (!matches) {
                return res.status(401).json({ success: false, error: 'PIN الحالي غير صحيح' });
            }
        }

        const newHash = await hashPasswordStrong(newPin);
        await db.ref('users/' + phone).update({ pin: newHash });

        res.json({ success: true });
    } catch (error) {
        console.error('❌ /change-pin فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/lookup-account', authLimiter, async (req, res) => {
    try {
        const decoded = verifyUserToken(req);
        if (!decoded) return res.status(401).json({ success: false, error: 'مطلوب تسجيل الدخول' });

        const { accountNumber } = req.body || {};
        if (!accountNumber) {
            return res.status(400).json({ success: false, error: 'رقم الحساب مطلوب' });
        }

        const snap = await db.ref('users').orderByChild('accountNumber').equalTo(String(accountNumber)).once('value');
        if (!snap.exists()) {
            return res.status(404).json({ success: false, error: 'الحساب غير موجود' });
        }

        let result = null;
        snap.forEach(child => {
            const v = child.val();
            result = { fullName: v.fullName || 'مستخدم غير معروف', accountNumber: v.accountNumber };
        });

        res.json({ success: true, ...result });
    } catch (error) {
        console.error('❌ /lookup-account فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});


app.post('/transfer', async (req, res) => {
    let phone = null;
    let amt = 0;
    let idempotency = null;
    let auditRef = null;
    let recipientPhone = null;
    let debitApplied = false;
    let creditApplied = false;

    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, error: 'مطلوب توكن' });
        }

        try {
            const decoded = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
            phone = decoded.phone;
        } catch (e) {
            return res.status(401).json({ success: false, error: 'توكن غير صالح أو منتهي' });
        }

        const { recipientAccount, amount, note } = req.body || {};
        const operationId = getOperationId(req);
        if (!phone || !recipientAccount) {
            return res.status(400).json({ success: false, error: 'بيانات ناقصة' });
        }
        amt = Number(amount);
        if (!amt || amt <= 0 || !isFinite(amt)) {
            return res.status(400).json({ success: false, error: 'مبلغ غير صحيح' });
        }
        if (amt < 100) {
            return res.status(400).json({ success: false, error: 'الحد الأدنى للتحويل هو 100 ريال' });
        }

        // 1) نقرأ المرسل والمستلم ونتحقق منهما قبل أي خصم.
        const senderSnap = await db.ref('users/' + phone).once('value');
        if (!senderSnap.exists()) {
            return res.status(404).json({ success: false, error: 'الحساب غير موجود' });
        }
        const sender = senderSnap.val();
        if (sender.isActivated !== true) {
            return res.status(403).json({ success: false, error: 'حساب المرسل غير مفعّل' });
        }

        const recSnap = await db.ref('users').orderByChild('accountNumber').equalTo(String(recipientAccount)).once('value');
        if (!recSnap.exists()) {
            return res.status(404).json({ success: false, error: 'رقم حساب المستلم غير موجود' });
        }
        let recipient = null;
        recSnap.forEach(child => { recipientPhone = child.key; recipient = child.val(); });
        if (!recipientPhone || recipientPhone === phone) {
            return res.status(400).json({ success: false, error: 'لا يمكنك التحويل لنفسك' });
        }
        if (!recipient || recipient.isActivated !== true) {
            return res.status(403).json({ success: false, error: 'حساب المستلم غير مفعّل' });
        }

        const initialSenderBalance = Number(sender.balance) || 0;
        if (phone !== '999' && initialSenderBalance < amt) {
            return res.status(400).json({ success: false, error: 'الرصيد غير كافي' });
        }

        idempotency = await claimIdempotency(phone, operationId);
        if (!idempotency.claimed) return res.status(idempotency.status).json(idempotency.response);

        const senderName = sender.fullName || sender.name || phone;
        const recipientName = recipient.fullName || recipient.name || recipientPhone;
        auditRef = db.ref('all_transactions').push();
        await auditRef.set({
            operationId: operationId || null,
            type: phone === '999' ? 'admin_transfer' : 'transfer',
            from: phone, to: recipientPhone,
            fromName: senderName, toName: recipientName,
            amount: amt, note: note || '', timestamp: Date.now(),
            status: 'validated'
        });

        // 2) الخصم الذري بعد اكتمال كل عمليات التحقق.
        let newSenderBalance = initialSenderBalance;
        if (phone !== '999') {
            const senderBalanceTx = await transactionWithWarmValue(
                db.ref('users/' + phone + '/balance'), current => {
                const currentBalance = Number(current) || 0;
                return currentBalance < amt ? undefined : currentBalance - amt;
            }, 'خصم رصيد التحويل');
            if (!senderBalanceTx.committed) {
                await auditRef.update({ status: 'rejected_insufficient_balance', updatedAt: Date.now() });
                return res.status(400).json({ success: false, error: 'الرصيد غير كافي' });
            }
            debitApplied = true;
            newSenderBalance = Number(senderBalanceTx.snapshot.val()) || 0;
            await auditRef.update({ status: 'debited', senderBalanceAfter: newSenderBalance, updatedAt: Date.now() });
        }

        // 3) الإضافة الذرية للمستلم.
        const recipientBalanceTx = await transactionWithWarmValue(
            db.ref('users/' + recipientPhone + '/balance'),
            current => (Number(current) || 0) + amt,
            'إضافة رصيد التحويل'
        );
        if (!recipientBalanceTx.committed) throw new Error('فشل إضافة الرصيد للمستلم');
        creditApplied = true;
        // 🔧 الإصلاح 4: التحويل بين مستخدمين = نقل (المجموع ثابت). أما التحويل الإداري من 999 فلا يُخصم من أحد
        // (لا رصيد مسجَّل للأدمن) فيزيد مجموع الأرصدة بمبلغ التحويل
        if (phone === '999') await _updateStatsSummary({ balanceDelta: amt });
        const newRecipientBalance = Number(recipientBalanceTx.snapshot.val()) || 0;
        await auditRef.update({ status: 'credited', receiverBalanceAfter: newRecipientBalance, updatedAt: Date.now() });

        // 4) السجل المالي يتم بعد نجاح الرصيدين مع حالة صريحة.
        const ts = Date.now();
        const updates = {};
        const senderHistoryKey = db.ref('users/' + phone + '/history').push().key;
        const recipientHistoryKey = db.ref('users/' + recipientPhone + '/history').push().key;
        updates['users/' + phone + '/history/' + senderHistoryKey] = {
            type: 'out', amount: amt,
            title: phone === '999' ? `تحويل إداري إلى ${recipientName}` : `تحويل إلى ${recipientName}`,
            date: new Date(ts).toLocaleString('ar-YE'), timestamp: ts, balanceAfter: newSenderBalance
        };
        updates['users/' + recipientPhone + '/history/' + recipientHistoryKey] = {
            type: 'in', amount: amt,
            title: phone === '999' ? `استلام تحويل إداري من ${senderName}` : `تحويل من ${senderName}`,
            date: new Date(ts).toLocaleString('ar-YE'), timestamp: ts, balanceAfter: newRecipientBalance
        };
        await db.ref().update(updates);
        await auditRef.update({ status: 'completed', completedAt: ts, updatedAt: ts });

        const fmt = (n) => Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        sendPush(recipientPhone, `أودع / ${senderName} لحسابك ${fmt(amt)} YER`, `رصيدك ${fmt(newRecipientBalance)} YER`);
        sendPush(phone, `تم تحويل ${fmt(amt)} لحساب ${recipientName}`, `رصيدك ${fmt(newSenderBalance)} YER`);
        queuePendingNotification(recipientPhone, {
            type: 'transfer_in', title: 'وصلك تحويل',
            body: `تم إيداع ${fmt(amt)} YER من ${senderName}`, amount: amt
        }).catch(error => console.error('❌ pending transfer notification:', error.message));
        queueSmsDelivery(recipientPhone,
            `كوفانت: وصلك تحويل\nالمبلغ: ${fmt(amt)} YER\nمن: ${senderName}\nرصيدك الجديد: ${fmt(newRecipientBalance)} YER`,
            { source: 'online_transfer', txId: auditRef.key }
        ).catch(error => console.error('❌ SMS transfer queue:', error.message));
        sendPush('999', '💸 تحويل جديد', `${senderName} حوّل ${fmt(amt)} YER إلى ${recipientName}`);

        const transferResponse = {
            success: true,
            newBalance: newSenderBalance,
            recipient: { phone: recipientPhone, fullName: recipientName, accountNumber: recipient.accountNumber }
        };
        await completeIdempotency(idempotency, transferResponse);
        return res.json(transferResponse);
    } catch (error) {
        console.error('❌ /transfer فشل:', error);
        // استرداد فوري إذا فشل أي جزء بعد الخصم.
        try {
            if (creditApplied && recipientPhone) {
                await transactionWithWarmValue(
                    db.ref('users/' + recipientPhone + '/balance'),
                    current => (Number(current) || 0) - amt,
                    'rollback رصيد المستلم'
                );
                // 🔧 الإصلاح 4: إلغاء إضافة تحويل إداري سبق احتسابها
                if (phone === '999') await _updateStatsSummary({ balanceDelta: -amt });
            }
            if (debitApplied && phone && phone !== '999') {
                await transactionWithWarmValue(
                    db.ref('users/' + phone + '/balance'),
                    current => (Number(current) || 0) + amt,
                    'rollback رصيد المرسل'
                );
            }
            if (auditRef) await auditRef.update({ status: 'rolled_back', rollbackReason: error.message || 'unknown', updatedAt: Date.now() });
        } catch (rollbackError) {
            console.error('❌ فشل استرداد التحويل:', rollbackError);
            if (auditRef) await auditRef.update({ status: 'rollback_failed', rollbackError: rollbackError.message || 'unknown', updatedAt: Date.now() }).catch(() => {});
        }
        res.status(500).json({ success: false, error: 'فشل تنفيذ التحويل وتمت محاولة استرداد الرصيد' });
    }
});

// ============================================================
// 10. نقطة /api/purchase-package — شراء باقة (مع JWT)
// ============================================================

// ============================================================
// ✅ [إصلاح 3] دالة موحدة لكتابة عملية بيع الكروت (تُستدعى من /api/purchase-package و /sms/purchase-package)
// تكتب كل شيء في عملية Firebase واحدة (db.ref().update) = ذرّية: إمّا تنجح كلها أو لا شيء منها:
//   1) نقل الكرت من kova_store/{باقة}/cards إلى .../sold
//   2) إنقاص kova_store_public/{باقة}/availableCount (ServerValue.increment: آمن مع الطلبات المتزامنة)
//   3) سجل users/{المشتري}/history (فيه الأكواد) + lastTransaction
//   4) إشعار notifications/{المشتري}
// حجز الكروت وخصم الرصيد والخزينة تبقى في المسارين كما هي (لم تُمسّ).
// ============================================================
async function _sellCardToUser(o) {
    const { buyerPhone, recipient, packageId, packageData, reserved, price, totalAmount, newBalance, ts, dateStr, via } = o;
    const isSms = via === 'sms';
    const pkgName = packageData.name || packageId;
    const count = reserved.length;
    const codes = reserved.map(item => item.code);
    const updates = {};
    const soldKeys = [];
    reserved.forEach(item => {
        const soldKey = db.ref('kova_store/' + packageId + '/sold').push().key;
        updates['kova_store/' + packageId + '/cards/' + item.key] = null;
        const rec = { code: item.code, customerId: recipient, timestamp: ts, date: dateStr, package: pkgName, price };
        if (isSms) { rec.soldVia = 'sms_offline'; rec.performedBy = '999'; }
        updates['kova_store/' + packageId + '/sold/' + soldKey] = rec;
        soldKeys.push(soldKey);
    });
    // العدّاد العام الذي يقرأه التطبيق (بدون أي أكواد)
    updates['kova_store_public/' + packageId + '/availableCount'] = admin.database.ServerValue.increment(-count);
    // 🔧 الإصلاح 4-هـ (ضمن نفس التحديث الذري):
    //   • عدّاد المباع للأدمن فقط (admin_sales — قراءة أدمن، لا يراه المستخدمون) بدل kova_store_public.
    //     يتطلب تشغيل backfillSalesData() مرة بعد النشر لتهيئة القيم التاريخية.
    updates['admin_sales/' + packageId + '/soldCount'] = admin.database.ServerValue.increment(count);
    //   • تجميع المبيعات اليومي لرسوم تحليل المبيعات بدون قراءة سجلات البيع (يوم العمل بتوقيت اليمن UTC+3)
    const dayKey = new Date(ts + 3 * 3600 * 1000).toISOString().slice(0, 10);
    updates['stats/sales_daily/' + packageId + '/' + dayKey + '/count'] = admin.database.ServerValue.increment(count);
    updates['stats/sales_daily/' + packageId + '/' + dayKey + '/amount'] = admin.database.ServerValue.increment(totalAmount);
    updates['stats/sales_daily_total/' + dayKey + '/count'] = admin.database.ServerValue.increment(count);
    updates['stats/sales_daily_total/' + dayKey + '/amount'] = admin.database.ServerValue.increment(totalAmount);
    updates['stats/sales_by_pkg/' + packageId + '/totalCount'] = admin.database.ServerValue.increment(count);
    updates['stats/sales_by_pkg/' + packageId + '/totalAmount'] = admin.database.ServerValue.increment(totalAmount);
    const historyKey = db.ref('users/' + buyerPhone + '/history').push().key;
    updates['users/' + buyerPhone + '/history/' + historyKey] = {
        type: 'out', amount: totalAmount,
        title: isSms ? `شراء ${count} كرت من ${pkgName} (SMS)` : `شراء ${count} كرت من باقة ${pkgName}`,
        date: dateStr, timestamp: ts, balanceAfter: newBalance,
        cardCode: codes.join(', '), codes: codes,
        // 🔧 الإصلاح 4-هـ: المستلم الفعلي والباقة مباشرة في السجل (تحليل الوكلاء/المستخدمين بلا قراءة سجلات البيع)
        recipient: recipient || buyerPhone, packageId: packageId, packageName: pkgName
    };
    updates['users/' + buyerPhone + '/lastTransaction'] = {
        type: 'out', amount: totalAmount, timestamp: ts, balanceAfter: newBalance,
        description: isSms ? `شراء كروت ${pkgName} (SMS)` : `شراء كروت ${pkgName}`
    };
    // إشعار المشتري يُكتب مع العملية نفسها ليراه عند عودته للإنترنت (مسار SMS لم يكن يكتبه سابقاً)
    updates['notifications/' + buyerPhone + '/' + ts + '_purchase'] = {
        id: ts + '_purchase',
        title: isSms ? '🛒 شراء باقة (SMS)' : '🛒 شراء باقة',
        message: isSms
            ? `تم شراء ${count} كرت من باقة ${pkgName} عبر SMS وخصم ${fmtMoney(totalAmount)} YER. الأكواد في سجل عملياتك.`
            : `تم خصم ${fmtMoney(totalAmount)} YER مقابل شراء ${count} كرت من باقة ${pkgName}.`,
        type: 'purchase', timestamp: ts, isRead: false
    };
    await db.ref().update(updates);
    return { codes, historyKey, soldKeys, buyerPhone, packageId, dayKey, count, totalAmount, ts };
}


// يعكس كل آثار البيع المكتوبة بواسطة _sellCardToUser في تحديث Firebase متعدد المسارات واحد.
function _buildCardSaleRollbackUpdates(o) {
    const { saleWrite, buyerPhone, packageId, reserved, treasuryMovement, adminNotificationPath } = o;
    const updates = {};
    const pkg = packageId || (saleWrite && saleWrite.packageId);
    if (saleWrite) {
        updates['users/' + buyerPhone + '/history/' + saleWrite.historyKey] = null;
        updates['notifications/' + buyerPhone + '/' + saleWrite.ts + '_purchase'] = null;
        (saleWrite.soldKeys || []).forEach(key => { updates['kova_store/' + pkg + '/sold/' + key] = null; });
        const inc = d => admin.database.ServerValue.increment(d);
        // 🔧 v61: إعادة عداد المخزون العام ضمن نفس rollback متعدد المسارات.
        updates['kova_store_public/' + pkg + '/availableCount'] = inc(saleWrite.count);
        updates['admin_sales/' + pkg + '/soldCount'] = inc(-saleWrite.count);
        updates['stats/sales_daily/' + pkg + '/' + saleWrite.dayKey + '/count'] = inc(-saleWrite.count);
        updates['stats/sales_daily/' + pkg + '/' + saleWrite.dayKey + '/amount'] = inc(-saleWrite.totalAmount);
        updates['stats/sales_daily_total/' + saleWrite.dayKey + '/count'] = inc(-saleWrite.count);
        updates['stats/sales_daily_total/' + saleWrite.dayKey + '/amount'] = inc(-saleWrite.totalAmount);
        updates['stats/sales_by_pkg/' + pkg + '/totalCount'] = inc(-saleWrite.count);
        updates['stats/sales_by_pkg/' + pkg + '/totalAmount'] = inc(-saleWrite.totalAmount);
    }
    (reserved || []).forEach(item => { updates['kova_store/' + pkg + '/cards/' + item.key] = item.original; });
    if (adminNotificationPath) updates[adminNotificationPath] = null;
    if (treasuryMovement && treasuryMovement.transactionKey && treasuryMovement.ledgerKey) {
        updates['treasury/transactions/' + treasuryMovement.transactionKey] = null;
        updates['full_ledger/' + treasuryMovement.ledgerKey] = null;
        updates['treasury/summary/balance'] = admin.database.ServerValue.increment(-Math.abs(Number(treasuryMovement.amount) || 0));
        updates['treasury/summary/updatedAt'] = Date.now();
        updates['stats/treasury/totalSales'] = admin.database.ServerValue.increment(-Math.abs(Number(treasuryMovement.amount) || 0));
        updates['stats/treasury/updatedAt'] = Date.now();
    }
    return updates;
}

app.post('/api/purchase-package', async (req, res) => {
    let phone = null;
    let idempotency = null;
    let auditRef = null;
    const reserved = [];
    let balanceDebited = false;
    let totalAmount = 0;
    let saleWrite = null, treasuryMovement = null, adminNotificationPath = null;

    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, error: 'مطلوب توكن' });
        }
        try {
            phone = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET).phone;
        } catch (e) {
            return res.status(401).json({ success: false, error: 'توكن غير صالح أو منتهي' });
        }

        const { packageId, count, customerId, targetPhone: requestedTargetPhone } = req.body || {};
        const targetPhone = String(requestedTargetPhone || customerId || phone);
        const operationId = getOperationId(req);
        const reservationId = operationId || ('purchase-' + crypto.randomBytes(12).toString('hex'));
        const requestedCount = Number(count);
        if (!packageId || !Number.isInteger(requestedCount) || requestedCount < 1 || requestedCount > 100) {
            return res.status(400).json({ success: false, error: 'بيانات ناقصة أو عدد غير صحيح' });
        }

        const userSnap = await db.ref('users/' + phone).once('value');
        if (!userSnap.exists()) return res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
        const userData = userSnap.val();
        if (userData.isActivated !== true) return res.status(403).json({ success: false, error: 'الحساب غير مفعّل' });

        const packageSnap = await db.ref('kova_store/' + packageId).once('value');
        if (!packageSnap.exists()) return res.status(404).json({ success: false, error: 'الباقة غير موجودة' });
        const packageData = packageSnap.val();
        const price = Number(packageData.sellPrice) || 0;
        totalAmount = price * requestedCount;
        if (!price || !isFinite(totalAmount)) return res.status(400).json({ success: false, error: 'سعر الباقة غير صحيح' });

        idempotency = await claimIdempotency(phone, operationId);
        if (!idempotency.claimed) return res.status(idempotency.status).json(idempotency.response);
        auditRef = db.ref('all_transactions').push();
        await auditRef.set({
            operationId: operationId || null, type: 'purchase', from: phone,
            packageId, count: requestedCount, amount: totalAmount,
            timestamp: Date.now(), status: 'validated'
        });

        // حجز كل كرت بمعاملة مستقلة؛ لا يمكن لطلبين متزامنين حجز نفس الكرت.
        const cardsRef = db.ref('kova_store/' + packageId + '/cards');
        const cardsSnap = await cardsRef.once('value');
        const cards = cardsSnap.val() || {};
        for (const key of Object.keys(cards).slice(0, requestedCount)) {
            const cardRef = cardsRef.child(key);
            const original = cards[key];

            let reservationTx = null;
            for (let attempt = 0; attempt < 3; attempt++) {
                // إيقاظ اتصال Firebase بعد Cold Start قبل بدء transaction.
                // نحتفظ بالقيمة لأن callback قد يُستدعى محلياً أولاً بقيمة null.
                const warmSnapshot = await cardRef.once('value');
                const warmedValue = warmSnapshot.val();
                console.log('🔍 مسار الكرت:', cardRef.toString());
                console.log('🔍 نتيجة once:', warmSnapshot.exists(), warmedValue);
                console.log('🔍 محاولة حجز', key, 'المحاولة', attempt + 1);
                reservationTx = await cardRef.transaction(current => {
                    // لا نلغي المعاملة بسبب null المحلي الأول؛ عند وصول القيمة
                    // الفعلية من الخادم سيُعاد تشغيل callback بالقيمة الحالية.
                    const candidate = current === null || current === undefined ? warmedValue : current;
                    if (!candidate) return;
                    if (candidate._kovaReservation && candidate._kovaReservation !== reservationId) return;
                    if (candidate._kovaReservation === reservationId) return candidate;
                    if (typeof candidate === 'string') {
                        return { code: candidate, _kovaReservation: reservationId, reservedAt: Date.now() };
                    }
                    return { ...candidate, _kovaReservation: reservationId, reservedAt: Date.now() };
                });

                console.log('🔍 نتيجة transaction:', reservationTx.committed);
                console.log('🔍 القيمة:', reservationTx.snapshot.val());

                if (reservationTx.committed) break;
                if (attempt < 2) {
                    await new Promise(resolve => setTimeout(resolve, 200));
                }
            }

            if (!reservationTx || !reservationTx.committed) break;
            const current = reservationTx.snapshot.val();
            reserved.push({ key, original, code: typeof current === 'string' ? current : (current.code || current.cardCode || current.value || key) });
        }
        if (reserved.length !== requestedCount) {
            const restore = {};
            reserved.forEach(item => { restore['kova_store/' + packageId + '/cards/' + item.key] = item.original; });
            if (Object.keys(restore).length) await db.ref().update(restore);
            await auditRef.update({ status: 'rejected_stock', updatedAt: Date.now() });
            return res.status(400).json({ success: false, error: 'عدد الكروت المطلوب غير متوفر' });
        }
        await auditRef.update({ status: 'reserved', reservedCount: reserved.length, updatedAt: Date.now() });

        // الخصم المالي ذري، ولا يُقبل إذا تغيّر الرصيد أثناء العملية.
        const balanceTx = await transactionWithWarmValue(
            db.ref('users/' + phone + '/balance'), current => {
            const balance = Number(current) || 0;
            return balance < totalAmount ? undefined : balance - totalAmount;
        }, 'خصم رصيد الشراء');
        if (!balanceTx.committed) throw new Error('الرصيد غير كافٍ');
        balanceDebited = true;
        // 🔧 الإصلاح 4: شراء كرت يخصم من رصيد المشتري (يذهب للخزينة) ⇒ totalBalance -totalAmount
        await _updateStatsSummary({ balanceDelta: -totalAmount });
        const newBalance = Number(balanceTx.snapshot.val()) || 0;
        const ts = Date.now();
        const dateStr = new Date(ts).toLocaleString('ar-YE');
        const codes = reserved.map(item => item.code);
        // ✅ [إصلاح 3] كتابة البيع كاملة (كروت + عدّاد عام + سجل + إشعار) عبر الدالة الموحدة في عملية ذرّية واحدة
        saleWrite = await _sellCardToUser({ buyerPhone: phone, recipient: targetPhone, packageId, packageData, reserved, price, totalAmount, newBalance, ts, dateStr, via: 'app' });
        // بيع الكرت يزيد النقد/الخزينة بقيمة سعر البيع.
        treasuryMovement = await recordTreasuryMovement(totalAmount, {
            type: 'card_sale', packageId, count: requestedCount,
            details: `بيع ${requestedCount} كرت من باقة ${packageData.name || packageId}`,
            performedBy: userData.fullName || phone
        });
        treasuryMovement.amount = totalAmount;
        await auditRef.update({ status: 'completed', balanceAfter: newBalance, completedAt: ts, updatedAt: ts });

        const adminMessage = `${userData.fullName || phone} اشترى ${requestedCount} كرت من باقة ${packageData.name || packageId} بمبلغ ${fmtMoney(totalAmount)} YER`;
        const adminNotifRef = db.ref('notifications/999').push();
        adminNotificationPath = 'notifications/999/' + adminNotifRef.key;
        await adminNotifRef.set({
            id: ts + '_admin_purchase', title: '🛒 شراء باقة', message: adminMessage,
            type: 'admin', timestamp: ts, isRead: false
        });
        const buyerCodes = codes.join('، ');
        const buyerTargetText = targetPhone === String(phone) ? '' : ` للعميل ${targetPhone}`;
        await Promise.all([
            Promise.resolve().then(() => sendPush(phone, 'تمت عملية شراء الباقة', `تم شراء ${requestedCount} كرت${buyerTargetText}. الأكواد: ${buyerCodes}. رصيدك ${fmtMoney(newBalance)} YER`, { persist: false })),
            Promise.resolve().then(() => sendPush('999', '🛒 شراء باقة', adminMessage, { persist: false }))
        ]);
        let whatsappResult = null;
        if (targetPhone !== String(phone)) {
            const customerSmsBody = `كوفانت — بطاقة إنترنت\n` +
                `الباقة: ${packageData.name || packageId}\n` +
                `السعر: ${fmtMoney(price)} YER\n` +
                `الأكواد:\n${codes.map((code, index) => (index + 1) + '. ' + code).join('\n')}\n` +
                `من: ${userData.fullName || phone}`;
            // إرسال الكرت بالواتساب بدون SMS وبدون انتظار: الشراء لا يتأخر ولا يتأثر بحالة الواتساب،
            // والنتيجة (نجاح/فشل) تُسجَّل في whatsapp_log.
            whatsappResult = { queued: true };
            sendCardViaWhatsApp(targetPhone, customerSmsBody, {
                source: 'online_purchase_customer', txId: auditRef.key
            }).catch(error => console.error('❌ WhatsApp customer card:', error.message));
            queuePendingNotification(targetPhone, {
                type: 'card_received', title: 'وصلك كرت',
                body: `تم شراء ${requestedCount} كرت من ${packageData.name || packageId}`,
                packageId, codes
            }).catch(error => console.error('❌ pending card notification:', error.message));
        }
        const buyerSmsBody = `كوفانت — تأكيد شراء\n` +
            `تم شراء ${requestedCount} كرت${buyerTargetText}\n` +
            `الأكواد: ${buyerCodes}\n` +
            `رصيدك: ${fmtMoney(newBalance)} YER`;
        queueSmsDelivery(phone, buyerSmsBody, {
            source: 'online_purchase_buyer', txId: auditRef.key
        }).catch(error => console.error('❌ SMS buyer queue:', error.message));

        const purchaseResponse = {
            success: true, newBalance, codes,
            message: `تم شراء ${requestedCount} كرت بنجاح`
        };
        if (whatsappResult) {
            purchaseResponse.whatsapp = { queued: true };
        }
        await completeIdempotency(idempotency, purchaseResponse);
        return res.json(purchaseResponse);
    } catch (error) {
        console.error('❌ Purchase package error:', error);
        try {
            const packageId = req.body?.packageId;
            const restore = _buildCardSaleRollbackUpdates({ saleWrite, buyerPhone: phone, packageId, reserved, treasuryMovement, adminNotificationPath });
            if (Object.keys(restore).length) await db.ref().update(restore);
            if (balanceDebited && phone) {
                await transactionWithWarmValue(
                    db.ref('users/' + phone + '/balance'),
                    current => (Number(current) || 0) + totalAmount,
                    'rollback رصيد الشراء'
                );
                // 🔧 الإصلاح 4: استرداد الرصيد يعيد ما خُصم من totalBalance
                await _updateStatsSummary({ balanceDelta: totalAmount });
            }
            if (auditRef) await auditRef.update({ status: 'rolled_back', rollbackReason: error.message || 'unknown', updatedAt: Date.now() });
        } catch (rollbackError) {
            console.error('❌ فشل استرداد شراء الباقة:', rollbackError);
            if (auditRef) await auditRef.update({ status: 'rollback_failed', rollbackError: rollbackError.message || 'unknown', updatedAt: Date.now() }).catch(() => {});
        }
        const message = error.message === 'الرصيد غير كافٍ' ? error.message : 'حدث خطأ داخلي وتمت محاولة استرداد العملية';
        return res.status(error.message === 'الرصيد غير كافٍ' ? 400 : 500).json({ success: false, error: message });
    }
});

// ============================================================
// 11. نقاط /admin/* — إدارة الأدمن (تدعم JWT + adminPassword)
// ============================================================

async function verifyAdmin(req) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        try {
            const token = authHeader.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            if (decoded.isAdmin || decoded.phone === '999') {
                return { isAdmin: true, phone: '999' };
            }
        } catch (e) {}
    }

    const { adminPhone, adminPassword } = req.body || {};
    if (adminPhone === '999' && safeEqual(adminPassword, process.env.ADMIN_PASSWORD)) {
        return { isAdmin: true, phone: '999' };
    }

    return { isAdmin: false };
}

function verifyUserToken(req) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null;
    }
    try {
        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        return decoded && decoded.phone ? decoded : null;
    } catch (e) {
        return null;
    }
}

async function queuePendingNotification(phone, notification) {
    if (!phone) return;
    await db.ref(`users/${phone}/pending_notifications`).push({
        ...notification,
        timestamp: notification.timestamp || Date.now()
    });
}

// كرت الزبون وتأكيد المشتري بعد الشراء يُرسلان بالواتساب حصراً — لا يوجد أي رجوع تلقائي إلى SMS.
// عند فشل الواتساب (غير متصل/رقم غير مسجّل/تعذّر الإرسال) يُسجَّل الخطأ في whatsapp_log ويُرجَع {ok:false}.
const WA_CARD_SOURCES = new Set(['online_purchase_customer', 'online_purchase_buyer']);
const WA_CONNECT_WAIT_MS = 12000;   // انتظار اتصال الواتساب بعد استيقاظ Render من النوم
const WA_SEND_TIMEOUT_MS = 15000;   // أقصى انتظار لإرسال رسالة واحدة قبل إرجاع الاستجابة

async function sendCardViaWhatsApp(phone, message, meta = {}) {
    const logRef = db.ref('whatsapp_log').push();
    const base = { to: String(phone), source: meta.source || null, txId: meta.txId || null, createdAt: Date.now() };
    const fail = async (error, status = 'failed') => {
        const msg = String((error && error.message) || error || 'فشل الإرسال').slice(0, 200);
        console.error('⚠️ WhatsApp card send failed:', msg);
        await logRef.set({
            ...base, status, error: msg, waStatus: wa.status,
            waError: wa.lastError ? String(wa.lastError).slice(0, 200) : null
        }).catch(() => {});
        return { ok: false, channel: 'whatsapp', logId: logRef.key, error: msg, pending: status === 'pending' };
    };
    let sendP = null;
    try {
        await waEnsureConnected(WA_CONNECT_WAIT_MS);
        if (wa.status !== 'open') throw new Error('الواتساب غير متصل');
        sendP = waSendText(phone, message);
        let timer;
        const timeout = new Promise((_, reject) => {
            timer = setTimeout(() => reject(Object.assign(new Error('تأخر إرسال الواتساب'), { timedOut: true })), WA_SEND_TIMEOUT_MS);
        });
        let jid;
        try { jid = await Promise.race([sendP, timeout]); } finally { clearTimeout(timer); }
        await logRef.set({ ...base, status: 'sent', jid });
        return { ok: true, channel: 'whatsapp', logId: logRef.key, jid };
    } catch (e) {
        if (e && e.timedOut && sendP) {
            // قد تنجح الرسالة لاحقاً: نحدّث السجل عند انتهاء المحاولة
            sendP.then(jid => logRef.update({ status: 'sent', jid, error: null }))
                 .catch(err => logRef.update({ status: 'failed', error: String((err && err.message) || err).slice(0, 200) }))
                 .catch(() => {});
            return fail(e, 'pending');
        }
        return fail(e);
    }
}

async function queueSmsDelivery(phone, message, meta = {}) {
    if (!phone || !message) return null;
    if (WA_CARD_SOURCES.has(meta.source)) {
        const result = await sendCardViaWhatsApp(phone, message, meta);
        return result.logId;   // لا رجوع إلى SMS أبداً لرسائل الكروت
    }
    const ref = db.ref('sms_queue').push();
    await ref.set({
        to: String(phone),
        message: String(message),
        from: 'COVANT',
        status: 'pending',
        attempts: 0,
        source: meta.source || 'server',
        txId: meta.txId || null,
        createdAt: Date.now()
    });
    return ref.key;
}

app.get('/user/pending-notifications', async (req, res) => {
    const decoded = verifyUserToken(req);
    if (!decoded) return res.status(401).json({ success: false, error: 'مطلوب توكن' });
    try {
        const ref = db.ref(`users/${decoded.phone}/pending_notifications`);
        const snap = await ref.once('value');
        const notifications = snap.val() || {};
        if (Object.keys(notifications).length) await ref.remove();
        return res.json({ success: true, notifications: Object.values(notifications) });
    } catch (error) {
        console.error('❌ /user/pending-notifications:', error);
        return res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/admin/cleanup-sms-queue', async (req, res) => {
    const adminCheck = await verifyAdmin(req);
    if (!adminCheck.isAdmin) return res.status(401).json({ success: false, error: 'غير مصرح' });
    try {
        const snap = await db.ref('sms_queue').once('value');
        const items = snap.val() || {};
        const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
        const updates = {};
        Object.keys(items).forEach(key => {
            const item = items[key] || {};
            const timestamp = Number(item.sentAt || item.lastAttemptAt || item.createdAt || 0);
            if ((item.status === 'sent' || item.status === 'failed') && timestamp && timestamp < cutoff) {
                updates['sms_queue/' + key] = null;
            }
        });
        if (Object.keys(updates).length) await db.ref().update(updates);
        return res.json({ success: true, deleted: Object.keys(updates).length });
    } catch (error) {
        console.error('❌ /admin/cleanup-sms-queue:', error);
        return res.status(500).json({ success: false, error: 'خطأ داخلي' });
    }
});

app.post('/admin/deposit', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) {
            return res.status(401).json({ success: false, error: 'غير مصرح' });
        }

        const { phone, amount } = req.body;
        const amt = Number(amount);
        if (!phone || !amt || amt <= 0 || !isFinite(amt)) {
            return res.status(400).json({ success: false, error: 'بيانات غير صحيحة' });
        }

        const userSnap = await db.ref('users/' + phone).once('value');
        if (!userSnap.exists()) {
            return res.status(404).json({ success: false, error: 'الحساب غير موجود' });
        }

        const adminSnap = await db.ref('users/999').once('value');
        const adminName = (adminSnap.val() && adminSnap.val().fullName) || 'ادارة كوفانت';

        const treasuryBalance = await getTreasurySummary();
        if (amt > treasuryBalance) {
            return res.status(400).json({
                success: false,
                error: `رصيد الخزينة الحالي (${treasuryBalance.toFixed(2)} YER) لا يكفي لإتمام إيداع بقيمة ${amt.toFixed(2)} YER`
            });
        }

        const balRef = db.ref('users/' + phone + '/balance');
        const balTxResult = await transactionWithWarmValue(
            balRef, cur => (Number(cur) || 0) + amt, 'إيداع رصيد العميل'
        );
        if (!balTxResult.committed) throw new Error('تعذر تحديث رصيد العميل');
        // 🔧 الإصلاح 4: الإيداع يزيد مجموع الأرصدة
        await _updateStatsSummary({ balanceDelta: amt });
        const newBalance = Number(balTxResult.snapshot.val()) || 0;

        const ts = Date.now();
        await db.ref('users/' + phone + '/history').push({
            type: 'in', amount: amt, title: 'إيداع',
            date: new Date(ts).toLocaleString('ar-YE'), timestamp: ts, balanceAfter: newBalance
        });
        await db.ref('users/' + phone + '/lastTransaction').set({
            type: 'in', amount: amt, timestamp: ts, balanceAfter: newBalance, description: 'إيداع'
        });
        await recordTreasuryMovement(-amt, {
            type: 'deposit', details: `إيداع نقدي للعميل ${phone}`, performedBy: adminName
        });

        sendPush(phone, `تم إيداع / ${adminName} لحسابك ${fmtMoney(amt)} YER`, `رصيدك ${fmtMoney(newBalance)} YER`);
        queuePendingNotification(phone, {
            type: 'deposit', title: 'تم إيداع رصيد',
            body: `تم إيداع ${fmtMoney(amt)} YER في حسابك`, amount: amt
        }).catch(error => console.error('❌ pending deposit notification:', error.message));
        queueSmsDelivery(phone,
            `كوفانت: تم إيداع رصيد\nالمبلغ: ${fmtMoney(amt)} YER\nرصيدك الجديد: ${fmtMoney(newBalance)} YER`,
            { source: 'admin_deposit', txId: String(ts) }
        ).catch(error => console.error('❌ SMS deposit queue:', error.message));

        res.json({ success: true, newBalance });
    } catch (error) {
        console.error('❌ /admin/deposit فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/admin/invoice/create', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) {
            return res.status(401).json({ success: false, error: 'غير مصرح' });
        }

        const { phone, amount } = req.body;
        const amt = Number(amount);
        if (!phone || !amt || amt <= 0 || !isFinite(amt)) {
            return res.status(400).json({ success: false, error: 'بيانات غير صحيحة' });
        }

        const userSnap = await db.ref('users/' + phone).once('value');
        if (!userSnap.exists()) {
            return res.status(404).json({ success: false, error: 'الحساب غير موجود' });
        }

        const adminSnap = await db.ref('users/999').once('value');
        const adminName = (adminSnap.val() && adminSnap.val().fullName) || 'ادارة كوفانت';
        const invoiceNumber = Math.floor(1000 + Math.random() * 9000);

        const balRef = db.ref('users/' + phone + '/balance');
        const balTxResult = await transactionWithWarmValue(
            balRef, cur => (Number(cur) || 0) + amt, 'إضافة رصيد الفاتورة'
        );
        if (!balTxResult.committed) throw new Error('تعذر تحديث رصيد الفاتورة');
        // 🔧 الإصلاح 4: الفاتورة الآجلة تضيف رصيداً للعميل ⇒ totalBalance +amt (الدين يُسجَّل بعد حفظ الفاتورة أدناه)
        await _updateStatsSummary({ balanceDelta: amt });
        const newBalance = Number(balTxResult.snapshot.val()) || 0;

        const ts = Date.now();
        await db.ref('users/' + phone + '/history').push({
            type: 'in', amount: amt, title: `فاتورة آجلة رقم ${invoiceNumber}`,
            date: new Date(ts).toLocaleString('ar-YE'), timestamp: ts, balanceAfter: newBalance
        });
        await db.ref('users/' + phone + '/lastTransaction').set({
            type: 'in', amount: amt, timestamp: ts, balanceAfter: newBalance, description: `فاتورة آجلة رقم ${invoiceNumber}`
        });

        const invoiceRef = db.ref('users/' + phone + '/invoices').push();
        await invoiceRef.set({
            number: invoiceNumber, totalAmount: amt, paidAmount: 0, remainingAmount: amt,
            status: 'active', createdAt: ts, payments: []
        });
        // 🔧 الإصلاح 4: فاتورة نشطة جديدة ⇒ totalDebts +amt وtotalInvoices +1
        await _updateStatsSummary({ debtsDelta: amt, invoicesDelta: 1 });

        await recordTreasuryMovement(-amt, {
            type: 'credit', details: `فاتورة آجلة رقم ${invoiceNumber} للعميل ${phone}`, performedBy: adminName
        });
        await db.ref('notifications/' + phone).push({
            id: ts + '_invoice', title: `📄 فاتورة آجلة رقم ${invoiceNumber}`,
            message: `تم إنشاء فاتورة بقيمة ${fmtMoney(amt)} YER`,
            type: 'debt', timestamp: ts, isRead: false
        });

        sendPush(
            phone,
            `فاتورة آجلة رقم (${invoiceNumber}) بقيمة ${fmtMoney(amt)} YER على حسابك لصالح ${adminName}. المبلغ المستحق: ${fmtMoney(amt)} YER.`,
            `رصيدك ${fmtMoney(newBalance)} YER`,
            { persist: false }
        );

        res.json({ success: true, newBalance, invoiceNumber });
    } catch (error) {
        console.error('❌ /admin/invoice/create فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/admin/invoice/pay', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) {
            return res.status(401).json({ success: false, error: 'غير مصرح' });
        }

        const { phone, invoiceId, amount } = req.body;
        const amt = Number(amount);
        if (!phone || !invoiceId || !amt || amt <= 0 || !isFinite(amt)) {
            return res.status(400).json({ success: false, error: 'بيانات غير صحيحة' });
        }

        const invoiceRef = db.ref('users/' + phone + '/invoices/' + invoiceId);
        const invSnap = await invoiceRef.once('value');
        const invoice = invSnap.val();
        if (!invoice) {
            return res.status(404).json({ success: false, error: 'الفاتورة غير موجودة' });
        }
        if (invoice.status === 'paid') {
            return res.status(400).json({ success: false, error: 'الفاتورة مدفوعة بالكامل' });
        }
        if (amt > Number(invoice.remainingAmount || 0)) {
            return res.status(400).json({ success: false, error: `المبلغ يتجاوز المتبقي (${fmtMoney(invoice.remainingAmount)} YER)` });
        }

        const balRef = db.ref('users/' + phone + '/balance');
        const balTxResult = await transactionWithWarmValue(
            balRef, cur => {
            const curBal = Number(cur) || 0;
            if (curBal < amt) return;
            return curBal - amt;
        }, 'خصم رصيد سداد الفاتورة');
        if (!balTxResult.committed) {
            return res.status(400).json({ success: false, error: 'الرصيد غير كافٍ' });
        }
        const newBalance = Number(balTxResult.snapshot.val()) || 0;

        const invTxResult = await transactionWithWarmValue(
            invoiceRef, cur => {
            if (!cur || cur.status === 'paid') return;
            const remaining = Number(cur.remainingAmount || 0);
            if (amt > remaining) return;
            const newRemaining = Math.max(0, remaining - amt);
            return {
                ...cur,
                paidAmount: Number(cur.paidAmount || 0) + amt,
                remainingAmount: newRemaining,
                status: newRemaining <= 0 ? 'paid' : 'active',
                payments: { ...(cur.payments || {}), [Date.now()]: { amount: amt, date: Date.now(), note: 'سداد عبر المسؤول' } }
            };
        }, 'تحديث الفاتورة');

        if (!invTxResult.committed) {
            await transactionWithWarmValue(
                balRef,
                cur => (Number(cur) || 0) + amt,
                'rollback رصيد سداد الفاتورة'
            );
            return res.status(409).json({ success: false, error: 'تم تحديث الفاتورة من عملية أخرى بالتزامن، يرجى إعادة المحاولة' });
        }

        const updatedInvoice = invTxResult.snapshot.val();
        const newPaid = updatedInvoice.paidAmount;
        const newRemaining = updatedInvoice.remainingAmount;
        const newStatus = updatedInvoice.status;
        // 🔧 الإصلاح 4: بعد نجاح خصم الرصيد وتحديث الفاتورة معاً (لا rollback): الرصيد -amt والدين -amt،
        // وإن سُدّت بالكامل تنقص الفواتير النشطة 1
        await _updateStatsSummary({ balanceDelta: -amt, debtsDelta: -amt, invoicesDelta: newStatus === 'paid' ? -1 : 0 });

        await db.ref('users/' + phone + '/history').push({
            type: 'out', amount: amt, title: `سداد فاتورة رقم ${invoice.number}`,
            date: new Date(Date.now()).toLocaleString('ar-YE'), timestamp: Date.now(), balanceAfter: newBalance
        });
        await db.ref('users/' + phone + '/lastTransaction').set({
            type: 'out', amount: amt, timestamp: Date.now(), balanceAfter: newBalance,
            description: `سداد فاتورة رقم ${invoice.number}`
        });
        await recordTreasuryMovement(amt, {
            type: 'debt_payment', details: `سداد فاتورة رقم ${invoice.number} للعميل ${phone}`
        });

        const invoiceMsgTitle = newRemaining <= 0
            ? `تم سداد ${fmtMoney(amt)} YER من الفاتورة رقم (${invoice.number}). تمت تسوية الفاتورة بالكامل.`
            : `تم سداد ${fmtMoney(amt)} YER من الفاتورة رقم (${invoice.number}). المبلغ المتبقي المستحق: ${fmtMoney(newRemaining)} YER.`;
        sendPush(phone, invoiceMsgTitle, `رصيدك ${fmtMoney(newBalance)} YER`);
        sendPush('999', '💳 سداد فاتورة', `تم سداد ${fmtMoney(amt)} YER من فاتورة رقم ${invoice.number} للعميل ${phone}`);

        res.json({ success: true, newBalance, newRemaining, status: newStatus });
    } catch (error) {
        console.error('❌ /admin/invoice/pay فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

app.post('/admin/create-user', authLimiter, async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) {
            return res.status(401).json({ success: false, error: 'غير مصرح' });
        }

        const {
            firstName, fatherName, grandfatherName, familyName,
            birthDay, birthMonth, birthYear, address,
            phone, password, confirmPassword, referralCode, activateNow
        } = req.body || {};

        const fullName = [firstName, fatherName, grandfatherName, familyName].filter(Boolean).join(' ');
        if (!fullName) {
            return res.status(400).json({ success: false, error: 'يرجى إدخال الاسم الكامل' });
        }
        if (!phone || !isValidYemeniPhone(phone)) {
            return res.status(400).json({ success: false, error: 'رقم الجوال يجب أن يبدأ بـ 7 ويتكون من 9 أرقام' });
        }
        if (!password || password.length < 6) {
            return res.status(400).json({ success: false, error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
        }
        if (password !== confirmPassword) {
            return res.status(400).json({ success: false, error: 'كلمتا المرور غير متطابقتين' });
        }

        const existingSnap = await db.ref('users/' + phone).once('value');
        if (existingSnap.exists()) {
            return res.status(409).json({ success: false, error: 'هذا الرقم مسجل مسبقاً' });
        }

        const accountNumber = await getUniqueAccountNumber();
        const hashedPassword = await hashPasswordStrong(password);
        const birthDate = (birthDay && birthMonth && birthYear)
            ? `${String(birthYear).padStart(4, '0')}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`
            : '';

        const newUser = {
            fullName,
            firstName: firstName || '', fatherName: fatherName || '',
            grandfatherName: grandfatherName || '', familyName: familyName || '',
            birthDate,
            address: address || '',
            phone,
            password: hashedPassword,
            referralCode: referralCode || '',
            accountNumber,
            balance: 0,
            createdAt: Date.now(),
            isActivated: !!activateNow,
            maxDevices: 1,
            devices: {},
            history: {}
        };

        await db.ref('users/' + phone).set(newUser);
        // 🔧 الإصلاح 4: usersCount +1، وactivatedCount +1 إن أُنشئ مفعّلاً مباشرة
        await _updateStatsSummary({ usersDelta: 1, activatedDelta: newUser.isActivated ? 1 : 0 });

        res.json({ success: true, accountNumber, fullName });
    } catch (error) {
        console.error('❌ /admin/create-user فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// 🔧 الإصلاح 4: تفعيل/تعطيل حساب عبر الخادم (كان الأدمن يكتب isActivated مباشرة من المتصفح
// فلا يعلم stats/summary بالتغيير). نفس صلاحية بقية مسارات /admin/*.
// ============================================================
app.post('/admin/set-activation', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) return res.status(401).json({ success: false, error: 'غير مصرح' });

        const { phone, active } = req.body || {};
        if (!phone || typeof active !== 'boolean' || String(phone) === '999') {
            return res.status(400).json({ success: false, error: 'بيانات غير صحيحة' });
        }
        const userSnap = await db.ref('users/' + phone).once('value');
        if (!userSnap.exists()) return res.status(404).json({ success: false, error: 'الحساب غير موجود' });

        const wasActive = (userSnap.val() || {}).isActivated === true;
        await db.ref('users/' + phone + '/isActivated').set(active);
        const delta = (active ? 1 : 0) - (wasActive ? 1 : 0);
        if (delta !== 0) await _updateStatsSummary({ activatedDelta: delta });

        res.json({ success: true, isActivated: active });
    } catch (error) {
        console.error('❌ /admin/set-activation فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// 🔧 الإصلاح 4: إعادة حساب stats/summary بالكامل من users (مرة واحدة عند التهيئة، أو لتصحيح أي انحراف).
// يقرأ users على دفعات مفتاحية (500 → ذاكرة محدودة) ثم يكتب القيم المطلقة.
// يرجع الفروقات عن القيم السابقة لتتأكد من دقة التحديث التراكمي.
// ⚠️ شغّله وقت هدوء: عملية تحدث أثناء القراءة قد لا تُحتسب (أعد التشغيل إن لزم).
// ============================================================
let _statsRecalcRunning = false;
app.post('/admin/recalculate-stats', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) return res.status(401).json({ success: false, error: 'غير مصرح' });
        if (_statsRecalcRunning) return res.status(429).json({ success: false, error: 'إعادة الحساب قيد التنفيذ' });
        _statsRecalcRunning = true;
        try {
            const prevSnap = await db.ref(STATS_SUMMARY_PATH).once('value');
            const prev = prevSnap.val() || null;

            const t = { usersCount: 0, activatedCount: 0, totalBalance: 0, totalDebts: 0, totalInvoices: 0 };
            const PAGE = 500;
            let lastKey = null;
            for (;;) {
                const boundary = lastKey;
                let q = db.ref('users').orderByKey();
                if (boundary !== null) q = q.startAt(boundary);
                const limit = boundary === null ? PAGE : PAGE + 1;   // +1: العنصر الحدّي يُعاد
                const snap = await q.limitToFirst(limit).once('value');
                let raw = 0;
                snap.forEach(child => {
                    raw++;
                    lastKey = child.key;
                    if (child.key === boundary || child.key === '999') return;   // الأدمن لا يُحسب
                    const u = child.val() || {};
                    t.usersCount++;
                    if (u.isActivated === true) t.activatedCount++;
                    t.totalBalance += Number(u.balance) || 0;
                    const invoices = u.invoices || {};
                    for (const id of Object.keys(invoices)) {
                        const inv = invoices[id];
                        if (inv && inv.status === 'active' && Number(inv.remainingAmount) > 0) {
                            t.totalDebts += Number(inv.remainingAmount);
                            t.totalInvoices++;
                        }
                    }
                });
                if (raw < limit) break;
            }
            const r2 = n => Math.round(n * 100) / 100;
            t.totalBalance = r2(t.totalBalance);
            t.totalDebts = r2(t.totalDebts);
            const now = Date.now();
            await db.ref(STATS_SUMMARY_PATH).set({ ...t, updatedAt: now, recalculatedAt: now });

            const drift = {};
            if (prev && prev.recalculatedAt) {
                for (const k of Object.keys(t)) drift[k] = r2(t[k] - (Number(prev[k]) || 0));
            }
            res.json({ success: true, usersCount: t.usersCount, summary: t, previous: prev, drift });
        } finally {
            _statsRecalcRunning = false;
        }
    } catch (error) {
        console.error('❌ /admin/recalculate-stats فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// 🔧 الإصلاح 5: إعادة حساب stats/treasury من treasury/transactions (تهيئة أولى أو تصحيح انحراف).
// يقرأ الحركات على دفعات مفتاحية (500) ثم يكتب القيم المطلقة في عقدة منفصلة عن stats/summary
// (حتى لا يمسح recalculate-stats الخاص بالمستخدمين هذه الحقول — فهو يكتب بـ set).
// يرجع: الفروقات عن القيم السابقة + balanceDrift = (Σ changeAmount) − treasury/summary/balance
// ولا يعدّل treasury/summary/balance إطلاقاً (منطق مالي — القرار لك).
// ============================================================
let _treasuryStatsRecalcRunning = false;
app.post('/admin/recalculate-treasury-stats', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) return res.status(401).json({ success: false, error: 'غير مصرح' });
        if (_treasuryStatsRecalcRunning) return res.status(429).json({ success: false, error: 'إعادة الحساب قيد التنفيذ' });
        _treasuryStatsRecalcRunning = true;
        try {
            const prev = (await db.ref(TREASURY_STATS_PATH).once('value')).val() || null;
            const t = { totalSales: 0, totalDeposits: 0, totalInvoicesPaid: 0, legacyCreditSum: 0 };
            let sumAll = 0, txCount = 0;
            const PAGE = 500;
            let lastKey = null;
            for (;;) {
                const boundary = lastKey;
                let q = db.ref('treasury/transactions').orderByKey();
                if (boundary !== null) q = q.startAt(boundary);
                const limit = boundary === null ? PAGE : PAGE + 1;   // +1: العنصر الحدّي يُعاد
                const snap = await q.limitToFirst(limit).once('value');
                let raw = 0;
                snap.forEach(child => {
                    raw++;
                    lastKey = child.key;
                    if (child.key === boundary) return;
                    const tx = child.val() || {};
                    const c = Number(tx.changeAmount) || 0;
                    txCount++;
                    sumAll += c;
                    const d = _treasuryStatsDeltas(tx.type, c);
                    for (const k of Object.keys(d)) t[k] += d[k];
                });
                if (raw < limit) break;
            }
            const r2 = n => Math.round(n * 100) / 100;
            for (const k of Object.keys(t)) t[k] = r2(t[k]);
            const now = Date.now();
            await db.ref(TREASURY_STATS_PATH).set({ ...t, updatedAt: now, recalculatedAt: now });

            const balance = Number((await db.ref('treasury/summary/balance').once('value')).val()) || 0;
            const drift = {};
            if (prev && prev.recalculatedAt) {
                for (const k of Object.keys(t)) drift[k] = r2(t[k] - (Number(prev[k]) || 0));
            }
            res.json({ success: true, txCount, summary: t, drift, treasuryBalance: r2(balance), ledgerSum: r2(sumAll), balanceDrift: r2(sumAll - balance) });
        } finally {
            _treasuryStatsRecalcRunning = false;
        }
    } catch (error) {
        console.error('❌ /admin/recalculate-treasury-stats فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// تعيين نوع الحساب (وكيل / نقطة بيع) — يمر عبر الخادم (Admin SDK)
// حتى لا تمنعه قواعد Firebase للحقول الجديدة
// ============================================================
const SELLER_TYPES = new Set(['agent', 'pos']);

app.post('/admin/set-user-type', async (req, res) => {
    try {
        const adminCheck = await verifyAdmin(req);
        if (!adminCheck.isAdmin) {
            return res.status(401).json({ success: false, error: 'غير مصرح' });
        }
        const phone = String((req.body && req.body.phone) || '').trim();
        const raw = String((req.body && req.body.userType) || '').trim();
        const type = SELLER_TYPES.has(raw) ? raw : null;
        if (!phone || (raw && raw !== 'none' && !type)) {
            return res.status(400).json({ success: false, error: 'بيانات غير صحيحة' });
        }

        const userRef = db.ref('users/' + phone);
        const snap = await userRef.once('value');
        if (!snap.exists()) {
            return res.status(404).json({ success: false, error: 'الحساب غير موجود' });
        }
        const u = snap.val() || {};
        const profileDone = !!(u.agentProfile && u.agentProfile.completed);

        await userRef.update({
            userType: type,
            isAgent: !!type,
            agentProfileRequired: (type && !profileDone) ? true : null
        });

        const locRef = db.ref('locations/' + phone);
        const locSnap = await locRef.once('value');
        if (locSnap.exists()) {
            await locRef.update({ isAgent: !!type, userType: type });
        }

        res.json({ success: true, userType: type });
    } catch (error) {
        console.error('❌ /admin/set-user-type فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// حفظ بيانات الوكيل من المستخدم نفسه بعد تعيينه وكيلاً / نقطة بيع
app.post('/user/agent-profile', async (req, res) => {
    try {
        const decoded = verifyUserToken(req);
        if (!decoded) return res.status(401).json({ success: false, error: 'غير مصرح' });
        const phone = String(decoded.phone);

        const userRef = db.ref('users/' + phone);
        const snap = await userRef.once('value');
        const u = snap.val();
        if (!u || !SELLER_TYPES.has(u.userType)) {
            return res.status(403).json({ success: false, error: 'حسابك غير معيّن كوكيل أو نقطة بيع' });
        }

        const b = req.body || {};
        const karimiAccount = String(b.karimiAccount || '').trim().slice(0, 40);
        const businessType = String(b.businessType || '').trim().slice(0, 60);
        const lat = Number(b.lat), lng = Number(b.lng);
        if (!karimiAccount || !businessType || !isFinite(lat) || !isFinite(lng) ||
            Math.abs(lat) > 90 || Math.abs(lng) > 180) {
            return res.status(400).json({ success: false, error: 'بيانات غير مكتملة' });
        }

        const now = Date.now();
        await userRef.update({
            agentProfile: { karimiAccount, businessType, lat, lng, completed: true, updatedAt: now },
            agentProfileRequired: null
        });
        await db.ref('locations/' + phone).set({
            lat, lng,
            name: u.fullName || phone,
            isAgent: true, userType: u.userType,
            businessType,
            updatedAt: now
        });
        res.json({ success: true });
    } catch (error) {
        console.error('❌ /user/agent-profile فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي بالخادم' });
    }
});

// ============================================================
// 12. نقطة /refresh — تجديد آمن للجلسة عبر Refresh Token
// ============================================================
app.post('/refresh', authLimiter, async (req, res) => {
    try {
        const { phone, refreshToken } = req.body;
        if (!phone || !refreshToken) {
            return res.status(400).json({ success: false, error: 'بيانات ناقصة' });
        }

        const session = await getSession(phone);
        if (!session) {
            return res.status(404).json({ success: false, error: 'لا توجد جلسة' });
        }

        const providedHash = sha256Hex(refreshToken);
        const isExpired = !session.refreshTokenExpiry || Date.now() > Number(session.refreshTokenExpiry);
        const isMatch = session.refreshTokenHash && safeEqual(session.refreshTokenHash, providedHash);

        if (!isMatch || isExpired) {
            await clearSession(phone);
            return res.status(401).json({ success: false, error: 'الجلسة منتهية' });
        }

        const isAdmin = phone === '999';
        const { accessToken, refreshToken: newRefreshToken } = await issueSessionTokens(phone, isAdmin);
        const firebaseToken = await createFirebaseAuthToken(phone, isAdmin);

        const userSnap = await db.ref('users/' + phone).once('value');
        const user = userSnap.val() || {};

        const {
            password: _p, pin: _pin,
            refreshTokenHash: _rh, refreshTokenExpiry: _re,
            failedAttempts: _fa, lockUntil: _lu,
            ...safeUser
        } = user;

        res.json({
            success: true,
            isAdmin,
            token: accessToken,
            refreshToken: newRefreshToken,
            firebaseToken,
            user: { ...safeUser, phone }
        });
    } catch (error) {
        console.error('❌ /refresh فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي' });
    }
});

// ============================================================
// 12-ب. نقطة /logout — إلغاء جلسة refresh نهائياً
// ============================================================
app.post('/logout', authLimiter, async (req, res) => {
    try {
        const { phone, refreshToken } = req.body || {};
        if (!phone || !refreshToken) return res.status(400).json({ success: false, error: 'phone وrefreshToken مطلوبان' });
        const session = await getSession(phone);
        if (!session || !safeEqual(session.refreshTokenHash, sha256Hex(refreshToken))) {
            return res.status(401).json({ success: false, error: 'جلسة غير صالحة' });
        }
        await clearSession(phone);
        res.json({ success: true });
    } catch (error) {
        console.error('❌ /logout فشل:', error);
        res.status(500).json({ success: false, error: 'خطأ داخلي' });
    }
});

// ============================================================
// 13. نقطة /api/external/charge — شحن خارجي (يمن موبايل، سبأفون، MTN)
// ============================================================
app.post('/api/external/charge', chargeLimiter, async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'مطلوب توكن' });
        }
        let callerPhone, callerIsAdmin = false;
        try {
            const decoded = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
            callerPhone = decoded.phone;
            callerIsAdmin = !!decoded.isAdmin;
        } catch (e) {
            return res.status(401).json({ error: 'توكن غير صالح أو منتهي' });
        }

        const { mobile, amount, service } = req.body;
        if (!mobile || !amount) {
            return res.status(400).json({ error: 'رقم الهاتف والمبلغ مطلوبان' });
        }
        if (!callerIsAdmin && mobile !== callerPhone) {
            return res.status(403).json({ error: 'لا يمكنك شحن رقم غير رقمك الخاص' });
        }
        const targetUserSnap = await db.ref('users/' + mobile).once('value');
        if (!targetUserSnap.exists()) return res.status(404).json({ error: 'المستخدم غير موجود' });
        if (targetUserSnap.val().isActivated !== true) return res.status(403).json({ error: 'الحساب غير مفعّل' });
        const amt = Number(amount);
        if (!amt || amt <= 0 || !isFinite(amt)) {
            return res.status(400).json({ error: 'مبلغ غير صحيح' });
        }

        const transid = `CH-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;

        const hashPassword = crypto.createHash('md5').update(process.env.SYSTEM_PASSWORD).digest('hex');
        const rawString = hashPassword + transid + process.env.SYSTEM_USERNAME + mobile;
        const token = crypto.createHash('md5').update(rawString).digest('hex');

        let baseUrl = process.env.API_BASE_URL;
        if (service === 'sabafon') baseUrl = process.env.SABAFON_API_URL;
        else if (service === 'mtn') baseUrl = process.env.MTN_API_URL;

        const url = `${baseUrl}/yem?action=bill&userid=${process.env.SYSTEM_USERNAME}&mobile=${mobile}&transid=${transid}&token=${token}&amount=${amount}`;

        const response = await fetch(url);
        const data = await response.json();

        await db.ref('external_charges/' + transid).set({
            mobile,
            amount,
            service: service || 'yem',
            transid,
            status: data.resultCode === '0' ? 'pending' : 'failed',
            result: data,
            timestamp: Date.now()
        });

        res.json(data);
    } catch (error) {
        console.error('❌ Charge error:', error);
        res.status(500).json({ error: 'خطأ في الاتصال بالخادم الخارجي' });
    }
});

// ============================================================
// 14. نقطة /webhook — استقبال تحديثات المزود الخارجي
// ============================================================
function verifyWebhookSignature(req, payload) {
    const provided = String(req.headers['x-webhook-signature'] || '').replace(/^sha256=/i, '').trim();
    if (!provided || !/^[a-f0-9]{64}$/i.test(provided)) return false;
    const raw = req.rawBody && req.rawBody.length ? req.rawBody : Buffer.from(JSON.stringify(payload || {}));
    const expected = crypto.createHmac('sha256', process.env.BACKPASS_KEY).update(raw).digest('hex');
    return safeEqual(provided.toLowerCase(), expected.toLowerCase());
}

async function handleWebhook(req, res, payload) {
    const { action, transid, backpass, message } = payload || {};
    if (!safeEqual(backpass, process.env.BACKPASS_KEY)) return res.status(403).send('Unauthorized');
    if (req.method === 'POST' && !verifyWebhookSignature(req, payload)) return res.status(403).send('Invalid signature');
    if (!action || !transid) return res.status(400).send('Missing webhook fields');

    const transRef = db.ref('external_charges/' + transid);
    const snapshot = await transRef.once('value');
    if (!snapshot.exists()) return res.status(404).send('Transaction not found');

    if (action === 'done') {
        const data = snapshot.val();
        if (data.status === 'done') return res.send('OK');
        const targetUser = await db.ref('users/' + data.mobile).once('value');
        if (!targetUser.exists() || targetUser.val().isActivated !== true) {
            await transRef.update({ status: 'failed', failedAt: Date.now(), message: 'الحساب غير مفعّل أو غير موجود' });
            return res.status(403).send('Account not active');
        }
        const balanceTx = await transactionWithWarmValue(
            db.ref('users/' + data.mobile + '/balance'),
            cur => (Number(cur) || 0) + Number(data.amount || 0),
            'شحن webhook'
        );
        if (!balanceTx.committed) return res.status(500).send('Balance update failed');
        // 🔧 الإصلاح 4: شحن خارجي مؤكد يزيد مجموع الأرصدة
        await _updateStatsSummary({ balanceDelta: Number(data.amount || 0) });
        await transRef.update({ status: 'done', completedAt: Date.now() });
    } else if (action === 'ban') {
        await transRef.update({ status: 'failed', failedAt: Date.now(), message });
    } else {
        return res.status(400).send('Unknown action');
    }
    res.send('OK');
}

app.get('/webhook', async (req, res) => {
    try { return await handleWebhook(req, res, req.query); }
    catch (error) { console.error('❌ GET /webhook فشل:', error); return res.status(500).send('Webhook error'); }
});
app.post('/webhook', async (req, res) => {
    try { return await handleWebhook(req, res, req.body); }
    catch (error) { console.error('❌ POST /webhook فشل:', error); return res.status(500).send('Webhook error'); }
});

// ============================================================
// 🔥 15. نقطة /activate — تفعيل الحساب عبر البوت
// ============================================================
const BOT_KEY = process.env.BOT_KEY;

app.post('/activate', async (req, res) => {
    try {
        const botKeyHeader = req.headers['x-bot-key'];
        if (!safeEqual(botKeyHeader, BOT_KEY)) {
            return res.status(403).json({ error: 'غير مصرح' });
        }

        const { phone } = req.body;
        if (!phone) {
            return res.status(400).json({ error: 'رقم الهاتف مطلوب' });
        }

        const snap = await db.ref('users/' + phone).once('value');
        if (!snap.exists()) {
            return res.status(404).json({ error: 'المستخدم غير موجود' });
        }

        // 🔧 الإصلاح 4: نزيد activatedCount فقط إن لم يكن مفعّلاً (الاستدعاء المتكرر لا يضاعف العدّاد)
        const wasActivated = (snap.val() || {}).isActivated === true;
        await db.ref(`users/${phone}/isActivated`).set(true);
        if (!wasActivated) await _updateStatsSummary({ activatedDelta: 1 });

        res.json({ success: true, message: `تم تفعيل حساب ${phone}` });
    } catch (error) {
        console.error('❌ /activate فشل:', error);
        res.status(500).json({ error: 'خطأ داخلي' });
    }
});

// ============================================================
// 🔥 15-ب. نقاط خاصة بالبوت (kova-bot)
// ============================================================
function verifyBotKey(req) {
    return safeEqual(req.headers['x-bot-key'], BOT_KEY);
}

app.get('/bot/find-user', async (req, res) => {
    if (!verifyBotKey(req)) return res.status(403).json({ error: 'غير مصرح' });
    try {
        const phone = String(req.query.phone || '');
        const searchDigits = phone.replace(/\D/g, '').slice(-9);
        if (!searchDigits) return res.status(400).json({ error: 'رقم غير صالح' });

        const directSnap = await db.ref('users/' + searchDigits).once('value');
        if (directSnap.exists()) {
            return res.json({ found: true, key: searchDigits, data: directSnap.val() });
        }

        const byPhone = await db.ref('users')
            .orderByChild('phone').equalTo(searchDigits)
            .once('value');
        if (byPhone.exists()) {
            let result = null;
            byPhone.forEach(c => { result = { key: c.key, data: c.val() }; });
            return res.json({ found: true, ...result });
        }

        const byAcc = await db.ref('users')
            .orderByChild('accountNumber').equalTo(searchDigits)
            .once('value');
        if (byAcc.exists()) {
            let result = null;
            byAcc.forEach(c => { result = { key: c.key, data: c.val() }; });
            return res.json({ found: true, ...result });
        }

        res.json({ found: false });
    } catch (error) {
        console.error('❌ /bot/find-user فشل:', error);
        res.status(500).json({ error: 'خطأ داخلي' });
    }
});

app.get('/bot/all-users', async (req, res) => {
    if (!verifyBotKey(req)) return res.status(403).json({ error: 'غير مصرح' });
    try {
        const limit = Math.min(parseInt(req.query.limit) || 100, 500);
        const snap = await db.ref('users')
            .orderByChild('createdAt')
            .limitToLast(limit)
            .once('value');
        res.json({ users: snap.val() || {}, count: snap.numChildren() });
    } catch (error) {
        console.error('❌ /bot/all-users فشل:', error);
        res.status(500).json({ error: 'خطأ داخلي' });
    }
});

app.get('/bot/pending-transactions', async (req, res) => {
    if (!verifyBotKey(req)) return res.status(403).json({ error: 'غير مصرح' });
    try {
        const snap = await db.ref('all_transactions')
            .orderByChild('processed')
            .equalTo(false)
            .limitToLast(200)
            .once('value');
        res.json({ transactions: snap.val() || {} });
    } catch (error) {
        console.error('❌ /bot/pending-transactions فشل:', error);
        res.status(500).json({ error: 'خطأ داخلي' });
    }
});

app.post('/bot/mark-processed', async (req, res) => {
    if (!verifyBotKey(req)) return res.status(403).json({ error: 'غير مصرح' });
    try {
        const { txId } = req.body || {};
        if (!txId) return res.status(400).json({ error: 'معرّف العملية مطلوب' });
        await db.ref('all_transactions/' + txId).update({ processed: true });
        res.json({ success: true });
    } catch (error) {
        console.error('❌ /bot/mark-processed فشل:', error);
        res.status(500).json({ error: 'خطأ داخلي' });
    }
});

/* ============================================================
   SMS Transfer — تحويل نيابة عن مستخدم (للأدمن فقط)
   ============================================================ */
app.post('/sms/transfer', async (req, res) => {
    let fromPhone = null;
    let recipientPhone = null;
    let amt = 0;
    let idempotency = null;
    let auditRef = null;
    let debitApplied = false;
    let creditApplied = false;

    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, error: 'مطلوب توكن' });
        }

        let decoded;
        try {
            decoded = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
        } catch (e) {
            return res.status(401).json({ success: false, error: 'توكن غير صالح' });
        }
        if (decoded.phone !== '999' || decoded.isAdmin !== true) {
            return res.status(403).json({ success: false, error: 'غير مصرح — يجب أن تكون الأدمن' });
        }

        const { from, toAccount, amount, note, sessionId } = req.body || {};
        if (!from || !toAccount || amount === undefined || amount === null) {
            return res.status(400).json({ success: false, error: 'بيانات ناقصة' });
        }

        fromPhone = String(from);
        amt = Number(amount);
        if (!isValidYemeniPhone(fromPhone)) {
            return res.status(400).json({ success: false, error: 'رقم المُرسل غير صالح' });
        }
        if (!amt || amt <= 0 || !isFinite(amt)) {
            return res.status(400).json({ success: false, error: 'مبلغ غير صحيح' });
        }
        if (amt < 100) {
            return res.status(400).json({ success: false, error: 'الحد الأدنى 100 ريال' });
        }

        const operationId = sessionId || getOperationId(req);
        if (!operationId) {
            return res.status(400).json({ success: false, error: 'sessionId مطلوب' });
        }

        const senderSnap = await db.ref('users/' + fromPhone).once('value');
        if (!senderSnap.exists()) {
            return res.status(404).json({ success: false, error: 'حساب المُرسل غير موجود' });
        }
        const sender = senderSnap.val();
        if (sender.isActivated !== true) {
            return res.status(403).json({ success: false, error: 'حساب المُرسل غير مفعّل' });
        }

        const recSnap = await db.ref('users').orderByChild('accountNumber').equalTo(String(toAccount)).once('value');
        if (!recSnap.exists()) {
            return res.status(404).json({ success: false, error: 'رقم حساب المستلم غير موجود' });
        }
        let recipient = null;
        recSnap.forEach(child => { recipientPhone = child.key; recipient = child.val(); });
        if (!recipientPhone || recipientPhone === fromPhone) {
            return res.status(400).json({ success: false, error: 'لا يمكن التحويل لنفسك' });
        }
        if (!recipient || recipient.isActivated !== true) {
            return res.status(403).json({ success: false, error: 'حساب المستلم غير مفعّل' });
        }

        const initialSenderBalance = Number(sender.balance) || 0;
        if (initialSenderBalance < amt) {
            return res.status(400).json({ success: false, error: 'الرصيد غير كافٍ' });
        }

        idempotency = await claimIdempotency(fromPhone, operationId);
        if (!idempotency.claimed) return res.status(idempotency.status).json(idempotency.response);

        const senderName = sender.fullName || sender.name || fromPhone;
        const recipientName = recipient.fullName || recipient.name || recipientPhone;
        auditRef = db.ref('all_transactions').push();
        await auditRef.set({
            operationId, type: 'sms_transfer', from: fromPhone, to: recipientPhone,
            fromName: senderName, toName: recipientName, amount: amt,
            note: note || 'تحويل عبر SMS', timestamp: Date.now(), performedBy: '999',
            source: 'sms_auto_processor', status: 'validated'
        });

        const senderBalanceTx = await transactionWithWarmValue(
            db.ref('users/' + fromPhone + '/balance'),
            current => { const balance = Number(current) || 0; return balance < amt ? undefined : balance - amt; },
            'خصم رصيد تحويل SMS'
        );
        if (!senderBalanceTx.committed) {
            await auditRef.update({ status: 'rejected_insufficient', updatedAt: Date.now() });
            return res.status(400).json({ success: false, error: 'الرصيد غير كافٍ' });
        }
        debitApplied = true;
        const newSenderBalance = Number(senderBalanceTx.snapshot.val()) || 0;

        const recipientBalanceTx = await transactionWithWarmValue(
            db.ref('users/' + recipientPhone + '/balance'),
            current => (Number(current) || 0) + amt,
            'إضافة رصيد تحويل SMS'
        );
        if (!recipientBalanceTx.committed) throw new Error('فشل إضافة الرصيد للمستلم');
        creditApplied = true;
        const newRecipientBalance = Number(recipientBalanceTx.snapshot.val()) || 0;

        const ts = Date.now();
        const updates = {};
        const senderHistoryKey = db.ref('users/' + fromPhone + '/history').push().key;
        const recipientHistoryKey = db.ref('users/' + recipientPhone + '/history').push().key;
        updates['users/' + fromPhone + '/history/' + senderHistoryKey] = {
            type: 'out', amount: amt, title: `تحويل إلى ${recipientName} (SMS)`,
            date: new Date(ts).toLocaleString('ar-YE'), timestamp: ts, balanceAfter: newSenderBalance
        };
        updates['users/' + recipientPhone + '/history/' + recipientHistoryKey] = {
            type: 'in', amount: amt, title: `تحويل من ${senderName} (SMS)`,
            date: new Date(ts).toLocaleString('ar-YE'), timestamp: ts, balanceAfter: newRecipientBalance
        };
        await db.ref().update(updates);
        await auditRef.update({ status: 'completed', completedAt: ts, updatedAt: ts });

        const response = {
            success: true, txId: operationId, newBalance: newSenderBalance,
            recipient: { phone: recipientPhone, fullName: recipientName }
        };
        await completeIdempotency(idempotency, response);
        return res.json(response);
    } catch (error) {
        console.error('❌ /sms/transfer فشل:', error);
        try {
            if (creditApplied && recipientPhone) {
                await transactionWithWarmValue(db.ref('users/' + recipientPhone + '/balance'), current => (Number(current) || 0) - amt, 'rollback المستلم SMS');
            }
            if (debitApplied && fromPhone) {
                await transactionWithWarmValue(db.ref('users/' + fromPhone + '/balance'), current => (Number(current) || 0) + amt, 'rollback المرسل SMS');
            }
            if (auditRef) await auditRef.update({ status: 'rolled_back', rollbackReason: error.message || 'unknown', updatedAt: Date.now() });
        } catch (rollbackError) {
            console.error('❌ rollback فشل:', rollbackError);
        }
        return res.status(500).json({ success: false, error: 'فشل التحويل وتم استرداد الرصيد' });
    }
});

/* ============================================================
   SMS Purchase — شراء كرت نيابة عن مستخدم (للأدمن فقط)
   ============================================================ */
app.post('/sms/purchase-package', async (req, res) => {
    let fromPhone = null;
    let idempotency = null;
    let auditRef = null;
    const reserved = [];
    let balanceDebited = false;
    let totalAmount = 0;
    let pkgId = null;
    let recipient = null;
    let saleWrite = null, treasuryMovement = null;

    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ success: false, error: 'مطلوب توكن' });
        let decoded;
        try { decoded = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET); }
        catch (e) { return res.status(401).json({ success: false, error: 'توكن غير صالح' }); }
        if (decoded.phone !== '999' || decoded.isAdmin !== true) return res.status(403).json({ success: false, error: 'غير مصرح' });

        const { buyer, packageId, count, customerId, sessionId } = req.body || {};
        if (!buyer || !packageId || count === undefined || count === null) return res.status(400).json({ success: false, error: 'بيانات ناقصة' });
        fromPhone = String(buyer);
        pkgId = String(packageId);
        recipient = String(customerId || buyer);
        const requestedCount = Number(count);
        if (!isValidYemeniPhone(fromPhone)) return res.status(400).json({ success: false, error: 'رقم المشتري غير صالح' });
        if (!Number.isInteger(requestedCount) || requestedCount < 1 || requestedCount > 100) return res.status(400).json({ success: false, error: 'عدد غير صحيح' });
        const operationId = sessionId || getOperationId(req);
        if (!operationId) return res.status(400).json({ success: false, error: 'sessionId مطلوب' });

        const userSnap = await db.ref('users/' + fromPhone).once('value');
        if (!userSnap.exists()) return res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
        const userData = userSnap.val();
        if (userData.isActivated !== true) return res.status(403).json({ success: false, error: 'الحساب غير مفعّل' });
        const packageSnap = await db.ref('kova_store/' + pkgId).once('value');
        if (!packageSnap.exists()) return res.status(404).json({ success: false, error: 'الباقة غير موجودة' });
        const packageData = packageSnap.val();
        const price = Number(packageData.sellPrice) || 0;
        totalAmount = price * requestedCount;
        if (!price || !isFinite(totalAmount)) return res.status(400).json({ success: false, error: 'سعر غير صحيح' });

        idempotency = await claimIdempotency(fromPhone, operationId);
        if (!idempotency.claimed) return res.status(idempotency.status).json(idempotency.response);
        auditRef = db.ref('all_transactions').push();
        await auditRef.set({ operationId, type: 'sms_purchase', from: fromPhone, packageId: pkgId, count: requestedCount, recipient, amount: totalAmount, performedBy: '999', source: 'sms_auto_processor', timestamp: Date.now(), status: 'validated' });

        const cardsRef = db.ref('kova_store/' + pkgId + '/cards');
        const cards = (await cardsRef.once('value')).val() || {};
        for (const key of Object.keys(cards).slice(0, requestedCount)) {
            const cardRef = cardsRef.child(key);
            const original = cards[key];
            let tx = null;
            for (let attempt = 0; attempt < 3; attempt++) {
                const warmSnapshot = await cardRef.once('value');
                const warmedValue = warmSnapshot.val();
                tx = await cardRef.transaction(current => {
                    const candidate = current === null || current === undefined ? warmedValue : current;
                    if (!candidate) return;
                    if (candidate._kovaReservation && candidate._kovaReservation !== operationId) return;
                    if (candidate._kovaReservation === operationId) return candidate;
                    if (typeof candidate === 'string') return { code: candidate, _kovaReservation: operationId, reservedAt: Date.now() };
                    return { ...candidate, _kovaReservation: operationId, reservedAt: Date.now() };
                });
                if (tx.committed) break;
                if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 200));
            }
            if (!tx || !tx.committed) break;
            const current = tx.snapshot.val();
            reserved.push({ key, original, code: typeof current === 'string' ? current : (current.code || current.cardCode || current.value || key) });
        }
        if (reserved.length !== requestedCount) {
            const restore = {};
            reserved.forEach(item => { restore['kova_store/' + pkgId + '/cards/' + item.key] = item.original; });
            if (Object.keys(restore).length) await db.ref().update(restore);
            await auditRef.update({ status: 'rejected_stock', updatedAt: Date.now() });
            return res.status(400).json({ success: false, error: 'عدد الكروت غير متوفر' });
        }

        const balanceRef = db.ref('users/' + fromPhone + '/balance');
        const warmedBalance = Number((await balanceRef.once('value')).val()) || 0;
        const balanceTx = await transactionWithWarmValue(balanceRef, current => {
            const balance = Number(current === null || current === undefined ? warmedBalance : current) || 0;
            return balance < totalAmount ? undefined : balance - totalAmount;
        }, 'خصم رصيد شراء SMS');
        if (!balanceTx.committed) throw new Error('الرصيد غير كافٍ');
        balanceDebited = true;
        // 🔧 الإصلاح 4: شراء كرت يخصم من رصيد المشتري (يذهب للخزينة) ⇒ totalBalance -totalAmount
        await _updateStatsSummary({ balanceDelta: -totalAmount });
        const newBalance = Number(balanceTx.snapshot.val()) || 0;
        const ts = Date.now();
        const dateStr = new Date(ts).toLocaleString('ar-YE');
        const codes = reserved.map(item => item.code);
        // ✅ [إصلاح 3] نفس الدالة الموحدة: الشراء عبر SMS يحدّث الكروت + العدّاد العام + السجل + الإشعار في عملية واحدة
        // (حتى لو كان هاتف المستخدم بلا إنترنت: يجد الكرت في سجله وإشعاراته عند عودته)
        saleWrite = await _sellCardToUser({ buyerPhone: fromPhone, recipient, packageId: pkgId, packageData, reserved, price, totalAmount, newBalance, ts, dateStr, via: 'sms' });
        treasuryMovement = await recordTreasuryMovement(totalAmount, { type: 'card_sale_sms', packageId: pkgId, count: requestedCount, details: `بيع ${requestedCount} كرت من ${packageData.name || pkgId} عبر SMS`, performedBy: userData.fullName || fromPhone });
        treasuryMovement.amount = totalAmount;
        await auditRef.update({ status: 'completed', balanceAfter: newBalance, completedAt: ts, updatedAt: ts });

        // ✅ [إصلاح 3] إشعار FCM للمشتري (أفضل جهد): يصل عند عودة جهازه للإنترنت؛ المرجع الأساسي هو السجل والإشعار في Firebase
        await Promise.resolve().then(() => sendPush(fromPhone, 'تمت عملية شراء الباقة', `تم شراء ${requestedCount} كرت عبر SMS. الأكواد في سجل عملياتك. رصيدك ${fmtMoney(newBalance)} YER`, { persist: false }));

        if (recipient && recipient !== fromPhone) queuePendingNotification(recipient, {
            type: 'card_received', title: 'وصلك كرت', body: `تم شراء ${requestedCount} كرت`, packageId: pkgId, codes
        }).catch(error => console.error('❌ pending SMS card notification:', error.message));
        const response = { success: true, txId: operationId, newBalance, codes, message: `تم شراء ${requestedCount} كرت بنجاح` };
        await completeIdempotency(idempotency, response);
        return res.json(response);
    } catch (error) {
        console.error('❌ /sms/purchase-package فشل:', error);
        try {
            const restore = _buildCardSaleRollbackUpdates({ saleWrite, buyerPhone: fromPhone, packageId: pkgId, reserved, treasuryMovement });
            if (Object.keys(restore).length) await db.ref().update(restore);
            if (balanceDebited && fromPhone) await transactionWithWarmValue(db.ref('users/' + fromPhone + '/balance'), current => (Number(current) || 0) + totalAmount, 'rollback شراء SMS');
            // 🔧 الإصلاح 4: استرداد الرصيد يعيد ما خُصم من totalBalance (لا يُنفَّذ إن فشل الاسترداد نفسه)
            if (balanceDebited && fromPhone) await _updateStatsSummary({ balanceDelta: totalAmount });
            if (auditRef) await auditRef.update({ status: 'rolled_back', rollbackReason: error.message || 'unknown', updatedAt: Date.now() });
        } catch (rollbackError) { console.error('❌ rollback فشل:', rollbackError); }
        const insufficient = error.message === 'الرصيد غير كافٍ';
        return res.status(insufficient ? 400 : 500).json({ success: false, error: insufficient ? error.message : 'حدث خطأ داخلي وتم استرداد العملية' });
    }
});
// معالج أخطاء موحّد لأي مسار مرحّل يمرر الخطأ إلى Express.
// ============================================================
// 15. مسارات سداد وتعز تل وإدارة الأسعار
// ============================================================
const sadaqRoutes = require('./sadaq-routes')({
    db, fetch, verifyUserToken, transactionWithWarmValue, recordTreasuryMovement,
    updateStatsSummary: _updateStatsSummary   // 🔧 الإصلاح 4: خصم/استرداد رصيد سداد يُحدّث stats/summary
});
const sadaqPricingAdmin = require('./sadaq-pricing-admin')({ db, fetch, verifyAdmin });
app.use('/api/sadaq', sadaqRoutes);
app.use('/api/admin/sadaq/pricing', sadaqPricingAdmin);
app.get('/admin-pricing', (req, res) => {
    res.set('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self' capacitor://localhost https://localhost http://localhost https://kovant-backend3.onrender.com");
    res.removeHeader('X-Frame-Options');
    res.sendFile(require('path').join(__dirname, 'admin-sadaq-pricing.html'));
});
console.log('✅ مسارات سداد + إدارة الأسعار مفعّلة');

// ============================================================
// 15.5 ربط الواتساب (Baileys) — مسارات الأدمن فقط
//   GET  /api/whatsapp/qr      → يشغّل البوت ويرجع باركود Base64
//   POST /api/whatsapp/pair    → { phoneNumber } → رمز الربط (8 خانات)
//   GET  /api/whatsapp/status  → حالة الاتصال
//   POST /api/whatsapp/logout  → فك الربط ومسح الجلسة
// الجلسة (creds + keys) محفوظة في Firebase Realtime Database تحت whatsapp_session (قابل للتغيير بالمتغير WA_SESSION_PATH)
// فلا تضيع عند نوم Render المجاني، ويتصل السيرفر تلقائياً عند الاستيقاظ دون باركود جديد.
// ============================================================
const waAuth = require('./wa-firebase-auth');
const WA_SESSION_PATH = process.env.WA_SESSION_PATH || 'whatsapp_session';
const wa = {
    sock: null,
    status: 'disconnected',   // disconnected | connecting | qr | open | reconnecting | logged_out | error
    qr: null,
    me: null,
    lastError: '',
    startedAt: 0,
    starting: false,
    retry: 0,
    retryTimer: null,
    loggingOut: false,
    authFlush: null
};
let waLib = null;
const waSleep = (ms) => new Promise(r => setTimeout(r, ms));

// تحميل كسول: إن لم تُثبَّت المكتبة لا يتعطل السيرفر، بل تُرجع المسارات خطأً واضحاً
function waLoadLib() {
    if (waLib) return waLib;
    const m = require('@whiskeysockets/baileys');
    waLib = {
        makeWASocket: m.default || m.makeWASocket,
        initAuthCreds: m.initAuthCreds,
        BufferJSON: m.BufferJSON,
        proto: m.proto,
        makeCacheableSignalKeyStore: m.makeCacheableSignalKeyStore,
        DisconnectReason: m.DisconnectReason,
        fetchLatestBaileysVersion: m.fetchLatestBaileysVersion,
        Browsers: m.Browsers,
        pino: require('pino')
    };
    return waLib;
}

async function waClearAuth() {
    try { await waAuth.clearSession(db, WA_SESSION_PATH); } catch (e) { console.error('⚠️ WhatsApp: تعذّر مسح الجلسة من Firebase:', e.message); }
}

async function waHasSession() {
    try { return await waAuth.hasRegisteredSession(db, WA_SESSION_PATH); } catch (e) { console.error('⚠️ WhatsApp: تعذّر قراءة الجلسة من Firebase:', e.message); return false; }
}

// ضمان الاتصال قبل الإرسال: بعد استيقاظ Render يحتاج الاتصال بضع ثوانٍ، فننتظره بدل الفشل فوراً
async function waEnsureConnected(timeoutMs) {
    if (wa.status === 'open') return true;
    if (wa.status === 'logged_out' || wa.status === 'qr') return false;
    if (!wa.sock && !wa.starting && wa.status !== 'reconnecting') {
        if (!(await waHasSession())) return false;
        waStart().catch(e => console.error('⚠️ WhatsApp ensure:', e.message));
    }
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline && wa.status !== 'open') {
        if ((wa.status === 'logged_out' || wa.status === 'qr' || wa.status === 'error') && !wa.starting) break;
        await waSleep(250);
    }
    return wa.status === 'open';
}

function waScheduleRetry(delayMs) {
    clearTimeout(wa.retryTimer);
    const delay = delayMs != null ? delayMs : Math.min(30000, 2000 * Math.pow(2, Math.min(wa.retry++, 4)));
    wa.retryTimer = setTimeout(() => { waStart().catch(e => console.error('⚠️ WhatsApp retry:', e.message)); }, delay);
}

function waOnConnection(sock, update) {
    if (sock !== wa.sock) return; // حدث من اتصال قديم
    try {
        const { connection, lastDisconnect, qr } = update;
        if (qr) {
            wa.qr = qr;
            wa.status = 'qr';
            try { require('qrcode-terminal').generate(qr, { small: true }); } catch (_) {}
        }
        if (connection === 'connecting' && wa.status !== 'qr') wa.status = 'connecting';
        if (connection === 'open') {
            wa.status = 'open';
            wa.qr = null;
            wa.retry = 0;
            wa.lastError = '';
            const id = (sock.user && sock.user.id) || '';
            wa.me = { number: id.split(':')[0].split('@')[0], name: (sock.user && sock.user.name) || '' };
            console.log('✅ WhatsApp متصل:', wa.me.number);
        }
        if (connection === 'close') {
            const L = waLoadLib();
            const err = lastDisconnect && lastDisconnect.error;
            const code = err && err.output && err.output.statusCode;
            const registered = !!(sock.authState && sock.authState.creds && sock.authState.creds.registered);
            wa.qr = null;
            wa.me = null;
            wa.sock = null;
            if (wa.loggingOut) { wa.status = 'disconnected'; return; }
            if (code === L.DisconnectReason.loggedOut) {
                waClearAuth();
                wa.status = 'logged_out';
                wa.lastError = 'تم فك الربط من الهاتف';
                return;
            }
            if (code === L.DisconnectReason.connectionReplaced) {
                // جلسة الواتساب مشتركة عبر Firebase: نسخة أخرى من السيرفر اتصلت بها. لا نعيد المحاولة كي لا نتصارع معها.
                wa.status = 'error';
                wa.lastError = 'اتصال الواتساب استُبدل بنسخة أخرى من السيرفر';
                return;
            }
            wa.lastError = (err && err.message) || '';
            if (!registered && code !== L.DisconnectReason.restartRequired) {
                // لم يتم الربط بعد (انتهت مهلة الباركود): نتوقف بدل توليد باركودات بلا نهاية
                wa.status = 'disconnected';
                return;
            }
            wa.status = 'reconnecting';
            waScheduleRetry(code === L.DisconnectReason.restartRequired ? 500 : undefined);
        }
    } catch (e) {
        console.error('⚠️ WhatsApp connection.update:', e.message);
    }
}

async function waStart() {
    if (wa.starting) return;
    if (wa.sock && ['connecting', 'qr', 'open'].includes(wa.status)) return;
    wa.starting = true;
    clearTimeout(wa.retryTimer);
    try {
        const L = waLoadLib();
        if (wa.authFlush) { try { await wa.authFlush(); } catch (_) {} }   // لا نقرأ الجلسة قبل اكتمال آخر كتابة في Firebase
        const { state, saveCreds, flush } = await waAuth.useFirebaseAuthState(db, WA_SESSION_PATH, L);
        wa.authFlush = flush;
        const logger = L.pino({ level: 'silent' });
        const authState = (typeof L.makeCacheableSignalKeyStore === 'function')
            ? { creds: state.creds, keys: L.makeCacheableSignalKeyStore(state.keys, logger) }
            : state;
        let version;
        try { version = (await L.fetchLatestBaileysVersion()).version; } catch (_) { /* نستخدم إصدار المكتبة الافتراضي */ }
        const sock = L.makeWASocket({
            auth: authState,
            version,
            logger,
            printQRInTerminal: false,
            browser: L.Browsers && L.Browsers.ubuntu ? L.Browsers.ubuntu('Chrome') : ['Ubuntu', 'Chrome', '22.04.4'],
            markOnlineOnConnect: false,
            syncFullHistory: false,
            generateHighQualityLinkPreview: false
        });
        wa.sock = sock;
        wa.status = 'connecting';
        wa.qr = null;
        wa.startedAt = Date.now();
        sock.ev.on('creds.update', async () => {
            try { await saveCreds(); } catch (e) { console.error('⚠️ WhatsApp saveCreds (Firebase):', e.message); }
        });
        sock.ev.on('connection.update', (u) => waOnConnection(sock, u));
        if (sock.ws && typeof sock.ws.on === 'function') {
            sock.ws.on('error', (e) => { wa.lastError = (e && e.message) || 'ws error'; });
        }
    } catch (e) {
        wa.sock = null;
        wa.status = 'error';
        wa.lastError = e && e.code === 'MODULE_NOT_FOUND'
            ? 'مكتبة Baileys غير مثبتة على السيرفر (npm install)'
            : ((e && e.message) || 'فشل تشغيل الواتساب');
        console.error('⚠️ WhatsApp start:', wa.lastError);
    } finally {
        wa.starting = false;
    }
}

// تحويل رقم الزبون إلى صيغة دولية (يمني افتراضياً): 7XXXXXXXX أو 07XXXXXXXX → 967XXXXXXXXX
function waNormalizePhone(phone) {
    let d = String(phone || '').replace(/\D/g, '').replace(/^00/, '');
    if (d.length === 9 && d.startsWith('7')) d = '967' + d;
    else if (d.length === 10 && d.startsWith('07')) d = '967' + d.slice(1);
    return d;
}
// إرسال متسلسل مع فاصل عشوائي 1.5–3.5 ثانية بين الرسائل (يقلل خطر الحظر)
let waSendChain = Promise.resolve();
function waSendText(phone, text) {
    const run = async () => {
        if (!wa.sock || wa.status !== 'open') throw new Error('الواتساب غير متصل');
        const digits = waNormalizePhone(phone);
        if (digits.length < 9 || digits.length > 15) throw new Error('رقم غير صالح');
        let jid = digits + '@s.whatsapp.net';
        try {
            const found = await wa.sock.onWhatsApp(digits);
            if (found && found[0]) {
                if (found[0].exists === false) throw new Error('الرقم غير مسجّل في واتساب');
                if (found[0].jid) jid = found[0].jid;
            }
        } catch (e) {
            if (/غير مسجّل/.test(e.message)) throw e;   // أخطاء الفحص الأخرى لا تمنع المحاولة
        }
        await wa.sock.sendMessage(jid, { text: String(text) });
        return jid;
    };
    const p = waSendChain.then(run, run);
    // الفاصل العشوائي يُطبَّق قبل الرسالة التالية، فلا يتأخر ردّ الرسالة الحالية
    waSendChain = p.catch(() => {}).then(() => waSleep(1500 + Math.floor(Math.random() * 2000)));
    return p;
}

// الانتظار حتى يتوفر باركود (أو يتصل، أو يفشل)
async function waWaitForQr(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline && !wa.qr && wa.status !== 'open' && wa.status !== 'error' && wa.status !== 'logged_out') {
        await waSleep(300);
    }
}

async function waAdminOnly(req, res, next) {
    try {
        const adminInfo = await verifyAdmin(req);
        if (!adminInfo.isAdmin) return res.status(403).json({ success: false, error: 'غير مصرح' });
        next();
    } catch (e) {
        res.status(500).json({ success: false, error: 'خطأ داخلي' });
    }
}
const waLimiter = rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false, message: { success: false, error: 'طلبات كثيرة، حاول بعد دقيقة' } });

app.get('/api/whatsapp/status', waAdminOnly, (req, res) => {
    res.json({
        success: true,
        status: wa.status,
        connected: wa.status === 'open',
        me: wa.me,
        hasQr: !!wa.qr,
        error: wa.lastError || null,
        uptimeSec: wa.status === 'open' && wa.startedAt ? Math.floor((Date.now() - wa.startedAt) / 1000) : 0
    });
});

app.get('/api/whatsapp/qr', waLimiter, waAdminOnly, async (req, res) => {
    try {
        if (wa.status === 'open') return res.json({ success: true, status: 'open', connected: true, me: wa.me });
        await waStart();
        await waWaitForQr(15000);
        if (wa.status === 'open') return res.json({ success: true, status: 'open', connected: true, me: wa.me });
        if (!wa.qr) {
            return res.status(503).json({ success: false, status: wa.status, error: wa.lastError || 'لم يُولَّد الباركود بعد، حاول مرة أخرى' });
        }
        const image = await require('qrcode').toDataURL(wa.qr, { margin: 2, width: 320, errorCorrectionLevel: 'M' });
        res.json({ success: true, status: 'qr', connected: false, qr: image });
    } catch (e) {
        console.error('⚠️ /api/whatsapp/qr:', e.message);
        res.status(500).json({ success: false, error: 'تعذّر توليد الباركود' });
    }
});

app.post('/api/whatsapp/pair', waLimiter, waAdminOnly, async (req, res) => {
    try {
        const digits = String((req.body && req.body.phoneNumber) || '').replace(/\D/g, '').replace(/^00/, '');
        if (digits.length < 8 || digits.length > 15) {
            return res.status(400).json({ success: false, error: 'رقم الهاتف غير صالح — اكتبه بالصيغة الدولية بدون + (مثال: 967771234567)' });
        }
        if (wa.status === 'open') return res.status(409).json({ success: false, status: 'open', error: 'الواتساب مربوط بالفعل' });
        await waStart();
        await waWaitForQr(15000);   // ظهور الباركود = الاتصال جاهز لطلب رمز الربط
        if (wa.status === 'open') return res.status(409).json({ success: false, status: 'open', error: 'الواتساب مربوط بالفعل' });
        if (!wa.sock || !wa.qr) {
            return res.status(503).json({ success: false, status: wa.status, error: wa.lastError || 'الاتصال بواتساب غير جاهز، حاول مرة أخرى' });
        }
        if (wa.sock.authState && wa.sock.authState.creds && wa.sock.authState.creds.registered) {
            return res.status(409).json({ success: false, error: 'هذه الجلسة مربوطة مسبقاً' });
        }
        const raw = await wa.sock.requestPairingCode(digits);
        const code = String(raw || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        res.json({ success: true, code: code.length === 8 ? code.slice(0, 4) + '-' + code.slice(4) : code, raw: code });
    } catch (e) {
        console.error('⚠️ /api/whatsapp/pair:', e.message);
        res.status(500).json({ success: false, error: 'تعذّر الحصول على رمز الربط' });
    }
});

// اختبار إرسال (للأدمن): { phone, text }
app.post('/api/whatsapp/send', waLimiter, waAdminOnly, async (req, res) => {
    try {
        const phone = req.body && req.body.phone;
        const text = String((req.body && req.body.text) || '').slice(0, 1000);
        if (!phone || !text) return res.status(400).json({ success: false, error: 'phone و text مطلوبان' });
        const jid = await waSendText(phone, text);
        res.json({ success: true, jid });
    } catch (e) {
        res.status(502).json({ success: false, error: e.message || 'فشل الإرسال' });
    }
});

app.post('/api/whatsapp/logout', waLimiter, waAdminOnly, async (req, res) => {
    try {
        wa.loggingOut = true;
        clearTimeout(wa.retryTimer);
        try { if (wa.sock) await wa.sock.logout(); } catch (_) {}
        try { if (wa.sock && wa.sock.end) wa.sock.end(undefined); } catch (_) {}
        wa.sock = null; wa.qr = null; wa.me = null; wa.status = 'disconnected'; wa.lastError = '';
        await waClearAuth();
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ success: false, error: 'تعذّر فك الربط' });
    } finally {
        wa.loggingOut = false;
    }
});

// استئناف الجلسة تلقائياً عند تشغيل السيرفر/استيقاظه من النوم: تُقرأ من Firebase ويتصل مباشرة دون باركود
async function waAutoResume() {
    try {
        if (await waHasSession()) {
            console.log('🔄 WhatsApp: استئناف الجلسة المحفوظة في Firebase');
            await waStart();
        } else {
            console.log('ℹ️ WhatsApp: لا توجد جلسة محفوظة — اربط الواتساب من لوحة الأدمن');
        }
    } catch (e) { console.error('⚠️ WhatsApp resume:', e.message); }
}
// مكتبة الواتساب قد ترمي رفضاً غير ملتقَط — لا نسمح له بإسقاط السيرفر
process.on('unhandledRejection', (reason) => {
    console.error('⚠️ unhandledRejection:', reason && reason.message ? reason.message : reason);
});
console.log('✅ مسارات ربط الواتساب (Baileys) مفعّلة');

app.use(errorHandler);

// ============================================================
// 16. تشغيل الخادم
// ============================================================
const PORT = process.env.PORT || 3000;
if (require.main === module) {
    app.listen(PORT, () => {
        console.log(`✅ خادم كوفانت يعمل على المنفذ ${PORT}`);
        console.log('🔐 الأسرار الإلزامية مضبوطة والتحصينات الأمنية مفعلة');
        console.log(`📡 API_BASE_URL: ${process.env.API_BASE_URL ? '✓ مضبوط' : '⚠️ غير مضبوط'}`);
        console.log(`📱 نقطة /activate جاهزة لتلقي طلبات التفعيل من البوت`);
        waAutoResume().catch(e => console.error('⚠️ WhatsApp resume:', e.message));
    });
}

module.exports = app;
