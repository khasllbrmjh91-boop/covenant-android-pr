/* ============================================================
   kv-qr.js — باركود كوفانت المشفّر
   ------------------------------------------------------------
   • encode(account)  : رقم الحساب  → نص مشفّر (AES-GCM) يوضع داخل الباركود
   • decode(text)     : النص الممسوح → رقم الحساب، أو null إن لم يكن باركود كوفانت
   • renderSvg(model) : رسم الباركود بلون كوفانت مع الشعار في المنتصف
   أي قارئ باركود خارجي سيرى نصاً عشوائياً غير مفهوم فقط؛
   ولا يستطيع فكّه إلا التطبيق نفسه.
   ============================================================ */
(function (root) {
    'use strict';

    var VERSION = 1;
    var IV_LEN = 12;
    var TAG_BITS = 96;                 // وسم تحقق 12 بايت لإبقاء الباركود صغيراً
    var ACC_BYTES = 5;                 // رقم الحساب (10 أرقام) في 5 بايت
    var TOTAL_LEN = 1 + IV_LEN + ACC_BYTES + TAG_BITS / 8;
    var ACCOUNT_RE = /^(40|41)\d{8}$/;
    var APP_SECRET = 'KOVANT/COVA-NET/QR/v1/7f3c9a52-b1d4-4e86-9c0a-5d2e8b6f1a47';
    var AAD = new TextEncoder().encode('KOVANT-QR-1');

    var BRAND_BLUE = '#1a6fa8';        // نفس أزرق بطاقة الرصيد في صفحة المستخدم
    var _keyPromise = null;

    function subtle() {
        var c = root.crypto;
        if (!c || !c.subtle) throw new Error('التشفير غير مدعوم على هذا الجهاز');
        return c.subtle;
    }

    function getKey() {
        if (!_keyPromise) {
            _keyPromise = subtle().digest('SHA-256', new TextEncoder().encode(APP_SECRET)).then(function (raw) {
                return subtle().importKey('raw', raw, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
            });
        }
        return _keyPromise;
    }

    function toB64u(bytes) {
        var s = '';
        for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
        return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }

    function fromB64u(str) {
        var b = String(str).replace(/-/g, '+').replace(/_/g, '/');
        while (b.length % 4) b += '=';
        var s = atob(b);
        var out = new Uint8Array(s.length);
        for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
        return out;
    }

    function accountToBytes(account) {
        var n = Number(account), out = new Uint8Array(ACC_BYTES);
        for (var i = ACC_BYTES - 1; i >= 0; i--) { out[i] = n % 256; n = Math.floor(n / 256); }
        return out;
    }

    function bytesToAccount(bytes) {
        var n = 0;
        for (var i = 0; i < bytes.length; i++) n = n * 256 + bytes[i];
        return String(n).padStart(10, '0');
    }

    async function encode(account) {
        account = String(account == null ? '' : account).trim();
        if (!ACCOUNT_RE.test(account)) throw new Error('رقم حساب غير صالح');
        var key = await getKey();
        var iv = root.crypto.getRandomValues(new Uint8Array(IV_LEN));
        var ct = new Uint8Array(await subtle().encrypt(
            { name: 'AES-GCM', iv: iv, additionalData: AAD, tagLength: TAG_BITS }, key, accountToBytes(account)));
        var out = new Uint8Array(1 + IV_LEN + ct.length);
        out[0] = VERSION;
        out.set(iv, 1);
        out.set(ct, 1 + IV_LEN);
        return toB64u(out);
    }

    // يعيد رقم الحساب أو null إذا لم يكن النص باركود كوفانت صحيحاً
    async function decode(text) {
        try {
            var s = String(text == null ? '' : text).trim();
            if (!/^[A-Za-z0-9_-]+$/.test(s)) return null;
            var bytes = fromB64u(s);
            if (bytes.length !== TOTAL_LEN || bytes[0] !== VERSION) return null;
            var key = await getKey();
            var pt = new Uint8Array(await subtle().decrypt(
                { name: 'AES-GCM', iv: bytes.slice(1, 1 + IV_LEN), additionalData: AAD, tagLength: TAG_BITS },
                key, bytes.slice(1 + IV_LEN)));
            var acc = bytesToAccount(pt);
            return ACCOUNT_RE.test(acc) ? acc : null;
        } catch (e) {
            return null;
        }
    }

    /* ---------------- الرسم ---------------- */

    function modelFromText(text) {
        if (typeof root.QRCode !== 'function') throw new Error('مكتبة QR غير متاحة');
        var holder = root.document.createElement('div');
        var q = new root.QRCode(holder, {
            text: text, width: 256, height: 256,
            colorDark: '#000000', colorLight: '#ffffff',
            correctLevel: root.QRCode.CorrectLevel.H
        });
        if (!q._oQRCode) throw new Error('تعذر إنشاء الباركود');
        return q._oQRCode;
    }

    function r(n) { return Math.round(n * 100) / 100; }

    function roundRect(x, y, w, h, rad) {
        if (!rad) return 'M' + r(x) + ' ' + r(y) + 'h' + r(w) + 'v' + r(h) + 'h' + r(-w) + 'z';
        return 'M' + r(x + rad) + ' ' + r(y) + 'h' + r(w - 2 * rad) + 'a' + r(rad) + ' ' + r(rad) + ' 0 0 1 ' + r(rad) + ' ' + r(rad) +
            'v' + r(h - 2 * rad) + 'a' + r(rad) + ' ' + r(rad) + ' 0 0 1 ' + r(-rad) + ' ' + r(rad) +
            'h' + r(-(w - 2 * rad)) + 'a' + r(rad) + ' ' + r(rad) + ' 0 0 1 ' + r(-rad) + ' ' + r(-rad) +
            'v' + r(-(h - 2 * rad)) + 'a' + r(rad) + ' ' + r(rad) + ' 0 0 1 ' + r(rad) + ' ' + r(-rad) + 'z';
    }

    // ملاحظة: المربعات الثلاثة (finder) تبقى حادة الزوايا عمداً — تدويرها يُضعف القراءة (اختُبر: 11/14 مقابل 14/14)
    // يبني SVG من نموذج QR (getModuleCount / isDark)
    function renderSvg(model, opts) {
        opts = opts || {};
        var color = opts.color || BRAND_BLUE;
        var bg = opts.background || '#ffffff';
        var n = model.getModuleCount();
        var margin = 2;
        var total = n + margin * 2;

        // قطر الشعار ≈ 26% من عرض الباركود (ضمن قدرة التصحيح H = 30% من المساحة)
        var logoD = Math.max(7, Math.round(n * 0.26));
        if (logoD % 2 === 0) logoD += 1;
        var c = n / 2;
        var clearR = logoD / 2 + 0.6;

        function inFinder(row, col) {
            return (row < 7 && col < 7) || (row < 7 && col >= n - 7) || (row >= n - 7 && col < 7);
        }

        var d = '';
        for (var row = 0; row < n; row++) {
            for (var col = 0; col < n; col++) {
                if (!model.isDark(row, col) || inFinder(row, col)) continue;
                var dx = col + 0.5 - c, dy = row + 0.5 - c;
                if (dx * dx + dy * dy < clearR * clearR) continue;      // مساحة الشعار
                d += roundRect(col + margin + 0.04, row + margin + 0.04, 0.92, 0.92, 0.28);
            }
        }

        var finders = '';
        [[0, 0], [n - 7, 0], [0, n - 7]].forEach(function (p) {
            var x = p[0] + margin, y = p[1] + margin;
            finders += '<path fill="' + color + '" fill-rule="evenodd" d="' +
                roundRect(x, y, 7, 7, 0) + roundRect(x + 1, y + 1, 5, 5, 0) + '"/>' +
                '<path fill="' + color + '" d="' + roundRect(x + 2, y + 2, 3, 3, 0) + '"/>';
        });

        // شعار كوفانت: بلاطة زرقاء بإشارة واي فاي بيضاء (نفس أيقونة التطبيق)
        var cx = c + margin, cy = c + margin, s = (logoD - 0.8) / 100;
        var logo =
            '<circle cx="' + r(cx) + '" cy="' + r(cy) + '" r="' + r(logoD / 2) + '" fill="' + bg + '"/>' +
            '<g transform="translate(' + r(cx - (logoD - 0.8) / 2) + ' ' + r(cy - (logoD - 0.8) / 2) + ') scale(' + s.toFixed(5) + ')">' +
            '<rect x="6" y="6" width="88" height="88" rx="26" fill="' + color + '"/>' +
            '<path d="M24 47.5A37 37 0 0 1 76 47.5" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round"/>' +
            '<path d="M35.5 59A21 21 0 0 1 64.5 59" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round"/>' +
            '<circle cx="50" cy="71" r="6" fill="#fff"/></g>';

        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + total + ' ' + total +
            '" shape-rendering="geometricPrecision"><rect width="' + total + '" height="' + total + '" fill="' + bg + '"/>' +
            '<path fill="' + color + '" d="' + d + '"/>' + finders + logo + '</svg>';
    }

    // يبني SVG لحساب معيّن (مشفّر)
    async function buildForAccount(account, opts) {
        var payload = await encode(account);
        return { payload: payload, svg: renderSvg(modelFromText(payload), opts) };
    }

    // SVG → صورة PNG (للحفظ والمشاركة). ينتج لوحة بيضاء فيها الباركود + اسم المستخدم + رقم الحساب
    function svgToImage(svg, size) {
        return new Promise(function (resolve, reject) {
            var img = new root.Image();
            img.onload = function () { resolve(img); };
            img.onerror = function () { reject(new Error('تعذر تحويل الباركود')); };
            img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
                svg.replace('<svg ', '<svg width="' + size + '" height="' + size + '" '));
        });
    }

    async function toPngBlob(svg, info) {
        var qrSize = 720, pad = 56, headH = info && info.name ? 120 : 0, footH = info && info.account ? 120 : 0;
        var W = qrSize + pad * 2, H = qrSize + pad * 2 + headH + footH;
        var canvas = root.document.createElement('canvas');
        canvas.width = W; canvas.height = H;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);
        var img = await svgToImage(svg, qrSize);
        ctx.drawImage(img, pad, pad + headH, qrSize, qrSize);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        if (headH) {
            ctx.fillStyle = BRAND_BLUE; ctx.font = '800 44px Cairo, Tahoma, sans-serif';
            ctx.fillText(info.name, W / 2, pad + 40, qrSize);
        }
        if (footH) {
            ctx.fillStyle = '#334155'; ctx.font = '700 46px monospace';
            ctx.fillText(info.account, W / 2, H - pad - 30);
        }
        return new Promise(function (resolve, reject) {
            canvas.toBlob(function (b) { b ? resolve(b) : reject(new Error('تعذر إنشاء الصورة')); }, 'image/png');
        });
    }

    root.KVQR = {
        encode: encode, decode: decode,
        renderSvg: renderSvg, buildForAccount: buildForAccount, toPngBlob: toPngBlob,
        BRAND_BLUE: BRAND_BLUE, ACCOUNT_RE: ACCOUNT_RE
    };
})(typeof window !== 'undefined' ? window : globalThis);
