/* ============================================================
   COVA NET — WiFi Monitor
   جامع بيانات شبكات كوفانت في الخلفية (صامت)
   ─────────────────────────────────────────────────────────
   ✅ يرفع إلى Firebase: wifi_monitoring/{phone}/{pushKey}
   ✅ لا يتعارض مع wifi-module.js
   ✅ يستخدم TuaWifiManager الموجود
   ✅ ينتظر waitForFirebaseAuth قبل كل كتابة
============================================================ */
(function() {
    'use strict';
    if (window.__WIFI_MONITOR_LOADED__) return;
    window.__WIFI_MONITOR_LOADED__ = true;

    // ✅ [إصلاح 2] ثوابت واضحة في أعلى الملف للتحكم في استهلاك Firebase
    // الاحتفاظ بالبيانات 7 أيام بدل 30 → أقل بيانات مخزّنة وأقل قراءة
    const RETENTION_DAYS = 7;
    // فترة المسح 15 دقيقة بدل 5 → عدد عمليات الرفع أقل بثلاث مرات
    const SCAN_INTERVAL = 15 * 60 * 1000;
    // نرفع الشبكة فقط إذا تغيّرت قوة إشارتها أكثر من 10 dBm (أو ظهرت جديدة)
    const SIGNAL_CHANGE_DBM = 10;
    // ✅ [تعديل 1] الرفع الدوري الذكي: كل 30 دقيقة، إن لم يتغيّر شيء، نحدّث فقط حقل timestamp
    // في آخر سجل مرفوع (حقل واحد ≈ 13 بايت) ليبقى "آخر ظهور" في صفحة الأدمن حديثاً
    const FORCE_REFRESH_MS = 30 * 60 * 1000;
    // رفع كامل إجباري مرة كل 24 ساعة (يعيد إرسال الحقول الثابتة ويحمي من حذف التنظيف لآخر سجل)
    const FULL_REFRESH_MS = 24 * 60 * 60 * 1000;
    // الحذف على دفعات: 50 سجلاً في كل مرة وبحد أقصى 5 مرات في كل فتح للتطبيق
    const CLEANUP_BATCH = 50;
    const CLEANUP_MAX_LOOPS = 5;
    // إعادة إرسال اسم المستخدم/الحساب/الجهاز مرة كل 24 ساعة فقط (بدل كل مسح)
    const IDENTITY_REFRESH_MS = 24 * 60 * 60 * 1000;

    const WM_CONFIG = {
        firstRunDelay: 30 * 1000,
        minRssi: -95,
        kovantRegex: /coav|cova|kovant|كوفا|كوفانت/i,
        uploadAllNetworks: true,   // رفع كل الشبكات الظاهرة وليس كوفانت فقط
        maxOtherNetworks: 15,      // الحد الأقصى للشبكات غير كوفانت في كل مسح (الأقوى + المتصل بها)
        otherMinRssi: -85,
        storageKey: 'kovant_wifi_monitor_last_run',
        debug: false
    };

    const _wm = {
        running: false, timer: null, lastRun: 0, uploading: false,
        totalScans: 0, totalNetworksUploaded: 0, lastError: null,
        identityTs: 0,
        lastKey: null, lastKeyPhone: null, lastBeatTs: 0, lastFullTs: 0
    };

    // ✅ [إصلاح 2] ذاكرة محلية لآخر نسخة تم رفعها لكل شبكة (المفتاح: BSSID أو SSID)
    // تُستخدم لمقارنة المسح الجديد ورفع الشبكات الجديدة/المتغيّرة فقط
    const _wmKnown = new Map();

    function _wmKey(net) {
        return (net.BSSID || net.bssid || net.SSID || '');
    }

    // يُرجع الشبكات الجديدة أو التي تغيّرت فقط (مع علامة isNew)
    function _wmFilterChanged(networks) {
        const now = Date.now();
        const out = [];
        const seen = {};
        networks.forEach(function(net) {
            const key = _wmKey(net);
            if (!key || seen[key]) return;
            seen[key] = true;
            const prev = _wmKnown.get(key);
            const level = (typeof net.level === 'number') ? net.level : null;
            const connected = net.isConnected === true;
            let changed = false;
            if (!prev) changed = true;                                   // شبكة جديدة
            else if (prev.connected !== connected) changed = true;       // تغيّرت حالة الاتصال (مهمة لإحصاء الاتصال)
            else if ((level === null) !== (prev.level === null)) changed = true;
            else if (level !== null && Math.abs(level - prev.level) > SIGNAL_CHANGE_DBM) changed = true; // تغيّر جوهري بالإشارة
            if (changed) out.push({ net: net, isNew: !prev });
        });
        return out;
    }

    // بعد نجاح الرفع نحفظ النسخة المرفوعة كمرجع للمقارنة القادمة
    function _wmRemember(items) {
        const now = Date.now();
        items.forEach(function(it) {
            _wmKnown.set(_wmKey(it.net), {
                level: (typeof it.net.level === 'number') ? it.net.level : null,
                connected: it.net.isConnected === true,
                ts: now
            });
        });
    }

    function _wmLog() {
        if (WM_CONFIG.debug) console.log.apply(console, ['[WiFiMonitor]'].concat(Array.prototype.slice.call(arguments)));
    }

    function _wmWarn() {
        console.warn.apply(console, ['[WiFiMonitor]'].concat(Array.prototype.slice.call(arguments)));
    }

    function _wmGetPlugin() {
        return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TuaWifiManager) || null;
    }

    function _wmIsKovantSSID(ssid) {
        return !!(ssid && WM_CONFIG.kovantRegex.test(ssid));
    }

    function _wmGetLocation() {
        return new Promise(function(resolve) {
            if (!navigator.geolocation) { resolve(null); return; }
            navigator.geolocation.getCurrentPosition(
                function(pos) {
                    resolve({
                        lat: pos.coords.latitude,
                        lng: pos.coords.longitude,
                        accuracy: pos.coords.accuracy || null
                    });
                },
                function() { resolve(null); },
                { enableHighAccuracy: false, timeout: 8000, maximumAge: 5 * 60 * 1000 }
            );
        });
    }

    function _wmScanNetworks() {
        const Wifi = _wmGetPlugin();
        if (!Wifi) return Promise.resolve([]);
        return Wifi.checkPermissions().then(function(perms) {
            if (perms.location !== 'granted') return [];
            return Wifi.scan({ minRssi: WM_CONFIG.minRssi }).then(function(result) {
                return (result && result.networks) || [];
            });
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
            return [];
        });
    }

    function _wmSelectNetworks(networks) {
        const kovant = networks.filter(function(n) { return _wmIsKovantSSID(n.SSID); });
        if (!WM_CONFIG.uploadAllNetworks) return kovant;
        const others = networks.filter(function(n) {
            return !_wmIsKovantSSID(n.SSID) &&
                (n.isConnected === true || (typeof n.level === 'number' && n.level >= WM_CONFIG.otherMinRssi));
        }).sort(function(a, b) {
            return ((b.isConnected === true) - (a.isConnected === true)) ||
                   ((typeof b.level === 'number' ? b.level : -999) - (typeof a.level === 'number' ? a.level : -999));
        }).slice(0, WM_CONFIG.maxOtherNetworks);
        return kovant.concat(others);
    }

    // ✅ [إصلاح 2] items = [{net, isNew}] — الشبكات الجديدة/المتغيّرة فقط
    // نُبقي الحقول التي تقرأها صفحة الأدمن (ssid, bssid, level, isConnected, isKovant ...)
    // والحقول الثابتة الثقيلة (capabilities, channelWidth, frequency, channel, wifiStandard)
    // تُرسل مرة واحدة فقط عند أول ظهور للشبكة، لأن صفحة الأدمن تأخذ آخر قيمة موجودة
    // ونحذف dateStr و accuracy (غير مستخدمين) ونرسل الهوية (الاسم/الحساب/الجهاز) مرة كل 24 ساعة
    function _wmPreparePayload(items) {
        if (!window.APP || !APP.user || !APP.user.phone) return Promise.resolve(null);
        return _wmGetLocation().then(function(location) {
            const timestamp = Date.now();
            const uniqueNetworks = items.map(function(it) {
                const net = it.net;
                const bssid = net.BSSID || net.bssid || '';
                const o = {
                    ssid: net.SSID || '(مخفية)',
                    bssid: bssid || null,
                    level: (typeof net.level === 'number') ? net.level : null,
                    isConnected: net.isConnected === true,
                    isKovant: _wmIsKovantSSID(net.SSID)
                };
                if (net.isConnected === true && net.linkSpeed) o.linkSpeed = net.linkSpeed;
                if (it.isNew) {
                    if (net.frequency) o.frequency = net.frequency;
                    if (net.channel) o.channel = net.channel;
                    if (net.capabilities) o.capabilities = net.capabilities;
                    if (net.channelWidth) o.channelWidth = net.channelWidth;
                    if (net.wifiStandard) o.wifiStandard = net.wifiStandard;
                }
                return o;
            });
            const payload = {
                phone: APP.user.phone,
                timestamp: timestamp,
                lat: location ? location.lat : null,
                lng: location ? location.lng : null,
                networks: uniqueNetworks,
                networksCount: uniqueNetworks.length
            };
            if (timestamp - _wm.identityTs > IDENTITY_REFRESH_MS) {
                payload.userName = APP.user.fullName || APP.user.phone;
                payload.accountNumber = APP.user.accountNumber || null;
                payload.deviceName = (typeof getDeviceName === 'function') ? getDeviceName() : null;
                payload.__identity = true; // علامة داخلية تُحذف قبل الرفع
            }
            return payload;
        });
    }

    function _wmUpload(payload) {
        if (!payload) return Promise.resolve(false);
        const authWait = (typeof waitForFirebaseAuth === 'function')
            ? waitForFirebaseAuth()
            : Promise.resolve();
        return authWait.then(function() {
            if (typeof database === 'undefined') return false;
            const key = database.ref('wifi_monitoring/' + payload.phone).push().key;
            const identitySent = payload.__identity === true;
            const data = Object.assign({}, payload);
            delete data.__identity; // لا نخزّن العلامة الداخلية
            // ✅ [إصلاح 3] نكتب السجل + فهرس المستخدم (آخر ظهور واسم) في عملية واحدة
            // حتى تقرأ لوحة الأدمن قائمة المستخدمين من الفهرس الصغير بدل تحميل كل wifi_monitoring
            const multi = {};
            multi['wifi_monitoring/' + payload.phone + '/' + key] = data;
            multi['wifi_monitoring_index/' + payload.phone] = { last: data.timestamp, name: (APP.user && APP.user.fullName) || payload.phone };
            return database.ref().update(multi).then(function() {
                _wm.totalNetworksUploaded += payload.networksCount;
                if (identitySent) _wm.identityTs = Date.now();
                // ✅ [تعديل 1] نحفظ مفتاح آخر سجل كامل ليحدّث الرفع الدوري timestamp الخاص به
                _wm.lastKey = key;
                _wm.lastKeyPhone = payload.phone;
                _wm.lastBeatTs = Date.now();
                _wm.lastFullTs = Date.now();
                return true;
            });
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
            _wmWarn('❌ فشل الرفع:', _wm.lastError);
            return false;
        });
    }

    // ✅ [تعديل 1] رفع دوري خفيف: حقل واحد فقط (timestamp) في آخر سجل كامل
    // صفحة الأدمن تحسب "آخر ظهور" من timestamp أحدث سجل، وشبكات هذا السجل ما زالت صحيحة لأنها لم تتغيّر
    function _wmHeartbeat() {
        const authWait = (typeof waitForFirebaseAuth === 'function')
            ? waitForFirebaseAuth()
            : Promise.resolve();
        return authWait.then(function() {
            if (typeof database === 'undefined') return false;
            const now = Date.now();
            const hb = {};
            hb['wifi_monitoring/' + APP.user.phone + '/' + _wm.lastKey + '/timestamp'] = now;
            hb['wifi_monitoring_index/' + APP.user.phone + '/last'] = now;   // ✅ [إصلاح 3] نحدّث الفهرس مع نفس الطلب
            return database.ref().update(hb).then(function() {
                    _wm.lastBeatTs = now;
                    return true;
                });
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
            return false;
        });
    }

    function _wmRunOnce() {
        if (_wm.uploading) return Promise.resolve();
        if (!window.APP || !APP.user || !APP.user.phone) return Promise.resolve();
        if (document.hidden) return Promise.resolve();

        _wm.uploading = true;
        let changedItems = [];
        return _wmScanNetworks().then(function(all) {
            const selected = _wmSelectNetworks(all);
            if (selected.length === 0) return null;
            const now = Date.now();
            const fullDue = !_wm.lastKey || _wm.lastKeyPhone !== APP.user.phone ||
                            (now - _wm.lastFullTs > FULL_REFRESH_MS);
            if (fullDue) {
                // أول ظهور في الجلسة أو مرّت 24 ساعة: رفع كامل لكل الشبكات
                _wmKnown.clear();
            }
            // ✅ نرفع الجديد/المتغيّر فقط (شبكة جديدة، إشارة >10 dBm، حالة اتصال)
            changedItems = _wmFilterChanged(selected);
            if (changedItems.length > 0) {
                // نضمّن الشبكة المتصلة دائماً حتى لا تظهر الصفحة "غير متصل" بالخطأ
                const hasConn = changedItems.some(function(it) { return it.net.isConnected === true; });
                if (!hasConn) {
                    const c = selected.filter(function(n) { return n.isConnected === true; })[0];
                    if (c) changedItems.push({ net: c, isNew: false });
                }
                return _wmPreparePayload(changedItems).then(function(payload) {
                    if (!payload) return null;
                    return _wmUpload(payload).then(function(ok) {
                        if (ok) _wmRemember(changedItems);
                        return ok;
                    });
                });
            }
            // لا تغيير حقيقي: رفع دوري (timestamp فقط) إن مرّت 30 دقيقة منذ آخر رفع
            if (now - _wm.lastBeatTs >= FORCE_REFRESH_MS) return _wmHeartbeat();
            return null;
        }).then(function() {
            _wm.totalScans++;
            _wm.lastRun = Date.now();
            try { localStorage.setItem(WM_CONFIG.storageKey, String(_wm.lastRun)); } catch (e) {}
        }).catch(function(err) {
            _wm.lastError = err.message || String(err);
        }).then(function() {
            _wm.uploading = false;
        });
    }

    // ✅ [إصلاح 2] تنظيف على دفعات بدون قراءة السجل كاملاً
    // قبل: once('value') على كل wifi_monitoring/{phone} (كل الـ30 يوماً) عند كل فتح
    // بعد: نطلب فقط السجلات الأقدم من حد الاحتفاظ، 50 في كل مرة، وبحد أقصى 5 مرات
    // (يعتمد على .indexOn: timestamp الموجود في القواعد تحت wifi_monitoring/$phone)
    function _wmCleanupOldData() {
        if (!window.APP || !APP.user || !APP.user.phone) return Promise.resolve();
        const phone = APP.user.phone;
        const cutoff = Date.now() - (RETENTION_DAYS * 24 * 60 * 60 * 1000);
        const authWait = (typeof waitForFirebaseAuth === 'function')
            ? waitForFirebaseAuth()
            : Promise.resolve();
        const baseRef = function() { return database.ref('wifi_monitoring/' + phone); };

        function pass(loop) {
            if (loop >= CLEANUP_MAX_LOOPS) return Promise.resolve();
            return baseRef().orderByChild('timestamp').endAt(cutoff).limitToFirst(CLEANUP_BATCH).once('value')
                .then(function(snap) {
                    if (!snap.exists()) return null;           // فارغة = المستخدم نظيف، نتوقف
                    const updates = {};
                    snap.forEach(function(child) { updates[child.key] = null; });
                    return baseRef().update(updates).then(function() {
                        // إن رجعت أقل من 50 فلا يوجد المزيد، نتوقف بدون استعلام إضافي
                        if (snap.numChildren() < CLEANUP_BATCH) return null;
                        return pass(loop + 1);
                    });
                });
        }
        return authWait.then(function() { return pass(0); }).catch(function() {});
    }

    function _wmStartTimer() {
        if (_wm.timer) clearInterval(_wm.timer);
        _wm.timer = setInterval(_wmRunOnce, SCAN_INTERVAL);
    }

    function _wmStopTimer() {
        if (_wm.timer) {
            clearInterval(_wm.timer);
            _wm.timer = null;
        }
    }

    window.WiFiMonitor = {
        start: function() {
            if (_wm.running) return;
            _wm.running = true;
            // ✅ إعادة ضبط الذاكرة المحلية عند كل تسجيل دخول حتى لا تختلط بيانات مستخدمين
            _wmKnown.clear();
            _wm.lastKey = null; _wm.lastKeyPhone = null; _wm.lastBeatTs = 0; _wm.lastFullTs = 0; _wm.identityTs = 0;
            setTimeout(_wmRunOnce, WM_CONFIG.firstRunDelay);
            _wmStartTimer();
            setTimeout(_wmCleanupOldData, 2 * 60 * 1000);
        },
        stop: function() {
            _wm.running = false;
            _wmStopTimer();
        },
        runNow: _wmRunOnce,
        getStatus: function() {
            return {
                running: _wm.running,
                lastRun: _wm.lastRun,
                totalScans: _wm.totalScans,
                totalNetworksUploaded: _wm.totalNetworksUploaded,
                lastError: _wm.lastError
            };
        }
    };

    function _wmWatchUser() {
        let loggedIn = false;
        setInterval(function() {
            const hasUser = !!(window.APP && APP.user && APP.user.phone);
            if (hasUser && !loggedIn) {
                loggedIn = true;
                window.WiFiMonitor.start();
            } else if (!hasUser && loggedIn) {
                loggedIn = false;
                window.WiFiMonitor.stop();
            }
        }, 3000);

        document.addEventListener('visibilitychange', function() {
            if (!document.hidden && _wm.running) {
                const since = Date.now() - _wm.lastRun;
                if (since > SCAN_INTERVAL) {
                    setTimeout(_wmRunOnce, 3000);
                }
            }
        });
    }

    function _wmBootstrap() {
        _wmWatchUser();
        _wmLog('✅ WiFi Monitor loaded');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', _wmBootstrap);
    } else {
        _wmBootstrap();
    }
})();