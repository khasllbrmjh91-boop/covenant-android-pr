/* ============================================================
   android-ui.js — طبقة تحسينات الواجهة بنمط أندرويد
   1) مؤشر التحقق الموحّد (دائرة النقاط بلا مربع) في كل مكان
   2) بطاقة صلاحية الإشعارات في صفحة المستخدم الرئيسية
   3) القائمة الجانبية: بيانات المستخدم + سحب للإغلاق
   4) نسخ رقم الحساب من الملف الشخصي
   تُحمَّل بعد router.js وبقية ملفات المنطق، ولا تغيّر منطق العمل.
   ============================================================ */
(function (window, document) {
    'use strict';
    if (window.__AX_UI__) return;
    window.__AX_UI__ = true;

    var DOT_COUNT = 12;

    function $(id) { return document.getElementById(id); }
    function safe(fn) { try { return fn(); } catch (e) { return undefined; } }
    function toast(msg, ok) {
        if (typeof window.showAlert === 'function') window.showAlert(msg, ok);
    }

    /* ============================================================
       1) مؤشر التحقق الموحّد
       ============================================================ */
    function buildRing(extraClass) {
        var ring = document.createElement('div');
        ring.className = 'px-ring' + (extraClass ? ' ' + extraClass : '');
        ring.setAttribute('aria-hidden', 'true');
        for (var i = 0; i < DOT_COUNT; i++) {
            var dot = document.createElement('span');
            dot.className = 'px-dot';
            dot.style.setProperty('--i', i);
            ring.appendChild(dot);
        }
        return ring;
    }

    function showVerify() {
        if (window.PurchaseUX && window.PurchaseUX.showLoader) window.PurchaseUX.showLoader();
    }
    function hideVerify() {
        if (window.PurchaseUX && window.PurchaseUX.hideLoader) window.PurchaseUX.hideLoader();
    }

    // نوافذ "جارٍ التحقق / جارٍ إنشاء الحساب" في الدخول والتسجيل
    if (window.PurchaseUX) {
        window.showLoadingModal = function () { showVerify(); };

        var origClose = window.closeLoginModal;
        window.closeLoginModal = function () {
            hideVerify();
            if (typeof origClose === 'function') return origClose.apply(this, arguments);
        };
    }

    // SweetAlert: التحقق/التحويل/المسح تظهر كدائرة نقاط فقط بلا صندوق
    function patchSwal() {
        var S = window.Swal;
        if (!S || S.__axPatched) return;
        S.__axPatched = true;

        function cleanup() {
            var popup = safe(function () { return S.getPopup(); });
            if (popup) {
                popup.classList.remove('px-swal-loading');
                var r = popup.querySelector(':scope > .px-ring');
                if (r) r.remove();
            }
            var cont = safe(function () { return S.getContainer(); });
            if (cont) cont.classList.remove('px-swal-loading');
        }

        var origFire = S.fire;
        S.fire = function () { cleanup(); return origFire.apply(this, arguments); };

        var origClose2 = S.close;
        S.close = function () {
            var res = origClose2.apply(this, arguments);
            cleanup();
            return res;
        };

        S.showLoading = function () {
            var popup = safe(function () { return S.getPopup(); });
            if (!popup) return;
            var cont = safe(function () { return S.getContainer(); });
            if (!popup.querySelector(':scope > .px-ring')) popup.appendChild(buildRing());
            popup.classList.add('px-swal-loading');
            if (cont) cont.classList.add('px-swal-loading');
        };
    }
    patchSwal();
    window.addEventListener('load', patchSwal);

    // استبدال المؤشرات القديمة (.spinner و fa-spinner داخل حالات التحميل)
    function upgradeSpinners(root) {
        (root || document).querySelectorAll('.spinner:not(.px-ring)').forEach(function (el) {
            if (el.childElementCount) return;
            el.classList.add('px-ring', 'px-inline');
            for (var i = 0; i < DOT_COUNT; i++) {
                var dot = document.createElement('span');
                dot.className = 'px-dot';
                dot.style.setProperty('--i', i);
                el.appendChild(dot);
            }
        });
        (root || document).querySelectorAll('.empty-state i.fa-spinner, .empty-state i.fa-spin').forEach(function (el) {
            if (el.closest('button')) return;
            el.replaceWith(buildRing('px-inline'));
        });
    }

    var upTimer = 0;
    function scheduleUpgrade() {
        if (upTimer) return;
        upTimer = window.requestAnimationFrame(function () { upTimer = 0; upgradeSpinners(); });
    }

    /* ============================================================
       2) صلاحية الإشعارات في صفحة المستخدم الرئيسية
       ============================================================ */
    var DISMISS_KEY = 'ax_notif_card_dismissed_at';
    var DISMISS_MS = 3 * 24 * 3600 * 1000;
    var busy = false;

    function isNative() {
        return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
    }

    function getDismissed() {
        var t = safe(function () { return parseInt(localStorage.getItem(DISMISS_KEY) || '0', 10); }) || 0;
        return t && (Date.now() - t) < DISMISS_MS;
    }

    // 'granted' | 'denied' | 'prompt' | 'unsupported'
    async function getNotifState() {
        if (isNative()) {
            var LN = window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
            if (!LN || !LN.checkPermissions) return 'unsupported';
            try {
                var p = await LN.checkPermissions();
                if (p.display === 'granted') return 'granted';
                if (p.display === 'denied') return 'denied';
                return 'prompt';
            } catch (e) { return 'unsupported'; }
        }
        if (typeof Notification === 'undefined') return 'unsupported';
        if (Notification.permission === 'granted') return 'granted';
        if (Notification.permission === 'denied') return 'denied';
        return 'prompt';
    }

    function userPageVisible() {
        var ui = $('userInterface');
        return !!ui && window.getComputedStyle(ui).display !== 'none' && !!(window.APP && window.APP.user);
    }

    async function refreshNotifPermCard() {
        var card = $('notifPermCard');
        if (!card) return;
        if (!userPageVisible()) { card.style.display = 'none'; return; }

        var state = await getNotifState();
        if (state === 'granted') {
            if (window.APP) window.APP.notificationsPrefEnabled = true;
            card.style.display = 'none';
            return;
        }
        if (state === 'unsupported' || getDismissed()) { card.style.display = 'none'; return; }

        var blocked = state === 'denied';
        card.classList.toggle('is-blocked', blocked);
        var title = $('notifPermTitle'), sub = $('notifPermSub'), btn = $('notifPermBtn');
        if (blocked) {
            if (title) title.textContent = 'الإشعارات متوقفة';
            if (sub) sub.textContent = 'فعّلها من إعدادات الجهاز > التطبيقات > كوفانت > الإشعارات';
            if (btn) btn.textContent = 'كيف؟';
        } else {
            if (title) title.textContent = 'فعّل الإشعارات';
            if (sub) sub.textContent = 'ليصلك كل جديد: تأكيد العمليات والعروض ورسائل الدعم';
            if (btn) btn.textContent = 'تفعيل';
        }
        card.style.display = 'flex';
    }

    window.dismissNotifPermCard = function () {
        safe(function () { localStorage.setItem(DISMISS_KEY, String(Date.now())); });
        var card = $('notifPermCard');
        if (card) card.style.display = 'none';
    };

    window.enableNotificationsFromHome = async function () {
        if (busy) return;
        var btn = $('notifPermBtn');
        busy = true;
        if (btn) btn.disabled = true;
        try {
            var state = await getNotifState();
            if (state === 'denied') {
                toast('فعّل الإشعارات من إعدادات الجهاز > التطبيقات > كوفانت > الإشعارات', false);
                return;
            }
            if (state === 'unsupported') {
                toast('الإشعارات غير متوفرة على هذا الجهاز', false);
                return;
            }

            var granted = false;
            if (isNative()) {
                var LN = window.Capacitor.Plugins.LocalNotifications;
                var res = await LN.requestPermissions();
                granted = res && res.display === 'granted';
                if (granted) {
                    try {
                        await LN.createChannel({
                            id: 'kovant_default',
                            name: 'إشعارات كوفانت',
                            description: 'إشعارات رسائل النظام',
                            importance: 5,
                            visibility: 1,
                            sound: 'default'
                        });
                    } catch (e) { /* القناة موجودة مسبقاً */ }
                }
            } else {
                var perm = await Notification.requestPermission();
                granted = perm === 'granted';
            }

            if (granted) {
                if (window.APP) window.APP.notificationsPrefEnabled = true;
                // تسجيل الجهاز لاستقبال الإشعارات من الخادم
                if (typeof window.registerDevice === 'function' && window.APP && window.APP.user && window.APP.user.phone) {
                    window.registerDevice(window.APP.user.phone).catch(function () {});
                }
                if (typeof window.syncNotificationsToggle === 'function') window.syncNotificationsToggle();
                toast('تم تفعيل الإشعارات', true);
            } else {
                toast('لم يتم السماح بالإشعارات', false);
            }
        } catch (e) {
            console.warn('enableNotificationsFromHome:', e);
            toast('تعذر تفعيل الإشعارات', false);
        } finally {
            busy = false;
            if (btn) btn.disabled = false;
            refreshNotifPermCard();
        }
    };

    /* ============================================================
       3) القائمة الجانبية
       ============================================================ */
    function fillSidebarHead() {
        var u = window.APP && window.APP.user;
        var nameEl = $('sbName'), accEl = $('sbAcc'), av = $('sbAvatar');
        if (!u || !nameEl) return;
        nameEl.textContent = u.fullName || 'مستخدم كوفانت';
        if (accEl) accEl.textContent = 'ID: ' + (u.accountNumber || u.phone || '--');
        if (av) {
            av.textContent = '';
            if (u.avatar) {
                var img = document.createElement('img');
                img.alt = '';
                img.src = u.avatar;
                av.appendChild(img);
            } else {
                var ic = document.createElement('i');
                ic.className = 'fa-regular fa-user';
                av.appendChild(ic);
            }
        }
    }

    var origToggleSidebar = window.toggleSidebar;
    if (typeof origToggleSidebar === 'function') {
        window.toggleSidebar = function () {
            var ov = $('sidebarOverlay');
            var opening = ov && !ov.classList.contains('active');
            if (opening) fillSidebarHead();
            var r = origToggleSidebar.apply(this, arguments);
            if (ov) document.body.classList.toggle('sb-open', ov.classList.contains('active'));
            return r;
        };
    }

    // سحب القائمة لليمين لإغلاقها (الواجهة RTL والقائمة على اليمين)
    (function initSidebarSwipe() {
        var ov = $('sidebarOverlay');
        var sb = ov && ov.querySelector('.sidebar');
        if (!sb) return;
        var x0 = 0, y0 = 0, dx = 0, drag = false, locked = false;
        sb.addEventListener('touchstart', function (e) {
            var t = e.touches[0];
            x0 = t.clientX; y0 = t.clientY; dx = 0; drag = true; locked = false;
        }, { passive: true });
        sb.addEventListener('touchmove', function (e) {
            if (!drag) return;
            var t = e.touches[0];
            var mx = t.clientX - x0, my = t.clientY - y0;
            if (!locked) {
                if (Math.abs(my) > Math.abs(mx) && Math.abs(my) > 8) { drag = false; return; }
                if (Math.abs(mx) > 8) locked = true;
            }
            if (locked && mx > 0) {
                dx = mx;
                sb.classList.add('is-dragging');
                sb.style.transform = 'translateX(' + dx + 'px)';
            }
        }, { passive: true });
        function end() {
            if (!drag && !dx) return;
            drag = false;
            sb.classList.remove('is-dragging');
            sb.style.transform = '';
            if (dx > 70 && ov.classList.contains('active')) window.toggleSidebar();
            dx = 0;
        }
        sb.addEventListener('touchend', end);
        sb.addEventListener('touchcancel', end);
    })();

    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        var ov = $('sidebarOverlay');
        if (ov && ov.classList.contains('active')) window.toggleSidebar();
    });

    /* ============================================================
       4) الملف الشخصي
       ============================================================ */
    window.pfCopyAccount = function () {
        var el = $('pdAccountNumber');
        var id = (el && el.textContent || '').trim();
        if (!id || id === '---') { toast('لا يوجد رقم حساب لنسخه', false); return; }
        var done = function () { toast('تم نسخ رقم الحساب', true); };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(id).then(done, function () { fallbackCopy(id, done); });
        } else {
            fallbackCopy(id, done);
        }
    };
    function fallbackCopy(text, cb) {
        var ta = document.createElement('textarea');
        ta.value = text; ta.style.cssText = 'position:fixed;opacity:0;';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); cb(); } catch (e) { /* لا شيء */ }
        ta.remove();
    }

    /* ============================================================
       ربط التنقل: تحديث البطاقة/المفاتيح بعد كل انتقال
       ============================================================ */
    var origNavigate = window.navigateTo;
    if (typeof origNavigate === 'function') {
        window.navigateTo = function (pageId) {
            var r = origNavigate.apply(this, arguments);
            if (pageId === 'userInterface') setTimeout(refreshNotifPermCard, 350);
            if (pageId === 'profileInterface' && typeof window.syncNotificationsToggle === 'function') {
                setTimeout(window.syncNotificationsToggle, 250);
            }
            return r;
        };
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) refreshNotifPermCard();
    });
    window.addEventListener('focus', refreshNotifPermCard);

    function init() {
        upgradeSpinners();
        if (window.MutationObserver) {
            new MutationObserver(scheduleUpgrade).observe(document.body, { childList: true, subtree: true });
        }
        refreshNotifPermCard();
        setInterval(function () { if (!document.hidden) refreshNotifPermCard(); }, 4000);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();

    window.AndroidUI = { buildRing: buildRing, refreshNotifPermCard: refreshNotifPermCard };
}(window, document));
