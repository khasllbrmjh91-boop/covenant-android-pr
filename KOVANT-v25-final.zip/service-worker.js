// service-worker.js — التشغيل بدون إنترنت (تخزين مؤقت للتطبيق فقط)

const CACHE_NAME = 'kova-cache-v21';
const APP_SHELL = [
  '/', '/index.html',
  '/css/style.css', '/css/login.css', '/css/user.css', '/css/user-app.css', '/css/admin.css',
  '/css/topup.css', '/css/sms.css', '/css/wallets.css', '/css/topup-approval.css',
  '/css/admin-settings.css', '/css/sales-analysis.css', '/css/users-analysis.css', '/css/agents-analysis.css', '/css/counters-map.css',
  '/js/firebase-config.js', '/js/offline-queue.js', '/js/auth.js', '/js/user-logic.js',
  '/js/admin-logic.js', '/js/router.js', '/js/sms-logic.js', '/js/wallets-logic.js',
  '/js/topup.js', '/js/topup-approval-logic.js', '/js/sms-native-bridge.js',
  '/js/sms-balance-you.js', '/js/wifi-module.js', '/js/device-usage.js', '/js/admin-settings-logic.js',
  '/js/sales-analysis.js', '/js/users-analysis.js', '/js/agents-analysis.js', '/js/counters-map.js',
  '/manifest.json', '/icons/icon-192.png', '/icons/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache =>
    Promise.all(APP_SHELL.map(url => cache.add(url).catch(() => null)))
  ));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
  ).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request).then(response => {
      if (response && (response.ok || response.type === 'opaque')) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy)).catch(() => {});
      }
      return response;
    }).catch(() => caches.match(event.request).then(cached => cached || new Response('', { status: 503 })))
  );
});
