# تطبيق كوفانت لأندرويد — دليل البناء خطوة بخطوة

هذا المشروع جاهز لتحويل نظام كوفانت إلى تطبيق أندرويد حقيقي عبر Capacitor،
مع بصمة أندرويد الأصلية (بدل WebAuthn) وإشعارات Firebase أصلية تعمل حتى
لو كان التطبيق مغلقاً تماماً.

**ملاحظة مهمة**: هذه الخطوات تحتاج إنترنت وجهاز كمبيوتر (Windows/Mac/Linux)
فيه Node.js وAndroid Studio مثبّتين — لا يمكن تنفيذها من داخل المحادثة.

---

## 1) المتطلبات قبل البدء

- تثبيت **Node.js** (نسخة 18 أو أحدث): https://nodejs.org
- تثبيت **Android Studio**: https://developer.android.com/studio
  (يثبّت معه Android SDK تلقائياً)
- حساب Firebase مفتوح مسبقاً على نفس مشروعك الحالي (`kova-cash`)

---

## 2) تثبيت الحزم

افتح Terminal / CMD داخل مجلد المشروع (حيث يوجد `package.json`) ونفّذ:

```bash
npm install
npx cap add android
npx cap sync android
```

هذا ينشئ مجلد `android/` فيه مشروع أندرويد كامل جاهز، ويربط ملفات الويب
الموجودة في `www/` بداخله.

---

## 3) ربط Firebase الأصلي (ضروري للإشعارات)

الإشعارات الحالية عبر Service Worker تتوقف إذا أُغلق التطبيق كلياً. لتفادي
هذا نحتاج ملف إعداد Firebase الأصلي لأندرويد:

1. من [Firebase Console](https://console.firebase.google.com) افتح مشروع **kova-cash**.
2. اضغط ⚙️ Project Settings → **Add app** → اختر أيقونة Android.
3. أدخل Package name بالضبط: `com.kovant.app`
   (نفس القيمة الموجودة في `capacitor.config.json`)
4. حمّل ملف **google-services.json**.
5. ضعه داخل: `android/app/google-services.json`

> ⚠️ إذا غيّرت `appId` في `capacitor.config.json`، لازم تسجّل نفس الاسم
> الجديد في Firebase أيضاً، وإلا الإشعارات لن تصل.

---

## 4) صلاحيات أندرويد (تحقق من AndroidManifest.xml)

افتح `android/app/src/main/AndroidManifest.xml` وتأكد من وجود هذه الصلاحيات
(بعض الإضافات تضيفها تلقائياً، لكن راجعها للتأكد):

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

- `CAMERA` ضرورية لمسح رموز QR.
- `USE_BIOMETRIC` ضرورية للبصمة الأصلية.
- `POST_NOTIFICATIONS` ضرورية لإشعارات أندرويد 13 فما فوق.

---

## 5) فتح المشروع وبناء APK

```bash
npx cap open android
```

هذا يفتح Android Studio تلقائياً على مشروعك. من هناك:

1. انتظر حتى ينتهي Gradle من التزامن (Sync) — أول مرة قد تأخذ عدة دقائق.
2. من القائمة: **Build → Generate Signed Bundle / APK**.
3. اختر **APK**، ثم أنشئ مفتاح توقيع جديد (Keystore) في أول مرة واحفظه
   بمكان آمن (تحتاجه لاحقاً لأي تحديث للتطبيق).
4. اختر **release** ثم Finish — سيبني لك APK جاهز للتثبيت المباشر.

> لو تبي تجرب بسرعة بدون توقيع نهائي: **Run ▶️** مباشرة على جهاز أندرويد
> حقيقي موصول بالكمبيوتر (USB Debugging مفعّل) أو على محاكي (Emulator).

---

## 6) ملاحظات مهمة عن الاختبار

- **البصمة**: لازم تختبرها على **جهاز حقيقي** فيه بصمة مسجّلة في إعدادات
  النظام، أو محاكي (Emulator) مفعّل فيه Fingerprint افتراضي من إعدادات
  الأندرويد الافتراضية بالمحاكي.
- **الإشعارات وقتك التطبيق مغلق**: تحتاج فعلياً `google-services.json`
  المذكور بالخطوة 3، وإلا التوكن الذي يصل للسيرفر لن يكون توكن FCM حقيقي
  يعمل بالخلفية.
- **الخادم الخلفي** (`kovant-backend3.onrender.com`): يبقى يعمل بدون أي
  تعديل لأن الطلبات من التطبيق هي طلبات HTTP عادية (لا يوجد قيود CORS على
  الطلبات من تطبيق أندرويد أصلي كما في المتصفح).

---

## 7) ماذا تغيّر بالضبط في الكود؟

- ملف جديد: `www/js/native-bridge.js` — يكتشف تلقائياً هل التطبيق شغّال
  كتطبيق أندرويد أو كمتصفح/PWA، ويوجّه البصمة والإشعارات للمسار الصحيح.
- `www/js/auth.js` و `www/js/user-logic.js`: تم تعديل دوال البصمة الثلاث
  فقط (تسجيل، تحقق، إلغاء) لتفرّع حسب البيئة. نسخة الويب (WebAuthn) لم
  تُمس ولا تزال تعمل تماماً كما كانت.
- `www/js/firebase-config.js`: دالة `registerDevice` أصبحت تستخدم
  الإشعارات الأصلية تلقائياً عند التشغيل داخل التطبيق.

أي تحديث تسويه لاحقاً على ملفات `www/` (تصميم، منطق، صفحات) ينعكس في
التطبيق بعد إعادة تنفيذ:

```bash
npx cap sync android
```
