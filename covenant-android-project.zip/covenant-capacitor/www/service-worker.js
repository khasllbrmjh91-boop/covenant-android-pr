// service-worker.js — التشغيل بدون إنترنت (تخزين مؤقت فقط)

const CACHE_NAME = 'kova-cache-v5';
const urlsToCache = [
  '/',
  '/index.html',
  '/css/style.css',
  '/css/login.css',
  '/css/user.css',
  '/css/admin.css',
  '/js/firebase-config.js',
  '/js/auth.js',
  '/js/user-logic.js',
  '/js/admin-logic.js',
  '/js/router.js',
  '/manifest.json'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache)));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request)
    .then(response => {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      return response;
    })
    .catch(() => caches.match(event.request))
  );
});