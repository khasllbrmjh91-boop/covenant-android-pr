// ============================================================
// Firebase Cloud Messaging — Service Worker
// ============================================================
// ✅ إعادة كتابة كاملة لهذا الملف. النسخة القديمة كانت معطوبة تماماً ولا يمكن
// أن تعمل إطلاقاً كملف Service Worker، للأسباب التالية:
//   1) لم يكن فيها أي importScripts() لتحميل مكتبة Firebase — فمتغيّر
//      `firebase` غير موجود أصلاً داخل Service Worker، وأول سطر
//      `firebase.initializeApp(...)` كان سيرمي خطأ فوري يمنع تسجيل
//      الـ Service Worker من الأساس.
//   2) كانت تحتوي على أكواد خاصة بصفحة المتصفح العادية (نسخة مكررة من
//      firebase-config.js) تستخدم localStorage و window و navigator بشكل
//      كامل — وهذه غير متوفرة إطلاقاً داخل بيئة Service Worker.
//   3) كانت تستدعي messaging.usePublicVapidKey(...) وهي دالة غير موجودة في
//      نسخة Firebase الحديثة (نفس خطأ الملف الرئيسي firebase-config.js).
// أي واحد من هذه الأسباب وحده كافٍ لمنع تسجيل الـ Service Worker بالكامل،
// وهو ما يفسّر عدم وصول أي إشعار عندما يكون الموقع مغلقاً أو في الخلفية.
// ============================================================

importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyDlFl3HpaDntr7yejTqXS8y9-z48mJCv2I",
  authDomain: "kova-cash.firebaseapp.com",
  databaseURL: "https://kova-cash-default-rtdb.firebaseio.com",
  projectId: "kova-cash",
  storageBucket: "kova-cash.firebasestorage.app",
  messagingSenderId: "17301396708",
  appId: "1:17301396708:web:589afc94c232c6b2bfe0f1",
  measurementId: "G-RFTLPZEEGQ"
});

const messaging = firebase.messaging();

// استقبال الإشعارات عندما يكون الموقع مغلقاً أو في الخلفية
messaging.onBackgroundMessage((payload) => {
  console.log('📩 [firebase-messaging-sw.js] إشعار خلفي:', payload);
  const title = (payload.notification && payload.notification.title) || 'كوفانت';
  const options = {
    body: (payload.notification && payload.notification.body) || '',
    icon: '/icons/icon-192.png',
    badge: '/icons/badge-96x96.png'
  };
  self.registration.showNotification(title, options);
});

// فتح/تركيز التطبيق عند الضغط على الإشعار
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow('/');
    })
  );
});
