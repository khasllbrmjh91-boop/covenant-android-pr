// ============================================================
// USER DATA (معدّل: حذف تصحيح الرصيد الخاطئ)
// ============================================================
let userDataUnsubscribe = null;

function subscribeToUserData(phone) {
    if (userDataUnsubscribe) {
        userDataUnsubscribe();
        userDataUnsubscribe = null;
    }
    const ref = database.ref('users/' + phone);
    userDataUnsubscribe = ref.on('value', (snap) => {
        const data = snap.val();
        if (!data) return;

        // ✅ نأخذ الرصيد كما هو من Firebase، المصدر الوحيد الموثوق
        APP.user = data;
        APP.user.phone = phone;
        updateUserUI(data, phone);
        renderLastTransactions();
        if (document.getElementById('allTransactionsInterface').classList.contains('active')) renderAllTransactions();
    });
}

function updateUserUI(data, phone) {
    if (!data) return;
    document.getElementById('userName').textContent = data.fullName || 'مستخدم';
    document.getElementById('accountId').textContent = `ID: ${data.accountNumber || data.phone}`;
    const bal = data.balance || 0;
    const formatted = $n(bal).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('amount').textContent = formatted;
    document.getElementById('amount').dataset.realValue = formatted;
    if (document.getElementById('barcodeInterface').style.display === 'block') updateBarcodePage();
    if (document.getElementById('transferInterface').style.display === 'block') document.getElementById('transfer-current-balance').innerText = $fmt(bal);
    if (document.getElementById('statementInterface').style.display === 'block') loadStatementData();
    if (phone && APP._notifListenerPhone !== phone) {
        APP._notifListenerPhone = phone;
        listenNotifications(phone);
    }
}

// ============================================================
// LAST TRANSACTION (عملية واحدة فقط)
// ============================================================
function renderLastTransactions() {
    const container = document.getElementById('lastTxContainer');
    if (!container || !APP.user) return;

    const history = APP.user.history || {};
    const arr = Object.values(history);

    if (arr.length === 0) {
        container.innerHTML = `
            <div style="padding:16px; text-align:center; color:var(--text-secondary); font-size:13px;">
                <i class="fas fa-inbox" style="font-size:20px; display:block; margin-bottom:4px;"></i>
                لا توجد عمليات مسجلة
            </div>
        `;
        return;
    }

    arr.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    const tx = arr[0];

    const amt = tx.amount || 0;
    const isNegative = (tx.type === 'out' || tx.type === 'withdraw');
    const sign = isNegative ? '-' : '+';
    const color = isNegative ? '#ef4444' : '#10b981';
    const icon = isNegative ? 'fa-arrow-up' : 'fa-arrow-down';
    const iconBg = isNegative ? 'rgba(239,68,68,0.08)' : 'rgba(16,185,129,0.08)';

    let dateStr = '--';
    if (tx.timestamp) {
        const d = new Date(tx.timestamp);
        dateStr = d.toLocaleString('ar-EG', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    container.innerHTML = `
        <div style="display:flex; align-items:center; gap:14px; padding:14px 16px;">
            <div style="width:44px; height:44px; min-width:44px; border-radius:50%; background:${iconBg}; display:flex; align-items:center; justify-content:center; color:${color}; font-size:20px;">
                <i class="fas ${icon}"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-weight:700; font-size:14px; color:var(--text-primary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                    ${esc(tx.title || 'معاملة')}
                </div>
                <div style="font-size:11px; color:var(--text-secondary); margin-top:2px;">
                    <i class="far fa-calendar-alt" style="margin-left:4px;"></i> ${dateStr}
                </div>
            </div>
            <div style="font-size:16px; font-weight:800; white-space:nowrap; color:${color};">
                ${sign} ${$fmt(amt)} <span style="font-size:11px; font-weight:600; color:var(--text-secondary);">YER</span>
            </div>
        </div>
    `;
}

// ============================================================
// NOTIFICATIONS
// ============================================================
function listenNotifications(phone) {
    if (!phone) return;
    database.ref('notifications/' + phone).on('child_added', snap => {
        const n = snap.val();
        if (!n) return;
        if (APP.notifications.some(x => x.id === n.id)) return;
        APP.notifications.unshift(n);
        renderNotifications();
        if (APP.soundEnabled) playMessengerSound();
        showToastMain(n);
        updateNotifBadge();
    });
    database.ref('notifications/' + phone).once('value', snap => {
        if (snap.exists()) {
            const all = [];
            snap.forEach(c => all.push(c.val()));
            all.sort((a, b) => b.timestamp - a.timestamp);
            APP.notifications = all;
            renderNotifications();
            updateNotifBadge();
        }
    });
}

function updateNotifBadge() {
    const badge = document.getElementById('notifBadge');
    if (!badge) return;
    const unread = APP.notifications.filter(n => !n.isRead).length;
    badge.innerText = unread > 0 ? unread : '0';
    badge.style.display = unread > 0 ? 'flex' : 'none';
}

function renderNotifications() {
    const c = document.getElementById('notifListContainer');
    if (!c) return;
    if (APP.notifications.length === 0) {
        c.innerHTML = `<div class="empty-state"><i class="fas fa-bell-slash"></i>لا توجد إشعارات حاليًا<div class="sub-text">ستظهر الإشعارات الجديدة هنا تلقائيًا</div></div>`;
        return;
    }
    const sorted = [...APP.notifications].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    c.innerHTML = sorted.map((n, idx) => {
        const isRead = n.isRead === true;
        const icon = n.title?.includes('إيداع') ? 'fa-arrow-down' :
            (n.title?.includes('تحويل') ? 'fa-exchange-alt' :
                (n.title?.includes('فاتورة') ? 'fa-file-invoice' : 'fa-bell'));
        let cls = 'amount-gold';
        if (n.type === 'deposit') cls = 'amount-green';
        else if (n.type === 'transfer') cls = 'amount-red';
        else if (n.type === 'debt') cls = 'amount-gold';
        let msg = esc(n.message || '');
        msg = msg.replace(/(\d+(?:,\d+)*)(?:\s*ريال)?/g, m => `<span class="amount-highlight ${cls}">${m}</span>`);
        return `
            <div class="notif-item ${isRead ? 'read' : ''}" data-id="${n.id || idx}">
                <div class="notif-header">
                    <div class="notif-icon"><i class="fas ${icon}"></i></div>
                    <div class="notif-title">
                        <span class="title-text">${esc(n.title || 'إشعار')} ${!isRead ? '<span class="unread-dot"></span>' : ''}</span>
                    </div>
                </div>
                <div class="notif-divider"></div>
                <div class="notif-body">
                    <div class="notif-message">${msg}</div>
                    <div class="notif-time">
                        <i class="far fa-clock"></i> <span>${getTimeAgo(n.timestamp || Date.now())}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    updateNotifBadge();
}

function showToastMain(notif) {
    const el = document.getElementById('floatingToastMain');
    if (!el) return;
    const color = notif.type === 'deposit' ? 'green' : (notif.type === 'transfer' ? 'red' : 'gold');
    let html = notif.floatingHtml || notif.message;
    const amtMatch = html.match(/<span class="amount-hl">(.*?)<\/span>/);
    if (amtMatch) html = html.replace(/<span class="amount-hl">.*?<\/span>/, `<span class="toast-amount ${color}">${amtMatch[1]}</span>`);
    else {
        const plain = html.match(/(\d+(?:,\d+)*)(?:\s*ريال)?/);
        if (plain) html = html.replace(plain[0], `<span class="toast-amount ${color}">${plain[0]}</span>`);
    }
    document.getElementById('toastMessageMain').innerHTML = html;
    document.getElementById('toastTime').textContent = 'الآن';
    if (APP.toastTimeout) clearTimeout(APP.toastTimeout);
    el.classList.add('visible');
    APP.toastTimeout = setTimeout(() => el.classList.remove('visible'), 7000);
}

function dismissToastMain() {
    if (APP.toastTimeout) clearTimeout(APP.toastTimeout);
    document.getElementById('floatingToastMain')?.classList.remove('visible');
}

function playMessengerSound() {
    if (!APP.soundEnabled) return;
    try {
        const ctx = new(window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator(),
            gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = 880;
        gain.gain.value = 0.15;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.stop(ctx.currentTime + 0.35);
        if (ctx.state === 'suspended') ctx.resume();
    } catch (e) {}
}

function toggleSound() {
    APP.soundEnabled = !APP.soundEnabled;
    localStorage.setItem('notif_sound', APP.soundEnabled ? 'true' : 'false');
    updateSoundUI();
    showAlert(APP.soundEnabled ? 'تم تفعيل الصوت' : 'تم إيقاف الصوت');
    if (APP.soundEnabled) playMessengerSound();
}

function updateSoundUI() {
    const btn = document.getElementById('soundToggleBtnNotif');
    if (APP.soundEnabled) {
        btn.innerHTML = '<i class="fas fa-volume-up"></i> الصوت';
        btn.classList.add('active');
    } else {
        btn.innerHTML = '<i class="fas fa-volume-mute"></i> الصوت';
        btn.classList.remove('active');
    }
}

// ============================================================
// showAlert (خاص بـ SweetAlert2)
// ============================================================
function showAlert(msg, isSuccess = true) {
    Swal.fire({
        title: isSuccess ? 'نجاح' : 'خطأ',
        text: msg,
        icon: isSuccess ? 'success' : 'error',
        confirmButtonText: 'حسناً',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        timer: 3000,
        timerProgressBar: true
    });
}

// ============================================================
// TRANSFER (معدّل: تحويل تلقائي بدون PIN باستخدام JWT)
// ============================================================
async function findUserByAccId(accId) {
    try {
        const res = await fetch('https://kovant-backend3.onrender.com/lookup-account', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ accountNumber: accId })
        });
        const data = await res.json();
        if (res.ok && data.success) {
            return { exists: true, fullName: data.fullName, accountNumber: data.accountNumber };
        }
        return { exists: false };
    } catch (e) { return { exists: false }; }
}

// ✅ دالة مساعدة للحصول على التوكن من localStorage
function getAuthToken() {
    const token = localStorage.getItem('auth_token');
    const expiry = parseInt(localStorage.getItem('auth_expiry') || '0');
    if (!token || Date.now() > expiry) {
        return null;
    }
    return token;
}

// ✅ executeTransfer — تحويل تلقائي باستخدام JWT (بدون PIN)
async function executeTransfer(recipientAccId, amount, note) {
    if (!APP.user) throw new Error('خطأ في الجلسة');

    const transid = `TRF-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const token = getAuthToken();

    if (!token) throw new Error('لم يتم العثور على توكن الجلسة، يرجى تسجيل الدخول مجدداً');

    const res = await fetch('https://kovant-backend3.onrender.com/transfer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({
            phone: APP.user.phone,
            transid: transid,
            recipientAccount: recipientAccId,
            amount: amount,
            note: note
        })
    });

    let data;
    try { data = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

    if (!res.ok || !data.success) {
        if (res.status === 401) {
            localStorage.removeItem('auth_token');
            localStorage.removeItem('auth_expiry');
            if (typeof clearSessionRefreshTimer === 'function') clearSessionRefreshTimer();
            throw new Error('انتهت صلاحية الجلسة، الرجاء تسجيل الدخول مجدداً');
        }
        throw new Error(data.error || 'فشل تنفيذ التحويل');
    }

    // تحديث الرصيد من الخادم (المصدر الوحيد الموثوق)
    APP.user.balance = data.newBalance;
    updateUserUI(APP.user, APP.user.phone);
    renderLastTransactions();
    const balanceEl = document.getElementById('transfer-current-balance');
    if (balanceEl) balanceEl.innerText = $fmt(data.newBalance);

    return { recipient: data.recipient };
}

// ✅ showTransferConfirmation — نافذة تأكيد واحدة (بدون PIN) مع تحسين جلب الرصيد
async function showTransferConfirmation() {
    const acc = document.getElementById('recipient-account').value.trim();
    const amtStr = document.getElementById('transfer-amount').value.trim();
    const note = document.getElementById('transfer-note').value.trim();

    if (!acc) return Swal.fire('خطأ', 'أدخل رقم حساب المستلم', 'error');
    if (!amtStr || isNaN(amtStr) || parseFloat(amtStr) <= 0) return Swal.fire('خطأ', 'أدخل مبلغ صحيح', 'error');
    let amount = parseFloat(amtStr);
    if (amount < 100) return Swal.fire('خطأ', 'الحد الأدنى للتحويل هو 100 ريال', 'error');

    Swal.fire({ title: 'جاري التحقق...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    
    let recipient, latestBalance;
    try {
        const [recipientResult, balanceSnap] = await Promise.all([
            findUserByAccId(acc),
            database.ref('users/' + APP.user.phone).once('value')
        ]);
        recipient = recipientResult;
        
        // ✅ تحسين جلب الرصيد مع معالجة جميع الحالات
        const userData = balanceSnap.val();
        if (userData && typeof userData.balance === 'number') {
            latestBalance = userData.balance;
        } else if (userData && typeof userData.balance === 'string') {
            latestBalance = parseFloat(userData.balance);
        } else {
            // 🔥 إذا لم نجد الرصيد، نجربه مرة أخرى من APP.user
            latestBalance = APP.user.balance || 0;
        }
        
        if (latestBalance !== undefined && !isNaN(latestBalance)) {
            APP.user.balance = latestBalance;
            console.log('✅ تم تحديث الرصيد من Firebase:', latestBalance);
        } else {
            console.warn('⚠️ لم نتمكن من جلب الرصيد، نستخدم الرصيد المخزن:', APP.user.balance);
        }
    } catch (e) {
        Swal.close();
        console.error('❌ خطأ في جلب البيانات:', e);
        return Swal.fire('خطأ', 'حدث خطأ أثناء التحقق', 'error');
    }
    Swal.close();

    if (!recipient.exists) return Swal.fire('خطأ', 'رقم الحساب غير موجود', 'error');
    
    // ✅ التحقق النهائي من الرصيد مع عرض تفصيلي
    const currentBalance = APP.user.balance || 0;
    console.log('💰 الرصيد الحالي:', currentBalance, 'المبلغ المطلوب:', amount);
    
    if (currentBalance < amount) {
        return Swal.fire({
            icon: 'error',
            title: 'الرصيد غير كافي',
            html: `الرصيد الحالي: <strong>${$fmt(currentBalance)} YER</strong><br>المبلغ المطلوب: <strong>${$fmt(amount)} YER</strong>`,
            confirmButtonText: 'حسناً',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8'
        });
    }

    // نافذة تأكيد واحدة (بدون أي حقل PIN أو كلمة مرور)
    const confirmResult = await Swal.fire({
        title: 'تأكيد التحويل',
        html: `
            <div style="text-align:right; background:rgba(255,255,255,0.03); border-radius:16px; padding:16px;">
                <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">📋 رقم حساب المستلم</span>
                    <span style="color:#58b8e8; font-weight:700;">${esc(recipient.accountNumber)}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">👤 اسم المستلم</span>
                    <span style="color:var(--text-primary); font-weight:700;">${esc(recipient.fullName || recipient.name)}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">💰 المبلغ</span>
                    <span style="color:#fbbf24; font-weight:800;">${$fmt(amount)} YER</span>
                </div>
                ${note ? `<div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <span style="color:var(--text-secondary);">📝 ملاحظة</span>
                    <span style="color:var(--text-primary);">${esc(note)}</span>
                </div>` : ''}
                <div style="margin-top:12px; background:#0d1231; border-radius:12px; padding:10px; text-align:center; color:var(--text-secondary); font-size:13px;">
                    🔒 جلسة موثوقة — سيتم التحويل فوراً
                </div>
            </div>
        `,
        confirmButtonText: 'تأكيد التحويل',
        cancelButtonText: 'إلغاء',
        showCancelButton: true,
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });
    if (!confirmResult.isConfirmed) return;

    // تنفيذ التحويل (بدون PIN)
    Swal.fire({ title: 'جاري التحويل...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    try {
        const result = await executeTransfer(acc, amount, note);
        Swal.close();
        await Swal.fire({
            title: 'تم التحويل بنجاح ✅',
            text: `تم تحويل ${$fmt(amount)} YER إلى ${result.recipient.fullName}`,
            icon: 'success',
            confirmButtonText: 'حسناً',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8'
        });
        document.getElementById('transfer-current-balance').innerText = $fmt(APP.user.balance);
        document.getElementById('recipient-account').value = '';
        document.getElementById('transfer-amount').value = '';
        document.getElementById('transfer-note').value = '';
    } catch (e) {
        Swal.close();
        if (e.message.includes('انتهت صلاحية الجلسة')) {
            Swal.fire({
                title: 'انتهت الجلسة',
                text: 'الرجاء تسجيل الدخول مجدداً',
                icon: 'warning',
                confirmButtonText: 'تسجيل الدخول',
                background: '#161b22',
                color: '#e6edf3',
                confirmButtonColor: '#1a6fa8'
            }).then(() => {
                if (typeof logout === 'function') logout();
                navigateTo('loginInterface', true);
            });
        } else {
            Swal.fire('خطأ', e.message, 'error');
        }
    }
}

// ============================================================
// BARCODE PAGE
// ============================================================
function updateBarcodePage() {
    const d = APP.user;
    if (!d) return;
    document.getElementById('bcPageUserName').textContent = d.fullName || 'مستخدم غير معروف';
    document.getElementById('bcPageUserPhone').textContent = `رقم الجوال: ${d.phone || '---'}`;
    document.getElementById('bcPageAccountId').textContent = d.accountNumber || '0000000000';
    document.getElementById('bcPageBalance').textContent = $n(d.balance || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('personalQrImage').src = `https://quickchart.io/qr?text=${encodeURIComponent(d.accountNumber || '')}&size=250&margin=2&ecLevel=H`;
}

function downloadQrCode() {
    const img = document.getElementById('personalQrImage');
    if (!img || !img.src) return showAlert('لا توجد صورة للتحميل', false);
    const canvas = document.createElement('canvas');
    canvas.width = 250;
    canvas.height = 250;
    const ctx = canvas.getContext('2d');
    const temp = new Image();
    temp.crossOrigin = 'anonymous';
    temp.onload = function() {
        ctx.drawImage(temp, 0, 0, 250, 250);
        canvas.toBlob(blob => {
            const link = document.createElement('a');
            link.download = `qr_${APP.user?.accountNumber || 'code'}.png`;
            link.href = URL.createObjectURL(blob);
            link.click();
            URL.revokeObjectURL(link.href);
            showAlert('تم تحميل الباركود');
        });
    };
    temp.src = img.src;
}

async function shareQrCode() {
    const img = document.getElementById('personalQrImage');
    if (!img || !img.src) return showAlert('لا توجد صورة للمشاركة', false);
    try {
        const r = await fetch(img.src);
        const blob = await r.blob();
        const file = new File([blob], `qr_${APP.user?.accountNumber || 'code'}.png`, { type: 'image/png' });
        if (navigator.share) {
            await navigator.share({ title: 'الباركود الخاص بي - كوفانت', files: [file] });
            showAlert('تمت المشاركة');
        } else {
            await navigator.clipboard.writeText(img.src);
            showAlert('تم نسخ رابط الباركود');
        }
    } catch (e) {
        if (e.name !== 'AbortError') {
            showAlert('فشلت المشاركة', false);
        }
    }
}

// ============================================================
// USER INVOICES
// ============================================================
async function loadUserInvoices() {
    const container = document.getElementById('userInvoicesContainer');
    if (!container || !APP.user) return;

    const userSnap = await database.ref('users/' + APP.user.phone).once('value');
    const user = userSnap.val();
    if (!user) {
        container.innerHTML = '<div class="empty-state">لا توجد بيانات</div>';
        return;
    }

    const invoices = user.invoices || {};
    const invoiceKeys = Object.keys(invoices).sort((a, b) => invoices[a].number - invoices[b].number);

    if (invoiceKeys.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 20px;">
                <i class="fas fa-file-invoice" style="font-size:40px; display:block; margin-bottom:10px; color:var(--text-secondary);"></i>
                <p style="color:var(--text-secondary); font-size:15px;">لا توجد فواتير مسجلة</p>
            </div>
        `;
        return;
    }

    let html = '';

    invoiceKeys.forEach(key => {
        const inv = invoices[key];
        const isPaid = inv.status === 'paid';
        const borderColor = isPaid ? 'var(--green)' : 'var(--red)';
        const statusText = isPaid ? 'مدفوعة' : 'نشطة';
        const statusColor = isPaid ? 'var(--green)' : 'var(--red)';

        let paymentsHtml = '';
        if (inv.payments && Object.keys(inv.payments).length > 0) {
            const paymentEntries = Object.values(inv.payments).sort((a, b) => a.date - b.date);
            let tempRemaining = inv.remainingAmount;
            const remainingHistory = [];
            for (let i = paymentEntries.length - 1; i >= 0; i--) {
                const p = paymentEntries[i];
                const amountBefore = tempRemaining + p.amount;
                remainingHistory[i] = tempRemaining;
                tempRemaining = amountBefore;
            }

            paymentsHtml = paymentEntries.map((p, idx) => {
                const displayDate = p.date ? new Date(p.date).toLocaleString('ar-EG', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }) : 'غير معروف';
                const remainingAfterPayment = remainingHistory[idx] || inv.remainingAmount;

                return `
                    <div style="background:rgba(255,255,255,0.02); border-radius:10px; padding:10px 14px; margin-bottom:6px; border-right:3px solid var(--gold);">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
                            <div>
                                <span style="font-weight:700; font-size:13px; color:var(--green);">💰 - ${$fmt(p.amount)} YER</span>
                                <span style="font-size:11px; color:var(--text-secondary); margin-right:10px;">
                                    <i class="far fa-calendar-alt"></i> ${displayDate}
                                </span>
                            </div>
                            <div style="font-size:12px; color:var(--text-secondary);">
                                <span style="color:var(--gold); font-weight:700;">المتبقي: ${$fmt(remainingAfterPayment)} YER</span>
                            </div>
                        </div>
                        ${p.note ? `<div style="font-size:11px; color:var(--text-secondary); margin-top:4px;">📝 ${esc(p.note)}</div>` : ''}
                    </div>
                `;
            }).join('');
        } else {
            paymentsHtml = '<div style="font-size:12px; color:var(--text-secondary); padding:8px 0;">لا توجد سدادت بعد</div>';
        }

        html += `
            <div style="background:var(--bg-card); backdrop-filter:blur(8px); border-radius:var(--radius); margin-bottom:16px; border:1px solid rgba(255,255,255,0.06); box-shadow:var(--shadow-glow); overflow:hidden; border-right:4px solid ${borderColor};">
                <div style="padding:14px 16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; border-bottom:1px solid rgba(255,255,255,0.04); background:rgba(255,255,255,0.02);">
                    <div>
                        <span style="font-weight:800; font-size:16px; color:var(--text-primary);">📄 فاتورة رقم ${inv.number}</span>
                        <span style="background:rgba(255,255,255,0.04); padding:2px 12px; border-radius:30px; font-size:12px; margin-right:10px; color:${statusColor}; font-weight:700;">
                            ${statusText}
                        </span>
                    </div>
                    <div style="font-size:12px; color:var(--text-secondary);">
                        <i class="far fa-calendar-alt"></i> ${new Date(inv.createdAt).toLocaleString('ar-EG', { year:'numeric', month:'2-digit', day:'2-digit' })}
                    </div>
                </div>
                <div style="padding:12px 16px; display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; background:rgba(0,0,0,0.1);">
                    <div style="text-align:center;">
                        <div style="font-size:10px; color:var(--text-secondary);">الإجمالي</div>
                        <div style="font-weight:800; font-size:15px; color:var(--text-primary);">${$fmt(inv.totalAmount)} YER</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:10px; color:var(--text-secondary);">المدفوع</div>
                        <div style="font-weight:800; font-size:15px; color:var(--green);">${$fmt(inv.paidAmount)} YER</div>
                    </div>
                    <div style="text-align:center;">
                        <div style="font-size:10px; color:var(--text-secondary);">المتبقي</div>
                        <div style="font-weight:800; font-size:15px; color:${inv.remainingAmount > 0 ? 'var(--red)' : 'var(--green)'};">${$fmt(inv.remainingAmount)} YER</div>
                    </div>
                </div>
                <div style="padding:12px 16px 16px;">
                    <div style="font-weight:700; font-size:13px; color:var(--text-secondary); margin-bottom:8px;">
                        <i class="fas fa-history"></i> عمليات السداد:
                    </div>
                    <div style="padding-right:4px;">
                        ${paymentsHtml}
                    </div>
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// ============================================================
// PACKAGES (معدّل: confirmSubscription تستدعي الخادم)
// ============================================================
function loadPackagesFromStore() {
    database.ref('kova_store').on('value', snap => {
        APP.storeData = snap.val() || {};
        renderPackages();
    });
}

function renderPackages() {
    const c = document.getElementById('packagesContainer');
    if (!c) return;
    const store = APP.storeData;
    const ids = Object.keys(store).filter(id => id !== 'gift_cards');
    if (!ids.length) {
        c.innerHTML = '<div class="empty-state"><i class="fas fa-box-open"></i><br>لا توجد باقات متاحة حالياً</div>';
        return;
    }
    let html = '';
    ids.forEach(id => {
        const cat = store[id];
        const name = cat.name || id;
        const price = cat.sellPrice ? $n(cat.sellPrice) : 0;
        const duration = cat.duration || 'غير محدد';
        const balance = cat.balance || 'غير محدد';
        const timeLimit = cat.timeLimit || 'غير محدد';
        const points = cat.rewardPoints || 0;
        const isMost = cat.mostRequested === true;
        const avail = cat.cards ? Object.keys(cat.cards).length : 0;
        if (!avail) return;
        html += `
            <div class="package-card ${isMost ? 'most-requested' : ''}">
                ${isMost ? '<div class="most-requested-badge"><i class="fas fa-fire"></i> الأكثر طلباً <i class="fas fa-chart-line"></i></div>' : ''}
                <div class="package-name">${esc(name)}</div>
                <div class="price">${esc(String(price))} <small>ريال</small></div>
                <div class="package-details">
                    <div class="detail-row"><span class="detail-label"><i class="fas fa-calendar-alt"></i> المدة:</span><span class="detail-value">${esc(duration)}</span></div>
                    <div class="detail-row"><span class="detail-label"><i class="fas fa-database"></i> الرصيد:</span><span class="detail-value">${esc(balance)}</span></div>
                    <div class="detail-row"><span class="detail-label"><i class="fas fa-infinity"></i> الوقت:</span><span class="detail-value">${esc(timeLimit)}</span></div>
                </div>
                <div class="points-reward"><i class="fas fa-gem"></i> +${esc(String(points))} نقطة مكافأة</div>
                <button class="subscribe-btn" onclick="openModal('${id}')"><i class="fas fa-shopping-cart"></i> اشتري الآن</button>
            </div>
        `;
    });
    c.innerHTML = html || '<div class="empty-state"><i class="fas fa-box-open"></i><br>جميع الباقات نفدت</div>';
}

function openModal(id) {
    const cat = APP.storeData[id];
    if (!cat) { showAlert('الباقة غير موجودة', false); return; }
    const keys = Object.keys(cat.cards || {});
    if (!keys.length) {
        Swal.fire('نفدت الكروت', 'عذراً، لا توجد كروت متاحة لهذه الباقة حالياً', 'warning');
        return;
    }
    APP.selectedCategoryId = id;
    APP.selectedCategory = cat;
    const price = cat.sellPrice ? $n(cat.sellPrice) : 0;
    document.getElementById('modalPackageName').textContent = cat.name || id;
    document.getElementById('modalPackagePrice').textContent = $fmt(price) + ' ريال';
    document.getElementById('customerId').value = '';
    document.getElementById('cardsCount').textContent = '1';
    document.getElementById('contactError').style.display = 'none';
    document.getElementById('subscribeModal').classList.add('active');
}

function closeModal() {
    document.getElementById('subscribeModal').classList.remove('active');
}

function changeCards(delta) {
    let v = parseInt(document.getElementById('cardsCount').textContent) || 1;
    v = Math.max(1, v + delta);
    document.getElementById('cardsCount').textContent = v;
}

// ✅ confirmSubscription — تستدعي الخادم (لا تكتب مباشرة في Firebase)
async function confirmSubscription() {
    const customerId = document.getElementById('customerId').value.trim();
    if (!customerId) { showAlert('الرجاء إدخال رقم العميل', false); return; }
    if (!/^[0-9]+$/.test(customerId)) { showAlert('الرجاء إدخال أرقام فقط', false); return; }
    localStorage.setItem('customerId', customerId);

    const count = parseInt(document.getElementById('cardsCount').textContent) || 1;
    const id = APP.selectedCategoryId;
    const cat = APP.selectedCategory;

    if (!id || !cat) {
        showAlert('حدث خطأ، الرجاء المحاولة مرة أخرى', false);
        return;
    }

    Swal.fire({
        title: 'جاري التحقق من الرصيد والكروت...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    try {
        const token = getAuthToken();
        if (!token) throw new Error('الرجاء تسجيل الدخول مجدداً');

        const response = await fetch('https://kovant-backend3.onrender.com/api/purchase-package', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({
                packageId: id,
                count: count,
                customerId: customerId
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            Swal.close();
            if (response.status === 401) {
                localStorage.removeItem('auth_token');
                localStorage.removeItem('auth_expiry');
                if (typeof clearSessionRefreshTimer === 'function') clearSessionRefreshTimer();
                return Swal.fire('خطأ', 'انتهت صلاحية الجلسة، الرجاء تسجيل الدخول مجدداً', 'error');
            }
            return Swal.fire('خطأ', data.error || 'فشلت عملية الشراء', 'error');
        }

        // ✅ نجحت العملية: تحديث الرصيد من رد الخادم
        APP.user.balance = data.newBalance;
        updateUserUI(APP.user, APP.user.phone);
        renderLastTransactions();

        Swal.close();

        // عرض الأكواد
        const container = document.getElementById('codesContainer');
        container.innerHTML = '';
        data.codes.forEach((code, idx) => {
            const div = document.createElement('div');
            div.className = 'single-code';
            div.innerHTML = `
                <span class="code-text">${esc(code)}</span>
                <button class="copy-single-btn" onclick="copySingleCode('${esc(code)}', this)">
                    <i class="fas fa-copy"></i>
                </button>
            `;
            container.appendChild(div);
        });

        document.getElementById('successSub').textContent = `تم تخصيص ${count} كرت بنجاح:`;
        document.getElementById('successModal').classList.add('active');
        closeModal();
        showAlert('تم الشراء بنجاح وتم إرسال الأكواد عبر البوت');

    } catch (e) {
        Swal.close();
        console.error(e);
        Swal.fire('خطأ', e.message || 'حدث خطأ أثناء عملية الشراء', 'error');
    }
}

function closeSuccessModal() {
    document.getElementById('successModal').classList.remove('active');
    navigateTo('userInterface', true);
}

function pickContact() {
    const errorDiv = document.getElementById('contactError');
    errorDiv.style.display = 'none';
    if (!navigator.contacts || typeof navigator.contacts.select !== 'function') {
        document.getElementById('errorText').textContent = 'جهازك أو متصفحك لا يدعم اختيار جهات الاتصال. الرجاء الإدخال يدوياً.';
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 6000);
        return;
    }
    navigator.contacts.select(['name', 'tel'], { multiple: false }).then(contacts => {
        if (contacts && contacts.length > 0 && contacts[0].tel && contacts[0].tel.length > 0) {
            let raw = contacts[0].tel[0];
            let cleaned = raw.replace(/[\s\-\(\)]/g, '');
            cleaned = cleaned.replace(/^(?:\+966|966|00966|0?966)/, '');
            if (cleaned.startsWith('0')) cleaned = cleaned.substring(1);
            cleaned = cleaned.replace(/[^0-9]/g, '');
            if (cleaned) {
                document.getElementById('customerId').value = cleaned;
                localStorage.setItem('customerId', cleaned);
            } else {
                document.getElementById('errorText').textContent = 'الرقم المستورد غير صالح. الرجاء الإدخال يدوياً.';
                errorDiv.style.display = 'block';
                setTimeout(() => errorDiv.style.display = 'none', 6000);
            }
        }
    }).catch(err => {
        let msg = 'حدث خطأ أثناء محاولة فتح جهات الاتصال. الرجاء الإدخال يدوياً.';
        if (err.name === 'InvalidStateError') msg = 'تعذر فتح جهات الاتصال بسبب قيود المتصفح. الرجاء الإدخال يدوياً.';
        else if (err.name === 'NotAllowedError') msg = 'تم رفض الوصول إلى جهات الاتصال. الرجاء الإدخال يدوياً.';
        document.getElementById('errorText').textContent = msg;
        errorDiv.style.display = 'block';
        setTimeout(() => errorDiv.style.display = 'none', 6000);
    });
}

// ============================================================
// SUPPORT (دردشة المستخدم)
// ============================================================
function getChatId(phone) { return (phone || 'unknown') + '_admin'; }

function openSupportPage() {
    if (!APP.user) return Swal.fire('تنبيه', 'الرجاء تسجيل الدخول أولاً', 'warning');
    document.getElementById('chatPage').classList.add('active');
    database.ref('users/' + APP.user.phone).update({ isOnline: true });
    loadMessages(APP.user.phone, 'userChatMessagesArea', false);
}

function closeChatPage() {
    document.getElementById('chatPage').classList.remove('active');
    if (APP.user) {
        database.ref('chats/' + getChatId(APP.user.phone)).off();
        database.ref('users/' + APP.user.phone).update({ isOnline: false });
        database.ref('chats/' + getChatId(APP.user.phone) + '/typing').remove();
    }
    APP.selectedMessage = null;
}

function loadMessages(phone, containerId, isAdmin) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const safePhone = phone || 'unknown';
    const chatRef = database.ref('chats/' + getChatId(safePhone));
    chatRef.off('value');
    chatRef.on('value', (snap) => {
        let msgs = snap.val();
        if (msgs && msgs.typing) delete msgs.typing;
        if (!msgs) {
            container.innerHTML =
                `<div class="empty-chat-msg"><i class="fas fa-comment-dots"></i><p>لا توجد رسائل سابقة</p><span>${isAdmin ? 'ابدأ المحادثة مع العميل' : 'ابدأ المحادثة مع فريق الدعم'}</span></div>`;
            return;
        }
        let html = '',
            lastDate = '';
        const sorted = Object.values(msgs).sort((a, b) => a.timestamp - b.timestamp);
        sorted.forEach((m, idx) => {
            const d = formatDateLabel(m.timestamp);
            if (d !== lastDate) { html += `<div class="date-divider">${d}</div>`; lastDate = d; }
            let outgoing = isAdmin ? (m.from === 'admin') : (m.from === safePhone);
            let isRead = m.read === true;
            let statusIcon = isRead ? '<i class="fas fa-check-double read-status read"></i>' :
                '<i class="fas fa-check read-status delivered"></i>';
            html += `
                <div class="message-row ${outgoing ? 'outgoing' : 'incoming'}" data-msg-text="${esc(m.text)}">
                    <div class="message-bubble">
                        <div>${esc(m.text)}</div>
                        <div class="message-time">
                            <span>${new Date(m.timestamp).toLocaleTimeString()}</span>
                            ${outgoing ? statusIcon : ''}
                        </div>
                    </div>
                </div>
            `;
            if (!outgoing && !isRead && document.getElementById(isAdmin ? 'chatDetailPage' : 'chatPage').classList.contains('active')) {
                const key = Object.keys(msgs).find(k => msgs[k].timestamp === m.timestamp && msgs[k].from === m.from);
                if (key) database.ref('chats/' + getChatId(safePhone) + '/' + key + '/read').set(true);
            }
        });
        container.innerHTML = html;
        container.scrollTop = container.scrollHeight;
    });
}

function formatDateLabel(ts) {
    const now = new Date();
    const d = new Date(ts);
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yest = new Date(today);
    yest.setDate(yest.getDate() - 1);
    const msgDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    if (msgDay.getTime() === today.getTime()) return 'اليوم';
    if (msgDay.getTime() === yest.getTime()) return 'أمس';
    const diff = Math.floor((today - msgDay) / (1000 * 60 * 60 * 24));
    if (diff < 7) {
        const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
        return days[d.getDay()];
    }
    return d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' });
}

function sendMessage(role) {
    let phone, inputId, chatId, containerId;
    if (role === 'user') {
        if (!APP.user) return;
        phone = APP.user.phone;
        inputId = 'userChatInput';
        chatId = getChatId(phone);
        containerId = 'userChatMessagesArea';
    } else {
        if (!APP.currentTicketId) return Swal.fire('خطأ', 'لم يتم تحديد المستخدم', 'error');
        phone = APP.currentTicketId;
        inputId = 'chatMsgInput';
        chatId = getChatId(phone);
        containerId = 'chatMessagesBox';
    }
    const inp = document.getElementById(inputId);
    const text = inp.value.trim();
    if (!text) return;
    database.ref('chats/' + chatId + '/typing').remove();
    const ref = database.ref('chats/' + chatId).push();
    const from = role === 'user' ? phone : 'admin';
    ref.set({ from, to: role === 'user' ? 'admin' : phone, text, timestamp: Date.now(), read: false });
    inp.value = '';
    if (role === 'user') database.ref('users/' + phone).update({ isOnline: true });
}

function handleTypingStart(role) {
    let phone;
    if (role === 'user') { if (!APP.user) return; phone = APP.user.phone; } else { if (!APP.currentTicketId) return;
        phone = APP.currentTicketId; }
    const chatId = getChatId(phone);
    const from = role === 'user' ? phone : 'admin';
    database.ref('chats/' + chatId + '/typing').set({ from, isTyping: true, timestamp: Date.now() });
    if (APP.typingTimeout) clearTimeout(APP.typingTimeout);
    APP.typingTimeout = setTimeout(() => { database.ref('chats/' + chatId + '/typing').remove(); }, 3000);
}

// ============================================================
// BANNERS & NEWS TICKER
// ============================================================
function loadUserBanners() {
    const wrap = document.getElementById('bannerWrapper');
    const dotsContainer = document.getElementById('dotsContainer');
    if (!wrap || !dotsContainer) return;

    let bannerIdx = 0;
    let bannerTimer = null;
    let intervalMs = 4500;

    function renderBanners(images) {
        if (bannerTimer) { clearInterval(bannerTimer); bannerTimer = null; }
        wrap.style.transform = 'translateX(0)';

        if (!images || !images.length) {
            wrap.innerHTML = '<div class="banner-slide" style="background:linear-gradient(135deg,#0d1231,#1a237e);"><div class="banner-overlay"></div><div class="banner-text"><h3>🚀 مرحباً بك في كوفانت</h3><p>خدماتك المالية بين يديك</p></div></div>';
            dotsContainer.innerHTML = '';
            return;
        }

        wrap.innerHTML = images.map(img => {
            const url = typeof img === 'string' ? img : (img.url || '');
            const title = (typeof img === 'object' && img.title) ? img.title : '';
            const sub = (typeof img === 'object' && img.sub) ? img.sub : '';
            const textBlock = (title || sub)
                ? `<div class="banner-overlay"></div><div class="banner-text">${title ? `<h3>${esc(title)}</h3>` : ''}${sub ? `<p>${esc(sub)}</p>` : ''}</div>`
                : '<div class="banner-overlay"></div>';
            return `<div class="banner-slide" style="background-image:url('${esc(url)}');">${textBlock}</div>`;
        }).join('');

        dotsContainer.innerHTML = images.map((_, i) => `<span class="dot ${i === 0 ? 'active' : ''}"></span>`).join('');
        bannerIdx = 0;

        if (images.length > 1) {
            bannerTimer = setInterval(() => {
                bannerIdx = (bannerIdx + 1) % images.length;
                wrap.style.transform = `translateX(-${bannerIdx * 100}%)`;
                dotsContainer.querySelectorAll('.dot').forEach((d, i) => d.classList.toggle('active', i === bannerIdx));
            }, intervalMs);
        }
    }

    database.ref('settings/bannerInterval').on('value', snap => {
        const val = snap.val();
        if (val) intervalMs = Number(val) * 1000;
    });

    database.ref('banners').on('value', snap => {
        let images = [];
        if (snap.exists()) {
            const data = snap.val();
            images = Array.isArray(data) ? data.filter(Boolean) : Object.values(data).filter(Boolean);
        }
        renderBanners(images);
    });
}

const _newsTickerState = { texts: ['مرحباً بك في كوفانت'], speed: 80, index: 0, timer: null };

function loadNewsTicker() {
    database.ref('newsTexts').on('value', snap => {
        let texts = [];
        if (snap.exists()) {
            const data = snap.val();
            texts = Array.isArray(data) ? data.filter(Boolean) : Object.values(data).filter(Boolean);
        }
        _newsTickerState.texts = texts.length ? texts : ['مرحباً بك في كوفانت'];
        _newsTickerState.index = 0;
        restartNewsTicker();
    });

    database.ref('settings/typingSpeed').on('value', snap => {
        const val = snap.val();
        _newsTickerState.speed = val ? Number(val) : 80;
    });
}

function restartNewsTicker() {
    if (_newsTickerState.timer) {
        clearTimeout(_newsTickerState.timer);
        _newsTickerState.timer = null;
    }
    typeNextNewsText();
}

function typeNextNewsText() {
    const el = document.getElementById('alertText');
    if (!el) return;
    const texts = _newsTickerState.texts;
    if (!texts.length) return;

    const text = texts[_newsTickerState.index % texts.length];
    let charIdx = 0;
    el.textContent = '';

    function typeChar() {
        if (charIdx <= text.length) {
            el.textContent = text.slice(0, charIdx);
            charIdx++;
            _newsTickerState.timer = setTimeout(typeChar, _newsTickerState.speed);
        } else {
            _newsTickerState.timer = setTimeout(() => {
                _newsTickerState.index++;
                typeNextNewsText();
            }, 2000);
        }
    }
    typeChar();
}

// ============================================================
// PROFILE / SETTINGS
// ============================================================
function loadProfilePage() {
    const toggle = document.getElementById('profileRequirePinToggle');
    if (toggle && APP.user) {
        toggle.checked = APP.user.requirePin === true;
        toggle.onchange = async function (e) {
            const checked = e.target.checked;
            const ok = await updateRequirePin(checked);
            if (!ok) toggle.checked = !checked;
        };
    }
    document.getElementById('profileOldPass').value = '';
    document.getElementById('profileNewPass').value = '';
    document.getElementById('profileOldPin').value = '';
    document.getElementById('profileNewPin').value = '';
    document.getElementById('pdNewPhoneNumber').value = '';

    updateProfileHeroUI(APP.user);
    loadProfileSessionDuration();

    const bioToggle = document.getElementById('pdBiometricToggle');
    if (bioToggle && APP.user) {
        const enabled = !!(APP.user.biometric && APP.user.biometric.enabled && APP.user.biometric.credentialId);
        bioToggle.checked = enabled;
        updateBiometricHelperText(enabled);
    }

    const notifToggle = document.getElementById('pdNotificationsToggle');
    if (notifToggle) notifToggle.checked = APP.notificationsPrefEnabled === true;
}

function updateProfileHeroUI(user) {
    if (!user) return;
    const name = user.fullName || 'مستخدم كوفانت';
    document.getElementById('pdDetailName').textContent = name;
    document.getElementById('pdDetailPhone').textContent = user.phone || '---';
    document.getElementById('pdAccountNumber').textContent = user.accountNumber || '---';
    document.getElementById('pdDateOfBirth').textContent = user.birthDate || '---';
    document.getElementById('pdAddress').textContent = user.address || '---';

    const avatarEl = document.getElementById('pdAvatar');
    const avatarText = document.getElementById('pdAvatarText');
    if (user.avatar) {
        avatarText.style.display = 'none';
        let img = avatarEl.querySelector('img');
        if (!img) {
            img = document.createElement('img');
            avatarEl.appendChild(img);
        }
        img.src = user.avatar;
    } else {
        avatarText.style.display = '';
        const img = avatarEl.querySelector('img');
        if (img) img.remove();
        avatarText.textContent = name.charAt(0).toUpperCase();
    }
}

window.handleProfileAvatarUpload = function (event) {
    if (!APP.user?.phone) return showAlert('يرجى تسجيل الدخول أولاً', false);
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
        showAlert('حجم الصورة كبير جداً (الحد الأقصى 1 ميجابايت)', false);
        return;
    }
    const reader = new FileReader();
    reader.onload = async function (e) {
        const dataURL = e.target.result;
        APP.user.avatar = dataURL;
        updateProfileHeroUI(APP.user);
        try {
            await database.ref('users/' + APP.user.phone).update({ avatar: dataURL });
            showAlert('تم تحديث الصورة الشخصية');
        } catch (err) {
            console.error('avatar upload error:', err);
            showAlert('تعذر حفظ الصورة', false);
        }
    };
    reader.readAsDataURL(file);
};

// ===== بصمة الجهاز (WebAuthn) =====
function bufToB64Url(buf) {
    const bytes = new Uint8Array(buf);
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}
function b64UrlToBuf(b64url) {
    let b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
    const pad = b64.length % 4;
    if (pad) b64 += '='.repeat(4 - pad);
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
}
function isSecureContextForWebAuthn() {
    return window.isSecureContext || location.protocol === 'https:' || location.hostname === 'localhost';
}
async function isBiometricSupported() {
    if (!window.PublicKeyCredential || !window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) return false;
    try { return await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable(); }
    catch (e) { return false; }
}
function updateBiometricHelperText(enabled) {
    const el = document.getElementById('pdBiometricHelperText');
    if (!el) return;
    el.textContent = enabled
        ? 'البصمة مفعلة بنجاح - سيتم استخدامها للتحقق'
        : 'عند التفعيل سيتم استخدام مستشعر البصمة للتحقق';
}
async function registerProfileBiometric() {
    if (!APP.user?.phone) { showAlert('يرجى تسجيل الدخول أولاً', false); return false; }

    // ===== تطبيق أندرويد (Capacitor) — بصمة النظام الأصلية =====
    if (typeof isNativeApp === 'function' && isNativeApp()) {
        const available = await nativeBiometricIsAvailable();
        if (!available) {
            Swal.fire('غير مدعوم', 'جهازك لا يدعم البصمة، أو لم يتم إعدادها في إعدادات النظام بعد.', 'warning');
            return false;
        }
        const { value: password } = await Swal.fire({
            title: 'تأكيد كلمة المرور',
            input: 'password',
            inputLabel: 'أدخل كلمة مرور حسابك مرة واحدة لتفعيل الدخول بالبصمة',
            inputPlaceholder: 'كلمة المرور',
            showCancelButton: true,
            confirmButtonText: 'تفعيل',
            cancelButtonText: 'إلغاء',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8',
            inputValidator: (v) => !v ? 'الرجاء إدخال كلمة المرور' : undefined
        });
        if (!password) return false;

        try {
            await nativeBiometricRegister(APP.user.phone, password);
            await database.ref('users/' + APP.user.phone + '/biometric').set({ enabled: true, type: 'native', createdAt: Date.now() });
            APP.user.biometric = { enabled: true, type: 'native' };
            updateBiometricHelperText(true);
            showAlert('تم تسجيل البصمة بنجاح');
            return true;
        } catch (e) {
            console.error(e);
            Swal.fire('خطأ', 'حدث خطأ أثناء تفعيل البصمة', 'error');
            return false;
        }
    }

    // ===== متصفح / PWA — WebAuthn (كما هي بدون أي تغيير) =====
    if (!isSecureContextForWebAuthn()) { Swal.fire('غير مدعوم', 'يجب تشغيل التطبيق عبر HTTPS لاستخدام البصمة.', 'warning'); return false; }
    if (!(await isBiometricSupported())) { Swal.fire('غير مدعوم', 'جهازك لا يدعم مستشعر البصمة أو المصادقة الحيوية.', 'warning'); return false; }
    try {
        const challenge = crypto.getRandomValues(new Uint8Array(32)).buffer;
        const userId = new TextEncoder().encode(APP.user.phone);
        const credential = await navigator.credentials.create({
            publicKey: {
                challenge,
                rp: { name: 'كوفانت', id: location.hostname || 'localhost' },
                user: { id: userId, name: APP.user.phone, displayName: APP.user.fullName || APP.user.phone },
                pubKeyCredParams: [{ alg: -7, type: 'public-key' }, { alg: -257, type: 'public-key' }],
                timeout: 60000,
                authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', requireResidentKey: false },
                attestation: 'none'
            }
        });
        const credentialId = bufToB64Url(credential.rawId);
        await database.ref('users/' + APP.user.phone + '/biometric').set({ credentialId, enabled: true, createdAt: Date.now() });

        localStorage.setItem('biometric_credential_id', credentialId);
        localStorage.setItem('biometric_user_phone', APP.user.phone);
        localStorage.removeItem('biometric_attempts');
        localStorage.removeItem('biometric_last_attempt_time');

        APP.user.biometric = { credentialId, enabled: true };
        updateBiometricHelperText(true);
        showAlert('تم تسجيل البصمة بنجاح');
        return true;
    } catch (e) {
        console.error(e);
        if (e.name === 'NotAllowedError') Swal.fire('تم الإلغاء', 'تم إلغاء تسجيل البصمة', 'info');
        else Swal.fire('خطأ', 'حدث خطأ أثناء تسجيل البصمة', 'error');
        return false;
    }
}
async function verifyProfileBiometric() {
    // ===== تطبيق أندرويد — تحقق عبر بصمة النظام الأصلية =====
    if (typeof isNativeApp === 'function' && isNativeApp()) {
        try {
            await nativeBiometricAuthenticate();
            return true;
        } catch (e) {
            console.error(e);
            return false;
        }
    }

    // ===== متصفح / PWA — WebAuthn =====
    const storedId = APP.user?.biometric?.credentialId;
    if (!storedId) return false;
    try {
        const challenge = crypto.getRandomValues(new Uint8Array(32)).buffer;
        const assertion = await navigator.credentials.get({
            publicKey: {
                challenge,
                allowCredentials: [{ id: b64UrlToBuf(storedId), type: 'public-key', transports: ['internal'] }],
                timeout: 60000,
                userVerification: 'required'
            }
        });
        return !!assertion;
    } catch (e) {
        console.error(e);
        if (e.name !== 'NotAllowedError') Swal.fire('فشل التحقق', 'تعذر التحقق من البصمة. حاول مرة أخرى.', 'error');
        return false;
    }
}
async function disableProfileBiometric() {
    if (!APP.user?.phone) return false;
    const verified = await verifyProfileBiometric();
    if (!verified) { showAlert('يجب التحقق من البصمة أولاً', false); return false; }
    try {
        await database.ref('users/' + APP.user.phone + '/biometric').remove();
        delete APP.user.biometric;

        if (typeof isNativeApp === 'function' && isNativeApp()) {
            await nativeBiometricRemove();
        }
        localStorage.removeItem('biometric_credential_id');
        localStorage.removeItem('biometric_user_phone');
        localStorage.removeItem('biometric_attempts');
        localStorage.removeItem('biometric_last_attempt_time');

        updateBiometricHelperText(false);
        showAlert('تم إلغاء تفعيل البصمة');
        return true;
    } catch (e) {
        Swal.fire('خطأ', 'تعذر إلغاء البصمة', 'error');
        return false;
    }
}

// ===== تغيير رقم الجوال =====
window.changeProfilePhone = async function () {
    if (!APP.user?.phone) return showAlert('يرجى تسجيل الدخول أولاً', false);
    const newPhone = document.getElementById('pdNewPhoneNumber').value.trim();
    if (!newPhone) return showAlert('أدخل رقم الجوال الجديد', false);
    if (!isValidYemeniPhone(newPhone)) return showAlert('رقم الجوال يجب أن يبدأ بـ 7 ويتكون من 9 أرقام', false);
    if (newPhone === APP.user.phone) return showAlert('هذا هو رقمك الحالي', false);

    try {
        const res = await fetch('https://kovant-backend3.onrender.com/change-phone-number', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ newPhone })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            Swal.fire('خطأ', data.error || 'حدث خطأ أثناء تغيير الرقم', 'error');
            return;
        }

        showAlert('تم تغيير رقم الجوال بنجاح، الرجاء تسجيل الدخول من جديد');
        document.getElementById('pdNewPhoneNumber').value = '';
        logout();
    } catch (e) {
        console.error('changeProfilePhone error:', e);
        Swal.fire('خطأ', 'حدث خطأ أثناء تغيير الرقم', 'error');
    }
};

// ===== مدة الجلسة =====
function loadProfileSessionDuration() {
    const select = document.getElementById('pdSessionDuration');
    if (!select) return;
    select.value = localStorage.getItem('sessionDuration') || '0';
}
window.saveProfileSessionDuration = function () {
    const val = document.getElementById('pdSessionDuration').value;
    localStorage.setItem('sessionDuration', val);
    const labels = { '0': 'دائماً', '5': '5 دقائق', '10': '10 دقائق', '15': '15 دقيقة', '30': '30 دقيقة', '60': 'ساعة' };
    showAlert('تم حفظ مدة الجلسة: ' + (labels[val] || val));
};

// ===== تهيئة القوائم القابلة للطي في صفحة الملف الشخصي =====
function initProfileCollapsibles() {
    document.querySelectorAll('#profileInterface .pd-collapsible-header').forEach(header => {
        header.addEventListener('click', function () {
            const item = this.closest('.pd-collapsible');
            const isActive = item.classList.contains('active');
            const card = item.closest('.pd-card');
            if (card) {
                card.querySelectorAll('.pd-collapsible.active').forEach(open => {
                    if (open !== item) open.classList.remove('active');
                });
            }
            item.classList.toggle('active', !isActive);
        });
    });

    document.getElementById('pdBiometricToggle')?.addEventListener('change', async function (e) {
        const enable = e.target.checked;
        if (enable) {
            const ok = await registerProfileBiometric();
            if (!ok) e.target.checked = false;
        } else {
            const ok = await disableProfileBiometric();
            if (!ok) e.target.checked = true;
        }
    });

    document.getElementById('pdNotificationsToggle')?.addEventListener('change', function (e) {
        APP.notificationsPrefEnabled = e.target.checked;
        showAlert(e.target.checked ? 'تم تفعيل الإشعارات' : 'تم إلغاء تفعيل الإشعارات');
    });
}

window.updateProfilePassword = async function () {
    if (!APP.user?.phone) return showAlert('يرجى تسجيل الدخول أولاً', false);
    const oldPass = document.getElementById('profileOldPass').value.trim();
    const newPass = document.getElementById('profileNewPass').value.trim();

    if (!oldPass || !newPass) return showAlert('يرجى تعبئة الحقلين', false);
    if (newPass.length < 6) return showAlert('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل', false);

    try {
        const res = await fetch('https://kovant-backend3.onrender.com/change-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            return showAlert(data.error || 'كلمة المرور الحالية غير صحيحة', false);
        }
        showAlert('تم تحديث كلمة المرور بنجاح');
        document.getElementById('profileOldPass').value = '';
        document.getElementById('profileNewPass').value = '';
    } catch (e) {
        console.error('updateProfilePassword error:', e);
        showAlert('حدث خطأ أثناء التحديث', false);
    }
};

window.updateProfilePin = async function () {
    if (!APP.user?.phone) return showAlert('يرجى تسجيل الدخول أولاً', false);
    const oldPin = document.getElementById('profileOldPin').value.trim();
    const newPin = document.getElementById('profileNewPin').value.trim();

    if (!newPin) return showAlert('يرجى إدخال PIN الجديد', false);
    if (!/^\d{4}$/.test(newPin)) return showAlert('PIN الجديد يجب أن يكون 4 أرقام', false);

    try {
        const res = await fetch('https://kovant-backend3.onrender.com/change-pin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getAuthToken()
            },
            body: JSON.stringify({ oldPin: oldPin, newPin: newPin })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            return showAlert(data.error || 'PIN الحالي غير صحيح', false);
        }
        showAlert('تم تحديث PIN بنجاح');
        document.getElementById('profileOldPin').value = '';
        document.getElementById('profileNewPin').value = '';
    } catch (e) {
        console.error('updateProfilePin error:', e);
        showAlert('حدث خطأ أثناء التحديث', false);
    }
};

async function updateRequirePin(enable) {
    if (!APP.user?.phone) return false;
    const phone = APP.user.phone;

    if (!enable && APP.user.requirePin === true) {
        const { value: pin } = await Swal.fire({
            title: 'تعطيل طلب PIN',
            text: 'أدخل PIN الحالي للتأكيد',
            input: 'password',
            inputAttributes: { maxlength: 4, inputmode: 'numeric' },
            showCancelButton: true,
            confirmButtonText: 'تأكيد',
            cancelButtonText: 'إلغاء',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8',
            cancelButtonColor: '#2a3340'
        });
        if (!pin) return false;
        const snap = await database.ref('users/' + phone + '/pin').once('value');
        const stored = snap.val();
        const hashedPin = await hashPassword(pin);
        const matches = stored === hashedPin || stored === pin;
        if (!matches) {
            showAlert('PIN غير صحيح', false);
            return false;
        }
    }

    try {
        await database.ref('users/' + phone).update({ requirePin: enable });
        APP.user.requirePin = enable;
        showAlert(enable ? 'تم تفعيل طلب PIN' : 'تم إلغاء طلب PIN');
        return true;
    } catch (e) {
        console.error('updateRequirePin error:', e);
        showAlert('حدث خطأ', false);
        return false;
    }
}

// ============================================================
// REGISTER (طبقة الربط مع الخادم)
// ============================================================
const user = {
    async registerUser(data) {
        const {
            firstName, fatherName, grandfatherName, familyName,
            birthDay, birthMonth, birthYear, address,
            phone, password, confirmPassword, referralCode
        } = data || {};

        const deviceId = generateDeviceId(),
            deviceName = getDeviceName(),
            fingerprint = getDeviceFingerprint(),
            deviceAnalytics = await getDeviceAnalytics();

        const res = await fetch('https://kovant-backend3.onrender.com/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                firstName, fatherName, grandfatherName, familyName,
                birthDay, birthMonth, birthYear, address,
                phone, password, confirmPassword, referralCode,
                deviceId, deviceName, fingerprint, deviceAnalytics
            })
        });

        let result;
        try { result = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

        if (!res.ok || !result.success) {
            throw new Error(result.error || 'تعذر إنشاء الحساب، حاول مرة أخرى');
        }

        return { success: true, accountNumber: result.accountNumber, fullName: result.fullName };
    }
};

// ============================================================
// تنبيه: هناك دوال أخرى (Profile, Biometric, إلخ) موجودة في ملفات منفصلة
// لكنها ليست جزءاً من هذا الملف.
// ============================================================