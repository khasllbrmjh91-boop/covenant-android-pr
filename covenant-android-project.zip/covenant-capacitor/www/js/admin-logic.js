// ============================================================
// ADMIN-LOGIC.JS — إدارة المستخدمين والأجهزة والزوار (نسخة معدلة)
// ============================================================

// ✅ التأكد من وجود الدوال المساعدة
if (typeof $n === 'undefined') {
    window.$n = function(v) {
        if (v === null || v === undefined) return 0;
        let str = String(v).replace(/,/g, '');
        let num = parseFloat(str);
        return isNaN(num) ? 0 : num;
    };
}
if (typeof $fmt === 'undefined') {
    window.$fmt = function(v) {
        return $n(v).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    };
}
if (typeof esc === 'undefined') {
    window.esc = function(s) {
        if (!s) return '';
        return String(s).replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m] || m);
    };
}
if (typeof getLastSeenText === 'undefined') {
    window.getLastSeenText = function(lastSeen) {
        if (!lastSeen) return 'غير مسجل';
        const ts = typeof lastSeen === 'number' ? lastSeen : parseInt(lastSeen);
        if (isNaN(ts)) return 'غير مسجل';
        const diff = Date.now() - ts;
        const s = Math.floor(diff / 1000);
        if (s < 10) return 'الآن';
        if (s < 60) return `منذ ${s} ثانية`;
        const m = Math.floor(s / 60);
        if (m < 60) return `منذ ${m} دقيقة`;
        const h = Math.floor(m / 60);
        if (h < 60) return `منذ ${h} ساعة`;
        const d = Math.floor(h / 24);
        if (d < 7) return `منذ ${d} يوم`;
        const w = Math.floor(d / 7);
        if (w < 4) return `منذ ${w} أسبوع`;
        const mo = Math.floor(d / 30);
        if (mo < 12) return `منذ ${mo} شهر`;
        return `منذ ${Math.floor(d / 365)} سنة`;
    };
}
if (typeof getChatId === 'undefined') {
    window.getChatId = function(phone) {
        return (phone || 'unknown') + '_admin';
    };
}

// ============================================================
// ADMIN: DASHBOARD
// ============================================================
function loadDashboardData() {
    database.ref('users').once('value').then(snap => {
        let total = 0,
            online = 0,
            totalBal = 0;
        if (snap.val()) {
            for (const k in snap.val()) {
                const u = snap.val()[k];
                total++;
                if (u.isOnline === true) online++;
                totalBal += $n(u.balance);
            }
        }
        document.getElementById('totalUsersStat').innerText = total;
        document.getElementById('onlineNowStat').innerText = online;
        document.getElementById('totalRevenueStat').innerText = $fmt(totalBal) + ' ريال';
        database.ref('user_devices').once('value').then(dSnap => {
            let devices = 0;
            if (dSnap.val()) {
                for (const k in dSnap.val()) {
                    const ud = dSnap.val()[k];
                    if (ud.devices) devices += Object.keys(ud.devices).length;
                }
            }
            document.getElementById('totalDevicesStat').innerText = devices;
            renderRevenueChart();
        });
    }).catch(() => {
        document.getElementById('totalUsersStat').innerText = '0';
        document.getElementById('onlineNowStat').innerText = '0';
        document.getElementById('totalRevenueStat').innerText = '0 ريال';
        document.getElementById('totalDevicesStat').innerText = '0';
        renderRevenueChart();
    });

    database.ref('kova_store').on('value', snap => {
        const c = document.getElementById('cardsStatsList');
        if (!c) return;
        const store = snap.val() || {};
        const ids = Object.keys(store).filter(id => id !== 'gift_cards');
        if (!ids.length) {
            c.innerHTML = '<div class="card-stat-empty">لا توجد فئات كروت</div>';
            return;
        }
        c.innerHTML = ids.map(id => {
            const item = store[id];
            const avail = item.cards ? Object.keys(item.cards).length : 0;
            const sold = item.sold ? Object.keys(item.sold).length : 0;
            return `<div class="card-stat-item">
                <span class="card-stat-name">${esc(item.name || id)}</span>
                <div class="card-stat-counts">
                    <span class="card-stat-available">${avail}</span>
                    <span class="card-stat-sold">${sold}</span>
                </div>
            </div>`;
        }).join('');
    });
}

async function renderRevenueChart() {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;
    await loadChartJs();

    const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const labels = [];
    const dayTotals = {};
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(now.getDate() - i);
        const key = d.toDateString();
        labels.push(dayNames[d.getDay()]);
        dayTotals[key] = 0;
    }

    try {
        const txSnap = await database.ref('treasury/transactions').once('value');
        const all = txSnap.val() || {};
        Object.values(all).forEach(tx => {
            if (!tx || tx.type !== 'credit' || !tx.timestamp) return;
            const key = new Date(tx.timestamp).toDateString();
            if (key in dayTotals) dayTotals[key] += $n(tx.changeAmount);
        });
    } catch (e) {
        console.error('❌ فشل تحميل بيانات الإيرادات:', e);
    }

    const revenueData = Object.values(dayTotals);

    if (APP.revenueChart) APP.revenueChart.destroy();
    APP.revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'الإيرادات (ريال)',
                data: revenueData,
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59,130,246,0.05)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#3b82f6',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { backgroundColor: 'rgba(15,23,42,0.9)', titleColor: '#f1f5f9', bodyColor: '#f1f5f9' }
            },
            scales: {
                x: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#94a3b8', font: { size: 8 } } },
                y: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#94a3b8', font: { size: 8 } } }
            }
        }
    });
}

async function loadChartJs() {
    if (typeof Chart !== 'undefined') return;
    return new Promise(r => {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js';
        s.onload = r;
        document.head.appendChild(s);
    });
}

// ============================================================
// ADMIN: USERS
// ============================================================
function loadAdminUsers() {
    if (APP._adminUsersListener) {
        database.ref('users').off('value', APP._adminUsersListener);
        APP._adminUsersListener = null;
    }
    APP._adminUsersListener = function(snap) {
        const list = [];
        if (snap.val()) {
            for (const k in snap.val()) {
                const d = snap.val()[k];
                list.push({
                    phone: k,
                    name: d.fullName || d.name || 'بدون اسم',
                    balance: $n(d.balance),
                    isActivated: d.isActivated !== false,
                    isOnline: d.isOnline || false,
                    lastSeen: d.lastSeen || '',
                    pass: d.password || '',
                    pin: d.pin || '',
                    accId: d.accountNumber || k.slice(-5),
                    maxDevices: d.maxDevices || 1,
                    devices: d.devices || {}
                });
            }
        }
        APP.adminUsers = list;
        renderAdminUsers();
    };
    database.ref('users').on('value', APP._adminUsersListener, function(err) {
        console.error('❌ فشل تحميل قائمة العملاء:', err);
        const c = document.getElementById('adminUsersContainer');
        if (c) c.innerHTML = '<div class="empty-state"><i class="fas fa-triangle-exclamation"></i><p>تعذّر تحميل بيانات العملاء</p></div>';
    });
}

// يفتح نافذة لإضافة مستخدم جديد مباشرة من لوحة الأدمن (نفس بيانات صفحة إنشاء حساب جديد)
window.addNewUserByAdmin = function() {
    Swal.fire({
        title: 'إضافة مستخدم جديد',
        html: `
            <div style="max-height:60vh;overflow-y:auto;padding-left:4px;">
            <div class="swal-field-group"><label>الاسم *</label><input id="swal-nu-first" placeholder="الاسم الأول"></div>
            <div class="swal-field-group"><label>الأب *</label><input id="swal-nu-father" placeholder="اسم الأب"></div>
            <div class="swal-field-group"><label>الجد *</label><input id="swal-nu-grand" placeholder="اسم الجد"></div>
            <div class="swal-field-group"><label>اللقب *</label><input id="swal-nu-last" placeholder="اللقب"></div>
            <div class="swal-field-group"><label>تاريخ الميلاد</label><input id="swal-nu-birth" type="date"></div>
            <div class="swal-field-group"><label>العنوان *</label><input id="swal-nu-address" placeholder="العزلة - القرية"></div>
            <div class="swal-field-group"><label>رقم الجوال *</label><input id="swal-nu-phone" type="tel" maxlength="9" placeholder="7XXXXXXXX (بدون 967+)" dir="ltr"></div>
            <div class="swal-field-group"><label>كلمة المرور *</label><input id="swal-nu-password" type="password" placeholder="6 أحرف على الأقل" autocomplete="new-password"></div>
            <div class="swal-field-group"><label>تأكيد كلمة المرور *</label><input id="swal-nu-confirm" type="password" autocomplete="new-password"></div>
            <div class="swal-field-group"><label>رمز الإحالة (اختياري)</label><input id="swal-nu-referral" placeholder="اختياري"></div>
            <div class="swal-field-group" style="display:flex;align-items:center;gap:8px;">
                <input id="swal-nu-activate" type="checkbox" checked style="width:auto;">
                <label style="margin:0;" for="swal-nu-activate">تفعيل الحساب مباشرة</label>
            </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'إضافة المستخدم',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340',
        width: 480,
        preConfirm: () => {
            const val = id => (document.getElementById(id)?.value || '').trim();
            const firstName = val('swal-nu-first');
            const fatherName = val('swal-nu-father');
            const grandfatherName = val('swal-nu-grand');
            const familyName = val('swal-nu-last');
            const birth = val('swal-nu-birth'); // yyyy-mm-dd
            const address = val('swal-nu-address');
            const phone = val('swal-nu-phone').replace(/[^0-9]/g, '');
            const password = val('swal-nu-password');
            const confirmPassword = val('swal-nu-confirm');
            const referralCode = val('swal-nu-referral');
            const activateNow = !!document.getElementById('swal-nu-activate')?.checked;

            if (!firstName || !fatherName || !grandfatherName || !familyName) {
                Swal.showValidationMessage('يرجى تعبئة الاسم كاملاً (الاسم، الأب، الجد، اللقب)');
                return false;
            }
            if (!address || address.length < 5) {
                Swal.showValidationMessage('العنوان مطلوب (5 أحرف على الأقل)');
                return false;
            }
            if (!/^7\d{8}$/.test(phone)) {
                Swal.showValidationMessage('رقم الجوال يجب أن يبدأ بـ 7 ويتكون من 9 أرقام');
                return false;
            }
            if (!password || password.length < 6) {
                Swal.showValidationMessage('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
                return false;
            }
            if (password !== confirmPassword) {
                Swal.showValidationMessage('كلمتا المرور غير متطابقتين');
                return false;
            }

            let birthDay = '', birthMonth = '', birthYear = '';
            if (birth) {
                const parts = birth.split('-');
                if (parts.length === 3) { birthYear = parts[0]; birthMonth = parts[1]; birthDay = parts[2]; }
            }

            return {
                firstName, fatherName, grandfatherName, familyName,
                birthDay, birthMonth, birthYear, address, phone,
                password, confirmPassword, referralCode, activateNow
            };
        }
    }).then(async r => {
        if (!r.isConfirmed || !r.value) return;

        if (!APP.adminPassword) {
            Swal.fire({
                icon: 'error',
                title: 'انتهت الجلسة',
                text: 'الرجاء تسجيل الدخول مجدداً',
                confirmButtonText: 'تسجيل الدخول',
                background: '#161b22',
                color: '#e6edf3',
                confirmButtonColor: '#1a6fa8'
            }).then(() => logout());
            return;
        }

        Swal.fire({
            title: 'جاري إنشاء الحساب...',
            allowOutsideClick: false,
            allowEscapeKey: false,
            background: '#161b22',
            color: '#e6edf3',
            didOpen: () => Swal.showLoading()
        });

        try {
            const res = await fetch('https://kovant-backend3.onrender.com/admin/create-user', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    adminPhone: '999',
                    adminPassword: APP.adminPassword,
                    ...r.value
                })
            });
            const data = await res.json();
            if (!res.ok || !data.success) throw new Error(data.error || 'تعذر إنشاء الحساب');
            Swal.fire('تم بنجاح', `تمت إضافة المستخدم "${data.fullName}" برقم حساب ${data.accountNumber}`, 'success');
        } catch (e) {
            Swal.fire('خطأ', e.message, 'error');
        }
    });
};

function renderAdminUsers() {
    const c = document.getElementById('adminUsersContainer');
    if (!c) return;
    const arr = APP.adminUsers;
    if (!arr.length) {
        c.innerHTML = '<div class="empty-state"><i class="fas fa-users-slash"></i><p>لا يوجد عملاء</p></div>';
        document.getElementById('adminUserCountSpan').innerText = "0 عميل";
        return;
    }
    document.getElementById('adminUserCountSpan').innerText = arr.length + " عميل";
    const q = document.getElementById('adminSearchUsers')?.value.toLowerCase() || '';
    const filtered = q ? arr.filter(u =>
        (u.name && u.name.toLowerCase().includes(q)) ||
        (u.phone && u.phone.includes(q)) ||
        (u.accId && u.accId.toString().includes(q))
    ) : arr;

    c.innerHTML = filtered.map(u => {
        const online = u.isOnline === true;
        const lastSeenText = u.lastSeen ? getLastSeenText(u.lastSeen) : 'غير مسجل';
        const status = online ?
            `<span class="status-badge online-text"><span class="dot dot-on"></span> متصل الآن</span>` :
            `<span class="status-badge offline-text"><span class="dot dot-off"></span> آخر ظهور: ${lastSeenText}</span>`;

        return `
            <div class="u-card">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                    <div style="flex:1; min-width:0;">
                        <div style="font-size:17px; font-weight:800; color:var(--text-primary);">${esc(u.name)}</div>
                        <div style="font-size:13px; color:var(--text-secondary); margin-top:2px;">${u.phone}</div>
                        <div style="margin-top:4px;">${status}</div>
                    </div>
                    <div style="text-align:left; flex-shrink:0;">
                        <div style="color:var(--blue); font-weight:900; font-size:18px;">
                            ${$fmt(u.balance)} <small style="font-size:9px; font-weight:600; color:var(--text-secondary);">YER</small>
                        </div>
                        <small style="background:rgba(255,255,255,0.04); padding:2px 10px; border-radius:30px; font-weight:800; display:inline-block; margin-top:4px; font-size:10px; color:var(--text-secondary);">
                            ID: ${u.accId || '—'}
                        </small>
                    </div>
                </div>
                <div class="admin-controls">
                    <button onclick="adminFinancialAction('${u.phone}')" class="ctrl-btn btn-depo"><i class="fas fa-coins"></i> إيداع</button>
                    <button onclick="adminEditUser('${u.phone}')" class="ctrl-btn btn-edit"><i class="fas fa-user-edit"></i> تعديل</button>
                    <button onclick="adminViewHistory('${u.phone}')" class="ctrl-btn btn-view"><i class="fas fa-file-invoice"></i> كشف</button>
                    <button onclick="adminToggleStatus('${u.phone}', ${u.isActivated})" class="ctrl-btn btn-lock"><i class="fas ${u.isActivated ? 'fa-user-slash' : 'fa-user-check'}"></i>${u.isActivated ? 'تعطيل' : 'تفعيل'}</button>
                </div>
            </div>
        `;
    }).join('');
}
document.getElementById('adminSearchUsers')?.addEventListener('input', renderAdminUsers);

window.adminEditUser = async function(phone) {
    const user = APP.adminUsers.find(u => u.phone === phone);
    if (!user) return;
    const { value: form } = await Swal.fire({
        title: 'تعديل بيانات العميل',
        html: `<input id="name_ed" class="swal2-input" placeholder="الاسم" value="${user.name}">
               <input id="pass_ed" class="swal2-input" placeholder="كلمة سر جديدة (اتركه فارغاً لعدم التغيير)" value="">
               <input id="pin_ed" class="swal2-input" placeholder="PIN جديد (اتركه فارغاً لعدم التغيير)" maxlength="4" value="">`,
        preConfirm: () => ({
            name: document.getElementById('name_ed').value,
            pass: document.getElementById('pass_ed').value,
            pin: document.getElementById('pin_ed').value
        }),
        confirmButtonText: 'حفظ التغييرات',
        cancelButtonText: 'إلغاء',
        showCancelButton: true,
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });
    if (form) {
        const updates = { fullName: form.name };
        if (form.pass) updates.password = await hashPassword(form.pass);
        if (form.pin) updates.pin = await hashPassword(form.pin);
        await database.ref('users/' + phone).update(updates);
        Swal.fire('نجح', 'تم تحديث البيانات', 'success');
    }
};

window.adminViewHistory = function(phone) {
    adminViewStatement(phone);
};

window.adminToggleStatus = function(phone, current) {
    database.ref('users/' + phone).update({ isActivated: !current });
    Swal.fire({ title: 'تم التغيير', icon: 'success', toast: true, timer: 1500, showConfirmButton: false });
};

// ============================================================
// ADMIN: FINANCIAL ACTIONS (معدّل لاستخدام APP.adminPassword)
// ============================================================

// ✅ إيداع نقدي (يعمل كما كان سابقًا: يضيف رصيدًا للمستخدم دون خصم من المالك)
async function adminDoDeposit(phone, type = 'cash') {
    const { value: amount } = await Swal.fire({
        title: 'إيداع نقدي',
        input: 'number',
        inputAttributes: { autocomplete: 'off' },
        showCancelButton: true,
        confirmButtonText: 'تأكيد',
        inputValidator: v => { if (!v || v <= 0) return 'أدخل مبلغاً صحيحاً'; }
    });
    if (!amount) return;

    // 🔥 التحقق من وجود كلمة مرور الأدمن
    if (!APP.adminPassword) {
        Swal.fire({
            icon: 'error',
            title: 'انتهت الجلسة',
            text: 'الرجاء تسجيل الدخول مجدداً',
            confirmButtonText: 'تسجيل الدخول',
            background: '#161b22',
            color: '#e6edf3',
            confirmButtonColor: '#1a6fa8'
        }).then(() => {
            logout();
        });
        return;
    }

    try {
        const res = await fetch('https://kovant-backend3.onrender.com/admin/deposit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                adminPhone: '999',
                adminPassword: APP.adminPassword,
                phone: phone,
                amount: $n(amount)
            })
        });
        let data = await res.json();
        if (!res.ok || !data.success) throw new Error(data.error || 'فشلت العملية');
        Swal.fire('نجح', 'تمت العملية', 'success');
        loadAdminUsers();
    } catch (e) {
        Swal.fire('خطأ', e.message, 'error');
    }
}

async function createNewInvoice(phone, amount) {
    // 🔥 التحقق من وجود كلمة مرور الأدمن
    if (!APP.adminPassword) {
        throw new Error('انتهت الجلسة، الرجاء تسجيل الدخول مجدداً');
    }

    const res = await fetch('https://kovant-backend3.onrender.com/admin/invoice/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            adminPhone: '999',
            adminPassword: APP.adminPassword,
            phone: phone,
            amount: $n(amount)
        })
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'فشل إنشاء الفاتورة');
    return data.invoiceNumber;
}

async function processInvoicePayment(phone, invoiceId, amount) {
    // 🔥 التحقق من وجود كلمة مرور الأدمن
    if (!APP.adminPassword) {
        throw new Error('انتهت الجلسة، الرجاء تسجيل الدخول مجدداً');
    }

    const res = await fetch('https://kovant-backend3.onrender.com/admin/invoice/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            adminPhone: '999',
            adminPassword: APP.adminPassword,
            phone: phone,
            invoiceId: invoiceId,
            amount: $n(amount)
        })
    });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'فشل سداد الفاتورة');
    return data;
}

async function showPayInvoiceModal(phone) {
    const snap = await database.ref('users/' + phone + '/invoices').once('value');
    const invoices = snap.val() || {};
    const activeInvoices = Object.entries(invoices).filter(([key, inv]) => inv.status === 'active' && inv.remainingAmount > 0);

    if (activeInvoices.length === 0) {
        return Swal.fire('تنبيه', 'لا توجد فواتير نشطة لهذا المستخدم', 'info');
    }

    const options = {};
    activeInvoices.forEach(([key, inv]) => {
        options[key] = `فاتورة رقم ${inv.number} - المتبقي: ${$fmt(inv.remainingAmount)} YER`;
    });

    const { value: invoiceKey } = await Swal.fire({
        title: 'اختر الفاتورة للسداد',
        input: 'select',
        inputOptions: options,
        showCancelButton: true,
        confirmButtonText: 'التالي',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });

    if (!invoiceKey) return;
    const selectedInvoice = invoices[invoiceKey];
    const maxAmount = selectedInvoice.remainingAmount;

    const { value: paymentAmount } = await Swal.fire({
        title: 'إدخال مبلغ السداد',
        html: `<div style="text-align:right;">
            <p>الفاتورة رقم: <strong>${selectedInvoice.number}</strong></p>
            <p>المتبقي: <strong style="color:var(--gold);">${$fmt(maxAmount)} YER</strong></p>
        </div>`,
        input: 'number',
        inputAttributes: { min: 1, max: maxAmount, step: '0.01', autocomplete: 'off' },
        showCancelButton: true,
        confirmButtonText: 'تأكيد السداد',
        inputValidator: v => {
            if (!v || v <= 0) return 'أدخل مبلغاً صحيحاً';
            if (v > maxAmount) return `المبلغ يتجاوز المتبقي (${$fmt(maxAmount)} YER)`;
        },
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });

    if (!paymentAmount) return;
    await processInvoicePayment(phone, invoiceKey, paymentAmount);
    Swal.fire('نجح', 'تم سداد الفاتورة', 'success');
    loadAdminUsers();
}

window.adminFinancialAction = async function(phone) {
    const { value: action } = await Swal.fire({
        title: 'إدارة رصيد العميل',
        icon: 'question',
        input: 'select',
        inputOptions: {
            'cash': '💰 إيداع نقدي',
            'debt': '📄 إنشاء فاتورة آجلة',
            'pay': '💳 سداد فاتورة'
        },
        showCancelButton: true,
        confirmButtonText: 'تأكيد',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });
    if (!action) return;

    if (action === 'cash') {
        await adminDoDeposit(phone, 'cash');
    } else if (action === 'debt') {
        const { value: amount } = await Swal.fire({
            title: 'فاتورة آجلة جديدة',
            input: 'number',
            inputLabel: 'قيمة الفاتورة',
            inputAttributes: { autocomplete: 'off' },
            showCancelButton: true,
            confirmButtonText: 'إنشاء',
            inputValidator: v => { if (!v || v <= 0) return 'أدخل مبلغاً صحيحاً'; }
        });
        if (amount) {
            try {
                await createNewInvoice(phone, amount);
                Swal.fire('نجح', 'تم إنشاء الفاتورة', 'success');
                loadAdminUsers();
            } catch (e) {
                Swal.fire('خطأ', e.message, 'error');
            }
        }
    } else if (action === 'pay') {
        await showPayInvoiceModal(phone);
    }
};

// ============================================================
// ADMIN: DEVICES
// ============================================================
function loadAdminDevices() {
    if (APP._adminDevicesListener) {
        database.ref('users').off('value', APP._adminDevicesListener);
        APP._adminDevicesListener = null;
    }
    APP._adminDevicesListener = function(snap) {
        const list = [];
        if (snap.val()) {
            for (const k in snap.val()) {
                const d = snap.val()[k];
                list.push({
                    phone: k,
                    name: d.fullName || d.name || 'بدون اسم',
                    maxDevices: d.maxDevices || 1,
                    devices: d.devices || {},
                    accountNumber: d.accountNumber || k.slice(-5)
                });
            }
        }
        renderAdminDevices(list);
    };
    database.ref('users').on('value', APP._adminDevicesListener);
}

function renderAdminDevices(list) {
    const c = document.getElementById('adminDevicesContainer');
    if (!c) return;
    if (!list || !list.length) {
        c.innerHTML = '<div class="empty-state"><i class="fas fa-users-slash"></i><p>لا يوجد مستخدمين مسجلين</p></div>';
        return;
    }
    c.innerHTML = list.map(u => {
        const keys = Object.keys(u.devices);
        return `
            <div class="u-card">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                    <div style="flex:1; min-width:0;">
                        <div style="font-size:17px; font-weight:800; color:var(--text-primary);">${esc(u.name)}</div>
                        <div style="font-size:13px; color:var(--text-secondary); margin-top:2px;">${u.phone}</div>
                        <div style="margin-top:4px;">
                            <span class="status-badge offline-text"><i class="fas fa-id-card"></i> المعرف: ${u.accountNumber}</span>
                        </div>
                    </div>
                    <div style="text-align:left; flex-shrink:0;">
                        <div style="color:var(--blue); font-weight:900; font-size:18px;">
                            ${keys.length} <small style="font-size:9px; font-weight:600; color:var(--text-secondary);">جهاز</small>
                        </div>
                        <small style="background:rgba(255,255,255,0.04); padding:2px 10px; border-radius:30px; font-weight:800; display:inline-block; margin-top:4px; font-size:10px; color:var(--text-secondary);">
                            الحد: ${u.maxDevices}
                        </small>
                    </div>
                </div>
                ${keys.length > 0 ? `<div class="devmgmt-grid">${keys.map(id => {
                    const dev = u.devices[id];
                    const analytics = dev?.analytics || {};
                    const browser = analytics.browser || 'غير معروف';
                    const os = analytics.os || 'غير معروف';
                    const model = analytics.deviceModel || dev?.deviceName || 'جهاز غير معروف';
                    const deviceType = analytics.deviceType || 'desktop';
                    const typeIcon = deviceType === 'mobile' ? 'fa-mobile-alt' : (deviceType === 'tablet' ? 'fa-tablet-alt' : 'fa-desktop');
                    const last = dev?.lastUsed ? new Date(dev.lastUsed).toLocaleString('ar-YE') : 'غير معروف';
                    const fp = dev?.fingerprint || 'غير متاح';
                    return `
                        <div class="devmgmt-card">
                            <div class="devmgmt-top">
                                <div class="devmgmt-icon"><i class="fas ${typeIcon}"></i></div>
                                <div class="devmgmt-info">
                                    <div class="devmgmt-title">${esc(model)}</div>
                                    <div class="devmgmt-sub">${esc(browser)} · ${esc(os)}</div>
                                </div>
                            </div>
                            <div class="devmgmt-row"><span><i class="far fa-clock"></i> آخر استخدام</span><span>${last}</span></div>
                            <div class="devmgmt-actions">
                                <button class="device-btn" onclick="copyFingerprint('${fp}')"><i class="fas fa-fingerprint"></i> نسخ البصمة</button>
                                <button class="device-btn danger" onclick="adminRemoveDevice('${u.phone}','${id}')"><i class="fas fa-trash-alt"></i> حذف</button>
                            </div>
                        </div>
                    `;
                }).join('')}</div>` : '<div class="device-empty">لا توجد أجهزة مسجلة</div>'}
                <div class="admin-controls" style="grid-template-columns:1fr;">
                    <button onclick="adminSetMaxDevices('${u.phone}')" class="ctrl-btn btn-edit"><i class="fas fa-edit"></i> تخصيص الحد الأقصى للأجهزة</button>
                </div>
            </div>
        `;
    }).join('');
}

window.adminSetMaxDevices = async function(phone) {
    const user = APP.adminUsers.find(u => u.phone === phone);
    if (!user) return;
    const { value: newMax } = await Swal.fire({
        title: 'تخصيص عدد الأجهزة',
        text: `الحد الحالي: ${user.maxDevices}`,
        input: 'number',
        inputValue: user.maxDevices,
        inputAttributes: { min: 1, max: 10, autocomplete: 'off' },
        confirmButtonText: 'تحديث',
        cancelButtonText: 'إلغاء',
        showCancelButton: true,
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340'
    });
    if (newMax && !isNaN(newMax) && newMax >= 1) {
        await database.ref('users/' + phone + '/maxDevices').set(Number(newMax));
        showAlert('تم تحديث الحد الأقصى');
    }
};

window.adminRemoveDevice = async function(phone, id) {
    const r = await Swal.fire({
        title: 'حذف الجهاز',
        text: 'هل أنت متأكد؟',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'نعم، احذف',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#2a3340'
    });
    if (r.isConfirmed) {
        await database.ref('users/' + phone + '/devices/' + id).set(null);
        showAlert('تم حذف الجهاز');
    }
};

function showFullFingerprint(fp) {
    Swal.fire({
        title: 'بصمة الجهاز الكاملة',
        text: fp,
        icon: 'info',
        confirmButtonText: 'نسخ',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8'
    }).then(r => { if (r.isConfirmed) copyFingerprint(fp); });
}

// ============================================================
// ADMIN: STORE
// ============================================================
function loadAdminStore() {
    database.ref('kova_store').on('value', snap => { APP.storeData = snap.val() || {};
        renderAdminStore();
        populateCardSelect(); });
}

function renderAdminStore() {
    const c = document.getElementById('adminStoreEditList');
    if (!c) return;
    const ids = Object.keys(APP.storeData).filter(id => id !== 'gift_cards');
    if (!ids.length) {
        c.innerHTML = '<div class="empty-state"><i class="fas fa-box-open"></i>لا توجد فئات بعد</div>';
        return;
    }
    c.innerHTML = ids.map(id => {
        const cat = APP.storeData[id];
        const name = cat.name || id;
        const avail = cat.cards ? Object.keys(cat.cards).length : 0;
        const sold = cat.sold ? Object.keys(cat.sold).length : 0;
        const isMost = cat.mostRequested === true;
        const fields = [
            { icon: 'fa-tag', label: 'سعر البيع', key: 'sellPrice' },
            { icon: 'fa-clock', label: 'المدة', key: 'duration' },
            { icon: 'fa-database', label: 'الرصيد', key: 'balance' },
            { icon: 'fa-hourglass-half', label: 'الوقت', key: 'timeLimit' },
            { icon: 'fa-gem', label: 'نقاط المكافأة', key: 'rewardPoints' },
            { icon: 'fa-ruler-horizontal', label: 'طول الكرت', key: 'cardLength' }
        ];
        let details = fields.map(f => {
            let val = cat[f.key];
            return val !== undefined && val !== null && val !== '' ?
                `<span><i class="fas ${f.icon}"></i> ${f.label}: ${esc(String(val))}</span>` : '';
        }).filter(Boolean).join('');
        if (!details) details = '<span style="color:#6b7a8a;font-size:12px;">لا توجد تفاصيل إضافية</span>';
        return `
            <div class="store-category-card ${isMost ? 'most-requested' : ''}">
                ${isMost ? '<div class="most-requested-badge-store"><i class="fas fa-fire"></i> الأكثر طلباً <i class="fas fa-chart-line"></i></div>' : ''}
                <div class="store-category-header">
                    <span class="store-category-name">${esc(name)}</span>
                    <div class="store-category-badges">
                        <span class="store-badge store-badge-avail">متوفر: ${avail}</span>
                        <span class="store-badge store-badge-sold">مباع: ${sold}</span>
                    </div>
                </div>
                <div class="store-category-details">${details}</div>
                <div class="store-category-actions">
                    <button class="edit-btn" onclick="editCategory('${id}')"><i class="fas fa-pen"></i> تعديل</button>
                    <button class="${isMost ? 'star-btn active' : 'star-btn'}" onclick="toggleMostRequested('${id}')"><i class="fas fa-star"></i> ${isMost ? 'إلغاء التخصيص' : 'تخصيص كأكثر طلباً'}</button>
                    <button class="del-btn" onclick="deleteCategory('${id}')"><i class="fas fa-trash"></i></button>
                </div>
            </div>
        `;
    }).join('');
}

function populateCardSelect() {
    const s = document.getElementById('cardTypeSelect');
    if (!s) return;
    s.innerHTML = '<option value="">-- اختر فئة --</option>';
    for (const id in APP.storeData) {
        if (id === 'gift_cards') continue;
        const cat = APP.storeData[id];
        const label = (cat.mostRequested ? '⭐ ' : '') + (cat.name || id);
        s.innerHTML += `<option value="${id}" data-length="${cat.cardLength || ''}">${esc(label)}</option>`;
    }
}

window.addNewCategory = function() {
    Swal.fire({
        title: 'إضافة فئة جديدة',
        html: `
            <div class="swal-field-group"><label>اسم الفئة <span style="color:#ef4444;">*</span></label><input id="swal-cat-name" placeholder="مثال: ستور 10$"></div>
            <div class="swal-field-group"><label>سعر البيع</label><input id="swal-sell-price" placeholder="مثال: 10"></div>
            <div class="swal-field-group"><label>المدة</label><input id="swal-duration" placeholder="مثال: 30 يوم"></div>
            <div class="swal-field-group"><label>الرصيد</label><input id="swal-balance" placeholder="مثال: 15 جيجا"></div>
            <div class="swal-field-group"><label>الوقت</label><input id="swal-time-limit" placeholder="مثال: 3 ساعات"></div>
            <div class="swal-field-group"><label>نقاط المكافأة</label><input id="swal-reward-points" placeholder="مثال: 25"></div>
            <div class="swal-field-group"><label>طول الكرت (عدد الخانات)</label><input id="swal-card-length" type="number" min="1" placeholder="مثال: 16 (اتركه فارغاً إن لم يكن ثابتاً)"></div>
            <div style="font-size:11px;color:#8b98a5;text-align:right;margin-top:-6px;">يُستخدم عند استخراج الأكواد تلقائياً من ملف: يتم اعتماد عدد الخانات (الأرقام/الحروف) فقط دون الشرطات، مثال: 1234-5678-9012-3456 = 16 خانة</div>
        `,
        showCancelButton: true,
        confirmButtonText: 'إضافة',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340',
        preConfirm: () => {
            const n = document.getElementById('swal-cat-name').value.trim();
            if (!n) { Swal.showValidationMessage('اسم الفئة مطلوب'); return false; }
            const lengthVal = document.getElementById('swal-card-length').value.trim();
            if (lengthVal && (!/^\d+$/.test(lengthVal) || Number(lengthVal) <= 0)) {
                Swal.showValidationMessage('طول الكرت يجب أن يكون رقماً صحيحاً أكبر من صفر');
                return false;
            }
            return {
                name: n,
                sellPrice: document.getElementById('swal-sell-price').value.trim(),
                duration: document.getElementById('swal-duration').value.trim(),
                balance: document.getElementById('swal-balance').value.trim(),
                timeLimit: document.getElementById('swal-time-limit').value.trim(),
                rewardPoints: document.getElementById('swal-reward-points').value.trim(),
                cardLength: lengthVal
            };
        }
    }).then(r => {
        if (r.isConfirmed && r.value) {
            const data = r.value;
            const newId = 'cat_' + Date.now();
            const obj = { name: data.name, cards: {}, sold: {}, mostRequested: false };
            if (data.sellPrice) obj.sellPrice = data.sellPrice;
            if (data.duration) obj.duration = data.duration;
            if (data.balance) obj.balance = data.balance;
            if (data.timeLimit) obj.timeLimit = data.timeLimit;
            if (data.rewardPoints) obj.rewardPoints = Number(data.rewardPoints);
            if (data.cardLength) obj.cardLength = Number(data.cardLength);
            database.ref('kova_store/' + newId).set(obj).then(() => showAlert('تمت إضافة الفئة بنجاح'))
                .catch(() => showAlert('حدث خطأ', false));
        }
    });
};

window.editCategory = function(id) {
    const cat = APP.storeData[id];
    if (!cat) return;
    Swal.fire({
        title: 'تعديل بيانات الفئة',
        html: `
            <div class="swal-field-group"><label>اسم الفئة <span style="color:#ef4444;">*</span></label><input id="swal-edit-name" value="${esc(cat.name || '')}" placeholder="مثال: ستور 10$"></div>
            <div class="swal-field-group"><label>سعر البيع</label><input id="swal-edit-sell" value="${cat.sellPrice || ''}" placeholder="مثال: 10"></div>
            <div class="swal-field-group"><label>المدة</label><input id="swal-edit-duration" value="${cat.duration || ''}" placeholder="مثال: 30 يوم"></div>
            <div class="swal-field-group"><label>الرصيد</label><input id="swal-edit-balance" value="${cat.balance || ''}" placeholder="مثال: 15 جيجا"></div>
            <div class="swal-field-group"><label>الوقت</label><input id="swal-edit-time" value="${cat.timeLimit || ''}" placeholder="مثال: 3 ساعات"></div>
            <div class="swal-field-group"><label>نقاط المكافأة</label><input id="swal-edit-points" value="${cat.rewardPoints || ''}" placeholder="مثال: 25"></div>
            <div class="swal-field-group"><label>طول الكرت (عدد الخانات)</label><input id="swal-edit-card-length" type="number" min="1" value="${cat.cardLength || ''}" placeholder="مثال: 16 (اتركه فارغاً إن لم يكن ثابتاً)"></div>
            <div style="font-size:11px;color:#8b98a5;text-align:right;margin-top:-6px;">يُستخدم عند استخراج الأكواد تلقائياً من ملف: يتم اعتماد عدد الخانات (الأرقام/الحروف) فقط دون الشرطات، مثال: 1234-5678-9012-3456 = 16 خانة</div>
        `,
        showCancelButton: true,
        confirmButtonText: 'تحديث',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340',
        preConfirm: () => {
            const n = document.getElementById('swal-edit-name').value.trim();
            if (!n) { Swal.showValidationMessage('اسم الفئة مطلوب'); return false; }
            const lengthVal = document.getElementById('swal-edit-card-length').value.trim();
            if (lengthVal && (!/^\d+$/.test(lengthVal) || Number(lengthVal) <= 0)) {
                Swal.showValidationMessage('طول الكرت يجب أن يكون رقماً صحيحاً أكبر من صفر');
                return false;
            }
            return {
                name: n,
                sellPrice: document.getElementById('swal-edit-sell').value.trim(),
                duration: document.getElementById('swal-edit-duration').value.trim(),
                balance: document.getElementById('swal-edit-balance').value.trim(),
                timeLimit: document.getElementById('swal-edit-time').value.trim(),
                rewardPoints: document.getElementById('swal-edit-points').value.trim(),
                cardLength: lengthVal
            };
        }
    }).then(r => {
        if (r.isConfirmed && r.value) {
            const data = r.value;
            const upd = { name: data.name };
            if (data.sellPrice) upd.sellPrice = data.sellPrice;
            else upd.sellPrice = null;
            if (data.duration) upd.duration = data.duration;
            else upd.duration = null;
            if (data.balance) upd.balance = data.balance;
            else upd.balance = null;
            if (data.timeLimit) upd.timeLimit = data.timeLimit;
            else upd.timeLimit = null;
            if (data.rewardPoints) upd.rewardPoints = Number(data.rewardPoints);
            else upd.rewardPoints = null;
            if (data.cardLength) upd.cardLength = Number(data.cardLength);
            else upd.cardLength = null;
            database.ref('kova_store/' + id).update(upd).then(() => showAlert('تم تحديث الفئة بنجاح'))
                .catch(() => showAlert('حدث خطأ', false));
        }
    });
};

window.toggleMostRequested = function(id) {
    const current = APP.storeData[id]?.mostRequested === true;
    const newVal = !current;
    if (newVal) {
        const upd = {};
        for (const k in APP.storeData) {
            if (k !== id && APP.storeData[k]?.mostRequested === true) upd[k + '/mostRequested'] = null;
        }
        upd[id + '/mostRequested'] = true;
        database.ref('kova_store').update(upd).then(() => showAlert('تم تعيين الفئة كالأكثر طلباً'))
            .catch(() => showAlert('حدث خطأ', false));
    } else {
        database.ref('kova_store/' + id + '/mostRequested').set(null)
            .then(() => showAlert('تم إلغاء تخصيص الفئة')).catch(() => showAlert('حدث خطأ', false));
    }
};

window.deleteCategory = async function(id) {
    const r = await Swal.fire({
        title: 'تأكيد الحذف',
        text: 'سيتم حذف الفئة وكل كروتها',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'نعم، احذف',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#2a3340'
    });
    if (!r.isConfirmed) return;
    const cat = APP.storeData[id];
    const avail = cat?.cards ? Object.keys(cat.cards).length : 0;
    const pricePerCard = cat?.sellPrice ? Number(cat.sellPrice) : 10;
    await database.ref('kova_store/' + id).remove();
    if (avail > 0) {
        await logTreasuryTransaction('card_delete_refund', -(avail * pricePerCard),
            `مردود حذف فئة كاملة - ${cat?.name || id} (${avail} كرت)`);
    }
    showAlert('تم الحذف وتسجيل الخصم في الخزينة');
    StoreManager.load();
};

window.addCardsToStore = function() {
    const id = document.getElementById('cardTypeSelect').value;
    const codes = document.getElementById('cardNumbers').value.trim().split('\n').filter(c => c.trim() !== "");
    if (!id || !codes.length) {
        Swal.fire('خطأ', 'اختر فئة وأدخل أكواد', 'error');
        return;
    }
    const cat = APP.storeData[id];
    if (!cat) { Swal.fire('خطأ', 'الفئة غير موجودة', 'error'); return; }
    let upd = {};
    const now = Date.now();
    codes.forEach(c => {
        const key = database.ref('kova_store/' + id + '/cards').push().key;
        upd[key] = { code: c.trim(), addedAt: now };
    });
    database.ref('kova_store/' + id + '/cards').update(upd).then(async () => {
        const pricePerCard = cat.sellPrice ? Number(cat.sellPrice) : 10;
        await logTreasuryTransaction('card_add', codes.length * pricePerCard,
            `إضافة ${codes.length} كرت للمخزن - فئة ${cat.name}`);
        Swal.fire('تم', `تم إضافة ${codes.length} كرت بنجاح`, 'success');
        document.getElementById('cardNumbers').value = '';
        StoreManager.load();
    }).catch(() => { Swal.fire('خطأ', 'حدث خطأ أثناء الحفظ', 'error'); });
};

// ============================================================
// ADMIN: STORE - استخراج الأكواد تلقائياً من ملف (TXT / CSV / PDF)
// ============================================================

// يقرأ ملف نصي (txt / csv) ويعيد محتواه كنص
function readTextFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('تعذرت قراءة الملف: ' + file.name));
        reader.readAsText(file, 'UTF-8');
    });
}

// يقرأ ملف PDF ويستخرج كل النصوص الموجودة فيه (بواسطة pdf.js)
async function readPdfFile(file) {
    if (!window.pdfjsLib) {
        throw new Error('تعذر تحميل مكتبة قراءة ملفات PDF، تأكد من الاتصال بالإنترنت');
    }
    const buffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        fullText += content.items.map(it => it.str || '').join(' ') + '\n';
    }
    return fullText;
}

// يستخرج من نص خام كل "الأكواد" المحتملة (أرقام/حروف قد تُفصل برموز شائعة مثل - _ . / , * :)
// ثم يفلترها حسب الطول المطلوب، ويعيد الكود "صافياً" بعد إزالة رموز الفصل منه بالكامل
function extractCodesByLength(text, requiredLength) {
    if (!text) return [];
    // مقطع مكوّن من أرقام/حروف إنجليزية، قد يحتوي بينه على رموز فاصلة شائعة (وليس في البداية أو النهاية)
    const SEPARATORS = /[-_./,*:]/g;
    const tokenRegex = /[A-Za-z0-9]+(?:[-_./,*:][A-Za-z0-9]+)*/g;
    const rawMatches = text.match(tokenRegex) || [];
    const seen = new Set();
    const results = [];
    rawMatches.forEach(tok => {
        const clean = tok.replace(SEPARATORS, ''); // الكود صافياً بدون أي رموز فاصلة (شرطات، نقاط، شرطة مائلة...الخ)
        if (!clean) return;
        if (requiredLength) {
            if (clean.length !== Number(requiredLength)) return;
        } else {
            // لا يوجد طول محدد للفئة: نتجاهل المقاطع القصيرة جداً (أقل من 6) لتقليل الأخطاء
            if (clean.length < 6) return;
        }
        if (!seen.has(clean)) { seen.add(clean); results.push(clean); }
    });
    return results;
}

window.onStoreCardFilesSelected = async function(inputEl) {
    const files = Array.from(inputEl.files || []);
    if (!files.length) return;

    const catId = document.getElementById('cardTypeSelect').value;
    if (!catId) {
        Swal.fire('تنبيه', 'يرجى اختيار الفئة أولاً قبل رفع الملف', 'warning');
        inputEl.value = '';
        return;
    }
    const cat = APP.storeData[catId];
    const requiredLength = cat && cat.cardLength ? Number(cat.cardLength) : null;

    Swal.fire({
        title: 'جاري استخراج الأكواد...',
        allowOutsideClick: false,
        allowEscapeKey: false,
        background: '#161b22',
        color: '#e6edf3',
        didOpen: () => Swal.showLoading()
    });

    let allCodes = [];
    try {
        for (const file of files) {
            const ext = (file.name.split('.').pop() || '').toLowerCase();
            let text = '';
            if (ext === 'pdf') {
                text = await readPdfFile(file);
            } else if (ext === 'txt' || ext === 'csv') {
                text = await readTextFile(file);
            } else {
                text = await readTextFile(file); // محاولة قراءته كنص افتراضياً
            }
            allCodes = allCodes.concat(extractCodesByLength(text, requiredLength));
        }
    } catch (err) {
        Swal.fire('خطأ', err && err.message ? err.message : 'تعذرت معالجة الملف', 'error');
        inputEl.value = '';
        return;
    }

    const textarea = document.getElementById('cardNumbers');
    const existingLines = textarea.value.split('\n').map(s => s.trim()).filter(Boolean);
    const seen = new Set(existingLines);
    const extractedCodes = [];
    allCodes.forEach(c => {
        if (!seen.has(c)) { seen.add(c); extractedCodes.push(c); }
    });
    inputEl.value = '';

    if (!extractedCodes.length) {
        Swal.fire('لا توجد نتائج',
            requiredLength ?
                `لم يتم العثور على أي كود مكوّن من ${requiredLength} خانة داخل الملف المحدد` :
                'لم يتم العثور على أكواد داخل الملف المحدد',
            'info');
        return;
    }

    showExtractedCodesList(extractedCodes, textarea, existingLines);
};

// يعرض قائمة بالأكواد المستخرجة مع عداد، وزر لنقلها إلى حقل المخزن
// التصميم شبكي مضغوط بعدة أعمدة + تمرير، بحيث يبقى مناسباً سواء كانت النتائج 10 أو 70 أو 150+ كود
function showExtractedCodesList(extractedCodes, textarea, existingLines) {
    const listHtml = extractedCodes.map(c =>
        `<div style="padding:5px 6px;border:1px solid rgba(255,255,255,0.08);border-radius:6px;background:rgba(255,255,255,0.04);font-family:monospace;font-size:12px;text-align:center;direction:ltr;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(c)}</div>`
    ).join('');

    Swal.fire({
        title: 'الأكواد المستخرجة',
        html: `
            <div style="text-align:center;margin-bottom:10px;">
                <span class="store-badge store-badge-avail" style="font-size:14px;">عدد الأكواد المستخرجة: ${extractedCodes.length}</span>
            </div>
            <div style="max-height:380px;overflow-y:auto;border:1px solid rgba(255,255,255,0.08);border-radius:8px;background:rgba(255,255,255,0.03);padding:8px;">
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:6px;">${listHtml}</div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'نقل الكروت الى حقل المخزن',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#1a6fa8',
        cancelButtonColor: '#2a3340',
        width: 640
    }).then(r => {
        if (r.isConfirmed) {
            textarea.value = existingLines.concat(extractedCodes).join('\n');
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2200,
                timerProgressBar: true,
                background: '#161b22',
                color: '#e6edf3'
            });
            Toast.fire({ icon: 'success', title: `تم نقل ${extractedCodes.length} كود إلى حقل المخزن` });
        }
    });
}

// ============================================================
// ADMIN: INVOICES
// ============================================================
async function loadAdminInvoicesOverview() {
    const container = document.getElementById('adminInvoicesOverviewContainer');
    if (!container) return;

    container.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i> جاري التحميل...</div>';

    let usersSnap;
    try {
        usersSnap = await database.ref('users').once('value');
    } catch (err) {
        console.error('❌ فشل تحميل الفواتير الآجلة:', err);
        container.innerHTML = '<div class="empty-state"><i class="fas fa-triangle-exclamation"></i><p>تعذّر تحميل البيانات</p></div>';
        return;
    }
    const users = usersSnap.val() || {};
    const debtors = [];

    for (const [phone, data] of Object.entries(users)) {
        if (phone === '999') continue;
        const invoices = data.invoices || {};
        let totalDebt = 0;
        let activeCount = 0;
        let lastDate = 0;
        for (const key in invoices) {
            const inv = invoices[key];
            if (inv.status === 'active' && inv.remainingAmount > 0) {
                totalDebt += inv.remainingAmount;
                activeCount++;
                if (inv.createdAt > lastDate) lastDate = inv.createdAt;
            }
        }
        if (totalDebt > 0) {
            debtors.push({
                phone,
                name: data.fullName || data.name || 'مستخدم',
                totalDebt,
                activeCount,
                lastDate
            });
        }
    }

    if (debtors.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 20px;">
                <i class="fas fa-check-circle" style="font-size:40px; color:var(--green); display:block; margin-bottom:10px;"></i>
                <p style="color:var(--text-secondary); font-size:15px;">لا يوجد مستخدمين عليهم فواتير</p>
            </div>
        `;
        return;
    }

    debtors.sort((a, b) => b.totalDebt - a.totalDebt);

    container.innerHTML = debtors.map(u => `
        <div class="user-invoice-card" onclick="loadAdminInvoiceDetail('${u.phone}')">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap;">
                <div>
                    <div class="user-name">${esc(u.name)}</div>
                    <div class="user-phone"><i class="fas fa-phone-alt" style="margin-left:4px;"></i> ${u.phone}</div>
                </div>
                <div class="debt-amount">${$fmt(u.totalDebt)} YER</div>
            </div>
            <div class="debt-summary">
                <span class="item">📄 الفواتير النشطة: <strong>${u.activeCount}</strong></span>
                <span class="item">📅 آخر فاتورة: <strong>${u.lastDate ? new Date(u.lastDate).toLocaleDateString('ar-EG') : '—'}</strong></span>
            </div>
            <div class="click-hint"><i class="fas fa-arrow-left"></i> اضغط لعرض التفاصيل</div>
        </div>
    `).join('');
}

async function loadAdminInvoiceDetail(phone) {
    const container = document.getElementById('adminInvoiceDetailContainer');
    const title = document.getElementById('adminInvoiceDetailTitle');
    if (!container) return;

    const userSnap = await database.ref('users/' + phone).once('value');
    const user = userSnap.val();
    if (!user) {
        container.innerHTML = '<div class="empty-state">المستخدم غير موجود</div>';
        return;
    }

    const userName = user.fullName || user.name || 'مستخدم';
    title.innerText = `فواتير ${userName}`;

    const invoices = user.invoices || {};
    const invoiceKeys = Object.keys(invoices).sort((a, b) => invoices[a].number - invoices[b].number);

    if (invoiceKeys.length === 0) {
        container.innerHTML = '<div class="empty-state">لا توجد فواتير لهذا المستخدم</div>';
        return;
    }

    let html = `
        <div style="background:var(--bg-card); backdrop-filter:blur(8px); border-radius:var(--radius); padding:14px 16px; margin-bottom:4px; border:1px solid rgba(255,255,255,0.04); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
            <div>
                <span style="font-weight:800; font-size:17px; color:var(--text-primary);">👤 ${esc(userName)}</span>
                <span style="font-size:13px; color:var(--text-secondary); margin-right:12px;"><i class="fas fa-phone-alt"></i> ${phone}</span>
            </div>
            <span style="background:rgba(255,255,255,0.04); padding:4px 14px; border-radius:30px; font-size:12px; color:var(--text-secondary);">
                عدد الفواتير: ${invoiceKeys.length}
            </span>
        </div>
    `;

    invoiceKeys.forEach(key => {
        const inv = invoices[key];
        const isPaid = inv.status === 'paid';
        const borderColor = isPaid ? 'var(--green)' : 'var(--red)';
        const statusText = isPaid ? '✅ مدفوعة' : '⚠️ نشطة';
        const statusClass = isPaid ? 'paid' : 'active';

        let paymentsHtml = '';
        if (inv.payments && Object.keys(inv.payments).length > 0) {
            const payments = Object.values(inv.payments).sort((a, b) => a.date - b.date);
            let tempRemaining = inv.remainingAmount;
            const remainingHistory = [];
            for (let i = payments.length - 1; i >= 0; i--) {
                const p = payments[i];
                const amountBefore = tempRemaining + p.amount;
                remainingHistory[i] = tempRemaining;
                tempRemaining = amountBefore;
            }

            paymentsHtml = payments.map((p, idx) => {
                const displayDate = p.date ? new Date(p.date).toLocaleString('ar-EG', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }) : 'غير معروف';
                const remainingAfter = remainingHistory[idx] || inv.remainingAmount;
                return `
                    <div class="payment-item">
                        <span class="amount">- ${$fmt(p.amount)} YER</span>
                        <span class="date"><i class="far fa-calendar-alt"></i> ${displayDate}</span>
                        <span class="remaining">المتبقي: ${$fmt(remainingAfter)} YER</span>
                    </div>
                `;
            }).join('');
        } else {
            paymentsHtml = '<div style="font-size:12px; color:var(--text-secondary); padding:8px 0;">لا توجد سدادت بعد</div>';
        }

        html += `
            <div class="admin-invoice-detail-card ${isPaid ? 'paid' : ''}">
                <div class="header">
                    <span class="title">📄 فاتورة رقم ${inv.number}</span>
                    <span class="status ${statusClass}">${statusText}</span>
                    <span class="date"><i class="far fa-calendar-alt"></i> ${new Date(inv.createdAt).toLocaleString('ar-EG', { year:'numeric', month:'2-digit', day:'2-digit' })}</span>
                </div>
                <div class="summary">
                    <div class="item">
                        <div class="label">الإجمالي</div>
                        <div class="value">${$fmt(inv.totalAmount)} YER</div>
                    </div>
                    <div class="item">
                        <div class="label">المدفوع</div>
                        <div class="value green">${$fmt(inv.paidAmount)} YER</div>
                    </div>
                    <div class="item">
                        <div class="label">المتبقي</div>
                        <div class="value ${inv.remainingAmount > 0 ? 'red' : 'green'}">${$fmt(inv.remainingAmount)} YER</div>
                    </div>
                </div>
                <div class="payments">
                    <div class="title"><i class="fas fa-history"></i> عمليات السداد</div>
                    ${paymentsHtml}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
    navigateTo('adminInvoiceDetailInterface', true);
}

// ============================================================
// ADMIN: NOTIFICATIONS
// ============================================================
const NOTIFICATION_TEMPLATES = {
    offer: {
        title: '🎁 عرض خاص',
        body: 'تفضل بزيارة تطبيقك الآن واستفد من العروض الحصرية لفترة محدودة!'
    },
    alert: {
        title: '⚠️ تنبيه مهم',
        body: 'يوجد تحديث جديد في النظام، يرجى مراجعة حسابك للاطلاع على التفاصيل.'
    },
    update: {
        title: '🔄 تحديث جديد',
        body: 'تم إضافة ميزات جديدة لتطبيق كوفانت، جربها الآن واستمتع بتجربة أفضل.'
    },
    promo: {
        title: '🔥 عروض حصرية',
        body: 'احصل على خصومات تصل إلى 50% على باقات النت المدفوعة مسبقاً، العرض لفترة محدودة!'
    }
};

async function loadUsersForNotificationSelect() {
    const select = document.getElementById('notifUserSelect');
    if (!select) return;

    try {
        const snap = await database.ref('user_tokens').once('value');
        const tokens = snap.val() || {};
        const users = [];

        const usersSnap = await database.ref('users').once('value');
        const usersData = usersSnap.val() || {};

        for (const phone in tokens) {
            const user = usersData[phone];
            users.push({
                phone: phone,
                name: user?.fullName || user?.name || 'مستخدم',
                hasToken: true
            });
        }

        users.sort((a, b) => a.name.localeCompare(b.name));

        select.innerHTML = '<option value="">-- اختر مستخدم --</option>';
        users.forEach(u => {
            select.innerHTML += `<option value="${u.phone}">${esc(u.name)} (${u.phone})</option>`;
        });

        updateRecipientCount();

        select.addEventListener('change', function() {
            updateRecipientCount();
            const selectedPhone = this.value;
            const infoSpan = document.getElementById('selectedUserInfo');
            if (selectedPhone) {
                const user = users.find(u => u.phone === selectedPhone);
                if (user) {
                    infoSpan.innerHTML = `👤 ${esc(user.name)} (${user.phone})`;
                    infoSpan.style.display = 'inline';
                }
            } else {
                infoSpan.style.display = 'none';
            }
        });

        document.querySelectorAll('input[name="notifTarget"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const container = document.getElementById('singleUserContainer');
                if (this.value === 'single') {
                    container.style.display = 'block';
                } else {
                    container.style.display = 'none';
                    document.getElementById('selectedUserInfo').style.display = 'none';
                }
                updateRecipientCount();
            });
        });

    } catch (e) {
        console.error('❌ فشل تحميل المستخدمين:', e);
        select.innerHTML = '<option value="">خطأ في التحميل</option>';
    }
}

function updateRecipientCount() {
    const target = document.querySelector('input[name="notifTarget"]:checked');
    const countSpan = document.getElementById('recipientCount');
    if (!countSpan) return;

    if (target && target.value === 'single') {
        const select = document.getElementById('notifUserSelect');
        if (select && select.value) {
            countSpan.textContent = '1';
        } else {
            countSpan.textContent = '0';
        }
    } else {
        const select = document.getElementById('notifUserSelect');
        const options = select ? select.options.length - 1 : 0;
        countSpan.textContent = options > 0 ? options : '0';
    }
}

window.adminSendNotification = async function() {
    const title = document.getElementById('notifAdminTitle').value.trim();
    const body = document.getElementById('notifAdminBody').value.trim();
    const target = document.querySelector('input[name="notifTarget"]:checked').value;

    if (!title || !body) {
        return showAlert('يرجى كتابة العنوان والمحتوى', false);
    }

    let phones = [];
    if (target === 'all') {
        const snap = await database.ref('user_tokens').once('value');
        const tokens = snap.val() || {};
        phones = Object.keys(tokens);
    } else {
        const select = document.getElementById('notifUserSelect');
        const phone = select.value;
        if (!phone) {
            return showAlert('الرجاء اختيار مستخدم', false);
        }
        const tokenSnap = await database.ref('user_tokens/' + phone + '/token').once('value');
        if (!tokenSnap.exists()) {
            return showAlert('⚠️ هذا المستخدم ليس لديه توكن إشعارات', false);
        }
        phones = [phone];
    }

    if (phones.length === 0) {
        return showAlert('لا يوجد مستخدمين مستهدفين', false);
    }

    const confirmResult = await Swal.fire({
        title: 'تأكيد الإرسال',
        html: `
            <div style="text-align:right; color:var(--text-secondary);">
                <p style="font-weight:700; color:var(--text-primary);">📨 سيتم إرسال الإشعار إلى <strong>${phones.length}</strong> مستلم</p>
                <div style="background:rgba(255,255,255,0.03); padding:10px; border-radius:10px; margin-top:10px;">
                    <div style="font-size:13px; color:var(--text-primary);"><strong>العنوان:</strong> ${esc(title)}</div>
                    <div style="font-size:13px; color:var(--text-primary); margin-top:4px;"><strong>المحتوى:</strong> ${esc(body)}</div>
                </div>
            </div>
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'نعم، أرسل',
        cancelButtonText: 'إلغاء',
        background: '#161b22',
        color: '#e6edf3',
        confirmButtonColor: '#3b82f6',
        cancelButtonColor: '#2a3340'
    });

    if (!confirmResult.isConfirmed) return;

    Swal.fire({
        title: 'جاري الإرسال...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    let successCount = 0;
    for (const phone of phones) {
        try {
            sendViaMyServer(phone, title, body);
            await database.ref('notifications/' + phone).push({
                id: Date.now() + '_admin_' + phone,
                title: title,
                message: body,
                type: 'admin',
                timestamp: Date.now(),
                isRead: false,
                floatingHtml: body
            });
            successCount++;
        } catch (e) {
            console.error(`فشل الإرسال إلى ${phone}:`, e);
        }
    }

    Swal.close();

    if (successCount > 0) {
        showAlert(`✅ تم إرسال الإشعار إلى ${successCount} من ${phones.length} مستلم`);
        await logAdminNotification(title, body, target === 'all' ? 'الجميع' : phones[0]);
        loadAdminNotificationLog();
    } else {
        showAlert('❌ فشل إرسال جميع الإشعارات', false);
    }
};

async function logAdminNotification(title, body, target) {
    const ref = database.ref('admin_notifications_log').push();
    await ref.set({
        title,
        body,
        target,
        timestamp: Date.now(),
        date: new Date().toLocaleString('ar-YE')
    });
    loadAdminNotificationLog();
}

async function loadAdminNotificationLog() {
    const container = document.getElementById('adminNotifLog');
    if (!container) return;
    const snap = await database.ref('admin_notifications_log').orderByChild('timestamp').limitToLast(20).once('value');
    const logs = snap.val() || {};
    const entries = Object.values(logs).reverse();
    if (!entries.length) {
        container.innerHTML = '<div class="empty-state" style="padding:20px; font-size:12px;">لا توجد إشعارات مرسلة بعد</div>';
        return;
    }
    container.innerHTML = entries.map(log => `
        <div style="background:rgba(255,255,255,0.02); border-radius:8px; padding:8px 12px; margin-bottom:6px; border-right:2px solid var(--blue);">
            <div style="display:flex; justify-content:space-between; font-size:12px; color:var(--text-primary);">
                <strong>${esc(log.title)}</strong>
                <span style="color:var(--text-secondary); font-size:10px;">${log.date || new Date(log.timestamp).toLocaleString('ar-YE')}</span>
            </div>
            <div style="font-size:11px; color:var(--text-secondary);">${esc(log.body)}</div>
            <div style="font-size:9px; color:var(--text-secondary); margin-top:2px;">إلى: ${log.target === 'الجميع' ? 'جميع المستخدمين' : 'رقم: ' + log.target}</div>
        </div>
    `).join('');
}

// ============================================================
// ADMIN: SUPPORT TICKETS
// ============================================================
let allUsersArray = [];

function openSupportDashboard() {
    if (!APP.user || APP.user.phone !== '999') return Swal.fire('خطأ', 'هذه الصفحة خاصة بالمالك فقط', 'error');
    navigateTo('supportTicketsPage');
    loadTicketsData();
}

function closeSupportDashboard() {
    navigateTo('adminSystemInterface');
}

async function loadTicketsData() {
    await loadAllUsersForSupport();
    const chats = await database.ref('chats').once('value');
    const chatsVal = chats.val() || {};
    allUsersArray.forEach(u => {
        const chatId = getChatId(u.phone);
        const chat = chatsVal[chatId];
        let unread = 0;
        if (chat) {
            Object.values(chat).forEach(m => { if (m.from === u.phone && !m.read) unread++; });
        }
        u.unread = unread;
        u.lastMessage = chat ? Object.values(chat).sort((a, b) => b.timestamp - a.timestamp)[0]?.text : '';
        u.lastTime = chat ? new Date(Object.values(chat).sort((a, b) => b.timestamp - a.timestamp)[0]?.timestamp)
            .toLocaleTimeString() : '';
    });
    renderTicketsList(allUsersArray);
}

async function loadAllUsersForSupport() {
    const snap = await database.ref('users').once('value');
    const obj = snap.val() || {};
    allUsersArray = Object.entries(obj).map(([ph, data]) => ({ phone: ph, ...data })).filter(u => u.phone !== '999');
    return allUsersArray;
}

function renderTicketsList(users) {
    const cont = document.getElementById('ticketsListContainer');
    if (!cont) return;
    if (!users || !users.length) {
        cont.innerHTML = '<div class="chat-card" style="text-align:center;">لا توجد محادثات</div>';
        return;
    }
    cont.innerHTML = users.sort((a, b) => (b.unread || 0) - (a.unread || 0)).map(u => {
        const lastSeenText = u.lastSeen ? getLastSeenText(u.lastSeen) : 'غير مسجل';
        const statusText = u.isOnline ? 'متصل الآن' : `آخر ظهور: ${lastSeenText}`;
        const statusClass = u.isOnline ? 'online-text' : 'offline-text';
        const dotClass = u.isOnline ? 'dot-on' : 'dot-off';
        const statusBubble =
            `<span class="status-bubble ${statusClass}"><span class="${dotClass}" style="display:inline-block;width:6px;height:6px;border-radius:50%;margin-left:4px;"></span> ${statusText}</span>`;
        return `
            <div class="chat-card ${u.unread > 0 ? 'unread' : ''}" onclick="openChatWithUser('${u.phone}')">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="chat-info">
                    <h4>
                        <span class="user-full-name">${esc(u.fullName || u.name || 'مستخدم')}</span>
                        <span class="msg-time">${u.lastTime || ''}</span>
                    </h4>
                    <p>${u.lastMessage ? esc(u.lastMessage.substring(0, 40)) : 'لا توجد رسائل'}</p>
                    ${statusBubble}
                    ${u.unread > 0 ? '<div class="badge-dot"></div>' : ''}
                </div>
            </div>
        `;
    }).join('');
}

function filterTickets(filter) {
    let f = [...allUsersArray];
    if (filter === 'unread') f = allUsersArray.filter(u => u.unread > 0);
    else if (filter === 'pending') f = allUsersArray.filter(u => !u.isActivated);
    renderTicketsList(f);
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.tab[data-filter="${filter}"]`)?.classList.add('active');
}

function openChatWithUser(phone) {
    if (!phone || phone === 'undefined') { showAlert('رقم المستخدم غير صحيح', false); return; }
    APP.currentTicketId = phone;
    database.ref('users/' + phone).once('value').then(snap => {
        const u = snap.val();
        if (!u) return;
        document.getElementById('chatUserName').innerText = esc(u.fullName || u.name || 'مستخدم');
        updateAdminUserStatus(phone);
        database.ref('users/' + phone + '/isOnline').on('value', () => updateAdminUserStatus(phone));
        loadMessages(phone, 'chatMessagesBox', true);
        navigateTo('chatDetailPage');
    });
}

function updateAdminUserStatus(phone) {
    database.ref('users/' + phone).once('value').then(snap => {
        const u = snap.val();
        const st = document.getElementById('chatUserStatus');
        if (st && u) {
            const lastSeenText = u.lastSeen ? getLastSeenText(u.lastSeen) : 'غير مسجل';
            st.innerHTML = u.isOnline ?
                '<span class="online-dot"></span> <span>متصل الآن</span>' :
                `<span class="offline-dot"></span> <span>آخر ظهور: ${lastSeenText}</span>`;
        }
    });
}

function closeChatDetail() {
    if (APP.currentTicketId) {
        database.ref('chats/' + getChatId(APP.currentTicketId)).off();
        database.ref('chats/' + getChatId(APP.currentTicketId) + '/typing').off();
        database.ref('users/' + APP.currentTicketId + '/isOnline').off();
    }
    navigateTo('supportTicketsPage');
    loadTicketsData();
    APP.selectedMessage = null;
}

// ============================================================
// ADMIN: ACCOUNTING REPORT
// ============================================================
let activeTargetIdAcc = '';

function setupPickerAcc(id, list, isMonth) {
    let col = document.getElementById(id);
    if (!col) return;
    col.innerHTML = '<div class="spacer"></div>';
    if (isMonth) {
        const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
        monthNames.forEach((name, idx) => {
            let monthNumber = String(idx + 1).padStart(2, '0');
            col.innerHTML += `<div class="picker-item" data-val="${monthNumber}">${name}</div>`;
        });
    } else {
        const currentYear = new Date().getFullYear();
        const startYear = currentYear - 10;
        const endYear = currentYear + 5;
        for (let y = startYear; y <= endYear; y++) {
            col.innerHTML += `<div class="picker-item" data-val="${y}">${y}</div>`;
        }
    }
    col.innerHTML += '<div class="spacer"></div>';
    col.addEventListener('scroll', function() { updateSelectedItemAcc(this); });
    col.addEventListener('click', function(e) {
        const item = e.target.closest('.picker-item');
        if (item) {
            const colEl = item.closest('.picker-col');
            const offset = item.offsetTop - 88;
            colEl.scrollTo({ top: offset, behavior: 'smooth' });
        }
    });
}

function updateSelectedItemAcc(col) {
    const items = col.querySelectorAll('.picker-item');
    let selectedVal = null;
    items.forEach(el => {
        const rect = el.getBoundingClientRect();
        const colRect = col.getBoundingClientRect();
        const middle = colRect.top + colRect.height / 2;
        const elMiddle = rect.top + rect.height / 2;
        if (Math.abs(elMiddle - middle) < 30) {
            el.classList.add('selected');
            selectedVal = el.dataset.val;
        } else {
            el.classList.remove('selected');
        }
    });
    if (selectedVal) {
        let year = document.querySelector('#col-year-acc .selected')?.dataset.val;
        let month = document.querySelector('#col-month-acc .selected')?.dataset.val;
        let day = document.querySelector('#col-day-acc .selected')?.dataset.val;
        if (year && month && day && activeTargetIdAcc) {
            document.getElementById(activeTargetIdAcc).innerText = `${year}-${month}-${day}`;
        }
    }
}

function openPickerAcc(id) {
    activeTargetIdAcc = id;
    document.getElementById('sheetAcc').classList.add('active');
    document.getElementById('overlayAcc').style.display = 'block';
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
    const currentDay = String(now.getDate()).padStart(2, '0');

    if (id === 'to-text-acc' || id === 'from-text-acc') {
        const colDay = document.getElementById('col-day-acc');
        colDay.innerHTML = '<div class="spacer"></div>';
        for (let d = 1; d <= now.getDate(); d++) {
            let dayStr = String(d).padStart(2, '0');
            colDay.innerHTML += `<div class="picker-item" data-val="${dayStr}">${dayStr}</div>`;
        }
        colDay.innerHTML += '<div class="spacer"></div>';
        colDay.addEventListener('scroll', function() { updateSelectedItemAcc(this); });
        colDay.addEventListener('click', function(e) {
            const item = e.target.closest('.picker-item');
            if (item) {
                const colEl = item.closest('.picker-col');
                const offset = item.offsetTop - 88;
                colEl.scrollTo({ top: offset, behavior: 'smooth' });
            }
        });
    }

    setTimeout(() => {
        scrollToValAcc('col-year-acc', currentYear);
        scrollToValAcc('col-month-acc', currentMonth);
        scrollToValAcc('col-day-acc', currentDay);
    }, 150);
}

function scrollToValAcc(id, val) {
    let col = document.getElementById(id);
    if (!col) return;
    let items = Array.from(col.querySelectorAll('.picker-item'));
    let targetVal = String(val);
    if (id === 'col-day-acc' && (activeTargetIdAcc === 'to-text-acc' || activeTargetIdAcc === 'from-text-acc')) {
        const today = new Date();
        const maxDay = today.getDate();
        if (parseInt(targetVal) > maxDay) targetVal = String(maxDay).padStart(2, '0');
    }
    let target = items.find(el => el.dataset.val == targetVal);
    if (target) col.scrollTo({ top: target.offsetTop - 88, behavior: 'smooth' });
}

function closePickerAcc() {
    document.getElementById('sheetAcc').classList.remove('active');
    document.getElementById('overlayAcc').style.display = 'none';
    if (activeTargetIdAcc === 'to-text-acc' || activeTargetIdAcc === 'from-text-acc') {
        const today = new Date();
        const selectedDateStr = document.getElementById(activeTargetIdAcc).innerText;
        if (selectedDateStr) {
            const parts = selectedDateStr.split('-');
            const selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
            if (selectedDate > today) {
                const year = today.getFullYear();
                const month = String(today.getMonth() + 1).padStart(2, '0');
                const day = String(today.getDate()).padStart(2, '0');
                document.getElementById(activeTargetIdAcc).innerText = `${year}-${month}-${day}`;
                showAlert('لا يمكن اختيار تاريخ مستقبلي، تم ضبطه على اليوم الحالي.');
            }
        }
    }
}

function setTodayDateAcc() {
    const today = new Date();
    const str = today.toISOString().split('T')[0];
    document.getElementById('from-text-acc').innerText = str;
    document.getElementById('to-text-acc').innerText = str;
    fetchReportDataAcc();
}

async function fetchReportDataAcc() {
    let fromStr = document.getElementById('from-text-acc').innerText;
    let toStr = document.getElementById('to-text-acc').innerText;
    let fromDate = null,
        toDate = null;
    if (fromStr) { fromDate = new Date(fromStr);
        fromDate.setHours(0, 0, 0, 0); }
    if (toStr) { toDate = new Date(toStr);
        toDate.setHours(23, 59, 59, 999); }

    document.getElementById('report-content-acc').style.display = 'none';
    document.getElementById('loaderAcc').style.display = 'block';
    document.getElementById('emptyReportMsgAcc').style.display = 'none';

    let users = await database.ref('users').once('value');
    let all = [];
    users.forEach(c => {
        let u = c.val();
        if (u && u.phone !== '999' && u.history) {
            Object.values(u.history).forEach(item => {
                if (item.type === 'in' || item.type === 'out') {
                    let itemDate = null;
                    if (item.timestamp) itemDate = new Date(item.timestamp);
                    else if (item.date) itemDate = new Date(item.date);
                    if (itemDate && !isNaN(itemDate.getTime())) {
                        all.push({
                            date: item.date || itemDate.toLocaleString('en-US'),
                            timestamp: item.timestamp,
                            itemDate: itemDate,
                            title: `${u.fullName || u.name} - ${item.title}`,
                            amount: item.amount,
                            type: item.type
                        });
                    }
                }
            });
        }
    });

    let filtered = all.filter(item => {
        if (fromDate && item.itemDate < fromDate) return false;
        if (toDate && item.itemDate > toDate) return false;
        return true;
    });
    filtered.sort((a, b) => a.itemDate - b.itemDate);

    let running = 0,
        totalDebit = 0,
        totalCredit = 0,
        rows = '';
    for (let tr of filtered) {
        let debit = (tr.type === 'out') ? tr.amount : 0;
        let credit = (tr.type === 'in') ? tr.amount : 0;
        running += credit - debit;
        totalDebit += debit;
        totalCredit += credit;
        let displayDate = tr.date || tr.itemDate.toLocaleString('en-US');
        rows += `
            <tr>
                <td style="font-size:10px;">${esc(displayDate)}</td>
                <td class="col-desc" style="font-size:10px;">${esc(tr.title)}</td>
                <td class="debit" style="font-size:10px;">${debit > 0 ? $fmt(debit) : '-'}</td>
                <td class="credit" style="font-size:10px;">${credit > 0 ? $fmt(credit) : '-'}</td>
                <td class="balance" style="font-size:10px;">${$fmt(running)}</td>
            </tr>
        `;
    }
    if (filtered.length === 0) rows =
        '<tr><td colspan="5" style="text-align:center;color:var(--text-secondary);padding:20px;">لا توجد معاملات في هذه الفترة</td></tr>';

    document.getElementById('table-body-report-acc').innerHTML = rows;
    document.getElementById('totalDebitReportAcc').innerText = $fmt(totalDebit);
    document.getElementById('totalCreditReportAcc').innerText = $fmt(totalCredit);
    document.getElementById('totalNetReportAcc').innerText = $fmt(totalCredit - totalDebit);

    document.getElementById('rep-from-acc').innerText = fromDate ? fromDate.toLocaleDateString('en-US') : 'البداية';
    document.getElementById('rep-to-acc').innerText = toDate ? toDate.toLocaleDateString('en-US') : 'الحاضر';

    document.getElementById('loaderAcc').style.display = 'none';
    document.getElementById('report-content-acc').style.display = 'block';
}

function printDocumentAcc() {
    let content = document.getElementById('printable-area-acc').innerHTML;
    let iframe = document.getElementById('print-frame-acc');
    let pri = iframe.contentWindow;
    pri.document.open();
    pri.document.write(`
        <html dir="rtl">
        <head>
            <style>
                body{font-family:'Cairo',sans-serif;padding:20px;background:#fff;}
                .account-table{width:100%;border-collapse:collapse;}
                .account-table th,.account-table td{border:1px solid #000;padding:8px;text-align:center;font-size:12px;}
                .col-desc{text-align:right!important;}
                .footer-row{background:#f2f2f2;font-weight:bold;}
                .debit{color:#c62828;font-weight:bold;}
                .credit{color:#2e7d32;font-weight:bold;}
                .balance{background:#fff9c4;font-weight:bold;}
                .summary-row td{font-size:11px!important;}
            </style>
        </head>
        <body>${content}</body>
        </html>
    `);
    pri.document.close();
    setTimeout(() => { pri.focus(); pri.print(); }, 500);
}

// ============================================================
// ADMIN: TREASURY REPORT
// ============================================================
let activeTargetIdTreasury = '';

function setupPickerTreasury(id, list, isMonth) {
    let col = document.getElementById(id);
    if (!col) return;
    col.innerHTML = '<div class="spacer"></div>';
    if (isMonth) {
        const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
        monthNames.forEach((name, idx) => {
            let monthNumber = String(idx + 1).padStart(2, '0');
            col.innerHTML += `<div class="picker-item" data-val="${monthNumber}">${name}</div>`;
        });
    } else {
        const currentYear = new Date().getFullYear();
        const startYear = currentYear - 10;
        const endYear = currentYear + 5;
        for (let y = startYear; y <= endYear; y++) {
            col.innerHTML += `<div class="picker-item" data-val="${y}">${y}</div>`;
        }
    }
    col.innerHTML += '<div class="spacer"></div>';
    col.addEventListener('scroll', function() { updateSelectedItemTreasury(this); });
    col.addEventListener('click', function(e) {
        const item = e.target.closest('.picker-item');
        if (item) {
            const colEl = item.closest('.picker-col');
            const offset = item.offsetTop - 88;
            colEl.scrollTo({ top: offset, behavior: 'smooth' });
        }
    });
}

function updateSelectedItemTreasury(col) {
    const items = col.querySelectorAll('.picker-item');
    let selectedVal = null;
    items.forEach(el => {
        const rect = el.getBoundingClientRect();
        const colRect = col.getBoundingClientRect();
        const middle = colRect.top + colRect.height / 2;
        const elMiddle = rect.top + rect.height / 2;
        if (Math.abs(elMiddle - middle) < 30) {
            el.classList.add('selected');
            selectedVal = el.dataset.val;
        } else {
            el.classList.remove('selected');
        }
    });
    if (selectedVal) {
        let year = document.querySelector('#col-year-treasury .selected')?.dataset.val;
        let month = document.querySelector('#col-month-treasury .selected')?.dataset.val;
        let day = document.querySelector('#col-day-treasury .selected')?.dataset.val;
        if (year && month && day && activeTargetIdTreasury) {
            document.getElementById(activeTargetIdTreasury).innerText = `${year}-${month}-${day}`;
        }
    }
}

function openPickerTreasury(id) {
    activeTargetIdTreasury = id;
    document.getElementById('sheetTreasury').classList.add('active');
    document.getElementById('overlayTreasury').style.display = 'block';
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
    const currentDay = String(now.getDate()).padStart(2, '0');

    if (id === 'to-text-treasury' || id === 'from-text-treasury') {
        const colDay = document.getElementById('col-day-treasury');
        colDay.innerHTML = '<div class="spacer"></div>';
        for (let d = 1; d <= now.getDate(); d++) {
            let dayStr = String(d).padStart(2, '0');
            colDay.innerHTML += `<div class="picker-item" data-val="${dayStr}">${dayStr}</div>`;
        }
        colDay.innerHTML += '<div class="spacer"></div>';
        colDay.addEventListener('scroll', function() { updateSelectedItemTreasury(this); });
        colDay.addEventListener('click', function(e) {
            const item = e.target.closest('.picker-item');
            if (item) {
                const colEl = item.closest('.picker-col');
                const offset = item.offsetTop - 88;
                colEl.scrollTo({ top: offset, behavior: 'smooth' });
            }
        });
    }

    setTimeout(() => {
        scrollToValTreasury('col-year-treasury', currentYear);
        scrollToValTreasury('col-month-treasury', currentMonth);
        scrollToValTreasury('col-day-treasury', currentDay);
    }, 150);
}

function scrollToValTreasury(id, val) {
    let col = document.getElementById(id);
    if (!col) return;
    let items = Array.from(col.querySelectorAll('.picker-item'));
    let targetVal = String(val);
    if (id === 'col-day-treasury' && (activeTargetIdTreasury === 'to-text-treasury' || activeTargetIdTreasury === 'from-text-treasury')) {
        const today = new Date();
        const maxDay = today.getDate();
        if (parseInt(targetVal) > maxDay) targetVal = String(maxDay).padStart(2, '0');
    }
    let target = items.find(el => el.dataset.val == targetVal);
    if (target) col.scrollTo({ top: target.offsetTop - 88, behavior: 'smooth' });
}

function closePickerTreasury() {
    document.getElementById('sheetTreasury').classList.remove('active');
    document.getElementById('overlayTreasury').style.display = 'none';
    if (activeTargetIdTreasury === 'to-text-treasury' || activeTargetIdTreasury === 'from-text-treasury') {
        const today = new Date();
        const selectedDateStr = document.getElementById(activeTargetIdTreasury).innerText;
        if (selectedDateStr) {
            const parts = selectedDateStr.split('-');
            const selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
            if (selectedDate > today) {
                const year = today.getFullYear();
                const month = String(today.getMonth() + 1).padStart(2, '0');
                const day = String(today.getDate()).padStart(2, '0');
                document.getElementById(activeTargetIdTreasury).innerText = `${year}-${month}-${day}`;
                showAlert('لا يمكن اختيار تاريخ مستقبلي، تم ضبطه على اليوم الحالي.');
            }
        }
    }
}

function setTodayDateTreasury() {
    let today = new Date();
    let year = today.getFullYear();
    let month = String(today.getMonth() + 1).padStart(2, '0');
    let day = String(today.getDate()).padStart(2, '0');
    let todayStr = `${year}-${month}-${day}`;
    document.getElementById('from-text-treasury').innerText = todayStr;
    document.getElementById('to-text-treasury').innerText = todayStr;
    fetchTreasuryReport();
}

async function fetchTreasuryReport() {
    const fromStr = document.getElementById('from-text-treasury').innerText;
    const toStr = document.getElementById('to-text-treasury').innerText;
    let fromDate = null,
        toDate = null;
    if (fromStr) { fromDate = new Date(fromStr);
        fromDate.setHours(0, 0, 0, 0); }
    if (toStr) { toDate = new Date(toStr);
        toDate.setHours(23, 59, 59, 999); }

    document.getElementById('report-content-treasury').style.display = 'none';
    document.getElementById('loaderTreasury').style.display = 'block';
    document.getElementById('emptyReportMsgTreasury').style.display = 'none';

    try {
        const snapshot = await database.ref('treasury/transactions').once('value');
        const data = snapshot.val() || {};
        let transactions = Object.entries(data).map(([key, val]) => ({
            id: key,
            ...val,
            dateObj: val.date ? new Date(val.date) : null
        }));

        let filtered = transactions.filter(t => {
            if (!t.dateObj) return false;
            if (fromDate && t.dateObj < fromDate) return false;
            if (toDate && t.dateObj > toDate) return false;
            return true;
        });

        filtered.sort((a, b) => a.dateObj - b.dateObj);

        let running = 0,
            totalDebit = 0,
            totalCredit = 0,
            rows = '';
        for (let t of filtered) {
            let change = $n(t.changeAmount) || 0;
            let debit = 0,
                credit = 0;
            let displayText = '';

            switch (t.type) {
                case 'deposit':
                    debit = Math.abs(change);
                    displayText = `إيداع نقدي لعميل${t.customerName ? ' - ' + t.customerName : ''}`;
                    break;
                case 'card_purchase':
                    credit = Math.abs(change);
                    displayText = `شراء كرت (إيراد) - عميل: ${t.customerName || 'غير معروف'}`;
                    break;
                case 'debt_payment':
                    credit = Math.abs(change);
                    displayText =
                        `سند سداد الفاتورة - رقم الفاتورة: ${t.invoiceNumber || 'غير محدد'} - عميل: ${t.customerName || 'غير معروف'}`;
                    break;
                case 'credit':
                    debit = Math.abs(change);
                    displayText =
                        `إيداع فاتورة أجل - رقم الفاتورة: ${t.invoiceNumber || 'غير محدد'} - عميل: ${t.customerName || 'غير معروف'}`;
                    break;
                case 'card_add':
                    credit = Math.abs(change);
                    displayText = `إضافة كروت للمخزن${t.details ? ' - ' + t.details : ''}`;
                    break;
                case 'card_delete_refund':
                case 'card_delete':
                    debit = Math.abs(change);
                    displayText = `مردود حذف كرت (خصم) - المالك${t.details ? ' - ' + t.details : ''}`;
                    break;
                default:
                    if (change > 0) credit = Math.abs(change);
                    else debit = Math.abs(change);
                    displayText = t.type || 'عملية أخرى' + (t.details ? ' - ' + t.details : '');
                    break;
            }

            running += credit - debit;
            totalDebit += debit;
            totalCredit += credit;

            let displayDate = t.dateStr || (t.dateObj ? t.dateObj.toLocaleString('en-US', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            }) : 'غير معروف');

            rows += `
                <tr>
                    <td style="font-size:10px;">${esc(displayDate)}</td>
                    <td class="col-desc" style="font-size:10px;">${esc(displayText)}</td>
                    <td class="debit" style="font-size:10px;">${debit > 0 ? $fmt(debit) : '-'}</td>
                    <td class="credit" style="font-size:10px;">${credit > 0 ? $fmt(credit) : '-'}</td>
                    <td class="balance" style="font-size:10px;">${$fmt(running)}</td>
                </tr>
            `;
        }

        if (filtered.length === 0) {
            rows =
                '<tr><td colspan="5" style="text-align:center;color:var(--text-secondary);padding:20px;">لا توجد حركات للخزينة في هذه الفترة</td></tr>';
        }

        document.getElementById('table-body-treasury').innerHTML = rows;
        document.getElementById('totalDebitTreasury').innerText = $fmt(totalDebit);
        document.getElementById('totalCreditTreasury').innerText = $fmt(totalCredit);
        document.getElementById('totalNetTreasury').innerText = $fmt(totalCredit - totalDebit);

        document.getElementById('rep-from-treasury').innerText = fromStr || 'البداية';
        document.getElementById('rep-to-treasury').innerText = toStr || 'الحاضر';

        document.getElementById('loaderTreasury').style.display = 'none';
        document.getElementById('report-content-treasury').style.display = 'block';
    } catch (e) {
        console.error(e);
        document.getElementById('loaderTreasury').style.display = 'none';
        document.getElementById('emptyReportMsgTreasury').style.display = 'block';
        Swal.fire('خطأ', 'فشل في جلب بيانات الخزينة: ' + e.message, 'error');
    }
}

function printTreasuryReport() {
    let content = document.getElementById('printable-area-treasury').innerHTML;
    let iframe = document.getElementById('print-frame-treasury');
    let pri = iframe.contentWindow;
    pri.document.open();
    pri.document.write(`
        <html dir="rtl">
        <head>
            <style>
                body{font-family:'Cairo',sans-serif;padding:20px;background:#fff;}
                .account-table{width:100%;border-collapse:collapse;}
                .account-table th,.account-table td{border:1px solid #000;padding:8px;text-align:center;font-size:12px;}
                .col-desc{text-align:right!important;}
                .footer-row{background:#f2f2f2;font-weight:bold;}
                .debit{color:#c62828;font-weight:bold;}
                .credit{color:#2e7d32;font-weight:bold;}
                .balance{background:#fff9c4;font-weight:bold;}
                .summary-row td{font-size:11px!important;}
            </style>
        </head>
        <body>${content}</body>
        </html>
    `);
    pri.document.close();
    setTimeout(() => { pri.focus(); pri.print(); }, 500);
}

// ============================================================
// ADMIN: BANNER MANAGEMENT
// ============================================================
let _adminBannerImages = [];

function loadBannerManagementAdmin() {
    database.ref('banners').on('value', snap => {
        if (snap.exists()) {
            const data = snap.val();
            _adminBannerImages = Array.isArray(data) ? data.filter(Boolean) : Object.values(data).filter(Boolean);
        } else {
            _adminBannerImages = [];
        }
        renderBannerImagesListAdmin();
    });
    database.ref('settings/bannerInterval').once('value', snap => {
        const val = snap.val();
        if (val) document.getElementById('bannerIntervalInput').value = val;
    });
}

function renderBannerImagesListAdmin() {
    const container = document.getElementById('bannerImagesListAdmin');
    if (!container) return;
    if (_adminBannerImages.length === 0) {
        container.innerHTML = '<div class="empty-state">لا توجد صور، أضف صورة جديدة.</div>';
        return;
    }
    container.innerHTML = _adminBannerImages.map((img, index) => {
        const url = typeof img === 'string' ? img : (img.url || '');
        return `<div class="banner-image-item"><img src="${esc(url)}" class="banner-image-preview" onerror="this.src='https://placehold.co/100x100?text=%D8%AE%D8%B7%D8%A3'"><div class="banner-image-info"><div class="banner-image-title">صورة ${index + 1}</div></div><button class="delete-banner-btn" onclick="deleteBannerImageAdmin(${index})"><i class="fas fa-trash"></i> حذف</button></div>`;
    }).join('');
}

window.addBannerImage = function () {
    const input = document.getElementById('newBannerUrl');
    const url = input.value.trim();
    if (!url) return showAlert('الرجاء إدخال رابط الصورة', false);
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        return showAlert('الرابط يجب أن يبدأ بـ http:// أو https://', false);
    }
    _adminBannerImages.push({ url: url, title: '', sub: '' });
    database.ref('banners').set(_adminBannerImages)
        .then(() => { input.value = ''; showAlert('تمت إضافة الصورة بنجاح'); })
        .catch(err => { console.error(err); showAlert('حدث خطأ أثناء حفظ الصورة', false); });
};

window.deleteBannerImageAdmin = function (index) {
    Swal.fire({
        title: 'حذف الصورة', text: 'هل أنت متأكد من حذف هذه الصورة؟', icon: 'warning',
        showCancelButton: true, confirmButtonText: 'نعم، احذف', cancelButtonText: 'إلغاء',
        background: '#161b22', color: '#e6edf3', confirmButtonColor: '#ef4444', cancelButtonColor: '#2a3340'
    }).then(result => {
        if (result.isConfirmed) {
            _adminBannerImages.splice(index, 1);
            database.ref('banners').set(_adminBannerImages)
                .then(() => showAlert('تم حذف الصورة'))
                .catch(err => { console.error(err); showAlert('حدث خطأ أثناء الحذف', false); });
        }
    });
};

window.uploadBannerFromGallery = function () {
    const fileInput = document.getElementById('galleryImageInput');
    const file = fileInput.files[0];
    if (!file) return showAlert('الرجاء اختيار صورة أولاً', false);
    if (!file.type.startsWith('image/')) return showAlert('الملف المختار ليس صورة', false);

    const reader = new FileReader();
    reader.onload = function (e) {
        _adminBannerImages.push({ url: e.target.result, title: '', sub: '' });
        database.ref('banners').set(_adminBannerImages)
            .then(() => {
                fileInput.value = '';
                document.getElementById('bannerImagePreview').style.display = 'none';
                showAlert('تمت إضافة الصورة بنجاح');
            })
            .catch(err => { console.error(err); showAlert('حدث خطأ أثناء حفظ الصورة', false); });
    };
    reader.onerror = () => showAlert('حدث خطأ أثناء قراءة الملف', false);
    reader.readAsDataURL(file);
};

window.updateBannerIntervalAdmin = function () {
    const val = parseInt(document.getElementById('bannerIntervalInput').value);
    if (isNaN(val) || val < 1) return showAlert('يرجى إدخال مدة صحيحة (أكبر من 0)', false);
    database.ref('settings/bannerInterval').set(val)
        .then(() => showAlert('تم تحديث مدة التبديل'))
        .catch(err => { console.error(err); showAlert('حدث خطأ أثناء الحفظ', false); });
};

document.addEventListener('DOMContentLoaded', () => {
    const galleryInput = document.getElementById('galleryImageInput');
    if (galleryInput) {
        galleryInput.addEventListener('change', function (e) {
            const file = e.target.files[0];
            const preview = document.getElementById('bannerImagePreview');
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = ev => { preview.src = ev.target.result; preview.style.display = 'block'; };
                reader.readAsDataURL(file);
            } else if (preview) {
                preview.style.display = 'none';
                preview.src = '';
            }
        });
    }
});

// ============================================================
// ADMIN: NEWS MANAGEMENT
// ============================================================
let _adminNewsTexts = [];

function loadNewsManagementAdmin() {
    database.ref('newsTexts').on('value', snap => {
        if (snap.exists()) {
            const data = snap.val();
            _adminNewsTexts = Array.isArray(data) ? data.filter(Boolean) : Object.values(data).filter(Boolean);
        } else {
            _adminNewsTexts = ['مرحباً بك في كوفانت', 'خدمة التحويل الفوري متاحة', 'عروض الباقات الجديدة'];
            database.ref('newsTexts').set(_adminNewsTexts);
        }
        renderNewsTextsListAdmin();
    });
    database.ref('settings/typingSpeed').once('value', snap => {
        const val = snap.val();
        if (val) document.getElementById('typingSpeedInput').value = val;
    });
}

function renderNewsTextsListAdmin() {
    const container = document.getElementById('newsTextsListAdmin');
    if (!container) return;
    if (_adminNewsTexts.length === 0) {
        container.innerHTML = '<div class="empty-state">لا توجد نصوص، أضف نصاً جديداً.</div>';
        return;
    }
    container.innerHTML = _adminNewsTexts.map((text, index) =>
        `<div class="news-item"><span class="news-item-text">${esc(text)}</span><button class="delete-news-btn" onclick="deleteNewsTextAdmin(${index})"><i class="fas fa-trash"></i> حذف</button></div>`
    ).join('');
}

window.addNewsTextAdmin = function () {
    const input = document.getElementById('newNewsTextInput');
    const newText = input.value.trim();
    if (!newText) return showAlert('الرجاء إدخال نص الإعلان', false);
    _adminNewsTexts.push(newText);
    database.ref('newsTexts').set(_adminNewsTexts)
        .then(() => { input.value = ''; showAlert('تمت إضافة النص بنجاح'); })
        .catch(err => { console.error(err); showAlert('حدث خطأ أثناء حفظ النص', false); });
};

window.deleteNewsTextAdmin = function (index) {
    Swal.fire({
        title: 'حذف النص', text: 'هل أنت متأكد من حذف هذا النص الإعلاني؟', icon: 'warning',
        showCancelButton: true, confirmButtonText: 'نعم، احذف', cancelButtonText: 'إلغاء',
        background: '#161b22', color: '#e6edf3', confirmButtonColor: '#ef4444', cancelButtonColor: '#2a3340'
    }).then(result => {
        if (result.isConfirmed) {
            _adminNewsTexts.splice(index, 1);
            database.ref('newsTexts').set(_adminNewsTexts)
                .then(() => showAlert('تم حذف النص'))
                .catch(err => { console.error(err); showAlert('حدث خطأ أثناء الحذف', false); });
        }
    });
};

window.updateTypingSpeedAdmin = function () {
    const val = parseInt(document.getElementById('typingSpeedInput').value);
    if (isNaN(val) || val < 20) return showAlert('يرجى إدخال سرعة صحيحة (20 على الأقل)', false);
    database.ref('settings/typingSpeed').set(val)
        .then(() => showAlert('تم تحديث سرعة الطباعة'))
        .catch(err => { console.error(err); showAlert('حدث خطأ أثناء الحفظ', false); });
};

// ============================================================
// ADMIN: VISITORS
// ============================================================
let _adminVisitorsListener = null;

function loadAdminVisitors() {
    if (_adminVisitorsListener) {
        database.ref('users').off('value', _adminVisitorsListener);
        _adminVisitorsListener = null;
    }
    _adminVisitorsListener = function (snap) {
        const rows = [];
        const usersVal = snap.val() || {};
        for (const phone in usersVal) {
            const u = usersVal[phone];
            if (!u.devices) continue;
            for (const devId in u.devices) {
                const dev = u.devices[devId];
                rows.push({
                    phone,
                    fullName: u.fullName || u.name || 'بدون اسم',
                    accountNumber: u.accountNumber || phone.slice(-5),
                    deviceName: dev.deviceName || 'جهاز غير معروف',
                    deviceModel: dev.analytics?.deviceModel || '',
                    os: dev.analytics?.os || 'غير معروف',
                    browser: dev.analytics?.browser || 'غير معروف',
                    deviceType: dev.analytics?.deviceType || 'desktop',
                    lastUsed: dev.lastUsed || dev.addedAt || 0
                });
            }
        }
        rows.sort((a, b) => b.lastUsed - a.lastUsed);
        renderAdminVisitors(rows);
    };
    database.ref('users').on('value', _adminVisitorsListener);
}

function visitorsBreakdownRows(rows, field) {
    const counts = {};
    rows.forEach(r => { counts[r[field]] = (counts[r[field]] || 0) + 1; });
    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    const max = entries.length ? entries[0][1] : 1;
    if (!entries.length) return '<div class="device-empty">لا توجد بيانات</div>';
    return entries.map(([label, count]) => `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
            <div style="width:110px;font-size:12px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(label)}</div>
            <div style="flex:1;background:rgba(255,255,255,0.04);border-radius:20px;height:16px;overflow:hidden;">
                <div style="height:100%;width:${Math.max(6, Math.round((count / max) * 100))}%;background:linear-gradient(90deg,var(--blue),var(--purple));"></div>
            </div>
            <div style="width:36px;text-align:left;font-size:12px;font-weight:700;color:var(--text-primary);">${count}</div>
        </div>
    `).join('');
}

function renderAdminVisitors(rows) {
    const container = document.getElementById('adminVisitorsContainer');
    if (!container) return;

    const recentRows = rows.slice(0, 50).map(r => `
        <div class="device-entry">
            <div style="flex:1;">
                <div class="device-name"><i class="fas fa-user"></i> ${esc(r.fullName)} <span style="color:var(--text-secondary);font-weight:500;">— ${esc(r.accountNumber)}</span></div>
                <div style="font-size:11px;color:var(--text-secondary);margin-top:2px;">${esc(r.browser)} · ${esc(r.os)}${r.deviceModel ? ' · ' + esc(r.deviceModel) : ' · ' + esc(r.deviceName)}</div>
            </div>
            <div class="device-meta">
                <span><i class="fas fa-mobile-alt"></i> ${esc(r.deviceType)}</span>
                <span><i class="far fa-clock"></i> ${r.lastUsed ? new Date(r.lastUsed).toLocaleString('ar-YE') : ''}</span>
            </div>
        </div>
    `).join('') || '<div class="device-empty">لا توجد أجهزة مسجّلة بعد</div>';

    container.innerHTML = `
        <div class="dashboard-grid" style="margin-bottom:16px;">
            <div class="kpi-card" style="border-right:3px solid var(--purple);">
                <div class="kpi-icon" style="background:rgba(139,92,246,0.1);color:var(--purple);"><i class="fas fa-mobile-alt"></i></div>
                <div class="kpi-text"><span class="kpi-label">إجمالي الأجهزة المسجّلة</span><span class="kpi-value">${rows.length}</span></div>
            </div>
            <div class="kpi-card" style="border-right:3px solid var(--blue);">
                <div class="kpi-icon" style="background:rgba(59,130,246,0.1);color:var(--blue);"><i class="fas fa-users"></i></div>
                <div class="kpi-text"><span class="kpi-label">مستخدمون لديهم أجهزة</span><span class="kpi-value">${new Set(rows.map(r => r.phone)).size}</span></div>
            </div>
        </div>

        <div class="device-item">
            <div style="font-weight:800;font-size:13px;margin-bottom:12px;"><i class="fas fa-mobile-alt" style="color:var(--blue);margin-left:6px;"></i> حسب نوع الجهاز</div>
            ${visitorsBreakdownRows(rows, 'deviceType')}
        </div>
        <div class="device-item">
            <div style="font-weight:800;font-size:13px;margin-bottom:12px;"><i class="fas fa-globe" style="color:var(--green);margin-left:6px;"></i> حسب المتصفح</div>
            ${visitorsBreakdownRows(rows, 'browser')}
        </div>
        <div class="device-item">
            <div style="font-weight:800;font-size:13px;margin-bottom:12px;"><i class="fas fa-desktop" style="color:var(--gold);margin-left:6px;"></i> حسب نظام التشغيل</div>
            ${visitorsBreakdownRows(rows, 'os')}
        </div>

        <div class="device-item">
            <div style="font-weight:800;font-size:13px;margin-bottom:12px;"><i class="fas fa-history" style="color:var(--purple);margin-left:6px;"></i> آخر الأجهزة المستخدَمة (بالاسم ورقم الحساب)</div>
            <div class="device-list">${recentRows}</div>
        </div>
    `;
}