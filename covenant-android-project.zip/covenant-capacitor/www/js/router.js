// ============================================================
// UI HELPERS
// ============================================================
function toggleBalance() {
    const el = document.getElementById('amount');
    APP.hiddenBalance = !APP.hiddenBalance;
    if (APP.hiddenBalance) {
        el.textContent = '•••••••';
        document.getElementById('eyeIcon').className = 'fa-regular fa-eye-slash';
    } else {
        el.textContent = el.dataset.realValue || '0.00';
        document.getElementById('eyeIcon').className = 'fa-regular fa-eye';
    }
}

function toggleSidebar() {
    const ov = document.getElementById('sidebarOverlay');
    ov.classList.toggle('active');
    document.body.style.overflow = ov.classList.contains('active') ? 'hidden' : '';
}

function logout() {
    if (APP.user?.phone) {
        database.ref('notifications/' + APP.user.phone).off();
        database.ref('chats/' + getChatId(APP.user.phone)).off();
        database.ref('users/' + APP.user.phone).update({ isOnline: false });
    }
    APP.user = null;
    APP._notifListenerPhone = null;
    hideAllSystemPages();
    showAlert('تم تسجيل الخروج بنجاح');
}

function logoutUser() {
    document.getElementById('sidebarOverlay').classList.remove('active');
    document.body.style.overflow = '';
    logout();
}

// ============================================================
// NAVIGATION
// ============================================================
const PASSWORD_FIELDS_BY_PAGE = {
    loginInterface: ['loginPass', 'signupPass', 'signupConfirmPass'],
    profileInterface: ['profileOldPass', 'profileNewPass', 'profileOldPin', 'profileNewPin']
};
function syncPasswordFieldTypes(activePageId) {
    Object.entries(PASSWORD_FIELDS_BY_PAGE).forEach(([page, ids]) => {
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            el.type = (page === activePageId) ? 'password' : 'text';
        });
    });
}

const ALL_SYSTEM_PAGES = [
    'dashboardInterface', 'userInterface',
    'barcodeInterface', 'transferInterface', 'adminSystemInterface',
    'notificationsInterface', 'statementInterface', 'packagesInterface',
    'supportTicketsPage', 'chatPage', 'chatDetailPage', 'dataInterface',
    'storeCardsInterface', 'soldCardsInterface', 'allTransactionsInterface',
    'accountingReportInterface', 'treasuryReportInterface',
    'adminInvoicesInterface', 'adminInvoiceDetailInterface', 'userInvoicesInterface',
    'bannerManagementInterface', 'newsManagementInterface', 'profileInterface'
];
function hideAllSystemPages() {
    ALL_SYSTEM_PAGES.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = 'none';
            el.classList.remove('active');
        }
    });
}

function navigateTo(pageId, isMain) {
    // ============================================================
    // ✅ التحكم في خلفية الصفحة بالكامل (باستخدام كلاس system-mode)
    // ============================================================
    const body = document.body;
    const hideBgPages = [
        'dashboardInterface', 'userInterface', 'adminSystemInterface',
        'dataInterface', 'adminInvoicesInterface', 'adminInvoiceDetailInterface',
        'storeCardsInterface', 'soldCardsInterface', 'accountingReportInterface',
        'treasuryReportInterface', 'bannerManagementInterface', 'newsManagementInterface',
        'profileInterface', 'transferInterface', 'notificationsInterface',
        'statementInterface', 'packagesInterface', 'allTransactionsInterface',
        'supportTicketsPage', 'chatDetailPage', 'userInvoicesInterface'
    ];

    if (hideBgPages.includes(pageId)) {
        body.classList.add('system-mode');
    } else {
        body.classList.remove('system-mode');
    }

    // ============================================================
    // باقي الكود الأصلي للتنقل (لا تغيره)
    // ============================================================
    syncPasswordFieldTypes(pageId);
    // ✅ إصلاح: كان الاسم هنا 'loginInterface' وهو عنصر غير موجود فعلياً في الصفحة
    // (المعرّف الحقيقي هو 'login-view')، لذلك كانت شاشة الدخول لا تُخفى أبداً
    // عبر هذه الدالة، وتبقى ظاهرة خلف/أسفل صفحات لوحة التحكم والأدمن.
    document.getElementById('login-view')?.classList.add('hidden');
    document.getElementById('main-container') && (document.getElementById('main-container').style.display = 'none');
    const pages = [
        'dashboardInterface', 'userInterface',
        'barcodeInterface', 'transferInterface', 'adminSystemInterface',
        'notificationsInterface', 'statementInterface', 'packagesInterface',
        'supportTicketsPage', 'chatDetailPage', 'dataInterface',
        'storeCardsInterface', 'soldCardsInterface', 'allTransactionsInterface',
        'accountingReportInterface', 'treasuryReportInterface',
        'adminInvoicesInterface', 'adminInvoiceDetailInterface', 'userInvoicesInterface',
        'bannerManagementInterface', 'newsManagementInterface', 'profileInterface'
    ];
    pages.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.style.display = 'none';
            el.classList.remove('active');
        }
    });

    const target = document.getElementById(pageId);
    if (!target) return;

    if (pageId === 'supportTicketsPage' || pageId === 'chatDetailPage') {
        target.style.display = 'flex';
    } else {
        target.style.display = 'block';
    }

    const activePages = [
        'loginInterface', 'dashboardInterface', 'userInterface',
        'adminSystemInterface', 'packagesInterface', 'supportTicketsPage',
        'chatDetailPage', 'dataInterface', 'storeCardsInterface',
        'soldCardsInterface', 'allTransactionsInterface',
        'accountingReportInterface', 'statementInterface',
        'treasuryReportInterface', 'adminInvoicesInterface',
        'adminInvoiceDetailInterface', 'userInvoicesInterface', 'profileInterface'
    ];
    if (activePages.includes(pageId)) target.classList.add('active');

    APP.isMain = isMain;
    if (!isMain) history.pushState({ page: pageId }, '');
    else history.replaceState({ page: 'main' }, '');

    const dNav = document.getElementById('dashboardBottomNav');
    const adminPages = [
        'dashboardInterface', 'dataInterface', 'storeCardsInterface',
        'soldCardsInterface', 'accountingReportInterface',
        'treasuryReportInterface', 'adminSystemInterface',
        'adminInvoicesInterface', 'adminInvoiceDetailInterface'
    ];
    dNav.classList.toggle('active', adminPages.includes(pageId));

    const navBtns = dNav.querySelectorAll('.nav-btn');
    navBtns.forEach(btn => btn.classList.remove('active'));
    if (pageId === 'dashboardInterface') {
        if (navBtns[0]) navBtns[0].classList.add('active');
    } else if (['dataInterface', 'storeCardsInterface', 'soldCardsInterface',
            'accountingReportInterface', 'treasuryReportInterface',
            'adminInvoicesInterface', 'adminInvoiceDetailInterface'
        ].includes(pageId)) {
        if (navBtns[1]) navBtns[1].classList.add('active');
    }

    // تحميل البيانات حسب الصفحة
    if (pageId === 'dashboardInterface') loadDashboardData();
    if (pageId === 'adminSystemInterface') {
        navigateAdmin('system');
        loadAdminUsers();
        loadAdminStore();
    }
    if (pageId === 'barcodeInterface' && APP.user) updateBarcodePage();
    if (pageId === 'transferInterface' && APP.user) {
        document.getElementById('transfer-current-balance').innerText = $fmt(APP.user.balance);
    }
    if (pageId === 'statementInterface' && APP.user) {
        setDefaultStatementDates();
        loadStatementData();
    }
    if (pageId === 'profileInterface' && APP.user) {
        loadProfilePage();
    }
    if (pageId === 'accountingReportInterface') {
        setTimeout(() => {
            setupPickerAcc('col-year-acc', [], false);
            setupPickerAcc('col-month-acc', ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"], true);
            setupPickerAcc('col-day-acc', Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0')), false);
            setTodayDateAcc();
        }, 100);
    }
    if (pageId === 'treasuryReportInterface') {
        setTimeout(() => {
            setupPickerTreasury('col-year-treasury', [], false);
            setupPickerTreasury('col-month-treasury', ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"], true);
            setupPickerTreasury('col-day-treasury', Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0')), false);
            setTodayDateTreasury();
        }, 100);
    }
    if (pageId === 'userInterface' && APP.user) {
        updateUserUI(APP.user, APP.user.phone);
        renderLastTransactions();
    }
    if (pageId === 'notificationsInterface') renderNotifications();
    if (pageId === 'storeCardsInterface') StoreManager.load();
    if (pageId === 'soldCardsInterface') SoldManager.load();
    if (pageId === 'allTransactionsInterface' && APP.user) renderAllTransactions();
    if (pageId === 'packagesInterface') loadPackagesFromStore();
    if (pageId === 'adminInvoicesInterface') loadAdminInvoicesOverview();
    if (pageId === 'userInvoicesInterface') loadUserInvoices();
    if (pageId === 'bannerManagementInterface') loadBannerManagementAdmin();
    if (pageId === 'newsManagementInterface') loadNewsManagementAdmin();

    APP.selectedMessage = null;
}

// ============================================================
// ADMIN NAVIGATION
// ============================================================
function navigateAdmin(section) {
    const sections = ['adminSystemHome', 'adminPageUsers', 'adminPageCards', 'adminDevicesInterface', 'adminPageNotifications', 'adminVisitorsInterface'];
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });

    const titles = {
        system: 'إدارة النظام والتواصل',
        users: 'إدارة الحسابات',
        cards: 'مخزن الكروت',
        devices: 'إدارة الأجهزة',
        notifications: 'إدارة الإشعارات',
        visitors: 'زوّار الموقع'
    };

    if (section === 'system') {
        document.getElementById('adminSystemHome').style.display = 'block';
    } else if (section === 'users') {
        document.getElementById('adminPageUsers').style.display = 'block';
        loadAdminUsers();
    } else if (section === 'cards') {
        document.getElementById('adminPageCards').style.display = 'block';
        loadAdminStore();
    } else if (section === 'devices') {
        document.getElementById('adminDevicesInterface').style.display = 'block';
        loadAdminDevices();
    } else if (section === 'notifications') {
        document.getElementById('adminPageNotifications').style.display = 'block';
        loadAdminNotificationLog();
        loadUsersForNotificationSelect();
    } else if (section === 'visitors') {
        document.getElementById('adminVisitorsInterface').style.display = 'block';
        loadAdminVisitors();
    }

    document.getElementById('adminSystemTitle').innerText = titles[section] || 'إدارة النظام';
    APP.adminCurrentSection = section;

    const btn = document.getElementById('adminSystemBackBtn');
    if (section === 'system') {
        btn.innerHTML = '<i class="fas fa-arrow-right"></i> رجوع';
        btn.onclick = function() { navigateTo('dashboardInterface', true); };
    } else {
        btn.innerHTML = '<i class="fas fa-arrow-right"></i> رجوع';
        btn.onclick = function() { navigateAdmin('system'); };
    }

    document.querySelectorAll('.admin-bottom-nav .nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.admin-bottom-nav .nav-btn')?.classList.add('active');
}

function navigateAdminBack() {
    if (APP.adminCurrentSection === 'system') navigateTo('dashboardInterface', true);
    else navigateAdmin('system');
}

function toNumber(v) {
    if (typeof v === 'number') return v;
    let c = String(v).replace(/,/g, '').trim();
    let n = parseFloat(c);
    return isNaN(n) ? 0 : n;
}

// ============================================================
// STATEMENT
// ============================================================
let activeTargetIdStmt = '';

function setupPickerStmt(id, list, isMonth) {
    let col = document.getElementById(id);
    if (!col) return;
    col.innerHTML = '<div class="spacer"></div>';
    if (isMonth) {
        const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
        monthNames.forEach((name, idx) => {
            let monthNumber = String(idx + 1).padStart(2, '0');
            col.innerHTML += `<div class="picker-item" data-val="${monthNumber}">${name}</div>`;
        });
    } else {
        const currentYear = new Date().getFullYear();
        const startYear = currentYear - 10;
        const endYear = currentYear + 5;
        for (let y = startYear; y <= endYear; y++) {
            col.innerHTML += `<div class="picker-item" data-val="${y}">${y}</div>`;
        }
    }
    col.innerHTML += '<div class="spacer"></div>';
    col.addEventListener('scroll', function() { updateSelectedItemStmt(this); });
    col.addEventListener('click', function(e) {
        const item = e.target.closest('.picker-item');
        if (item) {
            const colEl = item.closest('.picker-col');
            const offset = item.offsetTop - 88;
            colEl.scrollTo({ top: offset, behavior: 'smooth' });
        }
    });
}

function updateSelectedItemStmt(col) {
    const items = col.querySelectorAll('.picker-item');
    let selectedVal = null;
    items.forEach(el => {
        const rect = el.getBoundingClientRect();
        const colRect = col.getBoundingClientRect();
        const middle = colRect.top + colRect.height / 2;
        const elMiddle = rect.top + rect.height / 2;
        if (Math.abs(elMiddle - middle) < 30) {
            el.classList.add('selected');
            selectedVal = el.dataset.val;
        } else {
            el.classList.remove('selected');
        }
    });
    if (selectedVal) {
        let year = document.querySelector('#col-year-stmt .selected')?.dataset.val;
        let month = document.querySelector('#col-month-stmt .selected')?.dataset.val;
        let day = document.querySelector('#col-day-stmt .selected')?.dataset.val;
        if (year && month && day && activeTargetIdStmt) {
            document.getElementById(activeTargetIdStmt).innerText = `${year}-${month}-${day}`;
        }
    }
}

function openPickerStmt(id) {
    activeTargetIdStmt = id;
    document.getElementById('sheetStmt').classList.add('active');
    document.getElementById('overlayStmt').style.display = 'block';
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
    const currentDay = String(now.getDate()).padStart(2, '0');

    if (id === 'to-text-stmt' || id === 'from-text-stmt') {
        const colDay = document.getElementById('col-day-stmt');
        colDay.innerHTML = '<div class="spacer"></div>';
        for (let d = 1; d <= now.getDate(); d++) {
            let dayStr = String(d).padStart(2, '0');
            colDay.innerHTML += `<div class="picker-item" data-val="${dayStr}">${dayStr}</div>`;
        }
        colDay.innerHTML += '<div class="spacer"></div>';
        colDay.addEventListener('scroll', function() { updateSelectedItemStmt(this); });
        colDay.addEventListener('click', function(e) {
            const item = e.target.closest('.picker-item');
            if (item) {
                const colEl = item.closest('.picker-col');
                const offset = item.offsetTop - 88;
                colEl.scrollTo({ top: offset, behavior: 'smooth' });
            }
        });
    }

    setTimeout(() => {
        scrollToValStmt('col-year-stmt', currentYear);
        scrollToValStmt('col-month-stmt', currentMonth);
        scrollToValStmt('col-day-stmt', currentDay);
    }, 150);
}

function scrollToValStmt(id, val) {
    let col = document.getElementById(id);
    if (!col) return;
    let items = Array.from(col.querySelectorAll('.picker-item'));
    let targetVal = String(val);
    if (id === 'col-day-stmt' && (activeTargetIdStmt === 'to-text-stmt' || activeTargetIdStmt === 'from-text-stmt')) {
        const today = new Date();
        const maxDay = today.getDate();
        if (parseInt(targetVal) > maxDay) targetVal = String(maxDay).padStart(2, '0');
    }
    let target = items.find(el => el.dataset.val == targetVal);
    if (target) col.scrollTo({ top: target.offsetTop - 88, behavior: 'smooth' });
}

function closePickerStmt() {
    document.getElementById('sheetStmt').classList.remove('active');
    document.getElementById('overlayStmt').style.display = 'none';
    if (activeTargetIdStmt === 'to-text-stmt' || activeTargetIdStmt === 'from-text-stmt') {
        const today = new Date();
        const selectedDateStr = document.getElementById(activeTargetIdStmt).innerText;
        if (selectedDateStr) {
            const parts = selectedDateStr.split('-');
            const selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
            if (selectedDate > today) {
                const year = today.getFullYear();
                const month = String(today.getMonth() + 1).padStart(2, '0');
                const day = String(today.getDate()).padStart(2, '0');
                document.getElementById(activeTargetIdStmt).innerText = `${year}-${month}-${day}`;
                showAlert('لا يمكن اختيار تاريخ مستقبلي، تم ضبطه على اليوم الحالي.');
            }
        }
    }
}

function setDefaultStatementDates() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const todayStr = `${year}-${month}-${day}`;
    document.getElementById('from-text-stmt').innerText = todayStr;
    document.getElementById('to-text-stmt').innerText = todayStr;
}

function setTodayStatement() {
    const today = new Date();
    const str = today.toISOString().split('T')[0];
    document.getElementById('from-text-stmt').innerText = str;
    document.getElementById('to-text-stmt').innerText = str;
    loadStatementData();
}

function loadStatementData() {
    if (!APP.user) {
        showAlert('الرجاء تسجيل الدخول أولاً');
        return;
    }
    document.getElementById('loaderStmt').style.display = 'block';
    document.getElementById('report-content-stmt').style.display = 'none';

    setTimeout(() => {
        document.getElementById('loaderStmt').style.display = 'none';
        document.getElementById('report-content-stmt').style.display = 'block';
        renderStatement();
    }, 300);
}

function renderStatement() {
    const fromStr = document.getElementById('from-text-stmt').innerText;
    const toStr = document.getElementById('to-text-stmt').innerText;
    let fromDate = null,
        toDate = null;
    if (fromStr) { fromDate = new Date(fromStr);
        fromDate.setHours(0, 0, 0, 0); }
    if (toStr) { toDate = new Date(toStr);
        toDate.setHours(23, 59, 59, 999); }

    const history = APP.user.history || {};
    const historyArray = Object.values(history);
    let filtered = historyArray.filter(item => {
        let itemDate = null;
        if (item.timestamp) itemDate = new Date(item.timestamp);
        else if (item.date) itemDate = new Date(item.date);
        if (!itemDate) return false;
        if (fromDate && itemDate < fromDate) return false;
        if (toDate && itemDate > toDate) return false;
        return true;
    });
    filtered.sort((a, b) => (a.timestamp || new Date(a.date).getTime()) - (b.timestamp || new Date(b.date).getTime()));

    let runningCash = 0,
        runningDebt = 0;
    let totalDebit = 0,
        totalCredit = 0;
    let rows = '';

    if (!filtered.length) {
        rows =
            '<tr><td colspan="5" style="text-align:center;color:var(--text-secondary);padding:30px 0;">لا توجد معاملات في هذه الفترة</td></tr>';
    } else {
        filtered.forEach(item => {
            let amount = $n(item.amount);
            let isDebit = (item.type === 'out' || item.type === 'withdraw');
            let isCredit = (item.type === 'in' || item.type === 'deposit' || item.type === 'transfer_in');
            let debit = isDebit ? amount : 0;
            let credit = isCredit ? amount : 0;

            let isDebtInvoice = item.title && (item.title.includes('فاتورة آجلة') || item.title.includes('إنشاء فاتورة'));
            if (isCredit) {
                if (isDebtInvoice) runningDebt += amount;
                else runningCash += amount;
            } else if (isDebit) {
                let isDebtPayment = item.title && item.title.includes('سداد فاتورة');
                if (isDebtPayment) runningDebt -= amount;
                else runningCash -= amount;
            }

            totalDebit += debit;
            totalCredit += credit;

            let displayDate = item.dateStr || item.date || '';
            if (item.timestamp) {
                const d = new Date(item.timestamp);
                displayDate = d.toLocaleString('en-US', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });
            }
            let runningTotal = runningCash + runningDebt;
            rows += `
                <tr>
                    <td style="font-size:10px;">${esc(displayDate)}</td>
                    <td class="col-desc" style="font-size:10px;">${esc(item.title || item.description || 'معاملة')}</td>
                    <td class="debit" style="font-size:10px;">${debit > 0 ? $fmt(debit) : '-'}</td>
                    <td class="credit" style="font-size:10px;">${credit > 0 ? $fmt(credit) : '-'}</td>
                    <td class="balance" style="font-size:10px;">${$fmt(runningTotal)}</td>
                </tr>
            `;
        });
    }

    const finalBalance = runningCash + runningDebt;
    document.getElementById('table-body-stmt').innerHTML = rows;
    document.getElementById('totalDebitStmt').innerText = $fmt(totalDebit);
    document.getElementById('totalCreditStmt').innerText = $fmt(totalCredit);
    document.getElementById('totalNetStmt').innerText = $fmt(totalCredit - totalDebit);

    const summaryRow = document.getElementById('summaryRowStmt');
    if (summaryRow) {
        summaryRow.style.display = 'table-row';
        document.getElementById('summaryCashStmt').innerText = `رصيد نقدي ${$fmt(runningCash)}`;
        document.getElementById('summaryDebtStmt').innerText = `رصيد الفاتورة المتبقي عليكم ${$fmt(runningDebt)}`;
        document.getElementById('summaryTotalStmt').innerText = `اجمالي الرصيد ${$fmt(finalBalance)}`;
    }

    document.getElementById('rep-from-stmt').innerText = fromStr || 'البداية';
    document.getElementById('rep-to-stmt').innerText = toStr || 'الحاضر';
    const userName = APP.user?.fullName || 'مستخدم';
    document.getElementById('repUserNameStmt').innerText = userName;
    document.getElementById('reportUserNameStmtBar').innerText = userName;

    document.getElementById('loaderStmt').style.display = 'none';
    document.getElementById('emptyReportMsgStmt').style.display = 'none';
    document.getElementById('report-content-stmt').style.display = 'block';
}

function printStatement() {
    let content = document.getElementById('printable-area-stmt').innerHTML;
    let iframe = document.getElementById('print-frame-stmt');
    let pri = iframe.contentWindow;
    pri.document.open();
    pri.document.write(`
        <html dir="rtl">
        <head>
            <style>
                body{font-family:'Cairo',sans-serif;padding:20px;background:#fff;}
                .account-table{width:100%;border-collapse:collapse;}
                .account-table th,.account-table td{border:1px solid #000;padding:8px;text-align:center;font-size:12px;}
                .col-desc{text-align:right!important;}
                .footer-row{background:#f2f2f2;font-weight:bold;}
                .debit{color:#c62828;font-weight:bold;}
                .credit{color:#2e7d32;font-weight:bold;}
                .balance{background:#fff9c4;font-weight:bold;}
                .summary-row td{font-size:11px!important;}
                .separator{opacity:0.3;padding:0 4px;}
            </style>
        </head>
        <body>${content}</body>
        </html>
    `);
    pri.document.close();
    setTimeout(() => { pri.focus(); pri.print(); }, 500);
}

// ============================================================
// SCANNER
// ============================================================
function startScanner() {
    stopScanner();
    document.getElementById('scanner-overlay').style.display = 'flex';
}

function stopScanner() {
    if (APP.html5Qr) {
        try { APP.html5Qr.stop().catch(e => {}); } catch (e) {}
    }
    APP.html5Qr = null;
    document.getElementById('scanner-overlay').style.display = 'none';
    document.getElementById('scanner-area').innerHTML = '';
}

async function startCameraScanner() {
    const sa = document.getElementById('scanner-area');
    if (!sa) return;
    sa.innerHTML = '';
    try {
        APP.html5Qr = new Html5Qrcode("scanner-area");
        await APP.html5Qr.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } },
            onScanSuccess, onScanError);
    } catch (e) {
        Swal.fire('خطأ', 'تعذر تشغيل الكاميرا.', 'error');
    }
}

function selectImageFromGallery() {
    const fi = document.getElementById('qr-file-input');
    if (!fi) return;
    fi.value = '';
    fi.click();
    fi.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        Swal.fire({
            title: 'جاري المسح',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });
        try {
            const temp = new Html5Qrcode("scanner-area");
            const decoded = await temp.scanFile(file, true);
            Swal.close();
            await onScanSuccess(decoded);
        } catch (err) {
            Swal.close();
            Swal.fire('خطأ', 'لم يتم العثور على رمز QR', 'error');
        }
    };
}

async function onScanSuccess(decodedText) {
    stopScanner();
    try {
        let acc = decodedText;
        try { const qd = JSON.parse(decodedText); if (qd.account) acc = qd.account; } catch (e) {}
        if (!/^(40|41)\d{8}$/.test(acc)) {
            Swal.fire('تنبيه', 'رمز QR غير صالح', 'warning');
            return;
        }
        document.getElementById('recipient-account').value = acc;
        Swal.fire({ title: 'تم المسح', icon: 'success', timer: 1500, showConfirmButton: false });
    } catch (e) {
        Swal.fire('خطأ', 'حدث خطأ', 'error');
    }
}

function onScanError(err) {
    if (err && !err.includes('NotFoundException')) console.error(err);
}

// ============================================================
// INIT & EVENT LISTENERS
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    hideAllSystemPages();

    document.getElementById('scan-qr-btn')?.addEventListener('click', startScanner);
    document.getElementById('startCameraBtn')?.addEventListener('click', startCameraScanner);
    document.getElementById('uploadGalleryBtn')?.addEventListener('click', selectImageFromGallery);
    document.getElementById('closeScannerBtn')?.addEventListener('click', stopScanner);

    document.getElementById('confirm-transfer-btn')?.addEventListener('click', showTransferConfirmation);

    document.getElementById('shareQrBtn')?.addEventListener('click', shareQrCode);
    document.getElementById('downloadQrBtn')?.addEventListener('click', downloadQrCode);

    document.getElementById('soundToggleBtnNotif')?.addEventListener('click', toggleSound);

    document.querySelectorAll('input[name="notifTarget"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const singleInput = document.getElementById('singleUserContainer');
            if (!singleInput) return;
            if (this.value === 'single') singleInput.style.display = 'block';
            else singleInput.style.display = 'none';
        });
    });

    const titleTypeSelect = document.getElementById('notifTitleType');
    const titleInput = document.getElementById('notifAdminTitle');
    const bodyInput = document.getElementById('notifAdminBody');

    if (titleTypeSelect && titleInput && bodyInput) {
        titleTypeSelect.addEventListener('change', function() {
            const selected = this.value;
            if (selected === 'custom') {
                titleInput.value = '';
                bodyInput.value = '';
                titleInput.placeholder = 'أدخل عنوان الإشعار...';
                bodyInput.placeholder = 'اكتب رسالة الإشعار هنا...';
            } else {
                const template = NOTIFICATION_TEMPLATES[selected];
                if (template) {
                    titleInput.value = template.title;
                    bodyInput.value = template.body;
                    titleInput.placeholder = '';
                    bodyInput.placeholder = '';
                }
            }
        });
        titleTypeSelect.value = 'custom';
        titleTypeSelect.dispatchEvent(new Event('change'));
    }

    loadUserBanners();
    loadNewsTicker();

    document.getElementById('subscribeModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });
    document.getElementById('successModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeSuccessModal();
    });

    document.getElementById('userChatInput')?.addEventListener('input', function(e) {
        if (this.value.trim().length > 0) handleTypingStart('user');
        else if (APP.user) database.ref('chats/' + getChatId(APP.user.phone) + '/typing').remove();
    });
    document.getElementById('userChatInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') { e.preventDefault();
            sendMessage('user'); }
    });
    document.getElementById('chatMsgInput')?.addEventListener('input', function(e) {
        if (this.value.trim().length > 0) handleTypingStart('admin');
        else if (APP.currentTicketId) database.ref('chats/' + getChatId(APP.currentTicketId) + '/typing').remove();
    });
    document.getElementById('chatMsgInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') { e.preventDefault();
            sendMessage('admin'); }
    });

    document.getElementById('adminSearchUsers')?.addEventListener('input', renderAdminUsers);

    try {
        if (localStorage.getItem('notif_sound') === 'true') {
            APP.soundEnabled = true;
            updateSoundUI();
        }
    } catch (e) {}

    loadPackagesFromStore();
    initProfileCollapsibles();

    window.addEventListener('popstate', function(event) {
        if (APP.isMain) {
            if (document.getElementById('userInterface').classList.contains('active') ||
                document.getElementById('dashboardInterface').classList.contains('active')) {
                history.pushState({ page: 'main' }, '');
                showAlert('أنت في الصفحة الرئيسية');
            }
            return;
        }
        if (document.getElementById('barcodeInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('transferInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('notificationsInterface').style.display === 'block') navigateTo('userInterface', true);
        else if (document.getElementById('adminSystemInterface').classList.contains('active')) navigateTo(
            'dashboardInterface', true);
        else if (document.getElementById('statementInterface').style.display === 'block') navigateTo('userInterface',
        true);
        else if (document.getElementById('packagesInterface').style.display === 'block') navigateTo('userInterface',
        true);
        else if (document.getElementById('supportTicketsPage').classList.contains('active')) navigateTo(
            'adminSystemInterface', true);
        else if (document.getElementById('chatDetailPage').classList.contains('active')) closeChatDetail();
        else if (document.getElementById('chatPage').classList.contains('active')) closeChatPage();
        else if (document.getElementById('dataInterface').classList.contains('active')) navigateTo(
        'dashboardInterface', true);
        else if (document.getElementById('storeCardsInterface').classList.contains('active')) navigateTo(
            'dataInterface', true);
        else if (document.getElementById('soldCardsInterface').classList.contains('active')) navigateTo('dataInterface',
            true);
        else if (document.getElementById('accountingReportInterface').classList.contains('active')) navigateTo(
            'dataInterface', true);
        else if (document.getElementById('treasuryReportInterface').classList.contains('active')) navigateTo(
            'dataInterface', true);
        else if (document.getElementById('allTransactionsInterface').classList.contains('active')) navigateTo(
            'userInterface', true);
        else if (document.getElementById('adminInvoicesInterface').classList.contains('active')) navigateTo(
            'dataInterface', true);
        else if (document.getElementById('adminInvoiceDetailInterface').classList.contains('active')) navigateTo(
            'adminInvoicesInterface', true);
        else if (document.getElementById('userInvoicesInterface').classList.contains('active')) navigateTo(
            'userInterface', true);
        else {
            if (APP.user) navigateTo('userInterface', true);
            else {
                hideAllSystemPages();
                showAuthContainer();
                if (typeof uiShowLoginView === 'function') uiShowLoginView();
            }
        }
        APP.selectedMessage = null;
    });

    if (document.getElementById('dashboardInterface').classList.contains('active')) {
        navigateTo('dashboardInterface', true);
    } else if (document.getElementById('userInterface').classList.contains('active')) {
        navigateTo('userInterface', true);
    }
});

// ============================================================
// SERVICE WORKER
// ============================================================
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js')
        .then(() => console.log('✅ Service Worker (كاش) مسجل بنجاح'))
        .catch(err => console.error('❌ فشل تسجيل Service Worker (كاش):', err));

    navigator.serviceWorker.register('/firebase-messaging-sw.js')
        .then(() => console.log('✅ Service Worker (إشعارات) مسجل بنجاح'))
        .catch(err => console.error('❌ فشل تسجيل Service Worker (إشعارات):', err));
}

console.log('🚀 تطبيق كوفانت جاهز مع جميع التعديلات النهائية');

// ============================================================
// SPLASH SCREEN, CAROUSEL, MODAL, ETC.
// ============================================================
(function() {
    const splash = document.getElementById('splash-screen');
    if (splash) {
        splash.addEventListener('click', function() {
            splash.classList.add('hidden');
            setTimeout(function() { splash.style.display = 'none'; }, 700);
        });
        setTimeout(function() {
            splash.classList.add('hidden');
            setTimeout(function() { splash.style.display = 'none'; }, 700);
        }, 2500);
    }
})();

// ============================================================
// ✅ طلب إذن الإشعارات مبكراً (عند فتح الموقع) بدل انتظار تسجيل الدخول
// (لا يطلب توكن هنا لأنه لا يوجد مستخدم بعد؛ فقط يطلب إذن المتصفح)
//
// ✅ إصلاح: أغلب المتصفحات (خصوصاً على الجوال) تتجاهل أو تحظر بصمت أي
// طلب لإذن الإشعارات لا يكون ناتجاً عن تفاعل مباشر من المستخدم (نقرة/لمسة).
// طلبه فقط داخل setTimeout بدون أي نقرة قد لا يُظهر أي نافذة إذن على
// الإطلاق، وهذا يفسّر عدم ظهور نافذة تفعيل الإشعارات. الحل: نطلب الإذن
// أيضاً عند أول نقرة/لمسة فعلية من المستخدم على الصفحة (شاشة الافتتاح مثلاً)
// مع إبقاء محاولة الـ setTimeout كخطة احتياطية للمتصفحات التي تسمح بذلك.
// ============================================================
(function() {
    if (typeof Notification === 'undefined') return;
    let asked = false;
    function askOnce() {
        if (asked || Notification.permission !== 'default') return;
        asked = true;
        Notification.requestPermission().then(p => {
            console.log('🔔 إذن الإشعارات:', p);
        }).catch(() => {});
    }
    document.addEventListener('click', askOnce, { once: true, capture: true });
    document.addEventListener('touchstart', askOnce, { once: true, capture: true });
    setTimeout(askOnce, 2600); // محاولة احتياطية بعد اختفاء splash مباشرة
})();

let currentSlide = 0;
const totalSlides = 3;
let bannerInterval;

function updateBanner() {
    const track = document.getElementById('bannerTrack');
    if (!track) return;
    track.style.transform = 'translateX(' + currentSlide * 100 + '%)';
    const dots = document.querySelectorAll('.banner-dot');
    dots.forEach(function(dot, index) { dot.classList.toggle('active', index === currentSlide); });
}

function goToSlide(index) {
    currentSlide = index;
    updateBanner();
    resetBannerInterval();
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    updateBanner();
}

function resetBannerInterval() {
    clearInterval(bannerInterval);
    bannerInterval = setInterval(nextSlide, 5000);
}

const bannerContainer = document.getElementById('bannerCarousel');
if (bannerContainer) {
    resetBannerInterval();
    bannerContainer.addEventListener('mouseenter', () => clearInterval(bannerInterval));
    bannerContainer.addEventListener('mouseleave', () => resetBannerInterval());
    bannerContainer.addEventListener('touchstart', () => clearInterval(bannerInterval), { passive: true });
    bannerContainer.addEventListener('touchend', () => resetBannerInterval(), { passive: true });

    let touchStartX = 0;
    bannerContainer.addEventListener('touchstart', (e) => touchStartX = e.changedTouches[0].screenX, { passive: true });
    bannerContainer.addEventListener('touchend', (e) => {
        const diff = touchStartX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) currentSlide = (currentSlide + 1) % totalSlides;
            else currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            updateBanner();
            resetBannerInterval();
        }
    }, { passive: true });
}

function showLoadingModal(text) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div class="modal-spinner"></div>
        <div class="modal-title">يرجى الانتظار</div>
        <div class="modal-subtitle">${text}</div>
    `;
    overlay.classList.add('visible');
}

function showModalMessage(text) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div style="font-size: 48px; color: var(--brand-accent); margin: 10px 0;">
            <i class="fa-solid fa-circle-info"></i>
        </div>
        <div class="modal-title" style="font-size:1.2rem;">${text}</div>
        <div class="modal-subtitle">اضغط أي مكان للإغلاق</div>
    `;
    overlay.classList.add('visible');
    setTimeout(() => closeLoginModal(), 3000);
}

function showSuccessModal(text) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div style="font-size: 48px; color: #10b981; margin: 10px 0;">
            <i class="fa-solid fa-circle-check"></i>
        </div>
        <div class="modal-title" style="font-size:1.2rem;">${text}</div>
        <div class="modal-subtitle">سيتم تحويلك تلقائياً...</div>
    `;
    overlay.classList.add('visible');
    setTimeout(() => closeLoginModal(), 2000);
}

function showMenuModal() {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = `
        <button class="modal-close-btn" onclick="closeLoginModal()">✕</button>
        <div class="modal-title" style="font-size:1.2rem;">تم تسجيل الدخول بنجاح</div>
        <div class="modal-subtitle">مرحباً بك في كوفانت! اختر وجهتك:</div>
        <div class="modal-menu-list">
            <button class="modal-menu-item" onclick="closeLoginModal(); showModalMessage('لوحة التحكم - قيد التطوير')">
                <span class="menu-icon"><i class="fa-solid fa-chart-pie"></i></span> لوحة التحكم
            </button>
            <button class="modal-menu-item" onclick="closeLoginModal(); showModalMessage('إدارة الباقات - قيد التطوير')">
                <span class="menu-icon"><i class="fa-solid fa-box"></i></span> إدارة الباقات
            </button>
            <button class="modal-menu-item" onclick="closeLoginModal(); showModalMessage('الإعدادات - قيد التطوير')">
                <span class="menu-icon"><i class="fa-solid fa-gear"></i></span> الإعدادات
            </button>
        </div>
    `;
    overlay.classList.add('visible');
}

function closeLoginModal() {
    document.getElementById('modal-overlay').classList.remove('visible');
}
document.getElementById('modal-overlay')?.addEventListener('click', function(e) {
    if (e.target === this) closeLoginModal();
});

document.addEventListener('DOMContentLoaded', function() {
    if (typeof populateDateSelects === 'function') populateDateSelects();
    if (typeof uiGoToStep1 === 'function') uiGoToStep1();
});

document.getElementById('referralCode')?.addEventListener('input', function(e) {
    this.value = this.value.replace(/[^A-Za-z0-9\u0621-\u064A]/g, '').toUpperCase();
});