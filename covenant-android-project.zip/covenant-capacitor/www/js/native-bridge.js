// ============================================================
// NATIVE BRIDGE — الجسر بين نسخة الويب (PWA) ونسخة تطبيق أندرويد
// ============================================================
// هذا الملف يكتشف تلقائياً هل التطبيق شغّال:
//   1) داخل تطبيق أندرويد حقيقي (عبر Capacitor)  → يستخدم بصمة أندرويد
//      الأصلية (Android Keystore + BiometricPrompt) وإشعارات FCM الأصلية.
//   2) أو داخل متصفح عادي / PWA  → يبقى يستخدم WebAuthn والإشعارات عبر
//      Service Worker كما هو الحال حالياً بدون أي تغيير.
//
// أي كود قديم في auth.js أو user-logic.js يستدعي هذه الدوال العامة بدل ما
// يتعامل مباشرة مع WebAuthn، فتتحول تلقائياً حسب البيئة.
// ============================================================

const NATIVE_BIOMETRIC_SERVER_ID = 'com.kovant.app.login';

function isNativeApp() {
    return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
}

function getCapacitorPlugins() {
    return (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins : {};
}

// ============================================================
// البصمة — Native (Android Keystore + BiometricPrompt)
// ============================================================
async function nativeBiometricIsAvailable() {
    const { NativeBiometric } = getCapacitorPlugins();
    if (!NativeBiometric) return false;
    try {
        const result = await NativeBiometric.isAvailable();
        return !!(result && result.isAvailable);
    } catch (e) {
        console.warn('nativeBiometricIsAvailable error:', e);
        return false;
    }
}

// يخزّن رقم الجوال وكلمة المرور بشكل مشفّر داخل خزنة النظام (Android Keystore)
// محمية ببصمة/وجه المستخدم. لا تُخزّن هذه البيانات في أي مكان آخر.
async function nativeBiometricRegister(phone, password) {
    const { NativeBiometric } = getCapacitorPlugins();
    if (!NativeBiometric) throw new Error('البصمة الأصلية غير متاحة');
    await NativeBiometric.setCredentials({
        username: phone,
        password: password,
        server: NATIVE_BIOMETRIC_SERVER_ID
    });
}

// يعرض نافذة البصمة الأصلية لأندرويد، وعند النجاح يرجع رقم الجوال وكلمة المرور
// المخزّنين حتى يتم تسجيل الدخول بهما عبر نفس مسار الدخول العادي auth.loginUser
async function nativeBiometricAuthenticate() {
    const { NativeBiometric } = getCapacitorPlugins();
    if (!NativeBiometric) throw new Error('البصمة الأصلية غير متاحة');

    await NativeBiometric.verifyIdentity({
        reason: 'الرجاء تأكيد بصمتك لتسجيل الدخول',
        title: 'تسجيل الدخول بالبصمة',
        subtitle: 'كوفانت',
        description: 'استخدم بصمتك أو وجهك لتأكيد هويتك'
    });

    const credentials = await NativeBiometric.getCredentials({ server: NATIVE_BIOMETRIC_SERVER_ID });
    return credentials; // { username, password }
}

async function nativeBiometricRemove() {
    const { NativeBiometric } = getCapacitorPlugins();
    if (!NativeBiometric) return;
    try {
        await NativeBiometric.deleteCredentials({ server: NATIVE_BIOMETRIC_SERVER_ID });
    } catch (e) {
        console.warn('nativeBiometricRemove error:', e);
    }
}

// ============================================================
// الإشعارات — Native (Firebase Cloud Messaging عبر Capacitor)
// ============================================================
// يسجّل الجهاز ويحصل على توكن FCM حقيقي يعمل حتى لو كان التطبيق مغلقاً
// تماماً (مقتول من الذاكرة)، بعكس Service Worker في الويب العادي الذي
// يعتمد على بقاء المتصفح مسجّلاً بالخلفية.
async function nativePushRegister(userPhone) {
    const { PushNotifications } = getCapacitorPlugins();
    if (!PushNotifications) {
        console.warn('⚠️ PushNotifications plugin غير متاح');
        return null;
    }

    let permStatus = await PushNotifications.checkPermissions();
    if (permStatus.receive !== 'granted') {
        permStatus = await PushNotifications.requestPermissions();
    }
    if (permStatus.receive !== 'granted') {
        console.warn('❌ المستخدم رفض إذن الإشعارات');
        return null;
    }

    return new Promise((resolve) => {
        PushNotifications.addListener('registration', async (token) => {
            try {
                await database.ref(`user_tokens/${userPhone}`).set({
                    token: token.value,
                    updatedAt: Date.now(),
                    device: 'تطبيق أندرويد'
                });
                await database.ref(`users/${userPhone}/fcmToken`).set(token.value);
                console.log('✅ تم حفظ توكن الإشعارات الأصلي');
            } catch (e) {
                console.error('❌ فشل حفظ توكن الإشعارات:', e);
            }
            resolve(token.value);
        });

        PushNotifications.addListener('registrationError', (err) => {
            console.error('❌ فشل تسجيل الإشعارات:', err);
            resolve(null);
        });

        PushNotifications.register();
    });
}

// استقبال الإشعارات والتطبيق مفتوح (Foreground) + الضغط على الإشعار
function nativePushAttachListeners() {
    const { PushNotifications } = getCapacitorPlugins();
    if (!PushNotifications) return;

    PushNotifications.addListener('pushNotificationReceived', (notification) => {
        const title = notification.title || 'كوفانت';
        const body = notification.body || '';
        if (typeof showFloatingToast === 'function') {
            showFloatingToast(title, body);
        }
    });

    PushNotifications.addListener('pushNotificationActionPerformed', (action) => {
        console.log('🔔 المستخدم ضغط على الإشعار:', action);
    });
}

if (isNativeApp()) {
    document.addEventListener('deviceready', nativePushAttachListeners, false);
    // بعض إصدارات Capacitor تُطلق DOMContentLoaded بدل deviceready
    document.addEventListener('DOMContentLoaded', nativePushAttachListeners, false);
}
