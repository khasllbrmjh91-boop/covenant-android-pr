// ============================================================
// AUTH: LOGIN, SIGNUP, FORGOT PASSWORD + PUSH NOTIFICATIONS
// ============================================================

// ✅ التأكد من وجود APP في النطاق العام
if (typeof APP === 'undefined') {
    var APP = {
        user: null,
        notifications: [],
        storeData: {},
        adminUsers: [],
        adminCurrentSection: 'system',
        selectedCategoryId: null,
        selectedCategory: null,
        hiddenBalance: false,
        soundEnabled: false,
        html5Qr: null,
        revenueChart: null,
        currentTicketId: null,
        selectedMessage: null,
        toastTimeout: null,
        longPressTimer: null,
        typingTimeout: null,
        _adminUsersListener: null,
        _adminDevicesListener: null,
        _notifListenerPhone: null,
        adminPassword: null // ✅ إضافة حقل لتخزين كلمة مرور الأدمن
    };
}

// ✅ تعريف isValidYemeniPhone
if (typeof isValidYemeniPhone === 'undefined') {
    function isValidYemeniPhone(p) {
        return /^7\d{8}$/.test(p);
    }
}

// ✅ تعريف الدوال المساعدة (في حال عدم وجودها من firebase-config.js)
if (typeof generateDeviceId === 'undefined') {
    function generateDeviceId() {
        let d = localStorage.getItem('deviceId');
        if (!d) {
            d = 'dev_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15);
            localStorage.setItem('deviceId', d);
        }
        return d;
    }
}
if (typeof hashPassword === 'undefined') {
    async function hashPassword(password) {
        const enc = new TextEncoder().encode(password);
        const buf = await crypto.subtle.digest('SHA-256', enc);
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
}
if (typeof getDeviceName === 'undefined') {
    function getDeviceName() {
        const ua = navigator.userAgent;
        if (/Android/i.test(ua)) return 'Android';
        if (/iPhone|iPad|iPod/i.test(ua)) return 'iOS';
        if (/Windows/i.test(ua)) return 'Windows';
        if (/Mac/i.test(ua)) return 'Mac';
        return 'جهاز غير معروف';
    }
}
if (typeof getDeviceFingerprint === 'undefined') {
    function getDeviceFingerprint() {
        const raw = [generateDeviceId(), navigator.userAgent || 'unknown', navigator.language || 'en', window.screen.width + 'x' + window.screen.height].join('###');
        return CryptoJS.SHA256(raw).toString(CryptoJS.enc.Hex);
    }
}
if (typeof getDeviceAnalytics === 'undefined') {
    async function getDeviceAnalytics() {
        return {
            os: navigator.userAgent.includes('Android') ? 'Android' : 'Unknown',
            browser: navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Unknown',
            deviceType: /Mobile/i.test(navigator.userAgent) ? 'mobile' : 'desktop'
        };
    }
}
if (typeof getUniqueAccountNumber === 'undefined') {
    async function getUniqueAccountNumber() {
        for (let i = 0; i < 20; i++) {
            const c = '40' + Math.floor(10000000 + Math.random() * 90000000).toString();
            const snap = await database.ref('users').orderByChild('accountNumber').equalTo(c).once('value');
            if (!snap.exists()) return c;
        }
        throw new Error('تعذر توليد رقم حساب فريد');
    }
}
if (typeof isDeviceLinkedToOtherAccount === 'undefined') {
    async function isDeviceLinkedToOtherAccount(deviceId, excludePhone) {
        const snap = await database.ref('users').once('value');
        if (!snap.val()) return false;
        for (const k in snap.val()) {
            const d = snap.val()[k];
            if (d.phone === excludePhone) continue;
            if (d.devices && d.devices[deviceId]) return true;
        }
        return false;
    }
}

// ✅ دوال عرض الرسائل
if (typeof showModalMessage === 'undefined') {
    function showModalMessage(msg) {
        const overlay = document.getElementById('modal-overlay');
        const content = document.getElementById('modalContent');
        if (!overlay || !content) return;
        content.innerHTML = `
            <div style="text-align:center;padding:20px;">
                <i class="fas fa-exclamation-circle" style="font-size:48px;color:var(--gold);margin-bottom:16px;"></i>
                <p style="font-size:16px;font-weight:600;color:var(--text-primary);">${msg}</p>
                <button onclick="closeLoginModal()" style="margin-top:16px;padding:10px 30px;background:var(--gold);color:#0b0f1a;border:none;border-radius:30px;font-weight:800;cursor:pointer;">حسناً</button>
            </div>
        `;
        overlay.style.display = 'flex';
    }
}
if (typeof closeLoginModal === 'undefined') {
    function closeLoginModal() {
        document.getElementById('modal-overlay').style.display = 'none';
    }
}
if (typeof showLoadingModal === 'undefined') {
    function showLoadingModal(msg) {
        const overlay = document.getElementById('modal-overlay');
        const content = document.getElementById('modalContent');
        if (!overlay || !content) return;
        content.innerHTML = `
            <div style="text-align:center;padding:20px;">
                <div style="width:40px;height:40px;border:3px solid rgba(255,255,255,0.06);border-top-color:var(--gold);border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 16px;"></div>
                <p style="font-size:14px;font-weight:600;color:var(--text-primary);">${msg}</p>
            </div>
        `;
        overlay.style.display = 'flex';
    }
}
if (typeof showSuccessModal === 'undefined') {
    function showSuccessModal(msg) {
        const overlay = document.getElementById('modal-overlay');
        const content = document.getElementById('modalContent');
        if (!overlay || !content) return;
        content.innerHTML = `
            <div style="text-align:center;padding:20px;">
                <i class="fas fa-check-circle" style="font-size:48px;color:var(--green);margin-bottom:16px;"></i>
                <p style="font-size:16px;font-weight:600;color:var(--text-primary);">${msg}</p>
                <button onclick="closeLoginModal()" style="margin-top:16px;padding:10px 30px;background:var(--green);color:#fff;border:none;border-radius:30px;font-weight:800;cursor:pointer;">حسناً</button>
            </div>
        `;
        overlay.style.display = 'flex';
    }
}
if (typeof showAlert === 'undefined') {
    function showAlert(msg, isSuccess) {
        const el = document.getElementById('customAlert');
        if (!el) return;
        document.getElementById('alertTextMsg').textContent = msg;
        el.querySelector('i').className = isSuccess ? 'fa-regular fa-circle-check' : 'fa-regular fa-circle-exclamation';
        el.querySelector('i').style.color = isSuccess ? '#58b8e8' : '#ef4444';
        el.classList.add('show');
        clearTimeout(el._timer);
        el._timer = setTimeout(() => el.classList.remove('show'), 4000);
    }
}
if (typeof subscribeToUserData === 'undefined') {
    function subscribeToUserData(phone) {
        console.log('✅ اشتراك في بيانات المستخدم:', phone);
        if (window.subscribeToUserData) window.subscribeToUserData(phone);
    }
}
if (typeof navigateTo === 'undefined') {
    function navigateTo(page, replaceHistory) {
        document.querySelectorAll('.page, #dashboardInterface, #userInterface, #dataInterface, #adminSystemInterface, #bannerManagementInterface, #newsManagementInterface, #storeCardsInterface, #soldCardsInterface, #accountingReportInterface, #treasuryReportInterface, #adminInvoicesInterface, #adminInvoiceDetailInterface, #userInvoicesInterface, #packagesInterface, #transferInterface, #barcodeInterface, #notificationsInterface, #statementInterface, #allTransactionsInterface, #chatPage, #supportTicketsPage, #profileInterface, #adminPageNotifications').forEach(el => {
            if (el) el.classList.remove('active');
            if (el) el.style.display = 'none';
        });
        const target = document.getElementById(page);
        if (target) {
            target.style.display = 'block';
            target.classList.add('active');
            console.log('✅ تم التنقل إلى:', page);
        } else {
            console.error('❌ الصفحة غير موجودة:', page);
        }
    }
}
if (typeof hideAuthContainer === 'undefined') {
    function hideAuthContainer() {
        const container = document.getElementById('main-container');
        if (container) container.style.display = 'none';
    }
}
if (typeof showAuthContainer === 'undefined') {
    function showAuthContainer() {
        const container = document.getElementById('main-container');
        if (container) container.style.display = '';
    }
}
if (typeof liClearAllErrors === 'undefined') {
    function liClearAllErrors(pairs) {
        pairs.forEach(([wrapId, errorId]) => {
            const wrap = document.getElementById(wrapId);
            const error = document.getElementById(errorId);
            if (wrap) wrap.classList.remove('error');
            if (error) error.classList.remove('visible');
        });
    }
}
if (typeof liShowFieldError === 'undefined') {
    function liShowFieldError(wrapId, errorId, message) {
        const wrap = document.getElementById(wrapId);
        const error = document.getElementById(errorId);
        if (wrap) wrap.classList.add('error');
        if (error) {
            error.textContent = message;
            error.classList.add('visible');
        }
    }
}
if (typeof uiShowLoginView === 'undefined') {
    function uiShowLoginView() {
        const loginView = document.getElementById('login-view');
        const signupView = document.getElementById('signup-view');
        if (loginView) loginView.classList.remove('hidden');
        if (signupView) signupView.classList.remove('active');
    }
}
if (typeof uiShowSignupView === 'undefined') {
    function uiShowSignupView() {
        const loginView = document.getElementById('login-view');
        const signupView = document.getElementById('signup-view');
        if (loginView) loginView.classList.add('hidden');
        if (signupView) signupView.classList.add('active');
    }
}
if (typeof uiGoToStep1 === 'undefined') {
    function uiGoToStep1() {
        const s1 = document.getElementById('signupStep1');
        const s2 = document.getElementById('signupStep2');
        if (s1) s1.style.display = 'block';
        if (s2) s2.style.display = 'none';
    }
}
if (typeof uiGoToStep2 === 'undefined') {
    function uiGoToStep2() {
        const s1 = document.getElementById('signupStep1');
        const s2 = document.getElementById('signupStep2');
        if (s1) s1.style.display = 'none';
        if (s2) s2.style.display = 'block';
    }
}
if (typeof validateStep1 === 'undefined') {
    function validateStep1() { return true; }
}
if (typeof validateStep2 === 'undefined') {
    function validateStep2() { return true; }
}
if (typeof clearSignupFields === 'undefined') {
    function clearSignupFields() {}
}
if (typeof startTypingEffect === 'undefined') {
    function startTypingEffect() {}
}

// ============================================================
// BARCODE (JSBarcode)
// ============================================================
async function loadJsBarcode() {
    if (typeof JsBarcode !== 'undefined') return;
    return new Promise(r => {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js';
        s.onload = r;
        document.head.appendChild(s);
    });
}

function printBarcode() {
    const pc = document.getElementById('barcodeSection').innerHTML;
    const oc = document.body.innerHTML;
    document.body.innerHTML = `<div style="padding:30px;text-align:center;background:#fff;direction:rtl;font-family:'Cairo',sans-serif;">${pc}</div>`;
    window.print();
    document.body.innerHTML = oc;
    location.reload();
}

// ============================================================
// ✅ تجديد تلقائي وصامت لتوكن الجلسة (JWT) — عبر Refresh Token حقيقي
// ============================================================
// المشكلة: التوكن صالح 15 دقيقة فقط. الحل: عند تسجيل الدخول يُصدر السيرفر
// أيضاً refresh token عشوائي طويل الأمد (30 يوماً)، نخزّنه ونستخدمه هنا
// لتجديد الجلسة تلقائياً دون الحاجة لكلمة المرور إطلاقاً بعد أول دخول —
// وهذا أكثر أماناً من الحل السابق الذي كان يحتفظ بكلمة المرور في الذاكرة.
// ============================================================
let _sessionRefreshTimer = null;

function clearSessionRefreshTimer() {
    if (_sessionRefreshTimer) {
        clearInterval(_sessionRefreshTimer);
        _sessionRefreshTimer = null;
    }
}

function scheduleSessionRefresh(phone) {
    clearSessionRefreshTimer();
    // نجدد كل 13 دقيقة (قبل انتهاء صلاحية الـ 15 دقيقة بهامش أمان دقيقتين)
    const REFRESH_EVERY_MS = 13 * 60 * 1000;
    _sessionRefreshTimer = setInterval(() => refreshSessionToken(phone), REFRESH_EVERY_MS);
}

async function refreshSessionToken(phone) {
    try {
        const refreshToken = localStorage.getItem('refresh_token');
        if (!refreshToken) {
            console.warn('⚠️ لا يوجد refresh token — سيُطلب تسجيل دخول جديد عند انتهاء الجلسة');
            return;
        }
        const res = await fetch('https://kovant-backend3.onrender.com/refresh', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, refreshToken })
        });
        let data;
        try { data = await res.json(); } catch (e) { throw new Error('استجابة غير صالحة'); }

        if (!res.ok || !data.success || !data.token) {
            console.warn('⚠️ فشل تجديد الجلسة تلقائياً:', data && data.error);
            return; // نترك التوكن القديم كما هو؛ سيُطلب تسجيل دخول جديد عند انتهائه فعلياً
        }
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('auth_expiry', Date.now() + 15 * 60 * 1000);
        // ✅ تدوير: نُخزّن الـ refresh token الجديد ونتخلص من القديم فوراً
        localStorage.setItem('refresh_token', data.refreshToken);
        console.log('✅ تم تجديد جلسة', phone, 'تلقائياً');
    } catch (e) {
        console.warn('⚠️ خطأ أثناء تجديد الجلسة تلقائياً:', e.message);
    }
}

// ============================================================
// ✅ AUTH OBJECT — المُعدّل للتوافق مع JWT وتخزين adminPassword
// ============================================================
const auth = {
    async loginUser(phone, password) {
        const deviceId = generateDeviceId(),
            deviceName = getDeviceName(),
            fingerprint = getDeviceFingerprint(),
            deviceAnalytics = await getDeviceAnalytics();

        const res = await fetch('https://kovant-backend3.onrender.com/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, password, deviceId, deviceName, fingerprint, deviceAnalytics })
        });

        let data;
        try { data = await res.json(); } catch (e) { throw new Error('تعذر الاتصال بالخادم'); }

        if (!res.ok || !data.success) {
            throw new Error(data.error || 'تعذر تسجيل الدخول، تحقق من البيانات');
        }

        localStorage.removeItem('biometric_attempts');
        localStorage.removeItem('biometric_last_attempt_time');

        // ✅ تخزين JWT في localStorage
        if (data.token) {
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('auth_expiry', Date.now() + 15 * 60 * 1000);
        }
        // ✅ تخزين Refresh Token (يُستخدم لاحقاً لتجديد الجلسة دون كلمة المرور)
        if (data.refreshToken) {
            localStorage.setItem('refresh_token', data.refreshToken);
        }

        // ✅ تسجيل الدخول إلى Firebase Auth بالـ Custom Token القادم من السيرفر.
        // هذا ضروري لتفعيل قواعد أمان قاعدة البيانات (auth != null / auth.uid) —
        // بدونه تبقى مسارات مثل notifications/user_tokens مفتوحة للجميع بلا داعٍ،
        // لأن الـ listeners في هذا الملف تتصل بقاعدة البيانات مباشرة كعميل غير مُصادَق.
        if (data.firebaseToken) {
            try {
                await firebase.auth().signInWithCustomToken(data.firebaseToken);
                console.log('✅ تم تسجيل الدخول إلى Firebase Auth');
            } catch (e) {
                console.error('❌ فشل تسجيل الدخول إلى Firebase Auth:', e.message);
                // لا نوقف تسجيل الدخول للتطبيق بسبب هذا وحده، لكن قراءة/كتابة
                // البيانات المحمية بالقواعد الجديدة (auth != null) ستفشل حتى ينجح هذا.
            }
        }

        APP.user = data.user;
        APP.user.phone = data.user.phone || phone;
        APP.user.isAdmin = !!data.isAdmin;

        // ✅ تخزين كلمة مرور الأدمن في APP (للإيداع والفواتير)
        if (data.isAdmin) {
            APP.adminPassword = password;
            console.log('🔑 تم تخزين كلمة مرور الأدمن في الجلسة');
        } else {
            APP.adminPassword = null;
        }

        // ✅ جدولة التجديد التلقائي للتوكن قبل انتهاء صلاحيته (عبر Refresh Token الآن)
        if (data.token) scheduleSessionRefresh(APP.user.phone);

        hideAuthContainer();
        navigateTo(data.isAdmin ? 'dashboardInterface' : 'userInterface', true);
        if (!data.isAdmin) subscribeToUserData(APP.user.phone);
        showAlert(data.isAdmin ? 'مرحباً أيها المسؤول!' : 'تم تسجيل الدخول إلى حسابك');

        // تسجيل الجهاز للإشعارات
        if (typeof registerDevice === 'function') {
            registerDevice(APP.user.phone).then(token => {
                if (token) console.log('✅ تم تسجيل الجهاز للإشعارات بنجاح');
                else console.warn('⚠️ فشل تسجيل الجهاز للإشعارات');
            }).catch(err => console.error('❌ خطأ في تسجيل الجهاز:', err));
        }

        return { success: true, isAdmin: !!data.isAdmin };
    },

    logout() {
        APP.user = null;
        APP.adminPassword = null; // ✅ مسح كلمة مرور الأدمن عند الخروج
        clearSessionRefreshTimer(); // ✅ إيقاف التجديد التلقائي عند الخروج
        // ✅ مسح JWT و Refresh Token من localStorage
        localStorage.removeItem('auth_token');
        localStorage.removeItem('auth_expiry');
        localStorage.removeItem('refresh_token');
        // ✅ الخروج من Firebase Auth أيضاً — وإلا تبقى جلسة auth.uid نشطة
        // في المتصفح بعد الخروج من التطبيق
        if (firebase.auth().currentUser) {
            firebase.auth().signOut().catch(e => console.warn('⚠️ فشل تسجيل الخروج من Firebase Auth:', e.message));
        }
        if (typeof hideAllSystemPages === 'function') hideAllSystemPages();
        document.body.classList.remove('system-mode');
        showAuthContainer();
        if (typeof uiShowLoginView === 'function') uiShowLoginView();
    }
};

// ✅ دالة مساعدة للحصول على التوكن (للاستخدام في التحويلات)
function getAuthToken() {
    const token = localStorage.getItem('auth_token');
    const expiry = parseInt(localStorage.getItem('auth_expiry') || '0');
    if (!token || Date.now() > expiry) {
        return null;
    }
    return token;
}

// ============================================================
// TOGGLE PASSWORD FUNCTIONS
// ============================================================
function toggleLoginPassword() {
    const input = document.getElementById('loginPassword');
    const btn = input?.parentElement?.querySelector('.toggle-password');
    if (!input || !btn) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.innerHTML = input.type === 'password' ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}
function toggleSignupPassword() {
    const input = document.getElementById('signupPassword');
    const btn = input?.parentElement?.querySelector('.toggle-password');
    if (!input || !btn) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.innerHTML = input.type === 'password' ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}
function toggleConfirmPassword() {
    const input = document.getElementById('confirmPassword');
    const btn = input?.parentElement?.querySelector('.toggle-password');
    if (!input || !btn) return;
    if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="fa-regular fa-eye-slash"></i>';
    } else {
        input.type = 'password';
        btn.innerHTML = '<i class="fa-regular fa-eye"></i>';
    }
}

// ============================================================
// EVENT LISTENERS
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    const loginPhone = document.getElementById('loginPhone');
    const signupPhone = document.getElementById('signupPhone');

    if (loginPhone) {
        loginPhone.addEventListener('input', function(e) {
            this.value = this.value.replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1632 + 48)).replace(/[^0-9]/g, '');
        });
    }
    if (signupPhone) {
        signupPhone.addEventListener('input', function(e) {
            this.value = this.value.replace(/[٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) - 1632 + 48)).replace(/[^0-9]/g, '');
        });
    }

    ['firstName', 'fatherName', 'grandfatherName', 'lastName'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', function() {
                this.value = this.value.replace(/[^\u0621-\u064A\u064B-\u0652\s]/g, '');
                const wrap = document.getElementById(this.id + 'Wrapper');
                const err = document.getElementById(this.id + 'Error');
                if (wrap) wrap.classList.remove('error');
                if (err) err.classList.remove('visible');
            });
        }
    });

    const address = document.getElementById('address');
    if (address) {
        address.addEventListener('input', function() {
            document.getElementById('addressWrapper')?.classList.remove('error');
            document.getElementById('addressError')?.classList.remove('visible');
        });
    }

    const signupPass = document.getElementById('signupPassword');
    if (signupPass) {
        signupPass.addEventListener('input', function(e) {
            const password = e.target.value;
            const fills = [
                document.getElementById('strengthFill1'),
                document.getElementById('strengthFill2'),
                document.getElementById('strengthFill3')
            ];
            const label = document.getElementById('strengthLabel');
            const shield = document.getElementById('strengthShield');
            const wrapper = document.getElementById('signupPasswordWrapper');
            const error = document.getElementById('signupPasswordError');
            if (wrapper) wrapper.classList.remove('error');
            if (error) error.classList.remove('visible');

            let score = 0;
            if (password.length >= 6) score++;
            if (password.length >= 10) score++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
            if (/\d/.test(password)) score++;
            if (/[!@#$%^&*(),.?":{}|<>_\-+=]/.test(password)) score++;
            if (/[\u0621-\u064A]/.test(password)) score++;

            let level = 0;
            if (score <= 1) level = 0;
            else if (score <= 3) level = 1;
            else if (score <= 5) level = 2;
            else level = 3;

            const colors = ['#f85149', '#f59e0b', '#10b981', '#10b981'];
            const labels = ['ضعيفة', 'متوسطة', 'قوية', 'قوية جداً'];
            const labelColors = ['#f85149', '#f59e0b', '#10b981', '#10b981'];
            const percentages = [[25,0,0], [100,50,0], [100,100,50], [100,100,100]];

            fills.forEach((fill, i) => {
                if (fill) {
                    fill.style.width = percentages[level][i] + '%';
                    fill.style.background = colors[level];
                    fill.style.transition = 'width 0.5s ease, background 0.5s ease';
                }
            });
            if (label) {
                label.textContent = labels[level];
                label.style.color = labelColors[level];
            }
            if (shield) shield.style.color = labelColors[level];
        });
    }

    const confirmPass = document.getElementById('confirmPassword');
    if (confirmPass) {
        confirmPass.addEventListener('input', function() {
            document.getElementById('confirmPasswordWrapper')?.classList.remove('error');
            document.getElementById('confirmPasswordError')?.classList.remove('visible');
        });
    }

    populateDateSelects();
});

function populateDateSelects() {
    const daySelect = document.getElementById('birthDay');
    const monthSelect = document.getElementById('birthMonth');
    const yearSelect = document.getElementById('birthYear');

    if (!daySelect || !monthSelect || !yearSelect) return;

    for (let i = 1; i <= 31; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        daySelect.appendChild(option);
    }
    for (let i = 1; i <= 12; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        monthSelect.appendChild(option);
    }
    const currentYear = new Date().getFullYear();
    for (let i = currentYear; i >= 1900; i--) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = i;
        yearSelect.appendChild(option);
    }
}

// ============================================================
// UI FUNCTIONS — التنقل بين خطوات التسجيل
// ============================================================
function uiGoToStep2() {
    if (validateStep1()) {
        document.getElementById('signupStep1').style.display = 'none';
        document.getElementById('signupStep2').style.display = 'block';
        document.getElementById('stepDot1').classList.remove('active');
        document.getElementById('stepDot1').classList.add('completed');
        document.getElementById('stepDot2').classList.add('active');
        document.getElementById('stepLine').classList.add('active');
        document.getElementById('stepDot1').textContent = '✓';
    }
}
function uiGoToStep1() {
    document.getElementById('signupStep2').style.display = 'none';
    document.getElementById('signupStep1').style.display = 'block';
    document.getElementById('stepDot2').classList.remove('active');
    document.getElementById('stepDot1').classList.add('active');
    document.getElementById('stepDot1').classList.remove('completed');
    document.getElementById('stepLine').classList.remove('active');
    document.getElementById('stepDot1').textContent = '1';
}

function validateStep1() {
    let isValid = true;
    const fields = [
        { id: 'firstName', wrapper: 'firstNameWrapper', error: 'firstNameError', label: 'الاسم' },
        { id: 'fatherName', wrapper: 'fatherNameWrapper', error: 'fatherNameError', label: 'الأب' },
        { id: 'grandfatherName', wrapper: 'grandfatherWrapper', error: 'grandfatherError', label: 'الجد' },
        { id: 'lastName', wrapper: 'lastNameWrapper', error: 'lastNameError', label: 'اللقب' },
        { id: 'birthDate', wrapper: 'birthDateWrapper', error: 'birthDateError', label: 'تاريخ الميلاد' },
        { id: 'address', wrapper: 'addressWrapper', error: 'addressError', label: 'العنوان' }
    ];

    fields.forEach(field => {
        const input = document.getElementById(field.id);
        const wrapper = document.getElementById(field.wrapper);
        const error = document.getElementById(field.error);
        if (!wrapper || !error) return;
        wrapper.classList.remove('error');
        error.classList.remove('visible');

        if (field.id !== 'birthDate') {
            if (!input || !input.value.trim()) {
                wrapper.classList.add('error');
                error.textContent = field.label + ' مطلوب';
                error.classList.add('visible');
                isValid = false;
            } else {
                if (['firstName', 'fatherName', 'grandfatherName', 'lastName'].includes(field.id)) {
                    const arabicPattern = /^[\u0621-\u064A\s]+$/;
                    if (!arabicPattern.test(input.value.trim())) {
                        wrapper.classList.add('error');
                        error.textContent = field.label + ' يجب أن يحتوي على أحرف عربية فقط';
                        error.classList.add('visible');
                        isValid = false;
                    }
                }
                if (field.id === 'address') {
                    if (input.value.trim().length < 5) {
                        wrapper.classList.add('error');
                        error.textContent = 'العنوان قصير جداً (5 أحرف على الأقل)';
                        error.classList.add('visible');
                        isValid = false;
                    }
                }
            }
        } else {
            const daySelect = document.getElementById('birthDay');
            const monthSelect = document.getElementById('birthMonth');
            const yearSelect = document.getElementById('birthYear');

            if (!daySelect || !monthSelect || !yearSelect) {
                wrapper.classList.add('error');
                error.textContent = 'حدث خطأ في تحميل حقول التاريخ';
                error.classList.add('visible');
                isValid = false;
                return;
            }

            const day = parseInt(daySelect.value, 10);
            const month = parseInt(monthSelect.value, 10);
            const year = parseInt(yearSelect.value, 10);

            if (!day || !month || !year) {
                wrapper.classList.add('error');
                error.textContent = 'يرجى اختيار تاريخ الميلاد كاملاً';
                error.classList.add('visible');
                isValid = false;
            } else {
                const birthDate = new Date(year, month - 1, day);
                if (birthDate.getFullYear() !== year || birthDate.getMonth() !== month - 1 || birthDate.getDate() !== day) {
                    wrapper.classList.add('error');
                    error.textContent = 'تاريخ غير صحيح (تحقق من اليوم والشهر)';
                    error.classList.add('visible');
                    isValid = false;
                } else {
                    const today = new Date();
                    let age = today.getFullYear() - year;
                    const m = today.getMonth() - (month - 1);
                    if (m < 0 || (m === 0 && today.getDate() < day)) age--;
                    if (birthDate >= today) {
                        wrapper.classList.add('error');
                        error.textContent = 'يرجى اختيار تاريخ ميلاد صحيح (غير مستقبلي)';
                        error.classList.add('visible');
                        isValid = false;
                    } else if (age < 9) {
                        wrapper.classList.add('error');
                        error.textContent = 'يجب أن يكون العمر 9 سنوات على الأقل';
                        error.classList.add('visible');
                        isValid = false;
                    }
                }
            }
        }
    });

    if (!isValid) {
        showModalMessage('يرجى تعبئة جميع الحقول المطلوبة بشكل صحيح');
        const firstError = document.querySelector('.input-wrapper.error');
        if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return isValid;
}

function validateStep2() {
    let isValid = true;
    const phone = document.getElementById('signupPhone');
    const phoneWrapper = document.getElementById('signupPhoneWrapper');
    const phoneError = document.getElementById('signupPhoneError');
    const password = document.getElementById('signupPassword');
    const passwordWrapper = document.getElementById('signupPasswordWrapper');
    const passwordError = document.getElementById('signupPasswordError');
    const confirmPassword = document.getElementById('confirmPassword');
    const confirmWrapper = document.getElementById('confirmPasswordWrapper');
    const confirmError = document.getElementById('confirmPasswordError');

    [phoneWrapper, passwordWrapper, confirmWrapper].forEach(w => {
        if (w) w.classList.remove('error');
    });
    [phoneError, passwordError, confirmError].forEach(e => {
        if (e) e.classList.remove('visible');
    });

    const phoneDigits = phone ? phone.value.replace(/[^0-9]/g, '') : '';
    if (!phoneDigits || phoneDigits.length !== 9) {
        if (phoneWrapper) phoneWrapper.classList.add('error');
        if (phoneError) {
            phoneError.textContent = 'رقم الجوال يجب أن يكون 9 أرقام';
            phoneError.classList.add('visible');
        }
        isValid = false;
    }
    if (password && password.value.length < 8) {
        if (passwordWrapper) passwordWrapper.classList.add('error');
        if (passwordError) {
            passwordError.textContent = 'كلمة المرور يجب أن تكون 8 أحرف على الأقل';
            passwordError.classList.add('visible');
        }
        isValid = false;
    }
    if (password && confirmPassword && password.value !== confirmPassword.value) {
        if (confirmWrapper) confirmWrapper.classList.add('error');
        if (confirmError) confirmError.classList.add('visible');
        isValid = false;
    }
    if (!isValid) {
        showModalMessage('يرجى تصحيح الأخطاء في الحقول المطلوبة');
        const firstError = document.querySelector('#signupStep2 .input-wrapper.error');
        if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return isValid;
}

function clearLoginErrors() {
    document.getElementById('loginPhoneWrapper')?.classList.remove('error');
    document.getElementById('loginPasswordWrapper')?.classList.remove('error');
    document.getElementById('loginPhoneError')?.classList.remove('visible');
    document.getElementById('loginPasswordError')?.classList.remove('visible');
}

function uiShowSignupView() {
    const loginView = document.getElementById('login-view');
    if (!loginView) return;
    loginView.style.opacity = '0';
    loginView.style.transform = 'translateY(-30px)';
    setTimeout(() => {
        loginView.classList.add('hidden');
        loginView.style.opacity = '1';
        loginView.style.transform = 'translateY(0)';
        document.getElementById('signup-view')?.classList.add('active');
        startTypingEffect();
    }, 300);
}

function uiShowLoginView() {
    const signupView = document.getElementById('signup-view');
    if (signupView) signupView.classList.remove('active');
    const loginView = document.getElementById('login-view');
    if (!loginView) return;
    loginView.classList.remove('hidden');
    loginView.style.opacity = '0';
    loginView.style.transform = 'translateY(-30px)';

    clearLoginErrors();

    setTimeout(() => {
        loginView.style.opacity = '1';
        loginView.style.transform = 'translateY(0)';
    }, 50);
}

let typingStarted = false;
function startTypingEffect() {
    if (typingStarted) return;
    typingStarted = true;
    const textElement = document.getElementById('signupSubText');
    if (!textElement) return;
    const message = 'مرحبا بكم في تطبيق كوفانت';
    let index = 0;
    textElement.textContent = '';
    textElement.style.borderRight = '2px solid var(--brand-accent)';

    function type() {
        if (index < message.length) {
            textElement.textContent += message.charAt(index);
            index++;
            setTimeout(type, 70);
        } else {
            textElement.style.borderRight = 'none';
        }
    }
    type();
}

// ============================================================
// onSignupClick — إنشاء حساب جديد
// ============================================================
async function onSignupClick() {
    if (!validateStep2()) return;

    const signupData = {
        firstName: document.getElementById('firstName')?.value.trim() || '',
        fatherName: document.getElementById('fatherName')?.value.trim() || '',
        grandfatherName: document.getElementById('grandfatherName')?.value.trim() || '',
        familyName: document.getElementById('lastName')?.value.trim() || '',
        birthDay: document.getElementById('birthDay')?.value.trim() || '',
        birthMonth: document.getElementById('birthMonth')?.value.trim() || '',
        birthYear: document.getElementById('birthYear')?.value.trim() || '',
        address: document.getElementById('address')?.value.trim() || '',
        phone: document.getElementById('signupPhone')?.value.replace(/[^0-9]/g, '') || '',
        password: document.getElementById('signupPassword')?.value || '',
        confirmPassword: document.getElementById('confirmPassword')?.value || '',
        referralCode: document.getElementById('referralCode')?.value.trim() || ''
    };

    showLoadingModal('جاري إنشاء الحساب...');
    try {
        if (typeof user !== 'undefined' && typeof user.registerUser === 'function') {
            await user.registerUser(signupData);
        } else {
            closeLoginModal();
            showModalMessage('تعذر إنشاء الحساب: تحقق من اتصالك بالإنترنت وأعد تحميل الصفحة');
            return;
        }
        closeLoginModal();

        document.getElementById('loginPhone').value = signupData.phone;
        document.getElementById('loginPassword').value = signupData.password;

        clearSignupFields();

        showSuccessModal('تم إنشاء الحساب بنجاح!');

        setTimeout(() => {
            uiShowLoginView();
            uiGoToStep1();
            typingStarted = false;
        }, 2000);
    } catch (err) {
        closeLoginModal();
        showModalMessage((err && err.message) ? err.message : 'تعذر إنشاء الحساب، حاول مرة أخرى');
    }
}

function clearSignupFields() {
    const fields = [
        'firstName', 'fatherName', 'grandfatherName', 'lastName',
        'address', 'signupPhone', 'signupPassword',
        'confirmPassword', 'referralCode'
    ];
    fields.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });

    ['birthDay', 'birthMonth', 'birthYear'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.selectedIndex = 0;
    });

    const fills = [
        document.getElementById('strengthFill1'),
        document.getElementById('strengthFill2'),
        document.getElementById('strengthFill3')
    ];
    fills.forEach(f => { if (f) f.style.width = '0%'; });
    const label = document.getElementById('strengthLabel');
    if (label) {
        label.textContent = '—';
        label.style.color = 'var(--text-muted)';
    }
    const shield = document.getElementById('strengthShield');
    if (shield) shield.style.color = 'var(--text-muted)';

    document.querySelectorAll('.input-wrapper.error').forEach(w => w.classList.remove('error'));
    document.querySelectorAll('.error-msg.visible').forEach(e => e.classList.remove('visible'));
    const subText = document.getElementById('signupSubText');
    if (subText) subText.textContent = '';
}

// ============================================================
// onLoginClick — تسجيل الدخول (يستدعي auth.loginUser)
// ============================================================
async function onLoginClick() {
    const phone = document.getElementById('loginPhone');
    const phoneWrapper = document.getElementById('loginPhoneWrapper');
    const phoneError = document.getElementById('loginPhoneError');
    const password = document.getElementById('loginPassword');
    const passwordWrapper = document.getElementById('loginPasswordWrapper');
    const passwordError = document.getElementById('loginPasswordError');

    if (phoneWrapper) phoneWrapper.classList.remove('error');
    if (passwordWrapper) passwordWrapper.classList.remove('error');
    if (phoneError) phoneError.classList.remove('visible');
    if (passwordError) passwordError.classList.remove('visible');

    let isValid = true;
    const phoneDigits = phone ? phone.value.replace(/[^0-9]/g, '') : '';

    if (phoneDigits !== '999') {
        if (!phoneDigits || phoneDigits.length !== 9) {
            if (phoneWrapper) phoneWrapper.classList.add('error');
            if (phoneError) {
                phoneError.textContent = 'رقم الجوال يجب أن يكون 9 أرقام';
                phoneError.classList.add('visible');
            }
            isValid = false;
        }
    }

    if (!password || !password.value.trim()) {
        if (passwordWrapper) passwordWrapper.classList.add('error');
        if (passwordError) passwordError.classList.add('visible');
        isValid = false;
    }
    if (!isValid) {
        showModalMessage('يرجى إدخال رقم الجوال وكلمة المرور بشكل صحيح');
        return;
    }

    showLoadingModal('جاري التحقق من البيانات...');
    try {
        await auth.loginUser(phoneDigits, password.value);
        closeLoginModal();
    } catch (err) {
        closeLoginModal();
        const msg = (err && err.message) ? err.message : 'تعذر تسجيل الدخول، تحقق من البيانات';
        if (msg.includes('غير مفعّل')) {
            Swal.fire({
                title: 'حسابك غير مفعّل',
                html: `<p style="color:var(--text-secondary);">لتفعيل حسابك، اضغط على الزر أدناه:</p>
                    <div style="display:flex;flex-direction:column;gap:10px;margin-top:15px;">
                        <a href="https://t.me/KovaCashBot?start=${phoneDigits}" target="_blank" style="display:block;background:#10b981;color:#fff;padding:12px;border-radius:40px;text-decoration:none;font-weight:700;">
                            <i class="fas fa-telegram-plane"></i> تفعيل عبر تلجرام
                        </a>
                    </div>`,
                confirmButtonText: 'حسناً',
                background: '#161b22',
                color: '#e6edf3',
                confirmButtonColor: '#1a6fa8',
                icon: 'info'
            });
        } else {
            showModalMessage(msg);
        }
    }
}

// ============================================================
// BIOMETRIC LOGIN (بصمة الجهاز)
// ============================================================
async function handleBiometricLogin() {
    // ===== تطبيق أندرويد (Capacitor) — بصمة النظام الأصلية =====
    if (typeof isNativeApp === 'function' && isNativeApp()) {
        try {
            const available = await nativeBiometricIsAvailable();
            if (!available) { showModalMessage('البصمة غير متاحة على هذا الجهاز'); return; }

            const credentials = await nativeBiometricAuthenticate();
            if (!credentials || !credentials.username || !credentials.password) {
                showModalMessage('لا توجد بصمة مسجلة لهذا الحساب');
                return;
            }

            showLoadingModal('جاري التحقق من البيانات...');
            try {
                await auth.loginUser(credentials.username, credentials.password);
                closeLoginModal();
                showAlert('تم تسجيل الدخول بالبصمة');
            } catch (err) {
                closeLoginModal();
                showModalMessage((err && err.message) ? err.message : 'تعذر تسجيل الدخول بالبصمة');
            }
        } catch (e) {
            console.error('❌ فشل البصمة الأصلية:', e);
            showModalMessage('فشل التحقق من البصمة');
        }
        return;
    }

    // ===== متصفح / PWA — WebAuthn (كما هي بدون أي تغيير) =====
    if (!window.PublicKeyCredential) {
        showModalMessage('المتصفح لا يدعم البصمة');
        return;
    }

    const storedPhone = localStorage.getItem('biometric_user_phone');
    const storedCredentialId = localStorage.getItem('biometric_credential_id');

    if (!storedPhone || !storedCredentialId) {
        showModalMessage('لا توجد بصمة مسجلة');
        return;
    }

    try {
        const credentialIdBuffer = Uint8Array.from(atob(storedCredentialId.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0)).buffer;
        const assertion = await navigator.credentials.get({
            publicKey: {
                challenge: crypto.getRandomValues(new Uint8Array(32)).buffer,
                allowCredentials: [{ id: credentialIdBuffer, type: 'public-key', transports: ['internal'] }],
                timeout: 60000,
                userVerification: 'required'
            }
        });
        if (assertion) {
            const userSnap = await database.ref('users/' + storedPhone).once('value');
            const userData = userSnap.val();
            if (userData && userData.isActivated !== false) {
                APP.user = userData;
                APP.user.phone = storedPhone;
                hideAuthContainer();
                navigateTo('userInterface', true);
                subscribeToUserData(storedPhone);
                showAlert('تم تسجيل الدخول بالبصمة');
            } else {
                showModalMessage('الحساب غير مفعل');
            }
        }
    } catch (e) {
        console.error('❌ فشل البصمة:', e);
        showModalMessage('فشل التحقق من البصمة');
    }
}

// ============================================================
// مستمع Enter في حقول تسجيل الدخول
// ============================================================
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const target = e.target;
        if (target && (target.id === 'loginPhone' || target.id === 'loginPassword')) {
            e.preventDefault();
            onLoginClick();
        }
    }
});